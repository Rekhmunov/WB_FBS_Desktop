"""Ozon FBS postings — isolated from Ozon FBO (supply-order) and WB FBS.

Uses api-seller.ozon.ru with Client-Id + Api-Key from supply_sources.

Source rule (same idea as WB FBS):
- marketplace=ozon and name contains «ФБС»/FBS, OR
- marketplace=ozon_fbs (legacy value kept for compatibility).
"""
from __future__ import annotations

import base64
import json
import logging
import re
import threading
import time
from datetime import UTC, datetime, time as dt_time, timedelta
from typing import Any, Callable, Mapping
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen
from zoneinfo import ZoneInfo

from .repository import ReviewRepository

_MSK = ZoneInfo("Europe/Moscow")

_log = logging.getLogger(__name__)

OZON_API = "https://api-seller.ozon.ru"

# ``/v4/posting/fbs/list`` rejects Limit outside (0, 100]. v3 allowed 1000;
# a 1000-page request is HTTP 400 and the status check then falls back to
# one ``/v3/posting/fbs/get`` per posting.
FBS_LIST_PAGE_LIMIT_MAX = 100

# UI tabs (portal-aligned)
TAB_AWAITING_PACKAGING = "awaiting_packaging"
TAB_AWAITING_DELIVER = "awaiting_deliver"
TAB_DELIVERING = "delivering"
TAB_ARBITRATION = "arbitration"
TAB_DELIVERED = "delivered"
TAB_CANCELLED = "cancelled"

TAB_LABELS: dict[str, str] = {
    TAB_AWAITING_PACKAGING: "Ожидают сборки",
    TAB_AWAITING_DELIVER: "Ожидают отгрузки",
    TAB_DELIVERING: "Доставляются",
    TAB_ARBITRATION: "Спорные",
    TAB_DELIVERED: "Доставлены",
    TAB_CANCELLED: "Отменены",
}

ALL_TABS = tuple(TAB_LABELS.keys())

_ARBITRATION_STATUSES = frozenset({"arbitration", "client_arbitration"})

SYNC_STATUSES = [
    "awaiting_packaging",
    "awaiting_deliver",
    "delivering",
    "arbitration",
    "client_arbitration",
    "delivered",
    "cancelled",
]

DEFAULT_LOOKBACK_DAYS = 3

_ozon_fbs_sync_lock = threading.Lock()
_ozon_fbs_sync_state: dict[str, object] = {
    "in_progress": False,
    "synced": 0,
    "total": 0,
    "message": "",
    "errors": [],
    "sources": [],
    "pallet_summary": [],
    "pallet_summary_error": "",
    "multi_summary": [],
    "cancel_requested": False,
}

_PALLET_SUMMARY_ERROR = (
    "Не удалось рассчитать паллеты после синхронизации. "
    "Проверьте кратность короба и категории товаров (Настройки → Товары)."
)


def is_fbs_source_name(name: object) -> bool:
    """True when supply source name is meant for FBS (contains ФБС/FBS)."""
    text = str(name or "").strip().lower()
    return "фбс" in text or "fbs" in text


def is_ozon_fbs_marketplace(marketplace: object) -> bool:
    """Legacy marketplace value used before name-based FBS detection."""
    return str(marketplace or "").strip().lower() == "ozon_fbs"


def is_ozon_fbs_source(source: Mapping[str, Any] | None) -> bool:
    """True for Ozon FBS cabinets.

    Name marker «ФБС»/FBS is the primary signal (same as before cabinet-id work);
    then marketplace=ozon_fbs or stored channel.
    """
    if not source:
        return False
    mp = str(source.get("marketplace") or "").strip().lower()
    if mp not in ("ozon", "ozon_fbs", "ozon_fbo"):
        return False
    if is_fbs_source_name(source.get("name")):
        return True
    if mp == "ozon_fbs":
        return True
    from . import supply_source_identity as supply_identity

    return supply_identity.source_is_fbs(source)


def is_ozon_fbo_source(source: Mapping[str, Any] | None) -> bool:
    """True for Ozon FBO cabinets.

    Name marker «ФБС»/FBS excludes from FBO; otherwise channel / marketplace.
    """
    if not source:
        return False
    mp = str(source.get("marketplace") or "").strip().lower()
    if mp not in ("ozon", "ozon_fbo"):
        return False
    if mp == "ozon_fbs" or is_fbs_source_name(source.get("name")):
        return False
    from . import supply_source_identity as supply_identity

    return supply_identity.source_is_fbo(source)


def compute_tab(status: object) -> str:
    s = str(status or "").strip().lower()
    if s in _ARBITRATION_STATUSES:
        return TAB_ARBITRATION
    if s == TAB_AWAITING_PACKAGING:
        return TAB_AWAITING_PACKAGING
    if s == TAB_AWAITING_DELIVER:
        return TAB_AWAITING_DELIVER
    if s == TAB_DELIVERING:
        return TAB_DELIVERING
    if s == TAB_DELIVERED:
        return TAB_DELIVERED
    if s == TAB_CANCELLED:
        return TAB_CANCELLED
    return TAB_AWAITING_PACKAGING


# Operational pipeline only (not cancelled / arbitration).
_PIPELINE_STATUS_RANK: dict[str, int] = {
    TAB_AWAITING_PACKAGING: 10,
    TAB_AWAITING_DELIVER: 20,
    TAB_DELIVERING: 30,
    TAB_DELIVERED: 40,
}


def pipeline_status_rank(*, status: object = "", tab: object = "") -> int | None:
    """Rank for packaging→deliver→delivering→delivered. None = non-pipeline."""
    if is_cancelled_posting(status=status, tab=tab):
        return None
    t = str(tab or "").strip().lower()
    if not t:
        t = compute_tab(status)
    if t == TAB_ARBITRATION or str(status or "").strip().lower() in _ARBITRATION_STATUSES:
        return None
    return _PIPELINE_STATUS_RANK.get(t)


def resolve_upsert_status(
    *,
    local_status: object = "",
    local_tab: object = "",
    remote_status: object = "",
) -> tuple[str, str]:
    """Pick status/tab for upsert; never regress packaging←deliver mid-sync race.

    Concurrent sync can still hold an ``awaiting_packaging`` page fetched before
    ship; applying it after local ship would bounce rows back to «Ожидают сборки».
    Cancelled / arbitration from Ozon always win.
    """
    new_status = str(remote_status or "").strip().lower()
    new_tab = compute_tab(new_status)
    if is_cancelled_posting(status=new_status, tab=new_tab):
        return new_status or TAB_CANCELLED, TAB_CANCELLED
    if new_tab == TAB_ARBITRATION or new_status in _ARBITRATION_STATUSES:
        return new_status or TAB_ARBITRATION, TAB_ARBITRATION

    old_status = str(local_status or "").strip().lower()
    old_tab = str(local_tab or "").strip().lower() or compute_tab(old_status)
    old_rank = pipeline_status_rank(status=old_status, tab=old_tab)
    new_rank = pipeline_status_rank(status=new_status, tab=new_tab)
    if (
        old_rank is not None
        and new_rank is not None
        and new_rank < old_rank
    ):
        return old_status or old_tab, old_tab
    return new_status, new_tab


_CANCELLED_STATUSES = frozenset(
    {
        TAB_CANCELLED,
        "cancelled_from_split_pending",
    }
)

_CANCEL_REASON_ID_LABELS: dict[int, str] = {
    352: "Товара нет в наличии",
    400: "Остался только бракованный товар",
    401: "Отмена из арбитража",
    402: "Другая причина",
    665: "Покупатель не забрал заказ",
    666: "Нет доставки в регион",
    667: "Заказ утерян службой доставки",
}

_CANCELLATION_TYPE_LABELS: dict[str, str] = {
    "client": "Отмена покупателем",
    "seller": "Отмена продавцом",
    "ozon": "Отмена Ozon",
    "customer": "Отмена покупателем",
    "buyer": "Отмена покупателем",
}


def is_cancelled_posting(*, status: object = "", tab: object = "") -> bool:
    s = str(status or "").strip().lower()
    t = str(tab or "").strip().lower()
    if t == TAB_CANCELLED:
        return True
    return s in _CANCELLED_STATUSES


# Tabs where badge counts must exclude cancelled postings (warehouse workload).
OPERATIONAL_COUNT_TABS = frozenset(
    {
        TAB_AWAITING_PACKAGING,
        TAB_AWAITING_DELIVER,
        TAB_DELIVERING,
    }
)


def sql_exclude_cancelled_postings_clause(*, prefix: str = "") -> str:
    """SQL fragment: row is not cancelled (status/tab)."""
    p = f"{prefix}." if prefix else ""
    statuses = ", ".join(f"'{s}'" for s in sorted(_CANCELLED_STATUSES))
    return (
        f"LOWER(COALESCE({p}tab, '')) <> '{TAB_CANCELLED}' "
        f"AND LOWER(COALESCE({p}status, '')) NOT IN ({statuses})"
    )


def posting_row_is_cancelled(row: dict[str, Any]) -> bool:
    """True when a posting dict/DB row represents a cancelled shipment."""
    if not isinstance(row, dict):
        return False
    if row.get("cancelled"):
        return True
    if is_cancelled_posting(status=row.get("status"), tab=row.get("tab")):
        return True
    return bool(cancel_reason_label_from_row(row))


def cancel_reason_label_from_posting(posting: dict[str, Any]) -> str:
    """Human-readable cancel reason from Ozon posting payload."""
    if not isinstance(posting, dict):
        return ""
    status = str(posting.get("status") or "").strip().lower()
    if not is_cancelled_posting(status=status, tab=compute_tab(status)):
        return ""
    cancellation = posting.get("cancellation")
    if isinstance(cancellation, dict):
        for key in ("cancel_reason", "cancel_reason_message", "reason"):
            text = str(cancellation.get(key) or "").strip()
            if text:
                return text
        try:
            rid = int(cancellation.get("cancel_reason_id") or 0)
        except (TypeError, ValueError):
            rid = 0
        if rid in _CANCEL_REASON_ID_LABELS:
            return _CANCEL_REASON_ID_LABELS[rid]
        ctype = str(
            cancellation.get("cancellation_type")
            or cancellation.get("cancel_type")
            or ""
        ).strip().lower()
        if ctype in _CANCELLATION_TYPE_LABELS:
            return _CANCELLATION_TYPE_LABELS[ctype]
    if status == "cancelled_from_split_pending":
        return "Отменено при разделении"
    return "Отменено"


def cancel_reason_label_from_row(row: dict[str, Any]) -> str:
    """Cancel label from local DB row (status/tab + optional raw_json)."""
    if not isinstance(row, dict):
        return ""
    status = str(row.get("status") or "").strip().lower()
    tab = str(row.get("tab") or "").strip().lower()
    if not is_cancelled_posting(status=status, tab=tab):
        return ""
    raw_text = str(row.get("raw_json") or "").strip()
    if raw_text:
        try:
            raw = json.loads(raw_text)
        except json.JSONDecodeError:
            raw = None
        if isinstance(raw, dict):
            label = cancel_reason_label_from_posting(raw)
            if label:
                return label
    return "Отменено"


def _utc_now() -> str:
    return datetime.now(UTC).isoformat()


def _iso_z(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%S.000Z")


class OzonFbsClient:
    # Ozon may return 429 when the Client-Id budget is exhausted; retry a few times
    # honouring Retry-After (see ozon_fbs_rate_limit).
    _MAX_429_RETRIES = 4

    def __init__(self, client_id: str, api_key: str, timeout: int = 45) -> None:
        self.client_id = str(client_id or "").strip()
        self.api_key = str(api_key or "").strip()
        self.timeout = timeout

    def _headers(self) -> dict[str, str]:
        return {
            "Client-Id": self.client_id,
            "Api-Key": self.api_key,
            "Content-Type": "application/json",
            "User-Agent": "FeedPilot-OzonFBS/1.0",
        }

    def _post_raw(self, path: str, body: dict[str, Any]) -> bytes:
        """POST with per-Client-Id pacing and Retry-After-aware 429 retries."""
        from . import ozon_fbs_rate_limit as rl

        url = f"{OZON_API}{path}"
        payload = json.dumps(body).encode("utf-8")
        last_err: Exception | None = None
        for attempt in range(self._MAX_429_RETRIES + 1):
            rl.acquire_client_slot(self.client_id)
            req = Request(url, data=payload, method="POST", headers=self._headers())
            try:
                with urlopen(req, timeout=self.timeout) as resp:
                    return resp.read()
            except HTTPError as exc:
                err_body = exc.read().decode("utf-8", errors="replace")
                if int(exc.code) == 429 and attempt < self._MAX_429_RETRIES:
                    wait = rl.backoff_seconds_for_429(
                        attempt=attempt,
                        retry_after=rl.parse_retry_after_seconds(
                            getattr(exc, "headers", None)
                        ),
                    )
                    # Pause the whole Client-Id bucket so parallel workers do not
                    # keep hammering while we back off.
                    rl.limiter_for_client(self.client_id).pause_for(wait)
                    _log.warning(
                        "ozon HTTP 429 path=%s attempt=%s sleep=%.2fs body=%s",
                        path,
                        attempt + 1,
                        wait,
                        (err_body or "")[:240],
                    )
                    time.sleep(wait)
                    last_err = RuntimeError(
                        f"Ozon HTTP 429: {err_body or exc.reason}"
                    )
                    continue
                raise RuntimeError(
                    f"Ozon HTTP {exc.code}: {err_body or exc.reason}"
                ) from exc
            except URLError as exc:
                raise RuntimeError(f"Ozon network error: {exc.reason}") from exc
        if last_err is not None:
            raise last_err
        raise RuntimeError(f"Ozon HTTP 429: rate limit exceeded for {path}")

    def post_json(self, path: str, body: dict[str, Any]) -> dict[str, Any]:
        raw = self._post_raw(path, body)
        try:
            data = json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise RuntimeError("Ozon API returned non-JSON response") from exc
        if not isinstance(data, dict):
            raise RuntimeError("Ozon API response must be a JSON object")
        return data

    def post_bytes(self, path: str, body: dict[str, Any]) -> bytes:
        return self._post_raw(path, body)

    def list_postings_page(
        self,
        *,
        status: str,
        since: datetime,
        to: datetime,
        limit: int = 50,
        cursor: str = "",
        with_extras: bool = True,
    ) -> tuple[list[dict[str, Any]], bool, str]:
        """One page of FBS postings via ``/v4/posting/fbs/list``.

        ``/v3/posting/fbs/list`` answers HTTP 429 with a zero per-second budget.
        v4 returns ``postings`` at the top level and continues with ``cursor``.
        Status goes in ``filter.statuses``; ``filter.status`` is ignored and
        would return the whole window. ``with_extras=False`` skips heavy
        nested payloads (status-check scan only needs ``posting_number`` and
        ``status``).
        """
        extras = bool(with_extras)
        # v4 reads ``filter.statuses`` (array). The v3 field ``filter.status``
        # is ignored, so a string there returns every posting in the window
        # and the progress line still names the requested status.
        body: dict[str, Any] = {
            "dir": "ASC",
            "filter": {
                "since": _iso_z(since),
                "to": _iso_z(to),
                "statuses": [str(status or "").strip()],
            },
            "limit": min(max(int(limit), 1), FBS_LIST_PAGE_LIMIT_MAX),
            "with": {
                "analytics_data": extras,
                "barcodes": extras,
                "financial_data": extras,
                "translit": extras,
            },
        }
        cur = str(cursor or "").strip()
        if cur:
            body["cursor"] = cur
        data = self.post_json("/v4/posting/fbs/list", body)
        # v4 payload is top-level. Keep the old ``result`` shape readable so a
        # stubbed response does not look like an empty page.
        if isinstance(data.get("postings"), list) or "cursor" in data:
            payload: dict[str, Any] = data
        elif isinstance(data.get("result"), dict):
            payload = data["result"]
        else:
            payload = data
        raw_postings = payload.get("postings")
        postings = raw_postings if isinstance(raw_postings, list) else []
        has_next = bool(payload.get("has_next"))
        next_cursor = str(payload.get("cursor") or "").strip() if has_next else ""
        clean = [p for p in postings if isinstance(p, dict)]
        return clean, has_next, next_cursor

    def get_posting(self, posting_number: str) -> dict[str, Any]:
        data = self.post_json(
            "/v3/posting/fbs/get",
            {
                "posting_number": str(posting_number),
                "with": {
                    "analytics_data": True,
                    "barcodes": True,
                    "financial_data": True,
                    "translit": True,
                },
            },
        )
        result = data.get("result")
        if not isinstance(result, dict):
            raise RuntimeError("Ozon get posting: empty result")
        return result

    def ship_posting(self, posting_number: str, packages: list[dict[str, Any]]) -> dict[str, Any]:
        return self.post_json(
            "/v4/posting/fbs/ship",
            {"posting_number": str(posting_number), "packages": packages},
        )

    def split_posting(
        self, posting_number: str, postings: list[dict[str, Any]]
    ) -> dict[str, Any]:
        """Split into separate postings without assembling (``/v1/posting/fbs/split``)."""
        return self.post_json(
            "/v1/posting/fbs/split",
            {
                "posting_number": str(posting_number),
                "postings": postings,
            },
        )

    def package_label_pdf(self, posting_numbers: list[str]) -> bytes:
        return self.post_bytes(
            "/v2/posting/fbs/package-label",
            {"posting_number": [str(p) for p in posting_numbers if str(p).strip()]},
        )

    def package_label_create_v3(self, posting_numbers: list[str]) -> list[dict[str, Any]]:
        """POST /v3/posting/fbs/package-label/create — async labels, ≤1000 numbers."""
        nums = [str(p).strip() for p in posting_numbers if str(p).strip()]
        if not nums:
            raise RuntimeError("Не указаны отправления для печати")
        if len(nums) > PACKAGE_LABEL_CREATE_V3_MAX:
            raise RuntimeError(
                f"Ozon принимает не больше {PACKAGE_LABEL_CREATE_V3_MAX} "
                "отправлений за одно задание на этикетки"
            )
        data = self.post_json(
            "/v3/posting/fbs/package-label/create",
            {"posting_numbers": nums},
        )
        tasks = parse_package_label_create_tasks(data)
        if not tasks:
            raise RuntimeError("Ozon не вернул задание на формирование этикеток")
        return tasks

    def package_label_get_v2(self, task_id: int | str) -> dict[str, Any]:
        """POST /v2/posting/fbs/package-label/get — status / file_url for a create task."""
        try:
            tid = int(str(task_id).strip())
        except (TypeError, ValueError) as exc:
            raise RuntimeError("Некорректный task_id задания этикеток Ozon") from exc
        data = self.post_json(
            "/v2/posting/fbs/package-label/get",
            {"task_id": tid},
        )
        return parse_package_label_get_result(data)

    def download_package_label_file(self, file_url: str) -> bytes:
        """GET the PDF from Ozon ``file_url`` (https, ozon hosts only)."""
        url = str(file_url or "").strip()
        if not url:
            raise RuntimeError("Ozon не вернул ссылку на файл этикеток")
        parsed = urlparse(url)
        if parsed.scheme != "https":
            raise RuntimeError("Ссылка на этикетки Ozon должна быть https")
        host = str(parsed.hostname or "").strip().lower()
        if not _is_ozon_label_file_host(host):
            raise RuntimeError(f"Неожиданный хост файла этикеток Ozon: {host or '—'}")
        req = Request(
            url,
            method="GET",
            headers={
                "User-Agent": "FeedPilot-OzonFBS/1.0",
                "Accept": "application/pdf,*/*",
            },
        )
        try:
            with urlopen(req, timeout=max(int(self.timeout), 60)) as resp:
                raw = resp.read()
        except HTTPError as exc:
            err_body = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(
                f"Ozon HTTP {exc.code} при скачивании этикеток: {err_body or exc.reason}"
            ) from exc
        except URLError as exc:
            raise RuntimeError(
                f"Ozon network error при скачивании этикеток: {exc.reason}"
            ) from exc
        if not raw:
            raise RuntimeError("Ozon вернул пустой файл этикеток")
        return raw

    def poll_package_label_task(
        self,
        task_id: int | str,
        *,
        timeout_sec: float = 180.0,
        interval_sec: float = 1.5,
        sleep: Callable[[float], None] | None = None,
    ) -> dict[str, Any]:
        """Poll ``package-label/get`` until ``file_url`` is ready or the task fails."""
        sleeper = time.sleep if sleep is None else sleep
        deadline = time.monotonic() + max(float(timeout_sec), 5.0)
        interval = max(float(interval_sec), 0.2)
        last: dict[str, Any] = {}
        while True:
            last = self.package_label_get_v2(task_id)
            if package_label_task_is_failed(last):
                raise RuntimeError(package_label_task_error_text(last))
            if package_label_task_is_ready(last):
                return last
            if time.monotonic() >= deadline:
                raise RuntimeError(
                    "Таймаут ожидания этикеток Ozon. "
                    "Повторите печать через минуту."
                )
            sleeper(interval)

    def fetch_async_package_label_pdf(
        self,
        posting_numbers: list[str],
        *,
        sleep: Callable[[float], None] | None = None,
        timeout_sec: float = 180.0,
    ) -> tuple[bytes, dict[str, Any]]:
        """Create v3 task, wait for v2 get, download PDF. Does not call sync v2 package-label."""
        tasks = self.package_label_create_v3(posting_numbers)
        task = select_small_label_task(tasks)
        data = self.poll_package_label_task(
            task["task_id"],
            timeout_sec=timeout_sec,
            sleep=sleep,
        )
        url = str(data.get("file_url") or "").strip()
        pdf = self.download_package_label_file(url)
        return pdf, data

    def delivery_method_list(
        self,
        *,
        warehouse_id: int | None = None,
        status: str = "ACTIVE",
        limit: int = 50,
        offset: int = 0,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """POST /v2/delivery-method/list — filter.warehouse_ids + cursor pagination."""
        del offset  # v2 uses cursor, not offset.
        filt: dict[str, Any] = {}
        if warehouse_id is not None:
            filt["warehouse_ids"] = [str(int(warehouse_id))]
        st = str(status or "").strip().upper()
        if st:
            filt["status"] = [st]
        body: dict[str, Any] = {
            "filter": filt,
            "limit": min(max(int(limit), 1), 100),
        }
        cur = str(cursor or "").strip()
        if cur:
            body["cursor"] = cur
        return self.post_json("/v2/delivery-method/list", body)

    def carriage_delivery_list(
        self,
        *,
        delivery_method_id: int,
        departure_date: str,
        limit: int = 100,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """POST /v2/carriage/delivery/list — body uses ``filter`` + ``limit``/``cursor``."""
        dep = str(departure_date or "").strip()
        if "T" in dep:
            dep = dep.split("T", 1)[0]
        body: dict[str, Any] = {
            "limit": min(max(int(limit), 1), 1000),
            "filter": {
                "delivery_method_id": int(delivery_method_id),
                "departure_date": dep,
            },
        }
        cur = str(cursor or "").strip()
        if cur:
            body["cursor"] = cur
        return self.post_json("/v2/carriage/delivery/list", body)

    def carriage_get(self, *, carriage_id: int) -> dict[str, Any]:
        """POST /v1/carriage/get — authoritative carriage status (list can lag)."""
        return self.post_json(
            "/v1/carriage/get", {"carriage_id": int(carriage_id)}
        )

    def fbs_act_create(
        self,
        *,
        delivery_method_id: int,
        departure_date: str | None = None,
        containers_count: int | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"delivery_method_id": int(delivery_method_id)}
        if departure_date:
            body["departure_date"] = str(departure_date)
        if containers_count is not None:
            body["containers_count"] = int(containers_count)
        return self.post_json("/v2/posting/fbs/act/create", body)

    def fbs_act_check_status(self, *, act_id: int) -> dict[str, Any]:
        return self.post_json("/v2/posting/fbs/act/check-status", {"id": int(act_id)})

    def fbs_act_get_barcode(self, *, carriage_id: int) -> dict[str, Any]:
        raw = self.post_bytes(
            "/v2/posting/fbs/act/get-barcode", {"id": int(carriage_id)}
        )
        try:
            data = json.loads(raw.decode("utf-8"))
            if isinstance(data, dict):
                return data
        except (UnicodeDecodeError, json.JSONDecodeError):
            pass
        return {
            "file_content": base64.b64encode(raw).decode("ascii"),
            "content_type": "image/png",
        }

    def fbs_act_get_barcode_text(self, *, carriage_id: int) -> dict[str, Any]:
        return self.post_json(
            "/v2/posting/fbs/act/get-barcode/text", {"id": int(carriage_id)}
        )

    def carriage_container_list(self, body: dict[str, Any]) -> dict[str, Any]:
        """POST /v1/carriage/container/list — грузоместа склада."""
        return self.post_json("/v1/carriage/container/list", body)

    def carriage_container_create(
        self,
        *,
        warehouse_id: int,
        containers_count: int,
        sort_type: str,
        cargo_type: str,
    ) -> dict[str, Any]:
        """POST /v1/carriage/container/create."""
        return self.post_json(
            "/v1/carriage/container/create",
            {
                "warehouse_id": int(warehouse_id),
                "containers_count": int(containers_count),
                "sort_type": str(sort_type),
                "cargo_type": str(cargo_type),
            },
        )

    def carriage_container_get(self, *, container_id: int) -> dict[str, Any]:
        return self.post_json(
            "/v1/carriage/container/get", {"container_id": int(container_id)}
        )

    def carriage_container_cancel(self, *, container_ids: list[int]) -> dict[str, Any]:
        """POST /v1/carriage/container/cancel — удаление грузомест."""
        return self.post_json(
            "/v1/carriage/container/cancel",
            {"container_ids": [int(x) for x in container_ids]},
        )

    def carriage_container_approve(self, *, container_ids: list[int]) -> dict[str, Any]:
        """POST /v1/carriage/container/approve — подтвердить состав грузоместа."""
        return self.post_json(
            "/v1/carriage/container/approve",
            {"container_ids": [int(x) for x in container_ids]},
        )

    def carriage_container_task_info(self, *, task_id: int) -> dict[str, Any]:
        """POST /v1/carriage/container/task/info — статус async-задачи fill/approve."""
        return self.post_json(
            "/v1/carriage/container/task/info",
            {"task_id": int(task_id)},
        )

    def carriage_container_fill(
        self, *, container_id: int, posting_numbers: list[str]
    ) -> dict[str, Any]:
        return self.post_json(
            "/v1/carriage/container/fill",
            {
                "container_id": int(container_id),
                "posting_numbers": list(posting_numbers),
            },
        )

    def carriage_container_remove_postings(
        self, *, container_id: int, posting_numbers: list[str]
    ) -> dict[str, Any]:
        return self.post_json(
            "/v1/carriage/container/remove-postings",
            {
                "container_id": int(container_id),
                "posting_numbers": list(posting_numbers),
            },
        )

    def carriage_container_label_get(self, *, container_ids: list[int]) -> dict[str, Any]:
        """POST /v1/carriage/container/label/get — PDF этикеток."""
        return self.post_json(
            "/v1/carriage/container/label/get",
            {"container_ids": [int(x) for x in container_ids]},
        )

    def product_exemplar_create_or_get(
        self, posting_number: str, products: list[dict[str, Any]]
    ) -> dict[str, Any]:
        return self.post_json(
            "/v6/fbs/posting/product/exemplar/create-or-get",
            {
                "posting_number": str(posting_number),
                "products": products,
            },
        )

    def product_exemplar_set(
        self,
        posting_number: str,
        *,
        multi_box_qty: int = 1,
        products: list[dict[str, Any]],
    ) -> dict[str, Any]:
        return self.post_json(
            "/v6/fbs/posting/product/exemplar/set",
            {
                "posting_number": str(posting_number),
                "multi_box_qty": max(int(multi_box_qty), 1),
                "products": products,
            },
        )

    def product_exemplar_validate(
        self, posting_number: str, products: list[dict[str, Any]]
    ) -> dict[str, Any]:
        return self.post_json(
            "/v5/fbs/posting/product/exemplar/validate",
            {
                "posting_number": str(posting_number),
                "products": products,
            },
        )

    def product_exemplar_status(self, posting_number: str) -> dict[str, Any]:
        return self.post_json(
            "/v5/fbs/posting/product/exemplar/status",
            {"posting_number": str(posting_number)},
        )

    def product_exemplar_create_or_get_v5(
        self, posting_number: str, products: list[dict[str, Any]]
    ) -> dict[str, Any]:
        return self.post_json(
            "/v5/fbs/posting/product/exemplar/create-or-get",
            {
                "posting_number": str(posting_number),
                "products": products,
            },
        )

    def mandatory_mark_is_required(
        self, posting_number: str, skus: list[int]
    ) -> list[dict[str, Any]]:
        """POST /v2/posting/fbs/product/mandatory-mark/is-required per SKU."""
        clean = []
        for sku in skus:
            try:
                clean.append(int(sku))
            except (TypeError, ValueError):
                continue
        if not clean:
            return []
        data = self.post_json(
            "/v2/posting/fbs/product/mandatory-mark/is-required",
            {
                "posting_number": str(posting_number),
                "sku": clean,
            },
        )
        result = data.get("result")
        if isinstance(result, list):
            return [x for x in result if isinstance(x, dict)]
        return []


# FBS posting ``status`` values from Seller API (/v3/posting/fbs/*).
# Container (грузоместо) statuses live in ozon_fbs_containers.status_label —
# do not reuse those wording here (e.g. acceptance_in_progress ≠ «Принято на СЦ»).
_OZON_LABEL_STATUS_RU: dict[str, str] = {
    # Working tabs (our product wording).
    TAB_AWAITING_PACKAGING: "Ожидает сборки",
    TAB_AWAITING_DELIVER: "Ожидает отгрузки",
    TAB_DELIVERING: "Доставляется",
    TAB_DELIVERED: "Доставлено",
    TAB_CANCELLED: "Отменено",
    TAB_ARBITRATION: "Арбитраж",
    # Early / registration lifecycle.
    "awaiting_registration": "Ожидает регистрации",
    "acceptance_in_progress": "Идёт приёмка",
    "awaiting_approve": "Ожидает подтверждения",
    # Official aliases / adjacent statuses.
    "awaiting_packaging": "Ожидает сборки",
    "awaiting_deliver": "Ожидает отгрузки",
    "client_arbitration": "Клиентский арбитраж",
    "driver_pickup": "У водителя",
    "not_accepted": "Не принято на СЦ",
    "sent_by_seller": "Отправлено продавцом",
    "cancelled_from_split_pending": "Отменено (разделение)",
}


def ozon_status_label_ru(status: object) -> str:
    st = str(status or "").strip().lower()
    if not st:
        return "неизвестен"
    return _OZON_LABEL_STATUS_RU.get(st, st)


PACKAGE_LABEL_CREATE_V3_MAX = 1000
_PACKAGE_LABEL_TASK_FAIL_CODES = frozenset(
    {"error", "failed", "fail", "cancelled", "canceled"}
)
_PACKAGE_LABEL_FILE_HOST_EXACT = frozenset(
    {"ozon.ru", "ozone.ru", "ozonusercontent.com", "yandexcloud.net"}
)
_PACKAGE_LABEL_FILE_HOST_SUFFIXES = (
    ".ozon.ru",
    ".ozone.ru",
    ".ozonusercontent.com",
    ".yandexcloud.net",
)


def _is_ozon_label_file_host(host: str) -> bool:
    h = str(host or "").strip().lower().rstrip(".")
    if not h:
        return False
    if h in _PACKAGE_LABEL_FILE_HOST_EXACT:
        return True
    return any(h.endswith(suf) for suf in _PACKAGE_LABEL_FILE_HOST_SUFFIXES)


def parse_package_label_create_tasks(data: Mapping[str, Any] | None) -> list[dict[str, Any]]:
    """Normalize v3 create response (no ``result`` wrapper; tolerate wrapped/old shapes)."""
    if not isinstance(data, Mapping):
        return []
    raw_tasks = data.get("tasks")
    if not isinstance(raw_tasks, list):
        nested = data.get("result")
        if isinstance(nested, Mapping):
            raw_tasks = nested.get("tasks")
            if not isinstance(raw_tasks, list):
                # Old v2 create: result.task_id
                tid = nested.get("task_id") or nested.get("taskId")
                if tid is not None:
                    raw_tasks = [nested]
        elif isinstance(nested, list):
            raw_tasks = nested
    if not isinstance(raw_tasks, list):
        tid = data.get("task_id") or data.get("taskId")
        if tid is not None:
            raw_tasks = [data]
        else:
            return []
    out: list[dict[str, Any]] = []
    for item in raw_tasks:
        if not isinstance(item, Mapping):
            continue
        tid = item.get("task_id")
        if tid is None:
            tid = item.get("taskId")
        if tid is None:
            continue
        try:
            task_id = int(str(tid).strip())
        except (TypeError, ValueError):
            continue
        task_type = str(
            item.get("task_type") or item.get("taskType") or ""
        ).strip().lower()
        out.append({"task_id": task_id, "task_type": task_type})
    return out


def select_small_label_task(tasks: list[Mapping[str, Any]]) -> dict[str, Any]:
    """Prefer 58×40 ``small_label`` when Ozon returns both sizes."""
    clean = [dict(t) for t in tasks if isinstance(t, Mapping) and t.get("task_id") is not None]
    if not clean:
        raise RuntimeError("Ozon не вернул задание на формирование этикеток")
    for t in clean:
        tt = str(t.get("task_type") or "").strip().lower()
        if tt in ("small_label", "small"):
            return {"task_id": int(t["task_id"]), "task_type": tt}
    first = clean[0]
    return {
        "task_id": int(first["task_id"]),
        "task_type": str(first.get("task_type") or "").strip().lower(),
    }


def parse_package_label_get_result(data: Mapping[str, Any] | None) -> dict[str, Any]:
    """Normalize v2 get response (no ``result`` wrapper; tolerate wrapped shapes)."""
    if not isinstance(data, Mapping):
        return {}
    src: Mapping[str, Any] = data
    nested = data.get("result")
    if isinstance(nested, Mapping) and not (
        data.get("file_url") or data.get("fileUrl") or data.get("status")
    ):
        src = nested
    file_url = str(src.get("file_url") or src.get("fileUrl") or src.get("file") or "").strip()
    status = src.get("status") if isinstance(src.get("status"), Mapping) else {}
    error = src.get("error") if isinstance(src.get("error"), Mapping) else {}
    unprinted_raw = status.get("unprinted_postings") if isinstance(status, Mapping) else None
    if not isinstance(unprinted_raw, list):
        unprinted_raw = src.get("unprinted_postings")
    unprinted: list[dict[str, str]] = []
    if isinstance(unprinted_raw, list):
        for item in unprinted_raw:
            if isinstance(item, Mapping):
                pn = str(item.get("posting_number") or item.get("postingNumber") or "").strip()
                if pn:
                    unprinted.append(
                        {
                            "posting_number": pn,
                            "message": str(item.get("message") or "").strip(),
                        }
                    )
            elif str(item or "").strip():
                unprinted.append({"posting_number": str(item).strip(), "message": ""})
    return {
        "file_url": file_url,
        "status_code": str(
            (status.get("code") if isinstance(status, Mapping) else "")
            or src.get("status_code")
            or (src.get("status") if isinstance(src.get("status"), str) else "")
            or ""
        ).strip().lower(),
        "postings_count": int(status.get("postings_count") or 0) if isinstance(status, Mapping) else 0,
        "printed_postings_count": (
            int(status.get("printed_postings_count") or 0) if isinstance(status, Mapping) else 0
        ),
        "unprinted_postings": unprinted,
        "error_code": str(error.get("code") or "").strip(),
        "error_message": str(error.get("message") or "").strip(),
        "raw": dict(data),
    }


def package_label_task_error_text(data: Mapping[str, Any] | None) -> str:
    parsed = (
        data
        if isinstance(data, Mapping) and "error_message" in data
        else parse_package_label_get_result(data)
    )
    msg = str(parsed.get("error_message") or "").strip()
    code = str(parsed.get("error_code") or parsed.get("status_code") or "").strip()
    if msg:
        return format_ozon_package_label_error(RuntimeError(msg))
    if code:
        return f"Ozon не сформировал этикетки (статус {code})"
    return "Ozon не сформировал этикетки"


def package_label_task_is_failed(data: Mapping[str, Any] | None) -> bool:
    parsed = (
        data
        if isinstance(data, Mapping) and "file_url" in data
        else parse_package_label_get_result(data)
    )
    if str(parsed.get("file_url") or "").strip():
        return False
    err = str(parsed.get("error_message") or parsed.get("error_code") or "").strip()
    if err:
        return True
    return str(parsed.get("status_code") or "").strip().lower() in _PACKAGE_LABEL_TASK_FAIL_CODES


def package_label_task_is_ready(data: Mapping[str, Any] | None) -> bool:
    parsed = (
        data
        if isinstance(data, Mapping) and "file_url" in data
        else parse_package_label_get_result(data)
    )
    return bool(str(parsed.get("file_url") or "").strip()) and not package_label_task_is_failed(parsed)


def explain_package_label_status_block(*, posting_number: str, status: object) -> str:
    """Human-readable reason when Ozon will reject /v2/posting/fbs/package-label."""
    pn = str(posting_number or "").strip() or "—"
    st = str(status or "").strip().lower()
    label = ozon_status_label_ru(st)
    if st == TAB_AWAITING_PACKAGING:
        return (
            f"Отправление {pn} в статусе «{label}». "
            "Сначала соберите заказ — этикетка Ozon доступна только после "
            "перехода в «Ожидает отгрузки»."
        )
    if st in (TAB_DELIVERING, TAB_DELIVERED):
        return (
            f"Отправление {pn} уже в статусе «{label}». "
            "Ozon API выдаёт этикетку только для «Ожидает отгрузки» — "
            "повторная печать через API недоступна."
        )
    if st == TAB_CANCELLED or st in _CANCELLED_STATUSES:
        return f"Отправление {pn} отменено — этикетка недоступна."
    if st == TAB_ARBITRATION or st in _ARBITRATION_STATUSES:
        return f"Отправление {pn} в арбитраже — этикетка недоступна."
    return (
        f"Отправление {pn}: статус «{label}». "
        "Печать этикетки возможна только для «Ожидает отгрузки»."
    )


def format_ozon_package_label_error(exc: BaseException) -> str:
    """Translate raw Ozon package-label errors into operator-facing Russian text."""
    text = str(exc).strip() or "ошибка Ozon"
    low = text.casefold()
    if "invalid_argument" in low:
        return (
            "Ozon отклонил печать этикетки: она доступна только для статуса "
            "«Ожидает отгрузки». Если заказ ещё на сборке — сначала соберите его. "
            "Если уже отгружен или доставляется — Ozon больше не отдаёт этикетку через API."
        )
    if (
        "aren't ready" in low
        or "not ready" in low
        or "не готов" in low
        or "postings aren't ready" in low
    ):
        return (
            "Этикетки ещё не готовы в Ozon. "
            "Подождите 1–2 минуты после сборки и повторите печать."
        )
    return text


def ensure_single_posting_label_printable(
    client: "OzonFbsClient", posting_number: str
) -> None:
    """Raise a clear RuntimeError when Ozon status cannot yield a package label."""
    pn = str(posting_number or "").strip()
    if not pn:
        raise RuntimeError("Не указаны отправления для печати")
    try:
        remote = client.get_posting(pn)
    except Exception:
        # Network / get failures: fall through to package-label and format its error.
        return
    status = str(remote.get("status") or "").strip().lower()
    if status and status != TAB_AWAITING_DELIVER:
        raise RuntimeError(
            explain_package_label_status_block(posting_number=pn, status=status)
        )


_OZON_LABEL_BATCH = 20


def fetch_merged_package_label_pdf(
    client: OzonFbsClient, posting_numbers: list[str]
) -> bytes:
    """Fetch Ozon package labels (≤20 per API call) and merge into one PDF."""
    nums = [str(p).strip() for p in posting_numbers if str(p).strip()]
    if not nums:
        raise RuntimeError("Не указаны отправления для печати")
    if len(nums) == 1:
        try:
            return client.package_label_pdf(nums)
        except Exception as exc:
            if isinstance(exc, ImportError) or "pymupdf" in str(exc).casefold():
                raise
            raise RuntimeError(format_ozon_package_label_error(exc)) from exc
    try:
        import pymupdf
    except ImportError as exc:
        raise RuntimeError(
            "Для печати стикеров Ozon нужен пакет pymupdf "
            "(pip install pymupdf). Сейчас он не установлен на сервере."
        ) from exc

    merged = pymupdf.open()
    errors: list[str] = []
    try:
        for i in range(0, len(nums), _OZON_LABEL_BATCH):
            batch = nums[i : i + _OZON_LABEL_BATCH]
            try:
                pdf_bytes = client.package_label_pdf(batch)
                src = pymupdf.open(stream=pdf_bytes, filetype="pdf")
                merged.insert_pdf(src)
                src.close()
            except Exception as exc:
                if isinstance(exc, ImportError) or "pymupdf" in str(exc).casefold():
                    raise
                for pn in batch:
                    try:
                        pdf_one = client.package_label_pdf([pn])
                        src = pymupdf.open(stream=pdf_one, filetype="pdf")
                        merged.insert_pdf(src)
                        src.close()
                    except Exception as exc_one:
                        if isinstance(exc_one, ImportError) or "pymupdf" in str(exc_one).casefold():
                            raise
                        err_text = format_ozon_package_label_error(exc_one)
                        errors.append(f"{pn}: {err_text}")
        if merged.page_count == 0:
            if errors:
                # Prefer the formatted message without the posting prefix when alone.
                first = errors[0]
                if first.startswith(f"{nums[0]}: "):
                    raise RuntimeError(first.split(": ", 1)[1])
                raise RuntimeError(first)
            raise RuntimeError(
                "Не удалось получить этикетки Ozon. "
                "Проверьте, что отправления собраны и этикетки доступны."
            )
        return merged.tobytes()
    finally:
        merged.close()


def ensure_ozon_fbs_tables(repo: ReviewRepository) -> None:
    with repo._connect() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS ozon_fbs_postings (
                id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
                user_id BIGINT NOT NULL,
                source_id BIGINT NOT NULL,
                posting_number TEXT NOT NULL,
                order_id BIGINT,
                order_number TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT '',
                tab TEXT NOT NULL DEFAULT 'awaiting_packaging',
                offer_id TEXT NOT NULL DEFAULT '',
                product_name TEXT NOT NULL DEFAULT '',
                sku BIGINT,
                quantity INTEGER NOT NULL DEFAULT 1,
                price BIGINT NOT NULL DEFAULT 0,
                warehouse_name TEXT NOT NULL DEFAULT '',
                warehouse_id BIGINT,
                barcodes_json TEXT NOT NULL DEFAULT '[]',
                products_json TEXT NOT NULL DEFAULT '[]',
                is_mandatory_mark BOOLEAN NOT NULL DEFAULT FALSE,
                created_at_ozon TIMESTAMPTZ,
                in_process_at TIMESTAMPTZ,
                raw_json TEXT NOT NULL DEFAULT '{}',
                synced_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                UNIQUE (user_id, source_id, posting_number)
            )
            """
        )
        conn.execute(
            repo._sql(
                "CREATE INDEX IF NOT EXISTS idx_ozon_fbs_postings_user_src_tab "
                "ON ozon_fbs_postings(user_id, source_id, tab, created_at_ozon DESC)"
            )
        )
        for ddl in (
            "ALTER TABLE ozon_fbs_postings ADD COLUMN IF NOT EXISTS marking_codes_json TEXT NOT NULL DEFAULT '[]'",
            "ALTER TABLE ozon_fbs_postings ADD COLUMN IF NOT EXISTS marking_saved_at TIMESTAMPTZ",
            "ALTER TABLE ozon_fbs_postings ADD COLUMN IF NOT EXISTS marking_ozon_synced BOOLEAN NOT NULL DEFAULT FALSE",
            "ALTER TABLE ozon_fbs_postings ADD COLUMN IF NOT EXISTS marking_gtd_number TEXT NOT NULL DEFAULT ''",
            "ALTER TABLE ozon_fbs_postings ADD COLUMN IF NOT EXISTS pick_verified BOOLEAN NOT NULL DEFAULT FALSE",
            "ALTER TABLE ozon_fbs_postings ADD COLUMN IF NOT EXISTS pick_barcode TEXT NOT NULL DEFAULT ''",
            "ALTER TABLE ozon_fbs_postings ADD COLUMN IF NOT EXISTS pick_verified_at TIMESTAMPTZ",
            "ALTER TABLE ozon_fbs_postings ADD COLUMN IF NOT EXISTS sticker_barcode TEXT NOT NULL DEFAULT ''",
            "ALTER TABLE ozon_fbs_postings ADD COLUMN IF NOT EXISTS sticker_lower_barcode TEXT NOT NULL DEFAULT ''",
            "ALTER TABLE ozon_fbs_postings ADD COLUMN IF NOT EXISTS sticker_scanit TEXT NOT NULL DEFAULT ''",
            "ALTER TABLE ozon_fbs_postings ADD COLUMN IF NOT EXISTS sticker_part_a TEXT NOT NULL DEFAULT ''",
            "ALTER TABLE ozon_fbs_postings ADD COLUMN IF NOT EXISTS sticker_part_b TEXT NOT NULL DEFAULT ''",
            "ALTER TABLE ozon_fbs_postings ADD COLUMN IF NOT EXISTS sticker_scanned_at TIMESTAMPTZ",
            "ALTER TABLE ozon_fbs_postings ADD COLUMN IF NOT EXISTS container_id BIGINT",
            "ALTER TABLE ozon_fbs_postings ADD COLUMN IF NOT EXISTS container_barcode TEXT NOT NULL DEFAULT ''",
            "ALTER TABLE ozon_fbs_postings ADD COLUMN IF NOT EXISTS container_synced BOOLEAN NOT NULL DEFAULT FALSE",
            "ALTER TABLE ozon_fbs_postings ADD COLUMN IF NOT EXISTS container_sync_error TEXT NOT NULL DEFAULT ''",
        ):
            try:
                conn.execute(ddl)
            except Exception:
                pass
        for idx_sql in (
            repo._sql(
                "CREATE INDEX IF NOT EXISTS idx_ozon_fbs_postings_sticker_barcode "
                "ON ozon_fbs_postings(user_id, source_id, sticker_barcode) "
                "WHERE sticker_barcode <> ''"
            ),
            repo._sql(
                "CREATE INDEX IF NOT EXISTS idx_ozon_fbs_postings_sticker_lower_barcode "
                "ON ozon_fbs_postings(user_id, source_id, sticker_lower_barcode) "
                "WHERE sticker_lower_barcode <> ''"
            ),
            repo._sql(
                "CREATE INDEX IF NOT EXISTS idx_ozon_fbs_postings_sticker_scanit "
                "ON ozon_fbs_postings(user_id, source_id, sticker_scanit) "
                "WHERE sticker_scanit <> ''"
            ),
            repo._sql(
                "CREATE INDEX IF NOT EXISTS idx_ozon_fbs_postings_sticker_part_b "
                "ON ozon_fbs_postings(user_id, source_id, sticker_part_b) "
                "WHERE sticker_part_b <> ''"
            ),
            repo._sql(
                "CREATE INDEX IF NOT EXISTS idx_ozon_fbs_postings_posting_number "
                "ON ozon_fbs_postings(user_id, source_id, posting_number)"
            ),
            repo._sql(
                "CREATE INDEX IF NOT EXISTS idx_ozon_fbs_postings_container_id "
                "ON ozon_fbs_postings(user_id, source_id, container_id) "
                "WHERE container_id IS NOT NULL"
            ),
        ):
            try:
                conn.execute(idx_sql)
            except Exception:
                pass


def sticker_parts_from_posting_number(posting_number: object) -> tuple[str, str]:
    """Split Ozon posting_number into sticker-style parts (order segment + suffix)."""
    pn = str(posting_number or "").strip()
    if not pn or "-" not in pn:
        return pn, ""
    head, tail = pn.split("-", 1)
    return str(head or "").strip(), str(tail or "").strip()


def normalize_ozon_package_barcode(value: object) -> str:
    """Return a usable Ozon package barcode, or ``""`` for empty/placeholders.

    After split Ozon may briefly return ``"0"`` (or other short digit stubs) in
    ``barcodes.upper_barcode`` / ``barcodes.lower_barcode`` before the real package QR is
    issued. Those must not be persisted as bound stickers — they block later
    ``only_if_empty`` fills and break scan matching.
    """
    raw = str(value or "").strip()
    if not raw:
        return ""
    folded = raw.casefold()
    if folded in {"0", "null", "none", "nil", "-", "n/a"}:
        return ""
    # Digit-only stubs shorter than a real Ozon package QR (≥12 digits).
    if raw.isdigit() and len(raw) < 12:
        return ""
    return raw


def ozon_package_barcode_is_blank(value: object) -> bool:
    """True when value is empty or an Ozon package-barcode placeholder."""
    return not normalize_ozon_package_barcode(value)


# New Ozon FBS instance label (scanit): unique id printed as ``ii…`` from 05.10.2026.
# Keep this independent of posting_number / package QR so old sticker match stays intact.
_OZON_SCANIT_RE = re.compile(r"^ii[A-Za-z0-9._-]{2,}$", re.IGNORECASE)


def looks_like_ozon_scanit(value: object) -> bool:
    """True for the new Ozon instance label (``ii`` + identifier), not a posting number."""
    q = re.sub(r"\s+", "", str(value or "").strip())
    return bool(_OZON_SCANIT_RE.fullmatch(q))


def normalize_ozon_scanit(value: object) -> str:
    """Return a usable Ozon ``scanit`` instance id, or ``""`` for empty/non-scanit values."""
    raw = str(value or "").strip()
    if not raw:
        return ""
    folded = raw.casefold()
    if folded in {"0", "null", "none", "nil", "-", "n/a"}:
        return ""
    if not looks_like_ozon_scanit(raw):
        return ""
    return raw


def _scanit_from_posting(posting: dict[str, Any]) -> str:
    scanit = normalize_ozon_scanit(posting.get("scanit"))
    if scanit:
        return scanit
    barcodes = posting.get("barcodes")
    if isinstance(barcodes, dict):
        return normalize_ozon_scanit(barcodes.get("scanit"))
    return ""


def sticker_fields_have_package_codes(fields: dict[str, Any] | None) -> bool:
    """True when Ozon returned a package QR and/or the new ``scanit`` instance id."""
    if not isinstance(fields, dict):
        return False
    return bool(
        str(fields.get("sticker_barcode") or "").strip()
        or str(fields.get("sticker_lower_barcode") or "").strip()
        or str(fields.get("sticker_scanit") or "").strip()
    )


def sticker_fields_from_posting(posting: dict[str, Any]) -> dict[str, str]:
    """Derive sticker binding from Ozon posting (``barcodes`` + ``scanit`` + posting_number).

    Ozon API ``FbsPostingBarcodes``: ``upper_barcode`` = верхняя этикетка,
    ``lower_barcode`` = нижняя. Источник: ``/v3/posting/fbs/get`` с ``with.barcodes``.
    New instance label (05.10.2026): posting ``scanit`` starting with ``ii``.
    """
    pn = str(posting.get("posting_number") or "").strip()
    part_a, part_b = sticker_parts_from_posting_number(pn)
    upper = ""
    lower = ""
    barcodes = posting.get("barcodes")
    if isinstance(barcodes, dict):
        upper = normalize_ozon_package_barcode(barcodes.get("upper_barcode"))
        lower = normalize_ozon_package_barcode(barcodes.get("lower_barcode"))
    return {
        "sticker_barcode": upper,
        "sticker_lower_barcode": lower,
        "sticker_scanit": _scanit_from_posting(posting),
        "sticker_part_a": part_a,
        "sticker_part_b": part_b,
    }


def posting_sticker_payload_from_row(row: dict[str, Any]) -> dict[str, Any]:
    """Sticker + order linkage fields for API payloads."""
    pn = str(row.get("posting_number") or "").strip()
    part_a = str(row.get("sticker_part_a") or "").strip()
    part_b = str(row.get("sticker_part_b") or "").strip()
    upper = normalize_ozon_package_barcode(row.get("sticker_barcode"))
    lower = normalize_ozon_package_barcode(row.get("sticker_lower_barcode"))
    scanit = normalize_ozon_scanit(row.get("sticker_scanit"))
    if (not upper or not lower or not scanit or (not part_a and not part_b)) and pn:
        posting = _posting_payload_from_row(row)
        if posting:
            hints = sticker_fields_from_posting({**posting, "posting_number": pn})
            if not upper:
                upper = normalize_ozon_package_barcode(hints.get("sticker_barcode"))
            if not lower:
                lower = normalize_ozon_package_barcode(hints.get("sticker_lower_barcode"))
            if not scanit:
                scanit = normalize_ozon_scanit(hints.get("sticker_scanit"))
            if not part_a:
                part_a = str(hints.get("sticker_part_a") or "").strip()
            if not part_b:
                part_b = str(hints.get("sticker_part_b") or "").strip()
    if not part_a and pn:
        part_a, part_b = sticker_parts_from_posting_number(pn)
    return {
        "posting_number": pn,
        "order_id": row.get("order_id"),
        "order_number": str(row.get("order_number") or "").strip(),
        "sticker_barcode": upper,
        "sticker_lower_barcode": lower,
        "sticker_scanit": scanit,
        "sticker_part_a": part_a,
        "sticker_part_b": part_b,
    }


def load_posting_sticker_map(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    posting_numbers: list[str],
) -> dict[str, dict[str, Any]]:
    nums = [str(x).strip() for x in posting_numbers if str(x).strip()]
    if not nums:
        return {}
    ensure_ozon_fbs_tables(repo)
    placeholders = ", ".join("?" for _ in nums)
    with repo._connect() as conn:
        rows = conn.execute(
            repo._sql(
                f"""
                SELECT posting_number, order_id, order_number,
                       sticker_barcode, sticker_lower_barcode, sticker_scanit,
                       sticker_part_a, sticker_part_b
                FROM ozon_fbs_postings
                WHERE user_id = ? AND source_id = ?
                  AND posting_number IN ({placeholders})
                """
            ),
            (user_id, source_id, *nums),
        ).fetchall()
    out: dict[str, dict[str, Any]] = {}
    for row in rows:
        d = repo._row_to_dict(row)
        pn = str(d.get("posting_number") or "").strip()
        if pn:
            out[pn] = posting_sticker_payload_from_row(d)
    return out


def persist_posting_stickers_batch(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    stickers: dict[str, dict[str, Any]],
    only_if_empty: bool = False,
    set_scanned_at: bool = False,
) -> int:
    """Persist sticker scan / Ozon label binding on ``ozon_fbs_postings`` by posting_number."""
    if not stickers:
        return 0
    ensure_ozon_fbs_tables(repo)
    updated = 0
    scanned_at_sql = "NOW()" if set_scanned_at else "sticker_scanned_at"
    with repo._connect() as conn:
        for pn_raw, st in stickers.items():
            if not isinstance(st, dict):
                continue
            pn = str(pn_raw or st.get("posting_number") or "").strip()
            if not pn:
                continue
            barcode = normalize_ozon_package_barcode(
                st.get("sticker_barcode") or st.get("barcode") or ""
            )
            lower_barcode = normalize_ozon_package_barcode(
                st.get("sticker_lower_barcode") or st.get("lower_barcode") or ""
            )
            scanit = normalize_ozon_scanit(
                st.get("sticker_scanit") or st.get("scanit") or ""
            )
            part_a = str(st.get("sticker_part_a") or st.get("partA") or "").strip()
            part_b = str(st.get("sticker_part_b") or st.get("partB") or "").strip()
            if not part_a and not part_b:
                hint_a, hint_b = sticker_parts_from_posting_number(pn)
                if not part_a:
                    part_a = hint_a
                if not part_b:
                    part_b = hint_b
            if not (barcode or lower_barcode or scanit or part_a or part_b):
                continue
            if only_if_empty:
                cur = conn.execute(
                    repo._sql(
                        """
                        UPDATE ozon_fbs_postings
                        SET sticker_barcode = CASE
                                WHEN (
                                        sticker_barcode = ''
                                        OR sticker_barcode = '0'
                                        OR (
                                            sticker_barcode ~ '^[0-9]+$'
                                            AND LENGTH(sticker_barcode) < 12
                                        )
                                     )
                                     AND ? <> '' THEN ?
                                ELSE sticker_barcode
                            END,
                            sticker_lower_barcode = CASE
                                WHEN (
                                        sticker_lower_barcode = ''
                                        OR sticker_lower_barcode = '0'
                                        OR (
                                            sticker_lower_barcode ~ '^[0-9]+$'
                                            AND LENGTH(sticker_lower_barcode) < 12
                                        )
                                     )
                                     AND ? <> '' THEN ?
                                ELSE sticker_lower_barcode
                            END,
                            sticker_scanit = CASE
                                WHEN sticker_scanit = '' AND ? <> '' THEN ?
                                ELSE sticker_scanit
                            END,
                            sticker_part_a = CASE
                                WHEN sticker_part_a = '' AND ? <> '' THEN ?
                                ELSE sticker_part_a
                            END,
                            sticker_part_b = CASE
                                WHEN sticker_part_b = '' AND ? <> '' THEN ?
                                ELSE sticker_part_b
                            END
                        WHERE user_id = ? AND source_id = ? AND posting_number = ?
                        """
                    ),
                    (
                        barcode,
                        barcode,
                        lower_barcode,
                        lower_barcode,
                        scanit,
                        scanit,
                        part_a,
                        part_a,
                        part_b,
                        part_b,
                        int(user_id),
                        int(source_id),
                        pn,
                    ),
                )
            else:
                cur = conn.execute(
                    repo._sql(
                        f"""
                        UPDATE ozon_fbs_postings
                        SET sticker_barcode = CASE
                                WHEN ? <> '' THEN ?
                                ELSE sticker_barcode
                            END,
                            sticker_lower_barcode = CASE
                                WHEN ? <> '' THEN ?
                                ELSE sticker_lower_barcode
                            END,
                            sticker_scanit = CASE
                                WHEN ? <> '' THEN ?
                                ELSE sticker_scanit
                            END,
                            sticker_part_a = CASE
                                WHEN ? <> '' THEN ?
                                ELSE sticker_part_a
                            END,
                            sticker_part_b = CASE
                                WHEN ? <> '' THEN ?
                                ELSE sticker_part_b
                            END,
                            sticker_scanned_at = {scanned_at_sql}
                        WHERE user_id = ? AND source_id = ? AND posting_number = ?
                        """
                    ),
                    (
                        barcode,
                        barcode,
                        lower_barcode,
                        lower_barcode,
                        scanit,
                        scanit,
                        part_a,
                        part_a,
                        part_b,
                        part_b,
                        int(user_id),
                        int(source_id),
                        pn,
                    ),
                )
            try:
                updated += int(cur.rowcount or 0)
            except (TypeError, ValueError, AttributeError):
                pass
    return updated


def apply_posting_sticker_hints(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    posting: dict[str, Any],
) -> None:
    """Fill empty sticker fields from Ozon get/list payload (package barcodes + posting_number)."""
    pn = str(posting.get("posting_number") or "").strip()
    if not pn:
        return
    hints = sticker_fields_from_posting(posting)
    if not (
        hints.get("sticker_barcode")
        or hints.get("sticker_lower_barcode")
        or hints.get("sticker_scanit")
        or hints.get("sticker_part_a")
        or hints.get("sticker_part_b")
    ):
        return
    persist_posting_stickers_batch(
        repo,
        user_id=user_id,
        source_id=source_id,
        stickers={pn: hints},
        only_if_empty=True,
    )


def _posting_payload_from_row(row: dict[str, Any]) -> dict[str, Any]:
    """Rebuild Ozon posting dict from DB row (raw_json + products_json fallback)."""
    posting: dict[str, Any] = {}
    raw_text = str(row.get("raw_json") or "").strip()
    if raw_text:
        try:
            parsed = json.loads(raw_text)
            if isinstance(parsed, dict):
                posting = parsed
        except json.JSONDecodeError:
            pass
    if not _products_from_posting(posting):
        try:
            pj = json.loads(str(row.get("products_json") or "[]"))
        except json.JSONDecodeError:
            pj = []
        if isinstance(pj, list):
            products = [p for p in pj if isinstance(p, dict)]
            if products:
                posting = dict(posting)
                posting["products"] = products
    return posting


def _product_has_mandatory_mark_flag(product: dict[str, Any]) -> bool:
    """Ozon v3: ``mandatory_mark`` may be bool or a non-empty list of codes."""
    mm = product.get("mandatory_mark")
    if isinstance(mm, list):
        return bool(mm)
    if isinstance(mm, str):
        return bool(mm.strip())
    return bool(mm)


def _requirement_sku_ids(posting: dict[str, Any], key: str) -> set[str]:
    """SKU/product_id values from ``requirements.<key>``."""
    ids: set[str] = set()
    req = posting.get("requirements")
    if isinstance(req, dict):
        arr = req.get(key)
        if isinstance(arr, list):
            for x in arr:
                text = str(x or "").strip()
                if text:
                    ids.add(text)
    return ids


def _mandatory_mark_sku_ids(posting: dict[str, Any]) -> set[str]:
    """SKU/product_id values that Ozon marks as requiring Chestny ZNAK."""
    return _requirement_sku_ids(posting, "products_requiring_mandatory_mark")


def _products_requiring_gtd_ids(posting: dict[str, Any]) -> set[str]:
    """SKU/product_id values that Ozon marks as requiring GTD (юрлица)."""
    return _requirement_sku_ids(posting, "products_requiring_gtd")


def _merge_requirement_sku_ids(
    posting: dict[str, Any], *, key: str, required_ids: set[str]
) -> dict[str, Any]:
    if not required_ids:
        return posting
    out = dict(posting)
    req = out.get("requirements")
    if not isinstance(req, dict):
        req = {}
        out["requirements"] = req
    existing = req.get(key)
    merged: list[str] = []
    if isinstance(existing, list):
        merged = [str(x).strip() for x in existing if str(x).strip()]
    for pid in sorted(required_ids):
        if pid not in merged:
            merged.append(pid)
    req[key] = merged
    return out


def _merge_products_requiring_mandatory_mark(
    posting: dict[str, Any], required_ids: set[str]
) -> dict[str, Any]:
    return _merge_requirement_sku_ids(
        posting, key="products_requiring_mandatory_mark", required_ids=required_ids
    )


def _merge_products_requiring_gtd(
    posting: dict[str, Any], required_ids: set[str]
) -> dict[str, Any]:
    return _merge_requirement_sku_ids(
        posting, key="products_requiring_gtd", required_ids=required_ids
    )


def posting_requires_pre_ship_gtd(row: dict[str, Any]) -> bool:
    """True when Ozon requires GTD before ship (legal-entity / юрлицо flow).

    Source of truth: ``requirements.products_requiring_gtd`` in raw posting.
    Catalog КИЗ alone does not trigger this — B2C mark-only orders stay on the
    supply «Маркировка» path.
    """
    posting = _posting_payload_from_row(row) if isinstance(row, dict) else None
    if not posting and isinstance(row, dict):
        posting = row
    if not isinstance(posting, dict):
        return False
    return bool(_products_requiring_gtd_ids(posting))


def pre_ship_exemplar_products(posting: dict[str, Any]) -> list[dict[str, Any]]:
    """Product lines that need exemplar set before ship for GTD/юрлицо orders.

    Union of ``products_requiring_gtd`` and ``products_requiring_mandatory_mark``.
    Marketplace buyout lines are included: Ozon can require GTD+КИЗ on them for
    юрлица, and skipping buyout left an empty list → «Не удалось определить товары».
    Falls back to all product lines when GTD is required but SKU lists empty.
    """
    if not isinstance(posting, dict):
        return []
    products = _products_from_posting(posting)
    gtd_ids = _products_requiring_gtd_ids(posting)
    mark_ids = _mandatory_mark_sku_ids(posting)
    need_ids = gtd_ids | mark_ids
    out: list[dict[str, Any]] = []
    for p in products:
        sku = p.get("sku") or p.get("product_id")
        sku_str = str(sku).strip() if sku is not None else ""
        if need_ids and sku_str not in need_ids:
            continue
        if not need_ids and not gtd_ids:
            continue
        try:
            pid = int(sku)
        except (TypeError, ValueError):
            continue
        try:
            qty = int(p.get("quantity") or 1)
        except (TypeError, ValueError):
            qty = 1
        out.append(
            {
                "product_id": pid,
                "quantity": max(qty, 1),
                "offer_id": p.get("offer_id"),
            }
        )
    if out:
        return out
    if not gtd_ids:
        return []
    # GTD required but SKU list empty / mismatched — send all lines (incl. buyout).
    for p in products:
        sku = p.get("sku") or p.get("product_id")
        try:
            pid = int(sku)
        except (TypeError, ValueError):
            continue
        try:
            qty = int(p.get("quantity") or 1)
        except (TypeError, ValueError):
            qty = 1
        out.append(
            {
                "product_id": pid,
                "quantity": max(qty, 1),
                "offer_id": p.get("offer_id"),
            }
        )
    return out


def pre_ship_exemplar_quantity(row: dict[str, Any]) -> int:
    """How many KIZ slots a pre-ship GTD posting needs."""
    posting = _posting_payload_from_row(row) if isinstance(row, dict) else None
    if not posting and isinstance(row, dict):
        posting = row
    if not isinstance(posting, dict):
        return 0
    products = pre_ship_exemplar_products(posting)
    if products:
        return sum(int(p.get("quantity") or 1) for p in products)
    try:
        return max(int(row.get("quantity") or 1), 1) if posting_requires_pre_ship_gtd(row) else 0
    except (TypeError, ValueError):
        return 1 if posting_requires_pre_ship_gtd(row) else 0


def posting_pre_ship_exemplar_ready(row: dict[str, Any]) -> bool:
    """Locally ready to ship: GTD required and already pushed to Ozon."""
    if not posting_requires_pre_ship_gtd(row):
        return True
    return bool(row.get("marking_ozon_synced"))


def posting_marking_flags_resolved(posting: dict[str, Any]) -> bool:
    """True when КИЗ requirement is known (required or confirmed absent via is-required)."""
    if not isinstance(posting, dict):
        return False
    products = _products_from_posting(posting)
    if _mandatory_mark(posting, products):
        return True
    req = posting.get("requirements")
    if not isinstance(req, dict):
        return False
    # Invalidate get-only era cache (empty requirements + checked) so is-required re-runs.
    if req.get("marking_check_version") is not None:
        return False
    if req.get("marking_is_required_checked"):
        return True
    return False


def posting_marking_flags_known(posting: dict[str, Any]) -> bool:
    """True when list/get payload already indicates КИЗ requirement."""
    if not isinstance(posting, dict):
        return False
    return _mandatory_mark(posting, _products_from_posting(posting))


def _posting_with_marking_checked(posting: dict[str, Any]) -> dict[str, Any]:
    out = dict(posting)
    req = out.get("requirements")
    if not isinstance(req, dict):
        req = {}
    else:
        req = dict(req)
    req["marking_is_required_checked"] = True
    # Drop get-era marker so future resolves trust is-required cache again.
    req.pop("marking_check_version", None)
    out["requirements"] = req
    return out


def enrich_posting_marking_flags(
    client: OzonFbsClient,
    posting: dict[str, Any],
    *,
    allow_exemplar_fallback: bool = True,
) -> dict[str, Any]:
    """Augment posting with marking requirements when get/list omit them."""
    if not isinstance(posting, dict):
        return posting
    products = _products_from_posting(posting)
    if _mandatory_mark(posting, products):
        return posting
    pn = str(posting.get("posting_number") or "").strip()
    if not pn:
        return posting
    sku_ints: list[int] = []
    payload_products: list[dict[str, Any]] = []
    for p in products:
        if bool(p.get("is_marketplace_buyout")):
            continue
        product_id = p.get("sku") or p.get("product_id")
        try:
            pid = int(product_id)
        except (TypeError, ValueError):
            continue
        try:
            qty = int(p.get("quantity") or 1)
        except (TypeError, ValueError):
            qty = 1
        payload_products.append({"product_id": pid, "quantity": max(qty, 1)})
    for p in products:
        product_id = p.get("sku") or p.get("product_id")
        try:
            pid = int(product_id)
        except (TypeError, ValueError):
            continue
        sku_ints.append(pid)
    if not sku_ints:
        return posting

    required_ids: set[str] = set()
    is_required_checked = False
    try:
        required_items = client.mandatory_mark_is_required(pn, sku_ints)
        is_required_checked = True
        for item in required_items:
            if not item.get("is_required"):
                continue
            sku_val = item.get("sku")
            if sku_val is not None:
                text = str(sku_val).strip()
                if text:
                    required_ids.add(text)
    except RuntimeError:
        pass
    if required_ids:
        return _posting_with_marking_checked(
            _merge_products_requiring_mandatory_mark(posting, required_ids)
        )
    if is_required_checked:
        return _posting_with_marking_checked(posting)
    if not allow_exemplar_fallback:
        # Light path (modal/TSD chunks): on is-required failure still mark checked
        # so the queue advances and the UI does not loop on the same postings.
        return _posting_with_marking_checked(posting)

    if not payload_products:
        return posting
    try:
        resp = client.product_exemplar_create_or_get(pn, payload_products)
    except RuntimeError:
        try:
            resp = client.product_exemplar_create_or_get_v5(pn, payload_products)
        except RuntimeError:
            return posting
    gtd_ids: set[str] = set()
    for item in resp.get("products") or []:
        if not isinstance(item, dict):
            continue
        if item.get("is_mandatory_mark_needed"):
            pid = item.get("product_id")
            if pid is not None:
                text = str(pid).strip()
                if text:
                    required_ids.add(text)
        if item.get("is_gtd_needed"):
            pid = item.get("product_id")
            if pid is not None:
                text = str(pid).strip()
                if text:
                    gtd_ids.add(text)
    out = _posting_with_marking_checked(
        _merge_products_requiring_mandatory_mark(posting, required_ids)
    )
    if gtd_ids:
        out = _merge_products_requiring_gtd(out, gtd_ids)
    return out


def enrich_posting_marking_flags_light(
    client: OzonFbsClient,
    posting: dict[str, Any],
) -> dict[str, Any]:
    """Resolve КИЗ flags via mandatory-mark/is-required only (safe for bulk sync)."""
    return enrich_posting_marking_flags(
        client, posting, allow_exemplar_fallback=False
    )


def catalog_requires_kiz(
    *,
    offer_id: str | None,
    sku: str | None,
    requires_kiz_map: dict[str, bool],
) -> bool:
    """Match posting line to Feedback → Settings → Products «Требует КИЗ».

    Lookup order (same as names/ШК): supplier_article via offer_id, then ozon_sku.
    """
    if not requires_kiz_map:
        return False
    article = str(offer_id or "").strip()
    sku_key = str(sku or "").strip()
    for key in (
        article,
        article.casefold() if article else "",
        sku_key,
        sku_key.casefold() if sku_key else "",
    ):
        if key and requires_kiz_map.get(key):
            return True
    return False


def apply_catalog_marking_flags(
    posting: dict[str, Any],
    requires_kiz_map: dict[str, bool],
) -> dict[str, Any]:
    """Set products_requiring_mandatory_mark from catalog checkbox (source of truth).

    Marketplace buyout lines are included: Feedback → Settings → Products
    «Требует КИЗ» applies regardless of ``is_marketplace_buyout``.
    """
    if not isinstance(posting, dict):
        return posting
    products = _products_from_posting(posting)
    required_ids: list[str] = []
    seen: set[str] = set()
    for p in products:
        offer = str(p.get("offer_id") or "").strip()
        sku_val = p.get("sku") if p.get("sku") is not None else p.get("product_id")
        sku_str = str(sku_val).strip() if sku_val is not None else ""
        if not catalog_requires_kiz(
            offer_id=offer, sku=sku_str, requires_kiz_map=requires_kiz_map
        ):
            continue
        if not sku_str or sku_str in seen:
            continue
        seen.add(sku_str)
        required_ids.append(sku_str)
    out = dict(posting)
    req = out.get("requirements")
    if not isinstance(req, dict):
        req = {}
    else:
        req = dict(req)
    req["products_requiring_mandatory_mark"] = required_ids
    req["marking_is_required_checked"] = True
    req.pop("marking_check_version", None)
    out["requirements"] = req
    return out


def stamp_catalog_marking_flags(
    repo: ReviewRepository,
    *,
    user_id: int,
    posting: dict[str, Any],
    requires_kiz_map: dict[str, bool] | None = None,
) -> dict[str, Any]:
    """Re-apply catalog «Требует КИЗ» after a live Ozon ``get_posting``.

    Raw Ozon payloads omit our local ``marking_is_required_checked`` stamp.
    Upserting them without this wipes the sync-time warm-up and forces
    Marking / Pick-verify modal opens to re-run N×40 catalog resolve chunks.
    """
    if not isinstance(posting, dict):
        return posting
    mapping = requires_kiz_map
    if mapping is None:
        try:
            mapping = repo.get_product_requires_kiz_map(user_id=user_id)
        except Exception as exc:
            _log.warning(
                "catalog kiz stamp map failed user=%s: %s", user_id, exc
            )
            return posting
    if not isinstance(mapping, dict):
        mapping = {}
    return apply_catalog_marking_flags(posting, mapping)


def _catalog_keys_match_posting(
    *,
    posting: dict[str, Any],
    row: dict[str, Any],
    keys: set[str],
) -> bool:
    """True when posting products / row offer+sku hit any catalog key."""
    if not keys:
        return False

    def _hit(value: object) -> bool:
        s = str(value or "").strip()
        return bool(s) and (s in keys or s.casefold() in keys)

    for p in _products_from_posting(posting):
        if not isinstance(p, dict):
            continue
        if _hit(p.get("offer_id")):
            return True
        sku_val = p.get("sku") if p.get("sku") is not None else p.get("product_id")
        if _hit(sku_val):
            return True
    if _hit(row.get("offer_id")) or _hit(row.get("sku")):
        return True
    return False


def invalidate_catalog_marking_flags_for_keys(
    repo: ReviewRepository,
    *,
    user_id: int,
    catalog_keys: list[str] | set[str] | tuple[str, ...],
) -> int:
    """Clear ``marking_is_required_checked`` on operational postings matching keys.

    Used when Settings → Products «Требует КИЗ» changes so modal residual resolve
    re-applies catalog flags. Touches only ``raw_json`` — codes / pick / stickers /
    supply_id stay intact.
    """
    keys: set[str] = set()
    for raw in catalog_keys or []:
        s = str(raw or "").strip()
        if not s:
            continue
        keys.add(s)
        keys.add(s.casefold())
    if not keys:
        return 0
    ensure_ozon_fbs_tables(repo)
    tabs = tuple(sorted(OPERATIONAL_COUNT_TABS))
    with repo._connect() as conn:
        rows = conn.execute(
            repo._sql(
                f"""
                SELECT source_id, posting_number, offer_id, sku, products_json, raw_json
                FROM ozon_fbs_postings
                WHERE user_id = ?
                  AND tab IN ({", ".join("?" for _ in tabs)})
                """
            ),
            (int(user_id), *tabs),
        ).fetchall()
    updated = 0
    for row in rows:
        d = repo._row_to_dict(row) if row else {}
        if not d:
            continue
        posting = _posting_payload_from_row(d)
        if not posting:
            continue
        if not _catalog_keys_match_posting(posting=posting, row=d, keys=keys):
            continue
        req = posting.get("requirements")
        if not isinstance(req, dict):
            continue
        if not req.get("marking_is_required_checked") and req.get(
            "marking_check_version"
        ) is None:
            continue
        new_req = dict(req)
        new_req.pop("marking_is_required_checked", None)
        new_req.pop("marking_check_version", None)
        new_posting = dict(posting)
        new_posting["requirements"] = new_req
        raw = json.dumps(new_posting, ensure_ascii=False)
        try:
            sid = int(d.get("source_id"))
            pn = str(d.get("posting_number") or "").strip()
        except (TypeError, ValueError):
            continue
        if not pn:
            continue
        try:
            with repo._connect() as conn:
                conn.execute(
                    repo._sql(
                        """
                        UPDATE ozon_fbs_postings
                        SET raw_json = ?
                        WHERE user_id = ? AND source_id = ? AND posting_number = ?
                        """
                    ),
                    (raw, int(user_id), sid, pn),
                )
            updated += 1
        except Exception as exc:
            _log.warning(
                "ozon invalidate marking flags %s/%s: %s",
                sid,
                pn,
                exc,
            )
    return updated


def posting_requires_marking(
    row: dict[str, Any],
    *,
    requires_kiz_map: dict[str, bool] | None = None,
) -> bool:
    """True when posting needs Chestny ZNAK marking.

    When ``requires_kiz_map`` is provided (Ozon FBS UI), catalog checkbox is the
    only gate — including marketplace buyout postings. Ozon is-required
    false-positives are ignored.
    """
    if requires_kiz_map is not None:
        posting = _posting_payload_from_row(row)
        products = _products_from_posting(posting) if posting else []
        if products:
            for p in products:
                sku_val = p.get("sku") if p.get("sku") is not None else p.get("product_id")
                if catalog_requires_kiz(
                    offer_id=p.get("offer_id"),
                    sku=sku_val,
                    requires_kiz_map=requires_kiz_map,
                ):
                    return True
            return False
        return catalog_requires_kiz(
            offer_id=row.get("offer_id"),
            sku=row.get("sku"),
            requires_kiz_map=requires_kiz_map,
        )
    if bool(row.get("is_mandatory_mark")):
        return True
    posting = _posting_payload_from_row(row)
    if not posting:
        return False
    products = _products_from_posting(posting)
    return _mandatory_mark(posting, products)


def marked_products_for_posting(
    posting: dict[str, Any],
    *,
    requires_kiz_map: dict[str, bool] | None = None,
) -> list[dict[str, Any]]:
    """Product lines that need mandatory_mark codes (sku + qty)."""
    if not isinstance(posting, dict):
        return []
    products = _products_from_posting(posting)
    if requires_kiz_map is not None:
        out: list[dict[str, Any]] = []
        for p in products:
            sku_val = p.get("sku") if p.get("sku") is not None else p.get("product_id")
            if not catalog_requires_kiz(
                offer_id=p.get("offer_id"),
                sku=sku_val,
                requires_kiz_map=requires_kiz_map,
            ):
                continue
            try:
                pid = int(sku_val)
            except (TypeError, ValueError):
                continue
            try:
                qty = int(p.get("quantity") or 1)
            except (TypeError, ValueError):
                qty = 1
            out.append(
                {
                    "product_id": pid,
                    "quantity": max(qty, 1),
                    "offer_id": p.get("offer_id"),
                }
            )
        return out
    required_skus = _mandatory_mark_sku_ids(posting)
    out = []
    for p in products:
        if bool(p.get("is_marketplace_buyout")):
            continue
        sku = p.get("sku") or p.get("product_id")
        sku_str = str(sku).strip() if sku is not None else ""
        needs = _product_has_mandatory_mark_flag(p)
        if not needs and required_skus and sku_str in required_skus:
            needs = True
        if not needs:
            continue
        product_id = p.get("sku") or p.get("product_id")
        try:
            pid = int(product_id)
        except (TypeError, ValueError):
            continue
        try:
            qty = int(p.get("quantity") or 1)
        except (TypeError, ValueError):
            qty = 1
        out.append({"product_id": pid, "quantity": max(qty, 1), "offer_id": p.get("offer_id")})
    if out:
        return out
    if _mandatory_mark(posting, products):
        for p in products:
            if bool(p.get("is_marketplace_buyout")):
                continue
            product_id = p.get("sku") or p.get("product_id")
            try:
                pid = int(product_id)
            except (TypeError, ValueError):
                continue
            try:
                qty = int(p.get("quantity") or 1)
            except (TypeError, ValueError):
                qty = 1
            out.append({"product_id": pid, "quantity": max(qty, 1), "offer_id": p.get("offer_id")})
    return out


def posting_marking_quantity(
    row: dict[str, Any],
    *,
    requires_kiz_map: dict[str, bool] | None = None,
) -> int:
    """How many KIZ codes the posting needs (sum of marked product qty)."""
    posting = _posting_payload_from_row(row)
    marked = marked_products_for_posting(posting, requires_kiz_map=requires_kiz_map)
    if marked:
        return sum(int(p.get("quantity") or 1) for p in marked)
    if posting_requires_marking(row, requires_kiz_map=requires_kiz_map):
        try:
            return max(int(row.get("quantity") or 1), 1)
        except (TypeError, ValueError):
            return 1
    return 0


def _parse_dt(value: object) -> str | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        return datetime.fromisoformat(text).isoformat()
    except ValueError:
        return text


def _products_from_posting(posting: dict[str, Any]) -> list[dict[str, Any]]:
    products = posting.get("products")
    if not isinstance(products, list):
        return []
    out: list[dict[str, Any]] = []
    for item in products:
        if isinstance(item, dict):
            out.append(item)
    return out


def _mandatory_mark(posting: dict[str, Any], products: list[dict[str, Any]]) -> bool:
    req = posting.get("requirements")
    if isinstance(req, dict):
        marks = req.get("products_requiring_mandatory_mark")
        if isinstance(marks, list) and marks:
            return True
    required_skus = _mandatory_mark_sku_ids(posting)
    for p in products:
        if _product_has_mandatory_mark_flag(p):
            return True
        sku = p.get("sku") or p.get("product_id")
        if sku is not None and str(sku).strip() in required_skus:
            return True
    return False


def _barcodes_from_posting(posting: dict[str, Any], products: list[dict[str, Any]]) -> list[str]:
    """Product ШК from posting products only (never offer_id / sku / package QR)."""
    del posting  # package upper/lower barcodes are not product ШК
    out: list[str] = []
    exclude: set[str] = set()
    for p in products:
        for key in ("sku", "offer_id"):
            text = str(p.get(key) or "").strip()
            if text:
                exclude.add(text)
                exclude.add(text.casefold())
        for key in ("barcode", "bar_code"):
            text = str(p.get(key) or "").strip()
            if text and text not in out and text.casefold() not in exclude:
                out.append(text)
        raw = p.get("barcodes")
        if isinstance(raw, list):
            for item in raw:
                text = str(item or "").strip()
                if text and text not in out and text.casefold() not in exclude:
                    out.append(text)
        elif isinstance(raw, str):
            text = raw.strip()
            if text and text not in out and text.casefold() not in exclude:
                out.append(text)
    return out


def resolve_product_barcodes(
    *,
    offer_id: str | None,
    sku: str | None,
    barcode_map: dict[str, list[str]],
    fallback: list[str] | None = None,
) -> list[str]:
    """ШК from Feedback → Settings → Products; never show offer_id/sku as barcodes."""
    article = str(offer_id or "").strip()
    sku_key = str(sku or "").strip()
    exclude = {x for x in (article, sku_key, article.casefold(), sku_key.casefold()) if x}
    codes: list[str] = []
    for key in (
        article,
        article.casefold() if article else "",
        sku_key,
        sku_key.casefold() if sku_key else "",
    ):
        if not key:
            continue
        found = barcode_map.get(key)
        if found:
            codes = list(found)
            break
    if not codes and fallback:
        codes = [str(x or "").strip() for x in fallback if str(x or "").strip()]
    out: list[str] = []
    seen: set[str] = set()
    for code in codes:
        text = str(code or "").strip()
        if not text or text in seen or text in exclude or text.casefold() in exclude:
            continue
        seen.add(text)
        out.append(text)
    return out


def upsert_posting(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    posting: dict[str, Any],
    protect_status_downgrade: bool = True,
    ensure_tables: bool = True,
) -> None:
    # Full sync calls ensure once up front; skip per-row DDL there (disk-heavy).
    if ensure_tables:
        ensure_ozon_fbs_tables(repo)
    posting_number = str(posting.get("posting_number") or "").strip()
    if not posting_number:
        return
    remote_status = str(posting.get("status") or "").strip().lower()
    status = remote_status
    tab = compute_tab(status)
    local_status = ""
    local_tab = ""
    if protect_status_downgrade:
        with repo._connect() as conn:
            existing = conn.execute(
                repo._sql(
                    """
                    SELECT status, tab FROM ozon_fbs_postings
                    WHERE user_id = ? AND source_id = ? AND posting_number = ?
                    """
                ),
                (user_id, source_id, posting_number),
            ).fetchone()
        if existing:
            if hasattr(existing, "keys"):
                local_status = str(existing["status"] or "")
                local_tab = str(existing["tab"] or "")
            else:
                local_status = str(existing[0] or "")
                local_tab = str(existing[1] or "")
            status, tab = resolve_upsert_status(
                local_status=local_status,
                local_tab=local_tab,
                remote_status=remote_status,
            )
    products = _products_from_posting(posting)
    first = products[0] if products else {}
    offer_id = str(first.get("offer_id") or "").strip()
    product_name = str(first.get("name") or "").strip()
    sku_raw = first.get("sku")
    sku: int | None = None
    try:
        if sku_raw is not None:
            sku = int(sku_raw)
    except (TypeError, ValueError):
        sku = None
    qty = 0
    for p in products:
        try:
            qty += int(p.get("quantity") or 0)
        except (TypeError, ValueError):
            qty += 1
    if qty <= 0:
        qty = 1
    # Keep a searchable hint in stored product_name (list UI uses products_json).
    base_label = product_name or offer_id or "Товар"
    if len(products) > 1:
        product_name = f"{base_label} (+{len(products) - 1})"
    elif qty > 1:
        product_name = f"{base_label} ×{qty}"
    else:
        product_name = base_label if product_name or offer_id else ""
    price = 0
    fin = posting.get("financial_data")
    if isinstance(fin, dict):
        fin_products = fin.get("products")
        if isinstance(fin_products, list) and fin_products:
            fp = fin_products[0]
            if isinstance(fp, dict):
                try:
                    price = int(float(fp.get("price") or 0))
                except (TypeError, ValueError):
                    price = 0
    analytics = posting.get("analytics_data")
    warehouse_name = ""
    warehouse_id: int | None = None
    if isinstance(analytics, dict):
        warehouse_name = str(analytics.get("warehouse") or "").strip()
        try:
            if analytics.get("warehouse_id") is not None:
                warehouse_id = int(analytics.get("warehouse_id"))
        except (TypeError, ValueError):
            warehouse_id = None
    order_id: int | None = None
    try:
        if posting.get("order_id") is not None:
            order_id = int(posting.get("order_id"))
    except (TypeError, ValueError):
        order_id = None
    order_number = str(posting.get("order_number") or "").strip()
    barcodes = _barcodes_from_posting(posting, products)
    mandatory = _mandatory_mark(posting, products)
    raw_json = json.dumps(posting, ensure_ascii=False)
    products_json = json.dumps(products, ensure_ascii=False)
    barcodes_json = json.dumps(barcodes, ensure_ascii=False)
    created_at = _parse_dt(posting.get("in_process_at") or posting.get("created_at"))
    in_process_at = _parse_dt(posting.get("in_process_at"))
    with repo._connect() as conn:
        conn.execute(
            repo._sql(
                """
                INSERT INTO ozon_fbs_postings (
                    user_id, source_id, posting_number, order_id, order_number,
                    status, tab, offer_id, product_name, sku, quantity, price,
                    warehouse_name, warehouse_id, barcodes_json, products_json,
                    is_mandatory_mark, created_at_ozon, in_process_at, raw_json, synced_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT (user_id, source_id, posting_number) DO UPDATE SET
                    order_id = EXCLUDED.order_id,
                    order_number = EXCLUDED.order_number,
                    status = EXCLUDED.status,
                    tab = EXCLUDED.tab,
                    offer_id = EXCLUDED.offer_id,
                    product_name = EXCLUDED.product_name,
                    sku = EXCLUDED.sku,
                    quantity = EXCLUDED.quantity,
                    price = EXCLUDED.price,
                    warehouse_name = EXCLUDED.warehouse_name,
                    warehouse_id = EXCLUDED.warehouse_id,
                    barcodes_json = EXCLUDED.barcodes_json,
                    products_json = EXCLUDED.products_json,
                    is_mandatory_mark = EXCLUDED.is_mandatory_mark,
                    created_at_ozon = EXCLUDED.created_at_ozon,
                    in_process_at = EXCLUDED.in_process_at,
                    raw_json = EXCLUDED.raw_json,
                    synced_at = EXCLUDED.synced_at
                """
            ),
            (
                user_id,
                source_id,
                posting_number,
                order_id,
                order_number,
                status,
                tab,
                offer_id,
                product_name,
                sku,
                qty,
                price,
                warehouse_name,
                warehouse_id,
                barcodes_json,
                products_json,
                repo._bool_db(mandatory),
                created_at,
                in_process_at,
                raw_json,
                _utc_now(),
            ),
        )
    apply_posting_sticker_hints(
        repo, user_id=user_id, source_id=source_id, posting=posting
    )


def _tab_counts(repo: ReviewRepository, *, user_id: int, source_id: int | None) -> dict[str, int]:
    ensure_ozon_fbs_tables(repo)
    clauses = ["user_id = ?"]
    params: list[Any] = [user_id]
    if source_id is not None:
        clauses.append("source_id = ?")
        params.append(source_id)
    where = " AND ".join(clauses)
    not_cancelled = sql_exclude_cancelled_postings_clause()
    counts = {tab: 0 for tab in ALL_TABS}
    with repo._connect() as conn:
        rows = conn.execute(
            repo._sql(
                f"""
                SELECT tab, COUNT(*) AS n
                FROM ozon_fbs_postings
                WHERE {where}
                  AND (
                    tab NOT IN ({", ".join("?" for _ in OPERATIONAL_COUNT_TABS)})
                    OR ({not_cancelled})
                  )
                GROUP BY tab
                """
            ),
            tuple([*params, *sorted(OPERATIONAL_COUNT_TABS)]),
        ).fetchall()
    for row in rows:
        tab = str(row["tab"] or "")
        if tab in counts:
            counts[tab] = int(row["n"] or 0)
    # Multi counts for every list/supplies response — managers and owner share the
    # same payload so «Разделить» / collect-block stay in sync for all roles.
    try:
        from . import ozon_fbs_detail as oz_detail

        multi_stats = oz_detail.count_awaiting_packaging_multi(
            repo, user_id=user_id, source_id=int(source_id) if source_id is not None else None
        )
        counts["awaiting_packaging_multi"] = int(multi_stats.get("multi_posting_count") or 0)
        counts["awaiting_packaging_multi_extra"] = int(multi_stats.get("extra_postings") or 0)
    except Exception:
        counts["awaiting_packaging_multi"] = 0
        counts["awaiting_packaging_multi_extra"] = 0
    return counts


def _postings_filter_sql(
    *,
    user_id: int,
    source_id: int | None,
    tab: str | None,
    search: str | None,
) -> tuple[str, list[Any]]:
    clauses = ["user_id = ?"]
    params: list[Any] = [user_id]
    if source_id is not None:
        clauses.append("source_id = ?")
        params.append(source_id)
    tab_key = str(tab or "").strip().lower()
    if tab_key:
        if tab_key == TAB_ARBITRATION:
            clauses.append("tab = ?")
            params.append(TAB_ARBITRATION)
        else:
            clauses.append("tab = ?")
            params.append(tab_key)
    q = str(search or "").strip()
    if q:
        like = f"%{q}%"
        search_parts = [
            "posting_number ILIKE ?",
            "order_number ILIKE ?",
            "offer_id ILIKE ?",
            "product_name ILIKE ?",
            "warehouse_name ILIKE ?",
            "barcodes_json ILIKE ?",
            "products_json ILIKE ?",
        ]
        search_params: list[Any] = [like, like, like, like, like, like, like]
        tail = posting_search_digit_tail(q)
        if tail:
            search_parts.append(
                "regexp_replace(posting_number, '[^0-9]', '', 'g') LIKE ?"
            )
            search_params.append(f"%{tail}")
        clauses.append("(" + " OR ".join(search_parts) + ")")
        params.extend(search_params)
    return " AND ".join(clauses), params


def resolve_product_display_name(
    *,
    offer_id: str | None,
    sku: str | None,
    name_by_article: dict[str, str],
    name_by_ozon_sku: dict[str, str],
) -> str:
    """Name from Feedback → Settings → Products (same priority as WB FBS New).

    Lookup: supplier article (offer_id), then Ozon SKU. Falls back to offer_id,
    never to marketplace title — matches WB FBS ``list_orders``.
    """
    article = str(offer_id or "").strip()
    sku_key = str(sku or "").strip()
    name = (
        name_by_article.get(article)
        or (name_by_article.get(article.casefold()) if article else "")
        or name_by_ozon_sku.get(sku_key)
        or (name_by_ozon_sku.get(sku_key.casefold()) if sku_key else "")
        or article
        or "—"
    )
    return str(name or "—").strip() or "—"


def products_from_posting_row(row: dict[str, Any]) -> list[dict[str, Any]]:
    """Product lines from an API posting dict or a DB row (``products_json``)."""
    products = _products_from_posting(row)
    if products:
        return products
    try:
        parsed = json.loads(str(row.get("products_json") or "[]"))
    except json.JSONDecodeError:
        return []
    if not isinstance(parsed, list):
        return []
    return [p for p in parsed if isinstance(p, dict)]


def enrich_posting_product_display(
    row: dict[str, Any],
    *,
    name_by_article: dict[str, str],
    name_by_ozon_sku: dict[str, str],
) -> dict[str, Any]:
    """Attach multi-unit / multi-SKU fields for list and supply-detail UI.

    Catalog name for the first line stays in ``product_name`` /
    ``product_name_display``. Composition is exposed via ``unit_count``,
    ``line_count``, ``products_brief`` — the UI must not rely on a ``(+N)``
    suffix in the title (that was overwritten by catalog resolve).
    """
    products = products_from_posting_row(row)
    brief: list[dict[str, Any]] = []
    unit_count = 0
    for p in products:
        offer = str(p.get("offer_id") or "").strip()
        sku_raw = p.get("sku") if p.get("sku") is not None else p.get("product_id")
        sku = str(sku_raw or "").strip()
        try:
            qty = max(int(p.get("quantity") or 1), 1)
        except (TypeError, ValueError):
            qty = 1
        unit_count += qty
        name = resolve_product_display_name(
            offer_id=offer,
            sku=sku,
            name_by_article=name_by_article,
            name_by_ozon_sku=name_by_ozon_sku,
        )
        brief.append(
            {
                "offer_id": offer,
                "sku": sku,
                "name": name,
                "quantity": qty,
            }
        )
    if not brief:
        offer = str(row.get("offer_id") or "").strip()
        sku = str(row.get("sku") or "").strip()
        try:
            unit_count = max(int(row.get("quantity") or 1), 1)
        except (TypeError, ValueError):
            unit_count = 1
        name = resolve_product_display_name(
            offer_id=offer,
            sku=sku,
            name_by_article=name_by_article,
            name_by_ozon_sku=name_by_ozon_sku,
        )
        brief = [
            {
                "offer_id": offer,
                "sku": sku,
                "name": name,
                "quantity": unit_count,
            }
        ]
    first = brief[0]
    row["product_name"] = first["name"]
    row["product_name_display"] = first["name"]
    row["unit_count"] = int(unit_count)
    row["line_count"] = len(brief)
    row["is_multi_unit"] = unit_count > 1
    row["is_multi_sku"] = len(brief) > 1
    row["products_brief"] = brief
    return row


def list_postings(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int | None,
    tab: str | None = None,
    search: str | None = None,
    page: int = 1,
    page_size: int = 50,
) -> dict[str, Any]:
    ensure_ozon_fbs_tables(repo)
    where, params = _postings_filter_sql(
        user_id=user_id, source_id=source_id, tab=tab, search=search
    )
    safe_page = max(int(page), 1)
    safe_size = min(max(int(page_size), 1), 200)
    offset = (safe_page - 1) * safe_size
    with repo._connect() as conn:
        total_row = conn.execute(
            repo._sql(f"SELECT COUNT(*) AS n FROM ozon_fbs_postings WHERE {where}"),
            tuple(params),
        ).fetchone()
        rows = conn.execute(
            repo._sql(
                f"""
                SELECT * FROM ozon_fbs_postings
                WHERE {where}
                ORDER BY created_at_ozon DESC NULLS LAST, posting_number DESC
                LIMIT ? OFFSET ?
                """
            ),
            tuple(params + [safe_size, offset]),
        ).fetchall()
    name_map = repo.get_product_name_by_article(user_id=user_id)
    ozon_sku_map = repo.get_product_name_by_ozon_sku(user_id=user_id)
    barcode_map = repo.get_product_barcodes_map(user_id=user_id)
    photo_map = repo.get_product_photo_map(user_id=user_id)
    items: list[dict[str, Any]] = []
    for row in rows:
        d = repo._row_to_dict(row)
        article = str(d.get("offer_id") or "").strip()
        sku = str(d.get("sku") or "").strip()
        enrich_posting_product_display(
            d,
            name_by_article=name_map,
            name_by_ozon_sku=ozon_sku_map,
        )
        d["product_photo"] = photo_map.get(article) or photo_map.get(sku) or ""
        # Prefer photo of first brief line when stored columns miss article.
        if not d["product_photo"] and d.get("products_brief"):
            first = d["products_brief"][0]
            fa = str(first.get("offer_id") or "").strip()
            fs = str(first.get("sku") or "").strip()
            d["product_photo"] = photo_map.get(fa) or photo_map.get(fs) or ""
        d["tab_label"] = TAB_LABELS.get(str(d.get("tab") or ""), str(d.get("tab") or ""))
        d["status_label"] = ozon_status_label_ru(d.get("status"))
        try:
            stored_barcodes = json.loads(d.get("barcodes_json") or "[]")
        except json.JSONDecodeError:
            stored_barcodes = []
        if not isinstance(stored_barcodes, list):
            stored_barcodes = []
        d["barcodes"] = resolve_product_barcodes(
            offer_id=article,
            sku=sku,
            barcode_map=barcode_map,
            fallback=stored_barcodes,
        )
        try:
            price = int(d.get("price") or 0)
        except (TypeError, ValueError):
            price = 0
        d["price_display"] = f"{price:,}".replace(",", " ") + " ₽" if price else "—"
        d["warehouse_label"] = str(d.get("warehouse_name") or "").strip() or "—"
        # Pre-ship GTD/юрлицо badge for «Ожидают сборки» (no extra Ozon calls).
        gtd_needed = posting_requires_pre_ship_gtd(d)
        d["pre_ship_gtd_required"] = gtd_needed
        d["marking_gtd_number"] = str(d.get("marking_gtd_number") or "").strip()
        d["marking_ozon_synced"] = bool(d.get("marking_ozon_synced"))
        if gtd_needed:
            d["pre_ship_exemplar_badge"] = (
                "ok" if d["marking_ozon_synced"] else "needed"
            )
        else:
            d["pre_ship_exemplar_badge"] = ""
        items.append(d)
    counts = _tab_counts(repo, user_id=user_id, source_id=source_id)
    return {
        "items": items,
        "total": int(total_row["n"]) if total_row else 0,
        "page": safe_page,
        "page_size": safe_size,
        "counts": counts,
    }


# Full posting: 0124861120-0199-1  |  order number (no package suffix): 0124861120-0199
_POSTING_NUMBER_QUERY_RE = re.compile(r"^\d{6,}-\d{3,}-\d{1,4}$")
_ORDER_NUMBER_QUERY_RE = re.compile(r"^\d{6,}-\d{3,}$")


def parse_posting_number_query(search: object) -> str:
    """Normalize toolbar find query: full posting, order number, or new ``ii…`` scanit."""
    q = re.sub(r"\s+", "", str(search or "").strip())
    if _POSTING_NUMBER_QUERY_RE.fullmatch(q) or _ORDER_NUMBER_QUERY_RE.fullmatch(q):
        return q
    if looks_like_ozon_scanit(q):
        return q
    return ""


def posting_search_digit_tail(search: object) -> str:
    """Last-4 posting/supply digits for list/modal SEARCH boxes only.

    Empty for instance labels (``ii…``) and package QR (12+ digits) so a
    sticker code never becomes a posting-tail query.
    """
    q = re.sub(r"\s+", "", str(search or "").strip())
    if not q or looks_like_ozon_scanit(q):
        return ""
    digits = re.sub(r"\D+", "", q)
    if len(digits) >= 12 and digits == q:
        return ""
    if 4 <= len(digits) <= 8:
        return digits[-4:]
    return ""


def is_ozon_order_number_query(search: object) -> bool:
    """True for order-number form without package suffix (…-0059, not …-0059-1)."""
    q = re.sub(r"\s+", "", str(search or "").strip())
    return bool(_ORDER_NUMBER_QUERY_RE.fullmatch(q))


def get_posting_by_number(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    posting_number: str,
) -> dict[str, Any] | None:
    """Exact local lookup across all tabs by posting_number."""
    ensure_ozon_fbs_tables(repo)
    pn = str(posting_number or "").strip()
    if not pn:
        return None
    with repo._connect() as conn:
        row = conn.execute(
            repo._sql(
                """
                SELECT * FROM ozon_fbs_postings
                WHERE user_id = ? AND source_id = ? AND posting_number ILIKE ?
                LIMIT 1
                """
            ),
            (user_id, int(source_id), pn),
        ).fetchone()
    if not row:
        return None
    d = repo._row_to_dict(row)
    # Prefer exact casefold match if ILIKE returned a loose hit (should be exact).
    if str(d.get("posting_number") or "").strip().casefold() != pn.casefold():
        return None
    return d


def list_postings_by_number_query(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    query: str,
    limit: int = 50,
) -> list[dict[str, Any]]:
    """Local rows for toolbar find: exact posting, order_number, or package siblings.

    ``0133209311-0059`` matches ``0133209311-0059-1``, ``…-2``, … via
    ``posting_number LIKE 'query-%'`` and/or ``order_number``.
    """
    ensure_ozon_fbs_tables(repo)
    q = str(query or "").strip()
    if not q:
        return []
    safe_limit = max(1, min(int(limit or 50), 50))
    child_like = f"{q}-%"
    with repo._connect() as conn:
        rows = conn.execute(
            repo._sql(
                """
                SELECT * FROM ozon_fbs_postings
                WHERE user_id = ? AND source_id = ?
                  AND (
                    posting_number ILIKE ?
                    OR order_number ILIKE ?
                    OR posting_number ILIKE ?
                  )
                ORDER BY posting_number ASC
                LIMIT ?
                """
            ),
            (int(user_id), int(source_id), q, q, child_like, safe_limit),
        ).fetchall()
    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    for row in rows:
        d = repo._row_to_dict(row)
        pn = str(d.get("posting_number") or "").strip()
        if not pn or pn.casefold() in seen:
            continue
        seen.add(pn.casefold())
        out.append(d)
    return out


def _enrich_posting_list_item(
    repo: ReviewRepository,
    *,
    user_id: int,
    row: dict[str, Any],
    name_map: dict[str, str] | None = None,
    ozon_sku_map: dict[str, str] | None = None,
    barcode_map: dict[str, list[str]] | None = None,
    photo_map: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Same enrichment as ``list_postings`` for a single DB row."""
    d = dict(row)
    names = name_map if name_map is not None else repo.get_product_name_by_article(user_id=user_id)
    sku_names = (
        ozon_sku_map
        if ozon_sku_map is not None
        else repo.get_product_name_by_ozon_sku(user_id=user_id)
    )
    barcodes = (
        barcode_map
        if barcode_map is not None
        else repo.get_product_barcodes_map(user_id=user_id)
    )
    photos = photo_map if photo_map is not None else repo.get_product_photo_map(user_id=user_id)
    article = str(d.get("offer_id") or "").strip()
    sku = str(d.get("sku") or "").strip()
    enrich_posting_product_display(
        d,
        name_by_article=names,
        name_by_ozon_sku=sku_names,
    )
    d["product_photo"] = photos.get(article) or photos.get(sku) or ""
    if not d["product_photo"] and d.get("products_brief"):
        first = d["products_brief"][0]
        fa = str(first.get("offer_id") or "").strip()
        fs = str(first.get("sku") or "").strip()
        d["product_photo"] = photos.get(fa) or photos.get(fs) or ""
    d["tab_label"] = TAB_LABELS.get(str(d.get("tab") or ""), str(d.get("tab") or ""))
    d["status_label"] = ozon_status_label_ru(d.get("status"))
    try:
        stored_barcodes = json.loads(d.get("barcodes_json") or "[]")
    except json.JSONDecodeError:
        stored_barcodes = []
    if not isinstance(stored_barcodes, list):
        stored_barcodes = []
    d["barcodes"] = resolve_product_barcodes(
        offer_id=article,
        sku=sku,
        barcode_map=barcodes,
        fallback=stored_barcodes,
    )
    try:
        price = int(d.get("price") or 0)
    except (TypeError, ValueError):
        price = 0
    d["price_display"] = f"{price:,}".replace(",", " ") + " ₽" if price else "—"
    d["warehouse_label"] = str(d.get("warehouse_name") or "").strip() or "—"
    return d


def refresh_posting_status_only(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    posting_number: str,
    remote_status: object,
) -> dict[str, Any] | None:
    """Write only ``status`` / ``tab`` from Ozon. Never touch supply / marking / stickers.

    Uses ``resolve_upsert_status`` so a stale Ozon ``awaiting_deliver`` cannot
    bounce a locally advanced ``delivering`` posting back to «Ожидают отгрузки»
    (same guard as sync upsert). Search-by-number must not create the illusion
    of a new supply on awaiting_deliver for an unchanged supply_id.
    """
    ensure_ozon_fbs_tables(repo)
    pn = str(posting_number or "").strip()
    if not pn:
        return None
    remote = str(remote_status or "").strip().lower()
    if not remote:
        return get_posting_by_number(
            repo, user_id=user_id, source_id=source_id, posting_number=pn
        )

    local = get_posting_by_number(
        repo, user_id=user_id, source_id=source_id, posting_number=pn
    )
    if not local:
        return None

    status, tab = resolve_upsert_status(
        local_status=local.get("status"),
        local_tab=local.get("tab"),
        remote_status=remote,
    )
    local_status = str(local.get("status") or "").strip().lower()
    local_tab = str(local.get("tab") or "").strip().lower()
    if status == local_status and tab == local_tab:
        return local

    with repo._connect() as conn:
        conn.execute(
            repo._sql(
                """
                UPDATE ozon_fbs_postings
                SET status = ?, tab = ?, synced_at = ?
                WHERE user_id = ? AND source_id = ? AND posting_number ILIKE ?
                """
            ),
            (status, tab, _utc_now(), user_id, int(source_id), pn),
        )
    return get_posting_by_number(
        repo, user_id=user_id, source_id=source_id, posting_number=pn
    )


# Chunk size for status-check bulk UPDATE (list → DB). Keeps statements bounded.
OZON_FBS_STATUS_APPLY_CHUNK = 500


def batch_apply_remote_statuses_for_delivering(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    remote_by_pn: dict[str, str],
    progress: Callable[[int, int, str], None] | None = None,
    should_stop: Callable[[], bool] | None = None,
    checked_base: int = 0,
    total_hint: int = 0,
) -> dict[str, Any]:
    """Bulk-write remote statuses for rows still on ``delivering``.

    Groups by resolved ``(status, tab)`` and runs ``UPDATE … IN (…)`` chunks.
    Race-safe: ``WHERE tab = delivering`` — rows already moved by an operator
    are skipped (rowcount 0). No per-row SELECT.
    """
    ensure_ozon_fbs_tables(repo)
    groups: dict[tuple[str, str], list[str]] = {}
    noop = 0
    for raw_pn, raw_st in (remote_by_pn or {}).items():
        pn = str(raw_pn or "").strip()
        remote = str(raw_st or "").strip().lower()
        if not pn or not remote:
            continue
        status, tab = resolve_upsert_status(
            local_status=TAB_DELIVERING,
            local_tab=TAB_DELIVERING,
            remote_status=remote,
        )
        if tab == TAB_DELIVERING:
            # Still on delivering (incl. anti-regression) — nothing to write.
            noop += 1
            continue
        groups.setdefault((status, tab), []).append(pn)

    # Flatten work list for progress / stop between chunks.
    work: list[tuple[str, str, list[str]]] = []
    for (status, tab), pns in groups.items():
        for i in range(0, len(pns), OZON_FBS_STATUS_APPLY_CHUNK):
            work.append((status, tab, pns[i : i + OZON_FBS_STATUS_APPLY_CHUNK]))

    updated = 0
    applied = 0
    stopped = False
    now = _utc_now()
    uid = int(user_id)
    src = int(source_id)
    hint = max(int(total_hint or 0), 1)

    if progress and (noop or work):
        progress(
            checked_base + noop,
            hint,
            f"Запись в БД: к переносу {sum(len(c) for _, _, c in work)}…",
        )

    with repo._connect() as conn:
        for status, tab, chunk in work:
            if should_stop and should_stop():
                stopped = True
                break
            placeholders = ", ".join("?" for _ in chunk)
            cur = conn.execute(
                repo._sql(
                    f"""
                    UPDATE ozon_fbs_postings
                    SET status = ?, tab = ?, synced_at = ?
                    WHERE user_id = ? AND source_id = ?
                      AND tab = ?
                      AND posting_number IN ({placeholders})
                    """
                ),
                (status, tab, now, uid, src, TAB_DELIVERING, *chunk),
            )
            try:
                n = int(getattr(cur, "rowcount", 0) or 0)
            except (TypeError, ValueError):
                n = 0
            if n < 0:
                n = len(chunk)
            updated += min(n, len(chunk))
            applied += len(chunk)
            if progress:
                progress(
                    checked_base + noop + applied,
                    hint,
                    f"Запись в БД… {noop + applied} "
                    f"(перенесено {updated})",
                )

    return {
        "checked": noop + applied,
        "updated": updated,
        "noop": noop,
        "stopped": stopped,
        "errors": 0,
    }


def format_lookup_datetime(value: object) -> str:
    """Operator-facing datetime for search cards (MSK ``DD.MM.YYYY HH:MM``)."""
    if value is None:
        return ""
    dt: datetime | None
    if isinstance(value, datetime):
        dt = value
    else:
        text = str(value or "").strip()
        if not text:
            return ""
        # Date-only from Ozon (warehouse_date / shipment_date).
        if len(text) == 10 and text[4] == "-" and text[7] == "-":
            try:
                d = datetime.strptime(text, "%Y-%m-%d").date()
                return d.strftime("%d.%m.%Y")
            except ValueError:
                return text
        try:
            dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
        except Exception:
            return text
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    try:
        from zoneinfo import ZoneInfo

        dt = dt.astimezone(ZoneInfo("Europe/Moscow"))
    except Exception:
        dt = dt.astimezone(UTC)
    return dt.strftime("%d.%m.%Y %H:%M")


def format_warehouse_date(value: object) -> str:
    """Format Ozon ``warehouse_date`` (creation date in warehouse TZ).

    Docs type it as plain string. When time is present without an offset we keep
    it as-is (warehouse-local), so we do not shift a local clock to MSK.
    Date-only values stay date-only. Values with an explicit offset/Z convert to MSK.
    """
    if value is None:
        return ""
    if isinstance(value, datetime):
        return format_lookup_datetime(value)
    text = str(value or "").strip()
    if not text:
        return ""
    if len(text) == 10 and text[4] == "-" and text[7] == "-":
        try:
            d = datetime.strptime(text, "%Y-%m-%d").date()
            return d.strftime("%d.%m.%Y")
        except ValueError:
            return text
    # Space-separated local datetime from warehouse TZ: keep clock as sent.
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%d.%m.%Y %H:%M:%S", "%d.%m.%Y %H:%M"):
        try:
            local_dt = datetime.strptime(text, fmt)
            return local_dt.strftime("%d.%m.%Y %H:%M")
        except ValueError:
            pass
    if "T" in text and not (
        text.endswith("Z") or "+" in text[10:] or text.count("-") > 2
    ):
        # Naive ISO local time — do not assume UTC.
        try:
            local_dt = datetime.fromisoformat(text)
            if local_dt.tzinfo is None:
                return local_dt.strftime("%d.%m.%Y %H:%M")
        except Exception:
            pass
    return format_lookup_datetime(text)


def build_posting_lookup_details(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    row: dict[str, Any],
    remote: dict[str, Any] | None = None,
    client: OzonFbsClient | None = None,
) -> dict[str, Any]:
    """Structured card for toolbar search / sticker lookup (KIZ, pick, GM, status)."""
    _ = (repo, user_id, source_id)
    from . import ozon_fbs_containers as oz_ct
    from . import wb_fbs as wb

    pn = str(row.get("posting_number") or "").strip()
    posting = remote if isinstance(remote, dict) and remote else _posting_payload_from_row(row)
    if not isinstance(posting, dict):
        posting = {}

    offer_id = str(row.get("offer_id") or "").strip()
    product_name = str(row.get("product_name") or "").strip() or offer_id or "—"
    order_number = str(
        row.get("order_number")
        or posting.get("order_number")
        or row.get("order_id")
        or ""
    ).strip()

    status = ""
    if isinstance(remote, dict):
        status = str(remote.get("status") or "").strip().lower()
    if not status:
        status = str(row.get("status") or posting.get("status") or "").strip().lower()
    tab = str(row.get("tab") or compute_tab(status) or "").strip().lower()

    try:
        codes = json.loads(str(row.get("marking_codes_json") or "[]"))
    except json.JSONDecodeError:
        codes = []
    if not isinstance(codes, list):
        codes = []
    kiz_codes = [wb._kiz_code_clean(x) for x in codes if wb._kiz_code_clean(x)]

    sticker = posting_sticker_payload_from_row(row)
    pick_barcode = str(row.get("pick_barcode") or "").strip()
    pick_verified = bool(row.get("pick_verified")) and bool(pick_barcode)

    try:
        container_id = int(row.get("container_id") or 0)
    except (TypeError, ValueError):
        container_id = 0
    container_barcode = str(row.get("container_barcode") or "").strip()
    container_label = container_barcode or (str(container_id) if container_id > 0 else "")
    container_status = ""
    container_status_label = ""
    container_warehouse_date = ""
    container_sc_accepted = False

    if container_id > 0 and client is not None:
        try:
            meta = oz_ct._fetch_container_row(client, container_id=container_id)
        except Exception as exc:
            _log.warning("ozon lookup container get %s: %s", container_id, exc)
            meta = None
        if isinstance(meta, dict):
            container_status = str(meta.get("status") or "").strip().lower()
            container_status_label = str(meta.get("status_label") or "").strip()
            container_warehouse_date = format_warehouse_date(meta.get("warehouse_date"))
            container_sc_accepted = oz_ct.is_sc_accepted_container(meta)
            number = meta.get("container_number")
            if not container_label and number not in (None, "", 0, "0"):
                container_label = str(number)

    return {
        "posting_number": pn,
        "product_name": product_name,
        "offer_id": offer_id,
        "order_number": order_number,
        "supply_id": str(row.get("supply_id") or "").strip(),
        "tab": tab,
        "tab_label": TAB_LABELS.get(tab, tab or "—"),
        "status": status,
        "status_label": ozon_status_label_ru(status),
        "sticker_barcode": normalize_ozon_package_barcode(
            sticker.get("sticker_barcode")
        ),
        "sticker_lower_barcode": normalize_ozon_package_barcode(
            sticker.get("sticker_lower_barcode")
        ),
        "sticker_scanit": normalize_ozon_scanit(sticker.get("sticker_scanit")),
        "kiz_codes": kiz_codes,
        "pick_verified": pick_verified,
        "pick_barcode": pick_barcode,
        "container_id": container_id if container_id > 0 else None,
        "container_label": container_label,
        "container_status": container_status,
        "container_status_label": container_status_label,
        "container_warehouse_date": container_warehouse_date,
        "container_sc_accepted": container_sc_accepted,
        "in_process_at": format_lookup_datetime(
            posting.get("in_process_at") or row.get("in_process_at")
        ),
        "shipment_date": format_lookup_datetime(posting.get("shipment_date")),
        "delivering_date": format_lookup_datetime(posting.get("delivering_date")),
    }


def _lookup_refresh_one_posting(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    local: dict[str, Any],
    client_id: str,
    api_key: str,
    allow_remote: bool,
    shared_client: OzonFbsClient | None = None,
) -> tuple[dict[str, Any], dict[str, Any], OzonFbsClient | None, bool, str]:
    """Refresh one local row from Ozon; return (row, remote, client, refreshed, warning)."""
    pn = str(local.get("posting_number") or "").strip()
    status_refreshed = False
    api_warning = ""
    remote: dict[str, Any] = {}
    api = shared_client
    if not (allow_remote and client_id and api_key and pn):
        return local, remote, api, False, ""
    try:
        if api is None:
            api = OzonFbsClient(client_id, api_key)
        got = api.get_posting(pn)
        if isinstance(got, dict):
            remote = got
        remote_status = str(remote.get("status") or "").strip()
        if remote_status:
            updated = refresh_posting_status_only(
                repo,
                user_id=user_id,
                source_id=source_id,
                posting_number=pn,
                remote_status=remote_status,
            )
            if updated:
                local = updated
                status_refreshed = True
        if remote:
            try:
                apply_posting_sticker_hints(
                    repo,
                    user_id=user_id,
                    source_id=source_id,
                    posting={**remote, "posting_number": pn},
                )
                hints = sticker_fields_from_posting({**remote, "posting_number": pn})
                hint_upper = str(hints.get("sticker_barcode") or "").strip()
                hint_lower = str(hints.get("sticker_lower_barcode") or "").strip()
                hint_scanit = str(hints.get("sticker_scanit") or "").strip()
                if hint_upper or hint_lower or hint_scanit:
                    patched = dict(local)
                    if hint_upper and ozon_package_barcode_is_blank(
                        patched.get("sticker_barcode")
                    ):
                        patched["sticker_barcode"] = hint_upper
                    if hint_lower and ozon_package_barcode_is_blank(
                        patched.get("sticker_lower_barcode")
                    ):
                        patched["sticker_lower_barcode"] = hint_lower
                    if hint_scanit and not normalize_ozon_scanit(
                        patched.get("sticker_scanit")
                    ):
                        patched["sticker_scanit"] = hint_scanit
                    local = patched
            except Exception as heal_exc:
                _log.warning(
                    "ozon_fbs lookup sticker heal failed pn=%s: %s", pn, heal_exc
                )
    except Exception as exc:
        _log.warning("ozon_fbs lookup status refresh failed pn=%s: %s", pn, exc)
        api_warning = "Статус из базы (Ozon API недоступен)"
        api = None
    return local, remote, api, status_refreshed, api_warning


def lookup_posting_by_number(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    posting_number: str,
    client_id: str | None = None,
    api_key: str | None = None,
    allow_remote: bool = True,
) -> dict[str, Any]:
    """Find posting(s) locally; refresh status from Ozon API when credentials allow.

    Accepts full ``posting_number`` (…-0059-1), order number (…-0059), or the
    new instance label (``ii…`` / ``scanit``). Order number returns all package
    siblings (…-1, …-2, …) stacked for the toolbar search.

    Local marking / supply_id are kept. ``status`` and ``tab`` are updated from
    ``/v3/posting/fbs/get``. Empty or placeholder package stickers (``"0"``)
    may be filled from Ozon ``barcodes`` / ``scanit``; real sticker values are
    not overwritten.
    """
    ensure_ozon_fbs_tables(repo)
    pn = parse_posting_number_query(posting_number) or str(posting_number or "").strip()
    sid = int(source_id)
    counts = _tab_counts(repo, user_id=user_id, source_id=sid)
    if not pn:
        return {
            "found": False,
            "source": "none",
            "posting_number": "",
            "tab": "",
            "item": None,
            "items": [],
            "match_count": 0,
            "counts": counts,
            "status_refreshed": False,
            "message": (
                "Укажите номер отправления, заказа или этикетки "
                "(например 0124861120-0199-1, 0124861120-0199 или ii…)"
            ),
        }

    scanit_query = looks_like_ozon_scanit(pn)
    order_query = (not scanit_query) and is_ozon_order_number_query(pn)
    if scanit_query:
        from . import ozon_fbs_stickers as oz_st

        found = oz_st.find_postings_by_sticker_scan(
            repo, user_id=user_id, source_id=sid, scan=pn
        )
        match_rows: list[dict[str, Any]] = []
        found_row = found.get("row")
        if isinstance(found_row, dict):
            match_rows = [found_row]
        elif found.get("ambiguous"):
            match_rows = [
                m for m in (found.get("matches") or []) if isinstance(m, dict)
            ]
        local_rows = []
        seen_pn: set[str] = set()
        for match in match_rows:
            one_pn = str(match.get("posting_number") or "").strip()
            if not one_pn or one_pn.casefold() in seen_pn:
                continue
            seen_pn.add(one_pn.casefold())
            full = get_posting_by_number(
                repo, user_id=user_id, source_id=sid, posting_number=one_pn
            )
            local_rows.append(full or match)
    elif order_query:
        local_rows = list_postings_by_number_query(
            repo, user_id=user_id, source_id=sid, query=pn
        )
    else:
        one = get_posting_by_number(
            repo, user_id=user_id, source_id=sid, posting_number=pn
        )
        local_rows = [one] if one else []

    if not local_rows:
        if scanit_query:
            miss_msg = f"Этикетка {pn} не найдена в локальной базе"
        elif order_query:
            miss_msg = f"Заказ {pn} не найден в локальной базе"
        else:
            miss_msg = f"Отправление {pn} не найдено в локальной базе"
        return {
            "found": False,
            "source": "none",
            "posting_number": pn,
            "tab": "",
            "item": None,
            "items": [],
            "match_count": 0,
            "counts": counts,
            "status_refreshed": False,
            "message": miss_msg,
        }

    cid = str(client_id or "").strip()
    key = str(api_key or "").strip()
    items: list[dict[str, Any]] = []
    details_first: dict[str, Any] | None = None
    any_refreshed = False
    api_warning = ""
    shared_client: OzonFbsClient | None = None

    for idx, row0 in enumerate(local_rows):
        local, remote, shared_client, refreshed, warn = _lookup_refresh_one_posting(
            repo,
            user_id=user_id,
            source_id=sid,
            local=row0,
            client_id=cid,
            api_key=key,
            allow_remote=allow_remote,
            shared_client=shared_client,
        )
        if refreshed:
            any_refreshed = True
        if warn and not api_warning:
            api_warning = warn
        item = _enrich_posting_list_item(repo, user_id=user_id, row=local)
        details = build_posting_lookup_details(
            repo,
            user_id=user_id,
            source_id=sid,
            row=local,
            remote=remote or None,
            client=shared_client,
        )
        if details.get("status_label"):
            item["status_label"] = details["status_label"]
            item["status"] = details.get("status") or item.get("status")
        items.append(item)
        if idx == 0:
            details_first = details

    if any_refreshed:
        counts = _tab_counts(repo, user_id=user_id, source_id=sid)

    source = "local+api" if any_refreshed else "local"
    message = api_warning
    if any_refreshed:
        message = "Статус обновлён из Ozon"
    elif len(items) > 1:
        message = f"Найдено отправлений: {len(items)}"

    first = items[0]
    return {
        "found": True,
        "source": source,
        "posting_number": str(first.get("posting_number") or pn),
        "query": pn,
        "tab": str(first.get("tab") or ""),
        "item": first,
        "items": items,
        "match_count": len(items),
        # Detail card only for a single hit; multi shows stacked table rows.
        "details": details_first if len(items) == 1 else None,
        "counts": counts,
        "status_refreshed": any_refreshed,
        "message": message,
    }


def unpack_posting_list_page(
    page: object,
) -> tuple[list[dict[str, Any]], bool, str]:
    """Normalize a list page to ``(postings, has_next, cursor)``.

    Callers that still return a 2-tuple ``(postings, has_next)`` stay valid:
    the next cursor is empty, so pagination stops after that page.
    """
    if not isinstance(page, tuple):
        return [], False, ""
    raw_postings = page[0] if len(page) >= 1 else []
    has_next = bool(page[1]) if len(page) >= 2 else False
    cursor = str(page[2] or "").strip() if len(page) >= 3 else ""
    if not isinstance(raw_postings, list):
        raw_postings = []
    clean = [p for p in raw_postings if isinstance(p, dict)]
    if not has_next:
        cursor = ""
    return clean, has_next, cursor


def sync_ozon_fbs_source(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    client_id: str,
    api_key: str,
    stop_requested: Callable[[], bool] | None = None,
    progress: Callable[[str, int], None] | None = None,
    lookback_days: int = DEFAULT_LOOKBACK_DAYS,
) -> dict[str, Any]:
    ensure_ozon_fbs_tables(repo)
    client = OzonFbsClient(client_id, api_key)
    stopped = False
    seen: set[str] = set()
    errors: list[str] = []

    def _stopped() -> bool:
        return bool(stop_requested and stop_requested())

    def _prog(msg: str) -> None:
        if progress:
            progress(msg, len(seen))

    date_to = datetime.now(UTC)
    date_from = date_to - timedelta(days=max(1, min(int(lookback_days), 90)))

    # Catalog «Требует КИЗ» once per source. Written into the same raw_json that
    # sync upserts — otherwise modal open re-runs N×40 flag upserts after wipe.
    # On map failure skip apply so we do not stamp false «checked» empties.
    catalog_kiz_ready = False
    requires_kiz_map: dict[str, bool] = {}
    try:
        requires_kiz_map = repo.get_product_requires_kiz_map(user_id=user_id)
        catalog_kiz_ready = True
        _prog("Синхронизация… + каталог КИЗ")
    except Exception as exc:
        _log.warning(
            "ozon_fbs catalog kiz map failed user=%s source=%s: %s",
            user_id,
            source_id,
            exc,
        )

    for status in SYNC_STATUSES:
        if _stopped():
            stopped = True
            break
        label = TAB_LABELS.get(compute_tab(status), status)
        cursor = ""
        pages = 0
        while pages < 200:
            if _stopped():
                stopped = True
                break
            try:
                postings, has_next, next_cursor = unpack_posting_list_page(
                    client.list_postings_page(
                        status=status,
                        since=date_from,
                        to=date_to,
                        limit=50,
                        cursor=cursor,
                    )
                )
            except Exception as exc:
                _log.warning("ozon_fbs list %s failed: %s", status, exc)
                errors.append(f"{label}: {exc}")
                break
            if not postings:
                break
            for posting in postings:
                pn = str(posting.get("posting_number") or "").strip()
                if not pn:
                    continue
                to_save = posting
                if catalog_kiz_ready and isinstance(posting, dict):
                    to_save = apply_catalog_marking_flags(posting, requires_kiz_map)
                upsert_posting(
                    repo,
                    user_id=user_id,
                    source_id=source_id,
                    posting=to_save,
                    ensure_tables=False,
                )
                seen.add(pn)
            pages += 1
            _prog(f"{label}… стр. {pages}")
            if not has_next or not next_cursor or next_cursor == cursor:
                break
            cursor = next_cursor
            time.sleep(0.25)
        time.sleep(0.15)

    repo.mark_supply_source_synced(source_id=source_id)

    # Stock stays on the operator move. «Перенести в доставку» writes the
    # ledger for that supply; moving it back reverses the rows. Sync only
    # stores Ozon statuses. WB FBS still reconciles from portal status.

    return {
        "postings": len(seen),
        "errors": errors,
        "stopped": stopped,
    }


def _as_positive_int(value: object) -> int | None:
    if value is None or str(value).strip() == "":
        return None
    try:
        n = int(value)
    except (TypeError, ValueError):
        return None
    return n if n > 0 else None


def compute_ozon_fbs_pallet_summary(
    repo: ReviewRepository,
    *,
    user_id: int,
    sources: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Pallets + boxes per Ozon FBS source from «Ожидают сборки» + «Ожидают отгрузки».

    Same formula as WB FBS:
    ``boxes = Σ (qty / box_qty)``
    ``pallets = Σ (qty / box_qty / boxes_per_pallet)``
    Products without ``box_qty`` are skipped; without category ``boxes_per_pallet``
    they still count toward boxes.
    """
    # Reuse WB formatters so labels stay identical in the UI.
    from .wb_fbs import format_boxes_ru, format_pallets_ru

    ensure_ozon_fbs_tables(repo)
    if not sources:
        return []

    products = repo.list_product_photos(user_id=user_id)
    categories = repo.list_product_categories(user_id=user_id, seed_defaults=True)
    cat_boxes: dict[str, int] = {}
    for cat in categories:
        name = str(cat.get("name") or "").strip()
        bpp = _as_positive_int(cat.get("boxes_per_pallet"))
        if name and bpp is not None:
            cat_boxes[name] = bpp

    # article / ozon_sku / casefold → (box_qty, boxes_per_pallet | None)
    product_meta: dict[str, tuple[int, int | None]] = {}
    for prod in products:
        box_qty = _as_positive_int(prod.get("box_qty"))
        if box_qty is None:
            continue
        cat_name = str(prod.get("product_category") or "").strip()
        bpp = cat_boxes.get(cat_name)
        meta = (box_qty, bpp)
        for raw_key in (
            prod.get("supplier_article"),
            prod.get("ozon_sku"),
            prod.get("wb_nmid"),
            prod.get("yandex_offer_id"),
        ):
            key = str(raw_key or "").strip()
            if not key:
                continue
            product_meta[key] = meta
            product_meta[key.casefold()] = meta

    source_names: dict[int, str] = {}
    source_ids: list[int] = []
    for src in sources:
        try:
            sid = int(src.get("source_id") if "source_id" in src else src.get("id"))
        except (TypeError, ValueError):
            continue
        source_ids.append(sid)
        source_names[sid] = str(
            src.get("name") or f"Источник {sid}"
        ).strip() or f"Источник {sid}"

    if not source_ids:
        return []

    placeholders = ", ".join("?" for _ in source_ids)
    with repo._connect() as conn:
        rows = conn.execute(
            repo._sql(
                f"""
                SELECT source_id, offer_id, sku, COALESCE(SUM(quantity), 0) AS qty
                FROM ozon_fbs_postings
                WHERE user_id = ?
                  AND tab IN (?, ?)
                  AND source_id IN ({placeholders})
                GROUP BY source_id, offer_id, sku
                """
            ),
            tuple(
                [
                    user_id,
                    TAB_AWAITING_PACKAGING,
                    TAB_AWAITING_DELIVER,
                    *source_ids,
                ]
            ),
        ).fetchall()

    totals_pallets: dict[int, float] = {sid: 0.0 for sid in source_ids}
    totals_boxes: dict[int, float] = {sid: 0.0 for sid in source_ids}
    for row in rows:
        d = repo._row_to_dict(row)
        try:
            sid = int(d.get("source_id"))
            qty = int(d.get("qty") or 0)
        except (TypeError, ValueError):
            continue
        if sid not in totals_pallets or qty <= 0:
            continue
        offer_id = str(d.get("offer_id") or "").strip()
        sku = str(d.get("sku") or "").strip()
        meta = None
        for key in (offer_id, sku, offer_id.casefold(), sku.casefold()):
            if key and key in product_meta:
                meta = product_meta[key]
                break
        if not meta:
            continue
        box_qty, bpp = meta
        boxes = float(qty) / float(box_qty)
        totals_boxes[sid] += boxes
        if bpp is not None:
            totals_pallets[sid] += boxes / float(bpp)

    summary: list[dict[str, Any]] = []
    for sid in source_ids:
        pallets = round(float(totals_pallets.get(sid) or 0.0) + 1e-12, 2)
        boxes = round(float(totals_boxes.get(sid) or 0.0) + 1e-12, 2)
        pallets_label = format_pallets_ru(pallets)
        boxes_label = format_boxes_ru(boxes)
        summary.append(
            {
                "source_id": sid,
                "name": source_names.get(sid) or f"Источник {sid}",
                "pallets": pallets,
                "boxes": boxes,
                "boxes_label": boxes_label,
                "pallets_label": f"{pallets_label} ({boxes_label})",
            }
        )
    return summary



def compute_ozon_fbs_supply_cargo_summary(
    repo: ReviewRepository,
    *,
    user_id: int,
    orders: list[dict[str, Any]] | None,
) -> dict[str, Any]:
    """Cargo summary for one Ozon FBS supply (postings from supply detail).

    Uses posting ``quantity`` (default 1). Cancelled postings are skipped.
    Same box/pallet formula as the sync banner.
    """
    from .wb_fbs import _product_box_meta_map, summarize_cargo_qty_lines

    product_meta = _product_box_meta_map(repo, user_id=user_id)
    qty_by_group: dict[tuple[str, str], int] = {}
    for order in orders or []:
        if not isinstance(order, dict):
            continue
        if order.get("cancelled") or str(order.get("cancel_reason_label") or "").strip():
            continue
        offer_id = str(order.get("offer_id") or "").strip()
        sku = str(order.get("sku") or "").strip()
        try:
            qty = int(order.get("quantity") or 1)
        except (TypeError, ValueError):
            qty = 1
        if qty <= 0:
            continue
        group = (offer_id, sku)
        qty_by_group[group] = int(qty_by_group.get(group) or 0) + qty
    lines: list[tuple[list[str], int]] = []
    for (offer_id, sku), qty in qty_by_group.items():
        lines.append(([offer_id, sku], int(qty)))
    return summarize_cargo_qty_lines(product_meta, lines)


def get_sync_state() -> dict[str, object]:
    with _ozon_fbs_sync_lock:
        return _copy_sync_state()


def request_sync_stop() -> bool:
    with _ozon_fbs_sync_lock:
        if _ozon_fbs_sync_state.get("in_progress"):
            _ozon_fbs_sync_state["cancel_requested"] = True
            return True
    return False


def _copy_sync_state() -> dict[str, object]:
    """Snapshot sync state for API (deep-copy mutable lists)."""
    st = dict(_ozon_fbs_sync_state)
    st["errors"] = list(_ozon_fbs_sync_state.get("errors") or [])
    st["sources"] = [
        dict(x) if isinstance(x, dict) else x
        for x in (_ozon_fbs_sync_state.get("sources") or [])
    ]
    st["pallet_summary"] = [
        dict(x) if isinstance(x, dict) else x
        for x in (_ozon_fbs_sync_state.get("pallet_summary") or [])
    ]
    st["pallet_summary_error"] = str(
        _ozon_fbs_sync_state.get("pallet_summary_error") or ""
    ).strip()
    st["multi_summary"] = [
        dict(x) if isinstance(x, dict) else x
        for x in (_ozon_fbs_sync_state.get("multi_summary") or [])
    ]
    return st


def start_sync_thread(
    *,
    repo: ReviewRepository,
    user_id: int,
    sources: list[dict[str, Any]],
    lookback_days: int = DEFAULT_LOOKBACK_DAYS,
    is_auto: bool = False,
    actor_user_id: int | None = None,
    actor_name: str = "",
) -> tuple[bool, str]:
    jobs: list[dict[str, Any]] = []
    for raw in sources:
        try:
            sid = int(raw.get("source_id") if "source_id" in raw else raw.get("id"))
        except (TypeError, ValueError):
            continue
        client_id = str(raw.get("client_id") or "").strip()
        api_key = str(raw.get("api_key") or "").strip()
        if not client_id or not api_key:
            continue
        jobs.append(
            {
                "source_id": sid,
                "client_id": client_id,
                "api_key": api_key,
                "name": str(raw.get("name") or f"Источник {sid}"),
            }
        )
    if not jobs:
        return False, "Нет активных источников OZON ФБС с Client-Id и Api-Key"

    source_rows = [
        {
            "source_id": int(j["source_id"]),
            "name": str(j["name"]),
            "status": "pending",
            "message": "Ожидание…",
            "postings": 0,
        }
        for j in jobs
    ]

    with _ozon_fbs_sync_lock:
        if _ozon_fbs_sync_state.get("in_progress"):
            return False, "Синхронизация уже запущена"
        _ozon_fbs_sync_state.update(
            {
                "in_progress": True,
                "synced": 0,
                "total": len(jobs),
                "message": f"Запуск… источников: {len(jobs)}",
                "errors": [],
                "sources": source_rows,
                "pallet_summary": [],
                "pallet_summary_error": "",
                "multi_summary": [],
                "cancel_requested": False,
                "is_auto": bool(is_auto),
            }
        )

    try:
        from . import ozon_fbs_ops_log as ops_log

        kind = "Автосинхронизация" if is_auto else "Синхронизация"
        ops_log.append_event(
            repo,
            user_id=user_id,
            action=ops_log.ACTION_AUTO_SYNC if is_auto else ops_log.ACTION_SYNC_START,
            message=(
                f"{kind} запущена ({len(jobs)} ист., глубина {lookback_days} дн.)"
            ),
            actor_user_id=actor_user_id,
            actor_name=actor_name or ("авто" if is_auto else ""),
            details={
                "sources_count": len(jobs),
                "lookback_days": int(lookback_days),
                "is_auto": bool(is_auto),
            },
        )
    except Exception:
        pass

    def _run() -> None:
        errors: list[str] = []
        synced_sources = 0
        total_postings = 0
        stopped = False
        pallet_summary_error = ""
        try:
            for idx, job in enumerate(jobs):
                with _ozon_fbs_sync_lock:
                    if _ozon_fbs_sync_state.get("cancel_requested"):
                        _ozon_fbs_sync_state["message"] = "Остановка…"
                        stopped = True
                        break
                    row = _ozon_fbs_sync_state["sources"][idx]
                    row["status"] = "running"
                    row["message"] = "Синхронизация…"

                def _progress(msg: str, n: int) -> None:
                    with _ozon_fbs_sync_lock:
                        row = _ozon_fbs_sync_state["sources"][idx]
                        row["message"] = msg
                        row["postings"] = n

                def _stop() -> bool:
                    with _ozon_fbs_sync_lock:
                        return bool(_ozon_fbs_sync_state.get("cancel_requested"))

                try:
                    result = sync_ozon_fbs_source(
                        repo,
                        user_id=user_id,
                        source_id=int(job["source_id"]),
                        client_id=str(job["client_id"]),
                        api_key=str(job["api_key"]),
                        stop_requested=_stop,
                        progress=_progress,
                        lookback_days=lookback_days,
                    )
                    with _ozon_fbs_sync_lock:
                        row = _ozon_fbs_sync_state["sources"][idx]
                        was_stopped = bool(result.get("stopped"))
                        row["status"] = "stopped" if was_stopped else "done"
                        row["postings"] = int(result.get("postings") or 0)
                        row["message"] = (
                            "Остановлено"
                            if was_stopped
                            else f"Готово: {row['postings']} отправлений"
                        )
                        if was_stopped:
                            stopped = True
                        else:
                            synced_sources += 1
                            total_postings += int(row["postings"] or 0)
                        for err in result.get("errors") or []:
                            if isinstance(err, str) and err:
                                errors.append(f"{job['name']}: {err}")
                except Exception as exc:
                    _log.exception("ozon_fbs sync source %s failed", job.get("source_id"))
                    with _ozon_fbs_sync_lock:
                        row = _ozon_fbs_sync_state["sources"][idx]
                        row["status"] = "error"
                        row["message"] = str(exc)
                    errors.append(f"{job['name']}: {exc}")

                with _ozon_fbs_sync_lock:
                    _ozon_fbs_sync_state["synced"] = idx + 1
        finally:
            pallet_summary: list[dict[str, Any]] = []
            multi_summary: list[dict[str, Any]] = []
            saved_done_messages: list[tuple[dict[str, Any], str]] = []
            if synced_sources > 0:
                with _ozon_fbs_sync_lock:
                    for row in _ozon_fbs_sync_state.get("sources") or []:
                        if isinstance(row, dict) and row.get("status") == "done":
                            saved_done_messages.append(
                                (row, str(row.get("message") or ""))
                            )
                            row["message"] = "Считаем паллеты…"
                try:
                    pallet_summary = compute_ozon_fbs_pallet_summary(
                        repo, user_id=user_id, sources=jobs
                    )
                except Exception as exc:
                    _log.exception(
                        "ozon_fbs pallet summary failed user=%s", user_id
                    )
                    pallet_summary = []
                    pallet_summary_error = _PALLET_SUMMARY_ERROR
                    detail = str(exc).strip()
                    if detail and detail not in pallet_summary_error:
                        pallet_summary_error = f"{_PALLET_SUMMARY_ERROR} ({detail})"
                try:
                    from . import ozon_fbs_detail as oz_detail

                    for job in jobs:
                        sid = int(job.get("source_id") or 0)
                        if not sid:
                            continue
                        stats = oz_detail.count_awaiting_packaging_multi(
                            repo, user_id=user_id, source_id=sid
                        )
                        multi_summary.append(
                            {
                                "source_id": sid,
                                "name": str(job.get("name") or f"Источник {sid}"),
                                "multi_count": int(stats.get("multi_posting_count") or 0),
                                "extra_postings": int(stats.get("extra_postings") or 0),
                            }
                        )
                except Exception:
                    _log.exception(
                        "ozon_fbs multi summary failed user=%s", user_id
                    )
                    multi_summary = []
                with _ozon_fbs_sync_lock:
                    for row, msg in saved_done_messages:
                        if row.get("message") == "Считаем паллеты…":
                            row["message"] = msg

            if synced_sources > 0:
                try:
                    repo.mark_ozon_fbs_synced(user_id=user_id, is_auto=bool(is_auto))
                except Exception:
                    _log.warning(
                        "ozon_fbs: failed to update ozon_fbs_last_synced_at for user %s",
                        user_id,
                    )

            with _ozon_fbs_sync_lock:
                _ozon_fbs_sync_state["in_progress"] = False
                _ozon_fbs_sync_state["errors"] = errors
                _ozon_fbs_sync_state["pallet_summary"] = pallet_summary
                _ozon_fbs_sync_state["pallet_summary_error"] = pallet_summary_error
                _ozon_fbs_sync_state["multi_summary"] = multi_summary
                stats_part = (
                    f"Источников: {synced_sources}/{len(jobs)} | "
                    f"Отправлений: {total_postings}"
                )
                if stopped or _ozon_fbs_sync_state.get("cancel_requested"):
                    _ozon_fbs_sync_state["message"] = f"Остановлено. {stats_part}"
                    done_action = "sync_stop"
                    done_level = "warn"
                elif errors:
                    _ozon_fbs_sync_state["message"] = (
                        f"Готово с ошибками. {stats_part}"
                    )
                    done_action = "sync_done"
                    done_level = "warn"
                else:
                    _ozon_fbs_sync_state["message"] = f"Готово. {stats_part}"
                    done_action = "sync_done"
                    done_level = "info"
                final_message = str(_ozon_fbs_sync_state.get("message") or "")
            try:
                from . import ozon_fbs_ops_log as ops_log

                ops_log.append_event(
                    repo,
                    user_id=user_id,
                    action=done_action,
                    message=final_message,
                    level=done_level,
                    actor_user_id=actor_user_id,
                    actor_name=actor_name or ("авто" if is_auto else ""),
                    details={
                        "synced_sources": synced_sources,
                        "total_postings": total_postings,
                        "errors_count": len(errors),
                        "is_auto": bool(is_auto),
                    },
                )
            except Exception:
                pass

    threading.Thread(target=_run, name="ozon-fbs-sync", daemon=True).start()
    kind = "Автосинхронизация" if is_auto else "Синхронизация"
    return True, f"{kind} запущена ({len(jobs)} источников)"


def list_fbs_sync_jobs(repo: ReviewRepository, *, user_id: int) -> list[dict[str, Any]]:
    """Build sync jobs for enabled Ozon FBS sources (name ФБС or legacy ozon_fbs)."""
    jobs: list[dict[str, Any]] = []
    for s in repo.list_supply_sources(user_id=user_id):
        if not s.get("is_enabled"):
            continue
        if not is_ozon_fbs_source(s):
            continue
        src_full = repo.get_supply_source_with_key(user_id=user_id, source_id=int(s["id"]))
        if not src_full:
            continue
        client_id = str(src_full.get("client_id") or "").strip()
        api_key = str(src_full.get("api_key") or "").strip()
        if not client_id or not api_key:
            continue
        jobs.append(
            {
                "source_id": int(s["id"]),
                "name": str(s.get("name") or ""),
                "client_id": client_id,
                "api_key": api_key,
            }
        )
    return jobs


def _parse_hhmm_to_time(value: object, *, default: str) -> dt_time:
    raw = ReviewRepository._normalize_hhmm(value, default=default)
    hour_s, minute_s = raw.split(":", 1)
    return dt_time(hour=int(hour_s), minute=int(minute_s))


def _msk_now() -> datetime:
    return datetime.now(_MSK)


def msk_time_in_active_window(
    *,
    now_msk: datetime | None = None,
    active_from: object = "12:00",
    active_to: object = "06:00",
) -> bool:
    """True if MSK local time is inside [from, to]; supports overnight windows."""
    now = now_msk or _msk_now()
    start = _parse_hhmm_to_time(active_from, default="12:00")
    end = _parse_hhmm_to_time(active_to, default="06:00")
    current = now.astimezone(_MSK).time().replace(second=0, microsecond=0)
    if start == end:
        return True
    if start < end:
        return start <= current <= end
    return current >= start or current <= end


def auto_sync_is_due(
    *,
    last_synced_at: str | None,
    interval_minutes: int | None = None,
) -> bool:
    if not last_synced_at:
        return True
    try:
        last_dt = datetime.fromisoformat(str(last_synced_at).replace("Z", "+00:00"))
    except ValueError:
        return True
    if last_dt.tzinfo is None:
        last_dt = last_dt.replace(tzinfo=UTC)
    minutes = max(1, int(interval_minutes or 1))
    return (datetime.now(UTC) - last_dt).total_seconds() >= float(minutes) * 60.0


def _manual_sync_block_bounds(
    settings: Mapping[str, Any] | None,
) -> tuple[str, str] | None:
    """Normalized (from, to) when block is enabled with a real interval; else None."""
    row = settings or {}
    if not bool(row.get("manual_sync_block_enabled")):
        return None
    from_s = ReviewRepository._normalize_hhmm(
        row.get("manual_sync_block_from"), default="00:00"
    )
    to_s = ReviewRepository._normalize_hhmm(
        row.get("manual_sync_block_to"), default="00:00"
    )
    if from_s == to_s:
        return None
    return from_s, to_s


def manual_sync_blocked_now(
    settings: Mapping[str, Any] | None,
    *,
    now_msk: datetime | None = None,
) -> bool:
    """Whether the Sync button must be disabled for all users right now.

    Requires a real interval (from != to). Equal bounds are treated as
    «no interval» so a default 00:00–00:00 cannot lock Sync all day by accident.
    """
    bounds = _manual_sync_block_bounds(settings)
    if not bounds:
        return False
    from_s, to_s = bounds
    return msk_time_in_active_window(
        now_msk=now_msk,
        active_from=from_s,
        active_to=to_s,
    )


def manual_sync_block_until_msk(
    settings: Mapping[str, Any] | None,
    *,
    now_msk: datetime | None = None,
) -> datetime | None:
    """End of the current block window in MSK, or None if not blocked now."""
    bounds = _manual_sync_block_bounds(settings)
    if not bounds:
        return None
    from_s, to_s = bounds
    now = (now_msk or _msk_now()).astimezone(_MSK)
    if not msk_time_in_active_window(
        now_msk=now, active_from=from_s, active_to=to_s
    ):
        return None
    end = _parse_hhmm_to_time(to_s, default="00:00")
    start = _parse_hhmm_to_time(from_s, default="00:00")
    end_dt = datetime.combine(now.date(), end, tzinfo=_MSK)
    if start < end:
        # Same-day window: end is today at ``to``.
        return end_dt
    # Overnight: evening → tomorrow ``to``; early morning → today ``to``.
    if now.time().replace(second=0, microsecond=0) >= start:
        return end_dt + timedelta(days=1)
    return end_dt


def manual_sync_block_payload(
    settings: Mapping[str, Any] | None,
    *,
    now_msk: datetime | None = None,
) -> dict[str, Any]:
    row = dict(settings or {})
    bounds = _manual_sync_block_bounds(row)
    from_s = bounds[0] if bounds else ReviewRepository._normalize_hhmm(
        row.get("manual_sync_block_from"), default="00:00"
    )
    to_s = bounds[1] if bounds else ReviewRepository._normalize_hhmm(
        row.get("manual_sync_block_to"), default="00:00"
    )
    until = manual_sync_block_until_msk(row, now_msk=now_msk)
    blocked = until is not None
    if blocked and until is not None:
        message = (
            "Кнопка заблокирована до "
            f"{until.strftime('%d.%m.%Y %H:%M')} (МСК)"
        )
        until_iso = until.isoformat()
    else:
        message = ""
        until_iso = None
    return {
        "manual_sync_block_enabled": bool(row.get("manual_sync_block_enabled")),
        "manual_sync_block_from": from_s,
        "manual_sync_block_to": to_s,
        "manual_sync_blocked": blocked,
        "manual_sync_block_until": until_iso,
        "manual_sync_block_message": message,
    }


class OzonFbsScheduler:
    """Background auto-sync for Ozon FBS only (no assembly / no WB FBS coupling)."""

    def __init__(self, repository: ReviewRepository) -> None:
        self.repository = repository
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()

    def start(self) -> None:
        with self._lock:
            if self._thread and self._thread.is_alive():
                return
            self._stop_event.clear()
            self._thread = threading.Thread(
                target=self._loop,
                name="feedpilot-ozon-fbs-scheduler",
                daemon=True,
            )
            self._thread.start()
            _log.info("OzonFbsScheduler: started")

    def stop(self) -> None:
        self._stop_event.set()

    def _loop(self) -> None:
        check_interval = 60
        while not self._stop_event.is_set():
            self._stop_event.wait(check_interval)
            if self._stop_event.is_set():
                break
            try:
                self._run_due_owners()
            except Exception as exc:
                _log.warning("OzonFbsScheduler loop error: %s", exc)

    def _run_due_owners(self) -> None:
        if get_sync_state().get("in_progress"):
            return
        try:
            users = self.repository.list_users(owner_only=True)
        except Exception:
            return
        for user in users:
            if self._stop_event.is_set() or get_sync_state().get("in_progress"):
                return
            user_id = int(user.get("id") or 0)
            if not user_id:
                continue
            try:
                settings = self.repository.get_ozon_fbs_sync_settings(user_id=user_id)
            except Exception:
                continue
            if not settings.get("enabled"):
                continue
            if not msk_time_in_active_window(
                active_from=settings.get("active_from"),
                active_to=settings.get("active_to"),
            ):
                continue
            interval_minutes = int(settings.get("interval_minutes") or 60)
            if not auto_sync_is_due(
                last_synced_at=settings.get("last_synced_at"),
                interval_minutes=interval_minutes,
            ):
                continue
            try:
                jobs = list_fbs_sync_jobs(self.repository, user_id=user_id)
            except Exception as exc:
                _log.warning(
                    "OzonFbsScheduler user %s list jobs error: %s", user_id, exc
                )
                continue
            if not jobs:
                continue
            lookback_days = int(settings.get("lookback_days") or DEFAULT_LOOKBACK_DAYS)
            ok, message = start_sync_thread(
                repo=self.repository,
                user_id=user_id,
                sources=jobs,
                lookback_days=lookback_days,
                is_auto=True,
                actor_name="авто",
            )
            if ok:
                _log.info(
                    "OzonFbsScheduler: started auto-sync user=%s sources=%s interval=%sm",
                    user_id,
                    len(jobs),
                    interval_minutes,
                )
            else:
                _log.info(
                    "OzonFbsScheduler: skip sync user=%s (%s)",
                    user_id,
                    message,
                )
