"""Ozon FBS posting detail: ship, stickers, picking helpers."""
from __future__ import annotations

import json
import logging
from typing import Any

from . import ozon_fbs as oz
from .repository import ReviewRepository

_log = logging.getLogger(__name__)


def get_posting_row(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    posting_number: str,
) -> dict[str, Any] | None:
    oz.ensure_ozon_fbs_tables(repo)
    with repo._connect() as conn:
        row = conn.execute(
            repo._sql(
                """
                SELECT * FROM ozon_fbs_postings
                WHERE user_id = ? AND source_id = ? AND posting_number = ?
                """
            ),
            (user_id, source_id, str(posting_number)),
        ).fetchone()
    return repo._row_to_dict(row) if row else None


def _products_from_posting_payload(posting: dict[str, Any]) -> list[dict[str, Any]]:
    products_raw = posting.get("products")
    if isinstance(products_raw, list) and products_raw:
        return [p for p in products_raw if isinstance(p, dict)]
    try:
        parsed = json.loads(str(posting.get("products_json") or "[]"))
        return [p for p in parsed if isinstance(p, dict)] if isinstance(parsed, list) else []
    except json.JSONDecodeError:
        return []


def posting_ship_unit_count(posting: dict[str, Any]) -> int:
    """How many physical units (and thus packages) ship will create."""
    total = 0
    for p in _products_from_posting_payload(posting):
        product_id = p.get("sku") if p.get("sku") is not None else p.get("product_id")
        try:
            int(product_id)
        except (TypeError, ValueError):
            continue
        try:
            qty = int(p.get("quantity") or 1)
        except (TypeError, ValueError):
            qty = 1
        total += max(qty, 1)
    if total > 0:
        return total
    try:
        return max(int(posting.get("quantity") or 1), 1)
    except (TypeError, ValueError):
        return 1


def ship_split_preview(rows: list[dict[str, Any]]) -> dict[str, int]:
    """Stats for UI: multi-unit postings → extra sibling postings after ship."""
    multi = 0
    units_total = 0
    for row in rows:
        if not isinstance(row, dict):
            continue
        units = posting_ship_unit_count(row)
        units_total += units
        if units > 1:
            multi += 1
    n = sum(1 for row in rows if isinstance(row, dict))
    result = units_total if n else 0
    return {
        "multi_posting_count": multi,
        "result_posting_count": result,
        "extra_postings": max(result - n, 0),
    }


def build_ship_packages(posting: dict[str, Any]) -> list[dict[str, Any]]:
    """Build ``/v4/posting/fbs/ship`` packages — one package with all products.

    Multi-unit orders must be split earlier via ``/v1/posting/fbs/split``;
    ship does not divide postings.
    """
    products = _products_from_posting_payload(posting)
    package_products: list[dict[str, Any]] = []
    for p in products:
        product_id = p.get("sku") if p.get("sku") is not None else p.get("product_id")
        try:
            pid = int(product_id)
        except (TypeError, ValueError):
            continue
        try:
            qty = int(p.get("quantity") or 1)
        except (TypeError, ValueError):
            qty = 1
        package_products.append({"product_id": pid, "quantity": max(qty, 1)})
    if not package_products:
        raise RuntimeError("Нет товаров для сборки отправления")
    return [{"products": package_products}]


def build_split_postings(posting: dict[str, Any]) -> list[dict[str, Any]]:
    """Build ``/v1/posting/fbs/split`` body — one posting entry per physical unit.

    First entry stays on the original ``posting_number``; the rest become siblings.
    """
    products = _products_from_posting_payload(posting)
    units: list[dict[str, Any]] = []
    for p in products:
        product_id = p.get("sku") if p.get("sku") is not None else p.get("product_id")
        try:
            pid = int(product_id)
        except (TypeError, ValueError):
            continue
        try:
            qty = int(p.get("quantity") or 1)
        except (TypeError, ValueError):
            qty = 1
        for _ in range(max(qty, 1)):
            units.append({"products": [{"product_id": pid, "quantity": 1}]})
    if len(units) < 2:
        raise RuntimeError("Отправление не является мультизаказом")
    return units


def _ship_result_posting_numbers(
    result: object, *, fallback_posting_number: str
) -> list[str]:
    """Extract posting numbers from ``/v4/posting/fbs/ship`` response."""
    out: list[str] = []
    seen: set[str] = set()

    def _add(value: object) -> None:
        pn = str(value or "").strip()
        if not pn or pn in seen:
            return
        seen.add(pn)
        out.append(pn)

    if isinstance(result, dict):
        raw = result.get("result")
        if isinstance(raw, list):
            for item in raw:
                if isinstance(item, str):
                    _add(item)
                elif isinstance(item, dict):
                    _add(item.get("posting_number"))
        elif isinstance(raw, str):
            _add(raw)
        add = result.get("additional_data")
        if isinstance(add, list):
            for item in add:
                if isinstance(item, dict):
                    _add(item.get("posting_number"))
    _add(fallback_posting_number)
    return out or [str(fallback_posting_number).strip()]


def _product_meta_by_sku(base: dict[str, Any]) -> dict[int, dict[str, Any]]:
    """Map Ozon SKU → offer_id/name from the pre-ship posting (for local siblings)."""
    out: dict[int, dict[str, Any]] = {}
    for p in _products_from_posting_payload(base):
        raw = p.get("sku") if p.get("sku") is not None else p.get("product_id")
        try:
            sku = int(raw)
        except (TypeError, ValueError):
            continue
        out[sku] = {
            "offer_id": str(p.get("offer_id") or "").strip(),
            "name": str(p.get("name") or "").strip(),
            "sku": sku,
        }
    return out


def _clear_package_sticker_barcodes(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    posting_numbers: list[str],
) -> None:
    """Clear package QR/lower barcodes so a following refresh can rebind cleanly.

    After split the parent posting_number often keeps a pre-split QR. Leaving it
    blocks print-time ``only_if_empty`` enrich. Parts (A/B) stay — they come from
    posting_number and are still valid.
    """
    nums = [str(x).strip() for x in posting_numbers if str(x).strip()]
    if not nums:
        return
    oz.ensure_ozon_fbs_tables(repo)
    placeholders = ", ".join("?" for _ in nums)
    try:
        with repo._connect() as conn:
            conn.execute(
                repo._sql(
                    f"""
                    UPDATE ozon_fbs_postings
                    SET sticker_barcode = '',
                        sticker_lower_barcode = '',
                        sticker_scanit = ''
                    WHERE user_id = ? AND source_id = ?
                      AND posting_number IN ({placeholders})
                    """
                ),
                (int(user_id), int(source_id), *nums),
            )
    except Exception as exc:
        _log.warning("ozon sticker clear failed: %s", exc)


def _refresh_postings_package_stickers_from_ozon(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    posting_numbers: list[str],
    client: oz.OzonFbsClient,
    overwrite: bool = True,
) -> int:
    """Best-effort: load package barcodes via get_posting and persist sticker_*.

    After split/ship Ozon issues new package labels. Local compose upserts do not
    carry ``barcodes``, so scan-by-sticker in Marking/Pick would miss until sync.
    Failures are logged and skipped — split/ship already succeeded locally.

    ``overwrite=True`` replaces stale parent barcodes after split (only_if_empty
    would keep the pre-split QR linked to the wrong physical label).
    """
    updated = 0
    seen: set[str] = set()
    for raw_pn in posting_numbers:
        pn = str(raw_pn or "").strip()
        if not pn or pn in seen:
            continue
        seen.add(pn)
        try:
            remote = client.get_posting(pn)
        except Exception as exc:
            _log.warning("ozon sticker refresh get_posting %s: %s", pn, exc)
            continue
        if not isinstance(remote, dict):
            continue
        hints = oz.sticker_fields_from_posting({**remote, "posting_number": pn})
        if not oz.sticker_fields_have_package_codes(hints):
            # Barcodes/scanit can lag briefly after split — do not wipe existing columns.
            continue
        try:
            n = oz.persist_posting_stickers_batch(
                repo,
                user_id=user_id,
                source_id=source_id,
                stickers={pn: hints},
                only_if_empty=not overwrite,
            )
            updated += int(n or 0)
        except Exception as exc:
            _log.warning("ozon sticker refresh persist %s: %s", pn, exc)
    return updated


def _persist_package_stickers_from_posting(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    posting_number: str,
    posting: dict[str, Any],
    overwrite: bool,
) -> None:
    """Persist package stickers from an already-fetched Ozon posting payload."""
    pn = str(posting_number or "").strip()
    if not pn or not isinstance(posting, dict):
        return
    hints = oz.sticker_fields_from_posting({**posting, "posting_number": pn})
    if not oz.sticker_fields_have_package_codes(hints):
        return
    try:
        oz.persist_posting_stickers_batch(
            repo,
            user_id=user_id,
            source_id=source_id,
            stickers={pn: hints},
            only_if_empty=not overwrite,
        )
    except Exception as exc:
        _log.warning("ozon sticker persist from posting %s: %s", pn, exc)


def _compose_posting_from_package(
    *,
    posting_number: str,
    package: dict[str, Any] | None,
    base: dict[str, Any],
    meta_by_sku: dict[int, dict[str, Any]],
    status: str = oz.TAB_AWAITING_DELIVER,
) -> dict[str, Any]:
    """Build a local posting payload after ship/split without calling Ozon get."""
    products: list[dict[str, Any]] = []
    for p in list((package or {}).get("products") or []):
        if not isinstance(p, dict):
            continue
        try:
            sku = int(p.get("product_id") if p.get("product_id") is not None else p.get("sku"))
        except (TypeError, ValueError):
            continue
        try:
            qty = max(int(p.get("quantity") or 1), 1)
        except (TypeError, ValueError):
            qty = 1
        meta = meta_by_sku.get(sku) or {}
        products.append(
            {
                "sku": sku,
                "product_id": sku,
                "quantity": qty,
                "offer_id": meta.get("offer_id") or "",
                "name": meta.get("name") or "",
            }
        )
    payload: dict[str, Any] = {
        "posting_number": str(posting_number),
        "status": str(status or oz.TAB_AWAITING_DELIVER),
        "products": products,
    }
    if isinstance(base, dict):
        for key in (
            "order_id",
            "order_number",
            "warehouse_id",
            "delivery_method",
            "in_process_at",
            "created_at",
            "financial_data",
        ):
            if key in base and base.get(key) is not None:
                payload[key] = base.get(key)
        analytics = base.get("analytics_data")
        if isinstance(analytics, dict):
            payload["analytics_data"] = dict(analytics)
        else:
            payload["analytics_data"] = {}
        wh_name = ""
        if isinstance(analytics, dict):
            wh_name = str(analytics.get("warehouse") or "").strip()
        if not wh_name:
            wh_name = str(base.get("warehouse_name") or "").strip()
        if wh_name:
            ad = payload.get("analytics_data")
            if not isinstance(ad, dict):
                ad = {}
            else:
                ad = dict(ad)
            if not ad.get("warehouse"):
                ad["warehouse"] = wh_name
            if base.get("warehouse_id") is not None and ad.get("warehouse_id") is None:
                ad["warehouse_id"] = base.get("warehouse_id")
            payload["analytics_data"] = ad
        req = base.get("requirements")
        if isinstance(req, dict):
            payload["requirements"] = dict(req)
    return payload


def _persist_shipped_postings_local(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    posting_numbers: list[str],
    packages: list[dict[str, Any]],
    base: dict[str, Any],
    status: str = oz.TAB_AWAITING_DELIVER,
) -> None:
    """Upsert parent + siblings locally without Ozon get calls."""
    meta = _product_meta_by_sku(base if isinstance(base, dict) else {})
    tab_status = str(status or oz.TAB_AWAITING_DELIVER)
    for idx, pn in enumerate(posting_numbers):
        package = packages[idx] if idx < len(packages) else None
        payload = _compose_posting_from_package(
            posting_number=str(pn),
            package=package,
            base=base if isinstance(base, dict) else {},
            meta_by_sku=meta,
            status=tab_status,
        )
        payload = oz.stamp_catalog_marking_flags(
            repo, user_id=user_id, posting=payload
        )
        try:
            oz.upsert_posting(
                repo,
                user_id=user_id,
                source_id=source_id,
                posting=payload,
                protect_status_downgrade=False,
            )
        except Exception:
            if tab_status == oz.TAB_AWAITING_DELIVER:
                _force_local_awaiting_deliver(
                    repo,
                    user_id=user_id,
                    source_id=source_id,
                    posting_number=str(pn),
                    posting=payload,
                )


def _package_from_split_products(prods: object) -> dict[str, Any] | None:
    if not isinstance(prods, list) or not prods:
        return None
    products = [
        {
            "product_id": p.get("product_id") or p.get("sku"),
            "quantity": p.get("quantity") or 1,
        }
        for p in prods
        if isinstance(p, dict)
    ]
    return {"products": products} if products else None


def _parse_split_response(
    result: object,
    *,
    fallback_posting_number: str,
    split_plan: list[dict[str, Any]],
) -> list[tuple[str, dict[str, Any] | None]]:
    """Map split API response → [(posting_number, products_package), ...].

    Raises if Ozon did not return enough sibling numbers for a multi split.
    """
    parent_pn = str(fallback_posting_number).strip()
    parent_products: dict[str, Any] | None = (
        split_plan[0] if split_plan else None
    )
    children: list[tuple[str, dict[str, Any] | None]] = []

    data = result if isinstance(result, dict) else {}
    # Ozon often wraps the payload: {"result": {"parent_posting": ..., "postings": ...}}
    wrapped = data.get("result")
    if isinstance(wrapped, dict) and (
        "parent_posting" in wrapped or "postings" in wrapped
    ):
        data = wrapped
    parent = data.get("parent_posting")
    if isinstance(parent, str) and parent.strip():
        parent_pn = parent.strip()
    elif isinstance(parent, dict):
        pn = str(parent.get("posting_number") or "").strip()
        if pn:
            parent_pn = pn
        pkg = _package_from_split_products(parent.get("products"))
        if pkg is not None:
            parent_products = pkg

    raw_children = data.get("postings")
    sibling_plan_idx = 1  # split_plan[0] stays on parent
    if isinstance(raw_children, list):
        for item in raw_children:
            if isinstance(item, str):
                pn = item.strip()
                package = None
            elif isinstance(item, dict):
                pn = str(item.get("posting_number") or "").strip()
                package = _package_from_split_products(item.get("products"))
            else:
                continue
            if not pn:
                continue
            # Response may list parent among postings — skip for sibling mapping.
            if pn == parent_pn:
                if package is not None:
                    parent_products = package
                continue
            if package is None and sibling_plan_idx < len(split_plan):
                package = split_plan[sibling_plan_idx]
            sibling_plan_idx += 1
            children.append((pn, package))

    expected_extra = max(len(split_plan) - 1, 0)
    if expected_extra > 0 and len(children) < expected_extra:
        raise RuntimeError(
            "Ozon не вернул номера после разбиения — повторите или синхронизируйте"
        )

    out: list[tuple[str, dict[str, Any] | None]] = [(parent_pn, parent_products)]
    seen = {parent_pn}
    for pn, package in children:
        if pn in seen:
            continue
        seen.add(pn)
        out.append((pn, package))
    return out


def split_posting(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    posting_number: str,
    client_id: str,
    api_key: str,
    client: oz.OzonFbsClient | None = None,
) -> dict[str, Any]:
    """Split a multi-unit posting via ``/v1/posting/fbs/split`` (no assemble).

    Status stays ``awaiting_packaging``. First unit keeps the original number.
    """
    row = get_posting_row(
        repo, user_id=user_id, source_id=source_id, posting_number=posting_number
    )
    if not row:
        raise RuntimeError("Отправление не найдено локально — синхронизируйте и повторите")

    units = posting_ship_unit_count(row)
    if units < 2:
        return {
            "ok": True,
            "skipped": True,
            "posting_number": str(posting_number),
            "posting_numbers": [str(posting_number)],
            "message": "Не мультизаказ",
        }

    api = client or oz.OzonFbsClient(client_id, api_key)
    remote: dict[str, Any] = {}
    try:
        remote = api.get_posting(str(posting_number))
    except Exception:
        remote = {}
    base = remote if remote else row
    plan = build_split_postings(base)
    result = api.split_posting(str(posting_number), plan)
    parts = _parse_split_response(
        result,
        fallback_posting_number=str(posting_number),
        split_plan=plan,
    )
    posting_numbers = [pn for pn, _ in parts]
    packages = [pkg if pkg is not None else {} for _, pkg in parts]
    _persist_shipped_postings_local(
        repo,
        user_id=user_id,
        source_id=source_id,
        posting_numbers=posting_numbers,
        packages=packages,
        base=base if isinstance(base, dict) else {},
        status=oz.TAB_AWAITING_PACKAGING,
    )
    # Drop pre-split parent QR, then bind fresh package barcodes for scan.
    _clear_package_sticker_barcodes(
        repo,
        user_id=user_id,
        source_id=source_id,
        posting_numbers=posting_numbers,
    )
    _refresh_postings_package_stickers_from_ozon(
        repo,
        user_id=user_id,
        source_id=source_id,
        posting_numbers=posting_numbers,
        client=api,
        overwrite=True,
    )
    return {
        "ok": True,
        "posting_number": str(posting_numbers[0] if posting_numbers else posting_number),
        "posting_numbers": posting_numbers,
        "from_units": units,
        "to_count": len(posting_numbers),
        "result": result,
    }


def _force_local_awaiting_deliver(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    posting_number: str,
    posting: dict[str, Any] | None = None,
) -> None:
    """Persist awaiting_deliver without relying on Ozon get eventual consistency."""
    pn = str(posting_number or "").strip()
    if not pn:
        return
    payload = dict(posting or {})
    payload["posting_number"] = pn
    payload["status"] = oz.TAB_AWAITING_DELIVER
    try:
        oz.upsert_posting(
            repo,
            user_id=user_id,
            source_id=source_id,
            posting=payload,
            protect_status_downgrade=False,
        )
    except Exception:
        with repo._connect() as conn:
            conn.execute(
                repo._sql(
                    """
                    UPDATE ozon_fbs_postings
                    SET status = ?, tab = ?, synced_at = CURRENT_TIMESTAMP
                    WHERE user_id = ? AND source_id = ? AND posting_number = ?
                    """
                ),
                (
                    oz.TAB_AWAITING_DELIVER,
                    oz.TAB_AWAITING_DELIVER,
                    user_id,
                    source_id,
                    pn,
                ),
            )


def _ship_error_already_assembled(exc: BaseException) -> bool:
    """Ozon may reject ship when posting already left awaiting_packaging."""
    text = str(exc or "").lower()
    needles = (
        "awaiting_deliver",
        "already",
        "уже собран",
        "уже отправлен",
        "нельзя собрать",
        "invalidstate",
        "invalid_state",
        "status_not_valid",
        "posting_already",
    )
    return any(n in text for n in needles)


def _ship_error_exemplar_not_filled(exc: BaseException) -> bool:
    """``/v4/posting/fbs/ship`` rejected because exemplar/KIZ/GTD data is incomplete."""
    return "EXEMPLAR_INFO_NOT_FILLED_COMPLETELY" in str(exc or "").upper()


def _packages_to_exemplar_products(
    packages: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """``product_id`` + ``quantity`` lines for exemplar create-or-get."""
    out: list[dict[str, Any]] = []
    seen: set[int] = set()
    for pkg in packages:
        if not isinstance(pkg, dict):
            continue
        for p in pkg.get("products") or []:
            if not isinstance(p, dict):
                continue
            try:
                pid = int(p.get("product_id"))
            except (TypeError, ValueError):
                continue
            if pid <= 0 or pid in seen:
                continue
            seen.add(pid)
            try:
                qty = int(p.get("quantity") or 1)
            except (TypeError, ValueError):
                qty = 1
            out.append({"product_id": pid, "quantity": max(qty, 1)})
    return out


def _exemplar_requires_codes_before_ship(
    client: oz.OzonFbsClient,
    *,
    posting_number: str,
    packages: list[dict[str, Any]],
) -> bool:
    """True when Ozon still needs КИЗ/ГТД/etc. before ship.

    Optional Chestny ZNAK (``is_mandatory_mark_possible`` without
    ``is_mandatory_mark_needed``) must NOT block — portal and live API allow
    ``/v4/posting/fbs/ship`` without codes for those postings.
    """
    products = _packages_to_exemplar_products(packages)
    if products:
        try:
            resp = client.product_exemplar_create_or_get(
                str(posting_number), products
            )
        except Exception as exc:
            _log.info(
                "ozon ship exemplar probe create-or-get %s failed: %s",
                posting_number,
                exc,
            )
            return True
        for item in resp.get("products") or []:
            if not isinstance(item, dict):
                continue
            if (
                item.get("is_mandatory_mark_needed")
                or item.get("is_gtd_needed")
                or item.get("is_rnpt_needed")
                or item.get("is_jw_uin_needed")
                or item.get("is_weight_needed")
            ):
                return True

    try:
        status_resp = client.product_exemplar_status(str(posting_number))
    except Exception as exc:
        _log.info(
            "ozon ship exemplar probe status %s failed: %s",
            posting_number,
            exc,
        )
        # If create-or-get already said nothing is needed, do not block on
        # a flaky status call; otherwise keep the original EXEMPLAR error.
        return not bool(products)
    status = str(status_resp.get("status") or "").strip().lower()
    if status in {"ship_not_available", "validation_in_process"}:
        return True
    return False


def ship_posting(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    posting_number: str,
    client_id: str,
    api_key: str,
    client: oz.OzonFbsClient | None = None,
    fast: bool = False,
) -> dict[str, Any]:
    """Ship one posting via ``/v4/posting/fbs/ship``.

    ``fast=True`` (bulk collect): prefer local products, skip post-ship get,
    treat «already assembled» as success — fewer Ozon round-trips / timeouts.
    """
    row = get_posting_row(
        repo, user_id=user_id, source_id=source_id, posting_number=posting_number
    )
    if not row:
        raise RuntimeError("Отправление не найдено локально — синхронизируйте и повторите")

    local_tab = str(row.get("tab") or "").strip().lower()
    if local_tab in {
        oz.TAB_AWAITING_DELIVER,
        oz.TAB_DELIVERING,
        oz.TAB_DELIVERED,
    }:
        return {
            "ok": True,
            "result": {"already": True},
            "skipped": True,
            "posting_numbers": [str(posting_number)],
        }

    api = client or oz.OzonFbsClient(client_id, api_key)
    packages: list[dict[str, Any]] | None = None
    remote: dict[str, Any] = {}

    if fast:
        try:
            packages = build_ship_packages(row)
        except Exception:
            packages = None
        if packages is None:
            try:
                remote = api.get_posting(str(posting_number))
            except Exception:
                remote = {}
            packages = build_ship_packages(remote if remote else row)
    else:
        try:
            remote = api.get_posting(str(posting_number))
        except Exception:
            remote = {}
        packages = build_ship_packages(remote if remote else row)

    try:
        result = api.ship_posting(str(posting_number), packages)
    except Exception as exc:
        if _ship_error_already_assembled(exc):
            result = {"already": True, "error": str(exc)}
        else:
            err_l = str(exc).lower()
            retried = False
            # Optional-mark fluke: Ozon sometimes returns EXEMPLAR… even when
            # create-or-get says mark is only possible (not needed). Portal ships
            # these without КИЗ — probe and retry once.
            if _ship_error_exemplar_not_filled(exc):
                blocks = _exemplar_requires_codes_before_ship(
                    api,
                    posting_number=str(posting_number),
                    packages=packages,
                )
                if not blocks:
                    _log.info(
                        "ozon ship %s EXEMPLAR… but exemplar not required — retry",
                        posting_number,
                    )
                    try:
                        result = api.ship_posting(str(posting_number), packages)
                        retried = True
                    except Exception as exc_retry:
                        if _ship_error_already_assembled(exc_retry):
                            result = {"already": True, "error": str(exc_retry)}
                            retried = True
                        else:
                            raise
                else:
                    raise RuntimeError(
                        "EXEMPLAR_INFO_NOT_FILLED_COMPLETELY: "
                        "нужен КИЗ («Честный ЗНАК») и/или ГТД перед сборкой"
                    ) from exc
            if not retried and (
                "429" in err_l or "http 5" in err_l or "network" in err_l
            ):
                # One soft retry on rate limit / transient HTTP.
                import time as _time

                _time.sleep(1.5)
                try:
                    result = api.ship_posting(str(posting_number), packages)
                    retried = True
                except Exception as exc2:
                    if not _ship_error_already_assembled(exc2):
                        raise
                    result = {"already": True, "error": str(exc2)}
                    retried = True
            if not retried:
                # Confirm remote status — may already be past packaging.
                try:
                    got = api.get_posting(str(posting_number))
                except Exception:
                    got = {}
                got_tab = oz.compute_tab(str((got or {}).get("status") or ""))
                if got_tab in {
                    oz.TAB_AWAITING_DELIVER,
                    oz.TAB_DELIVERING,
                    oz.TAB_DELIVERED,
                }:
                    _force_local_awaiting_deliver(
                        repo,
                        user_id=user_id,
                        source_id=source_id,
                        posting_number=str(posting_number),
                        posting=got if isinstance(got, dict) else None,
                    )
                    return {
                        "ok": True,
                        "result": {"already": True},
                        "skipped": True,
                        "posting_numbers": [str(posting_number)],
                    }
                raise

    posting_numbers = _ship_result_posting_numbers(
        result, fallback_posting_number=str(posting_number)
    )
    multi_split = len(packages) > 1
    base = remote or row

    # Bulk collect (fast): never N×get_posting for full status — upsert from ship
    # result + packages, then only refresh package sticker barcodes for scan linking.
    if fast:
        if multi_split:
            _persist_shipped_postings_local(
                repo,
                user_id=user_id,
                source_id=source_id,
                posting_numbers=posting_numbers,
                packages=packages,
                base=base if isinstance(base, dict) else {},
            )
            _clear_package_sticker_barcodes(
                repo,
                user_id=user_id,
                source_id=source_id,
                posting_numbers=posting_numbers,
            )
            _refresh_postings_package_stickers_from_ozon(
                repo,
                user_id=user_id,
                source_id=source_id,
                posting_numbers=posting_numbers,
                client=api,
                overwrite=True,
            )
        else:
            _force_local_awaiting_deliver(
                repo,
                user_id=user_id,
                source_id=source_id,
                posting_number=str(posting_number),
                posting=base if isinstance(base, dict) else None,
            )
        return {
            "ok": True,
            "result": result,
            "posting_numbers": posting_numbers,
        }

    # Interactive / single ship: refresh each resulting posting from Ozon when possible.
    for idx, pn in enumerate(posting_numbers):
        refreshed: dict[str, Any] = {}
        try:
            got = api.get_posting(str(pn))
            if isinstance(got, dict):
                refreshed = dict(got)
        except Exception:
            refreshed = {}
        if not refreshed.get("posting_number"):
            package = packages[idx] if idx < len(packages) else None
            refreshed = _compose_posting_from_package(
                posting_number=str(pn),
                package=package,
                base=base if isinstance(base, dict) else {},
                meta_by_sku=_product_meta_by_sku(
                    base if isinstance(base, dict) else {}
                ),
            )
        remote_status = str(refreshed.get("status") or "").strip().lower()
        remote_tab = oz.compute_tab(remote_status)
        if remote_tab not in (
            oz.TAB_AWAITING_DELIVER,
            oz.TAB_DELIVERING,
            oz.TAB_DELIVERED,
            oz.TAB_CANCELLED,
            oz.TAB_ARBITRATION,
        ):
            refreshed["status"] = oz.TAB_AWAITING_DELIVER
        # Preserve sync-time catalog KIZ warm (get_posting omits local stamp).
        refreshed = oz.stamp_catalog_marking_flags(
            repo, user_id=user_id, posting=refreshed
        )
        try:
            oz.upsert_posting(
                repo,
                user_id=user_id,
                source_id=source_id,
                posting=refreshed,
                protect_status_downgrade=False,
            )
        except Exception:
            _force_local_awaiting_deliver(
                repo,
                user_id=user_id,
                source_id=source_id,
                posting_number=str(pn),
                posting=refreshed if refreshed else None,
            )
        # upsert applies stickers only_if_empty — overwrite from this get so a
        # pre-ship / pre-split QR cannot block the real package barcodes.
        _persist_package_stickers_from_posting(
            repo,
            user_id=user_id,
            source_id=source_id,
            posting_number=str(pn),
            posting=refreshed,
            overwrite=True,
        )
    return {
        "ok": True,
        "result": result,
        "posting_numbers": posting_numbers,
    }


def count_awaiting_packaging_multi(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int | None,
) -> dict[str, int]:
    """How many multi-unit postings sit in «Ожидают сборки» (local)."""
    oz.ensure_ozon_fbs_tables(repo)
    if source_id is None:
        return {"multi_posting_count": 0, "result_posting_count": 0, "extra_postings": 0}
    with repo._connect() as conn:
        rows = conn.execute(
            repo._sql(
                """
                SELECT products_json, quantity FROM ozon_fbs_postings
                WHERE user_id = ? AND source_id = ? AND tab = ?
                  AND COALESCE(supply_id, '') = ''
                """
            ),
            (user_id, int(source_id), oz.TAB_AWAITING_PACKAGING),
        ).fetchall()
    items = [repo._row_to_dict(r) for r in rows]
    return ship_split_preview(items)


def list_awaiting_packaging_multi_numbers(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
) -> list[str]:
    """Posting numbers in awaiting_packaging with more than one ship unit."""
    oz.ensure_ozon_fbs_tables(repo)
    with repo._connect() as conn:
        rows = conn.execute(
            repo._sql(
                """
                SELECT * FROM ozon_fbs_postings
                WHERE user_id = ? AND source_id = ? AND tab = ?
                  AND COALESCE(supply_id, '') = ''
                ORDER BY created_at_ozon DESC NULLS LAST, posting_number DESC
                """
            ),
            (user_id, source_id, oz.TAB_AWAITING_PACKAGING),
        ).fetchall()
    out: list[str] = []
    for row in rows:
        d = repo._row_to_dict(row)
        if posting_ship_unit_count(d) > 1:
            pn = str(d.get("posting_number") or "").strip()
            if pn:
                out.append(pn)
    return out


def list_awaiting_packaging_numbers(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
) -> list[str]:
    oz.ensure_ozon_fbs_tables(repo)
    with repo._connect() as conn:
        rows = conn.execute(
            repo._sql(
                """
                SELECT posting_number FROM ozon_fbs_postings
                WHERE user_id = ? AND source_id = ? AND tab = ?
                ORDER BY created_at_ozon DESC NULLS LAST, posting_number DESC
                """
            ),
            (user_id, source_id, oz.TAB_AWAITING_PACKAGING),
        ).fetchall()
    out: list[str] = []
    for row in rows:
        pn = str(row["posting_number"] if hasattr(row, "keys") else row[0] or "").strip()
        if pn:
            out.append(pn)
    return out


def ship_all_awaiting_packaging(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    client_id: str,
    api_key: str,
) -> dict[str, Any]:
    """Ship every local «Ожидают сборки» posting via Ozon ``/v4/posting/fbs/ship``.

    Moves successful postings to ``awaiting_deliver`` (Ожидают отгрузки).
    """
    numbers = list_awaiting_packaging_numbers(
        repo, user_id=user_id, source_id=source_id
    )
    if not numbers:
        return {
            "ok": True,
            "total": 0,
            "shipped": 0,
            "failed": 0,
            "errors": [],
            "message": "Нет отправлений в «Ожидают сборки»",
        }
    client = oz.OzonFbsClient(client_id, api_key)
    shipped: list[str] = []
    errors: list[dict[str, str]] = []
    for pn in numbers:
        try:
            ship_posting(
                repo,
                user_id=user_id,
                source_id=source_id,
                posting_number=pn,
                client_id=client_id,
                api_key=api_key,
                client=client,
            )
            shipped.append(pn)
        except Exception as exc:
            errors.append({"posting_number": pn, "error": str(exc)})
    shipped_n = len(shipped)
    failed_n = len(errors)
    if shipped_n and not failed_n:
        message = f"Собрано {shipped_n} отправлений → «Ожидают отгрузки»"
        ok = True
    elif shipped_n and failed_n:
        message = f"Собрано {shipped_n}, ошибок {failed_n}"
        ok = False
    else:
        message = f"Не удалось собрать отправления ({failed_n})"
        ok = False
    return {
        "ok": ok,
        "total": len(numbers),
        "shipped": shipped_n,
        "failed": failed_n,
        "shipped_numbers": shipped,
        "errors": errors,
        "message": message,
    }


def posting_detail_payload(row: dict[str, Any]) -> dict[str, Any]:
    try:
        products = json.loads(row.get("products_json") or "[]")
    except json.JSONDecodeError:
        products = []
    try:
        barcodes = json.loads(row.get("barcodes_json") or "[]")
    except json.JSONDecodeError:
        barcodes = []
    return {
        "posting_number": row.get("posting_number"),
        "order_number": row.get("order_number"),
        "status": row.get("status"),
        "tab": row.get("tab"),
        "tab_label": oz.TAB_LABELS.get(str(row.get("tab") or ""), ""),
        "offer_id": row.get("offer_id"),
        "product_name": row.get("product_name"),
        "quantity": row.get("quantity"),
        "price_display": row.get("price_display") or row.get("price"),
        "warehouse_label": row.get("warehouse_name") or row.get("warehouse_label"),
        "is_mandatory_mark": bool(row.get("is_mandatory_mark")),
        "products": products if isinstance(products, list) else [],
        "barcodes": barcodes if isinstance(barcodes, list) else [],
        "can_ship": str(row.get("tab") or "") == oz.TAB_AWAITING_PACKAGING,
        "can_print_label": str(row.get("tab") or "") in {
            oz.TAB_AWAITING_PACKAGING,
            oz.TAB_AWAITING_DELIVER,
            oz.TAB_DELIVERING,
        },
    }


def print_package_labels(
    *,
    client_id: str,
    api_key: str,
    posting_numbers: list[str],
) -> bytes:
    """Lookup / detail-card sticker PDF via v3 create + v2 get (not sync v2)."""
    nums = [str(p).strip() for p in posting_numbers if str(p).strip()]
    if not nums:
        raise RuntimeError("Не указаны отправления для печати")
    client = oz.OzonFbsClient(client_id, api_key)
    # Search/kebab single-posting print: check Ozon status first so operators
    # get a clear RU message instead of raw INVALID_ARGUMENT JSON.
    if len(nums) == 1:
        oz.ensure_single_posting_label_printable(client, nums[0])
    try:
        pdf, _meta = client.fetch_async_package_label_pdf(nums)
        return pdf
    except RuntimeError as exc:
        raise RuntimeError(oz.format_ozon_package_label_error(exc)) from exc
