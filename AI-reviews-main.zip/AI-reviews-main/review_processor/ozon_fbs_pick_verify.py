"""Ozon FBS local ШК pick-check for supply modal (non-КИЗ postings)."""
from __future__ import annotations

import json
import logging
from datetime import UTC, datetime
from typing import Any

from . import ozon_fbs as oz
from . import ozon_fbs_supplies as oz_sup
from . import wb_fbs as wb
from . import wb_fbs_detail as wb_detail
from .ozon_fbs_marking import _load_posting_cancelled_map, order_kiz_flags_for_orders
from .repository import ReviewRepository

_log = logging.getLogger(__name__)


def _supply_detail_for_pick_verify(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    supply_id: str,
    posting_tab: str | None = None,
) -> dict[str, Any]:
    """Load supply detail for pick-verify from local DB (assembly + optional tab)."""
    tab_key = str(posting_tab or "").strip() or None
    return oz_sup.get_supply_detail(
        repo,
        user_id=user_id,
        source_id=source_id,
        supply_id=supply_id,
        posting_tab=tab_key,
    )


def allowed_pick_verify_posting_numbers(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    supply_id: str,
    posting_tab: str | None = None,
) -> set[str]:
    """Plain (non-КИЗ) posting numbers in a supply — assembly/local truth."""
    detail = _supply_detail_for_pick_verify(
        repo,
        user_id=user_id,
        source_id=int(source_id),
        supply_id=str(supply_id),
        posting_tab=posting_tab,
    )
    return {
        str(o.get("posting_number") or "").strip()
        for o in (detail.get("orders") or [])
        if isinstance(o, dict)
        and not o.get("kiz_required")
        and not oz.posting_row_is_cancelled(o)
        and str(o.get("posting_number") or "").strip()
    }


def load_posting_pick_map(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    posting_numbers: list[str],
) -> dict[str, dict[str, Any]]:
    nums = [str(x).strip() for x in posting_numbers if str(x).strip()]
    if not nums:
        return {}
    oz.ensure_ozon_fbs_tables(repo)
    placeholders = ", ".join("?" for _ in nums)
    with repo._connect() as conn:
        rows = conn.execute(
            repo._sql(
                f"""
                SELECT posting_number, pick_verified, pick_barcode, pick_verified_at,
                       container_id, container_barcode, container_synced, container_sync_error
                FROM ozon_fbs_postings
                WHERE user_id = ? AND source_id = ?
                  AND posting_number IN ({placeholders})
                """
            ),
            (user_id, source_id, *nums),
        ).fetchall()
    out: dict[str, dict[str, Any]] = {}
    for row in rows:
        d = repo._row_to_dict(row)
        pn = str(d.get("posting_number") or "").strip()
        if not pn:
            continue
        verified_at = d.get("pick_verified_at")
        try:
            cid = int(d.get("container_id") or 0)
        except (TypeError, ValueError):
            cid = 0
        barcode = str(d.get("container_barcode") or "").strip()
        if not barcode and cid > 0:
            barcode = str(cid)
        out[pn] = {
            "pick_verified": bool(d.get("pick_verified")),
            "pick_barcode": str(d.get("pick_barcode") or "").strip(),
            "pick_verified_at": wb._normalize_kiz_saved_at(verified_at)
            if verified_at
            else "",
            "container_id": cid if cid > 0 else None,
            "container_barcode": barcode,
            "container_synced": bool(d.get("container_synced")) and cid > 0,
            "container_sync_error": str(d.get("container_sync_error") or "").strip(),
        }
    return out


def update_posting_pick_verify(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    posting_number: str,
    verified: bool,
    barcode: str = "",
    expected_verified_at: str | None = None,
    force: bool = False,
) -> dict[str, Any]:
    """Persist local ШК pick-check. No Ozon API calls."""
    oz.ensure_ozon_fbs_tables(repo)
    pn = str(posting_number or "").strip()
    code = str(barcode or "").strip()
    is_ok = bool(verified) and bool(code)
    saved_at = datetime.now(UTC)
    expected = wb._normalize_kiz_saved_at(expected_verified_at)
    with repo._connect() as conn:
        row = conn.execute(
            repo._sql(
                """
                SELECT pick_verified, pick_barcode, pick_verified_at
                FROM ozon_fbs_postings
                WHERE user_id = ? AND source_id = ? AND posting_number = ?
                """
            ),
            (user_id, source_id, pn),
        ).fetchone()
        if not row:
            return {
                "ok": False,
                "conflict": False,
                "missing": True,
                "verified_at": "",
                "verified": False,
                "barcode": "",
            }
        d = repo._row_to_dict(row)
        cur_verified = bool(d.get("pick_verified")) and bool(
            str(d.get("pick_barcode") or "").strip()
        )
        cur_barcode = str(d.get("pick_barcode") or "").strip() if cur_verified else ""
        cur_saved = wb._normalize_kiz_saved_at(d.get("pick_verified_at"))
        new_verified = is_ok
        new_barcode = code if is_ok else ""
        if (
            not force
            and expected
            and cur_saved
            and expected != cur_saved
            and (cur_verified != new_verified or cur_barcode != new_barcode)
        ):
            return {
                "ok": False,
                "conflict": True,
                "missing": False,
                "verified_at": cur_saved,
                "verified": cur_verified,
                "barcode": cur_barcode,
            }
        if cur_verified == new_verified and cur_barcode == new_barcode:
            return {
                "ok": True,
                "conflict": False,
                "missing": False,
                "unchanged": True,
                # Keep token even when unverified so peer clear/fill can compare.
                "verified_at": cur_saved,
                "verified": cur_verified,
                "barcode": cur_barcode,
            }
        conn.execute(
            repo._sql(
                """
                UPDATE ozon_fbs_postings
                SET pick_verified = ?, pick_barcode = ?, pick_verified_at = ?
                WHERE user_id = ? AND source_id = ? AND posting_number = ?
                """
            ),
            (
                new_verified,
                new_barcode,
                # Always bump token (incl. clear) so multi-op status merge sees
                # peer unverify as strictly newer than the previous fill.
                saved_at,
                user_id,
                source_id,
                pn,
            ),
        )
    return {
        "ok": True,
        "conflict": False,
        "missing": False,
        "unchanged": False,
        "verified_at": wb._normalize_kiz_saved_at(saved_at),
        "verified": new_verified,
        "barcode": new_barcode,
    }


def load_posting_barcodes_map(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    posting_numbers: list[str],
) -> dict[str, list[str]]:
    """Trusted product barcodes for pick-verify save.

    Prefer Feedback → Products catalog (same as supply detail / UI), then
    fall back to ``barcodes_json`` on the posting. Empty ``barcodes_json``
    alone must not fail a scan that the UI already validated against catalog.
    """
    nums = [str(x).strip() for x in posting_numbers if str(x).strip()]
    if not nums:
        return {}
    oz.ensure_ozon_fbs_tables(repo)
    placeholders = ", ".join("?" for _ in nums)
    with repo._connect() as conn:
        rows = conn.execute(
            repo._sql(
                f"""
                SELECT posting_number, offer_id, sku, barcodes_json
                FROM ozon_fbs_postings
                WHERE user_id = ? AND source_id = ?
                  AND posting_number IN ({placeholders})
                """
            ),
            (user_id, source_id, *nums),
        ).fetchall()
    try:
        barcode_map = repo.get_product_barcodes_map(user_id=user_id)
    except Exception:
        barcode_map = {}
    if not isinstance(barcode_map, dict):
        barcode_map = {}
    out: dict[str, list[str]] = {}
    for row in rows:
        d = repo._row_to_dict(row)
        pn = str(d.get("posting_number") or "").strip()
        if not pn:
            continue
        try:
            parsed = json.loads(str(d.get("barcodes_json") or "[]"))
        except json.JSONDecodeError:
            parsed = []
        if not isinstance(parsed, list):
            parsed = []
        fallback = [str(x).strip() for x in parsed if str(x).strip()]
        out[pn] = oz.resolve_product_barcodes(
            offer_id=str(d.get("offer_id") or "").strip() or None,
            sku=str(d.get("sku") or "").strip() or None,
            barcode_map=barcode_map,
            fallback=fallback,
        )
    return out


def build_pick_verify_payload(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    supply_id: str,
    client_id: str | None = None,
    api_key: str | None = None,
    resolve_kiz: bool = True,
    max_postings: int | None = None,
    posting_tab: str | None = None,
) -> dict[str, Any]:
    """Rows for «Проверка ШК»: catalog КИЗ flags, then non-KIZ (plain) rows only."""
    cid = str(client_id or "").strip()
    key = str(api_key or "").strip()
    tab_key = str(posting_tab or "").strip() or None
    marking_resolve = oz_sup._empty_marking_resolve()
    chunk = oz_sup._clamp_live_check_chunk(
        max_postings if max_postings is not None else oz_sup.OZON_FBS_LIVE_CHECK_CHUNK
    )
    if resolve_kiz:
        try:
            marking_resolve = oz_sup.resolve_supply_kiz_flags_from_ozon(
                repo,
                user_id=user_id,
                source_id=source_id,
                supply_id=supply_id,
                client_id=cid,
                api_key=key,
                posting_tab=tab_key,
                max_postings=chunk,
            )
        except Exception as exc:
            _log.warning("ozon pick-verify resolve kiz %s: %s", supply_id, exc)

    detail = oz_sup.get_supply_detail(
        repo,
        user_id=user_id,
        source_id=source_id,
        supply_id=supply_id,
        posting_tab=tab_key,
    )
    # Keep cancelled plain rows in the modal (frozen composition); counters exclude them.
    plain_orders = [
        o
        for o in (detail.get("orders") or [])
        if isinstance(o, dict) and not o.get("kiz_required")
    ]
    posting_numbers = [
        str(o.get("posting_number") or "").strip()
        for o in plain_orders
        if str(o.get("posting_number") or "").strip()
    ]
    local_pick = load_posting_pick_map(
        repo,
        user_id=user_id,
        source_id=source_id,
        posting_numbers=posting_numbers,
    )
    rows: list[dict[str, Any]] = []
    for o in plain_orders:
        pn = str(o.get("posting_number") or "").strip()
        if not pn:
            continue
        local = local_pick.get(pn) or {}
        verified = bool(local.get("pick_verified")) and bool(
            str(local.get("pick_barcode") or "").strip()
        )
        rows.append(
            {
                "posting_number": pn,
                "product_name": o.get("product_name") or o.get("offer_id") or "",
                "product_photo": o.get("product_photo") or "",
                "offer_id": o.get("offer_id") or "",
                "sku": o.get("sku"),
                "barcodes": list(o.get("barcodes") or []),
                "quantity": int(o.get("quantity") or 1),
                "pick_verified": verified,
                "pick_barcode": str(local.get("pick_barcode") or "").strip()
                if verified
                else "",
                "pick_verified_at": str(local.get("pick_verified_at") or ""),
                "cancel_reason_label": str(o.get("cancel_reason_label") or ""),
                "cancelled": bool(o.get("cancelled")),
                "order_id": o.get("order_id"),
                "order_number": str(o.get("order_number") or "").strip(),
                "created_at_ozon": o.get("created_at_ozon") or o.get("in_process_at") or "",
                "in_process_at": o.get("in_process_at") or "",
                "sticker_barcode": str(o.get("sticker_barcode") or "").strip(),
                "sticker_lower_barcode": str(o.get("sticker_lower_barcode") or "").strip(),
                "sticker_scanit": str(o.get("sticker_scanit") or "").strip(),
                "sticker_part_a": str(o.get("sticker_part_a") or "").strip(),
                "sticker_part_b": str(o.get("sticker_part_b") or "").strip(),
                "container_id": local.get("container_id"),
                "container_barcode": str(local.get("container_barcode") or "").strip(),
                "container_synced": bool(local.get("container_synced")),
                "container_sync_error": str(local.get("container_sync_error") or "").strip(),
            }
        )
    all_orders = [o for o in (detail.get("orders") or []) if isinstance(o, dict)]
    return {
        "ok": True,
        "supply_id": detail.get("supply_id"),
        "source_id": source_id,
        "rows": rows,
        "plain_count": len(rows),
        "order_kiz_flags": order_kiz_flags_for_orders(all_orders),
        "marking_resolve": marking_resolve,
    }


def save_pick_verify(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    items: list[dict[str, Any]],
    allowed_posting_numbers: set[str] | None = None,
) -> dict[str, Any]:
    """Save local ШК pick-check. Never calls Ozon."""
    results: list[dict[str, Any]] = []
    ok_n = 0
    err_n = 0
    skipped_n = 0

    candidate_pns: list[str] = []
    for raw in items:
        if not isinstance(raw, dict):
            continue
        pn = str(raw.get("posting_number") or "").strip()
        if pn:
            candidate_pns.append(pn)

    trusted_barcodes = load_posting_barcodes_map(
        repo,
        user_id=int(user_id),
        source_id=int(source_id),
        posting_numbers=candidate_pns,
    )
    cancelled_map = _load_posting_cancelled_map(
        repo,
        user_id=user_id,
        source_id=source_id,
        posting_numbers=candidate_pns,
    )

    for raw in items:
        if not isinstance(raw, dict):
            continue
        pn = str(raw.get("posting_number") or "").strip()
        if not pn:
            continue
        if cancelled_map.get(pn):
            skipped_n += 1
            continue
        if allowed_posting_numbers is not None and pn not in allowed_posting_numbers:
            err_n += 1
            results.append(
                {
                    "posting_number": pn,
                    "ok": False,
                    "error": "Отправление не входит в эту поставку или требует КИЗ",
                }
            )
            continue
        clear = bool(raw.get("clear"))
        verified = bool(raw.get("pick_verified")) and not clear
        barcode = str(raw.get("pick_barcode") or "").strip()
        expected_verified_at = str(raw.get("expected_verified_at") or "").strip()
        force_save = bool(raw.get("force"))
        # Empty unverify without clear was silently skipped (no results[]), which
        # broke TSD × clear with «Сервер не вернул результат сохранения ШК».
        if not verified and not clear and not barcode:
            clear = True
        if not verified and not clear:
            if not barcode:
                skipped_n += 1
                continue
            verified = False
        if clear:
            verified = False
            barcode = ""
        if verified:
            order_barcodes = trusted_barcodes.get(pn)
            if order_barcodes is None:
                err_n += 1
                results.append(
                    {
                        "posting_number": pn,
                        "ok": False,
                        "error": "Отправление не найдено локально — синхронизируйте FBS и повторите",
                    }
                )
                continue
            ok, normalized, err = wb_detail.validate_ean_against_order_skus(
                barcode, order_barcodes
            )
            if not ok:
                err_n += 1
                results.append({"posting_number": pn, "ok": False, "error": err})
                continue
            barcode = normalized
        try:
            local_res = update_posting_pick_verify(
                repo,
                user_id=int(user_id),
                source_id=int(source_id),
                posting_number=pn,
                verified=verified,
                barcode=barcode if verified else "",
                expected_verified_at=expected_verified_at or None,
                force=force_save,
            )
        except Exception as exc:
            err_n += 1
            results.append(
                {
                    "posting_number": pn,
                    "ok": False,
                    "error": f"Ошибка сохранения: {exc}",
                }
            )
            continue
        if local_res.get("conflict"):
            err_n += 1
            results.append(
                {
                    "posting_number": pn,
                    "ok": False,
                    "conflict": True,
                    "pick_verified": bool(local_res.get("verified")),
                    "pick_barcode": str(local_res.get("barcode") or ""),
                    "pick_verified_at": str(local_res.get("verified_at") or ""),
                    "error": (
                        "Отправление уже сохранено другим оператором — "
                        "проверьте ШК и сохраните снова"
                    ),
                }
            )
            continue
        if not local_res.get("ok"):
            err_n += 1
            results.append(
                {
                    "posting_number": pn,
                    "ok": False,
                    "error": "Отправление не найдено локально — синхронизируйте FBS и повторите",
                }
            )
            continue
        ok_n += 1
        # Skip duplicate journal rows when bulk-save rewrites an already-verified ШК.
        already_same = bool(local_res.get("unchanged"))
        if verified and barcode and not already_same:
            from . import ozon_fbs_scans as oz_scans

            oz_scans.record_posting_scan(
                repo,
                user_id=user_id,
                source_id=source_id,
                scan_type=oz_scans.SCAN_PICK,
                scan_raw=barcode,
                posting_number=pn,
                pick_barcode=barcode,
            )
        results.append(
            {
                "posting_number": pn,
                "ok": True,
                "pick_verified": bool(local_res.get("verified")),
                "pick_barcode": str(local_res.get("barcode") or ""),
                "pick_verified_at": str(local_res.get("verified_at") or ""),
            }
        )
    try:
        from . import fbs_audit

        fbs_audit.audit(
            marketplace="ozon",
            action="pick_verify",
            result=("fail" if err_n else "ok"),
            user_id=user_id,
            source_id=source_id,
            saved=ok_n,
            errors=err_n,
            skipped=skipped_n,
            items=len(results),
        )
    except Exception:
        pass
    return {
        "ok": err_n == 0,
        "saved": ok_n,
        "errors": err_n,
        "skipped": skipped_n,
        "results": results,
    }


def check_supply_pick_verify_status(
    repo: ReviewRepository,
    *,
    user_id: int,
    source_id: int,
    supply_id: str,
    posting_tab: str | None = None,
) -> dict[str, Any]:
    """Local status for Проверка ШК button tone + container bind errors."""
    from . import ozon_fbs_supplies as oz_sup

    tab_key = str(posting_tab or "").strip() or None
    detail = oz_sup.get_supply_detail(
        repo,
        user_id=user_id,
        source_id=source_id,
        supply_id=supply_id,
        posting_tab=tab_key,
    )
    orders = [
        o
        for o in (detail.get("orders") or [])
        if isinstance(o, dict)
        and not o.get("kiz_required")
        and not oz.posting_row_is_cancelled(o)
    ]
    posting_numbers = [
        str(o.get("posting_number") or "").strip()
        for o in orders
        if str(o.get("posting_number") or "").strip()
    ]
    local = load_posting_pick_map(
        repo,
        user_id=user_id,
        source_id=source_id,
        posting_numbers=posting_numbers,
    )
    done = 0
    empty = 0
    status_rows: list[dict[str, Any]] = []
    for o in orders:
        pn = str(o.get("posting_number") or "").strip()
        if not pn:
            continue
        loc = local.get(pn) or {}
        verified = bool(loc.get("pick_verified")) and bool(
            str(loc.get("pick_barcode") or "").strip()
        )
        if verified:
            done += 1
            st = "ok"
        else:
            empty += 1
            st = "empty"
        status_rows.append(
            {
                "posting_number": pn,
                "pick_verified": verified,
                "pick_barcode": str(loc.get("pick_barcode") or "").strip() if verified else "",
                # Token is kept after clear so peer sync can adopt unverify.
                "pick_verified_at": str(loc.get("pick_verified_at") or ""),
                "pick_status": st,
                "container_id": loc.get("container_id"),
                "container_barcode": str(loc.get("container_barcode") or "").strip(),
                "container_synced": bool(loc.get("container_synced")),
                "container_sync_error": str(loc.get("container_sync_error") or "").strip(),
            }
        )
    total = len(orders)

    def _has_container_bind(row: dict[str, Any]) -> bool:
        try:
            cid = int(row.get("container_id") or 0)
        except (TypeError, ValueError):
            cid = 0
        if cid > 0:
            return True
        return bool(str(row.get("container_barcode") or "").strip())

    def _container_confirmed(row: dict[str, Any]) -> bool:
        if str(row.get("container_sync_error") or "").strip():
            return False
        if not bool(row.get("container_synced")):
            return False
        return _has_container_bind(row)

    container_errors = [
        {
            "posting_number": r["posting_number"],
            "container_barcode": r.get("container_barcode") or "",
            "error": r.get("container_sync_error") or "",
        }
        for r in status_rows
        if str(r.get("container_sync_error") or "").strip()
    ]
    containers_required = any(_has_container_bind(r) for r in status_rows)
    containers_bound = sum(1 for r in status_rows if _container_confirmed(r))
    containers_complete = (not containers_required) or (
        total > 0 and containers_bound == total
    )
    if container_errors:
        tone = "error"
    elif total > 0 and done == total and containers_complete:
        tone = "ok"
    else:
        tone = ""
    return {
        "ok": True,
        "required": total,
        "done": done,
        "empty": empty,
        "status": tone,
        "containers_required": containers_required,
        "containers_bound": containers_bound,
        "containers_total": total,
        "container_errors": container_errors,
        "container_error_count": len(container_errors),
        "orders": status_rows,
    }
