"""FBS supply row tones: pale-red (GM formed) / green (accepted + TTN)."""

from __future__ import annotations

from pathlib import Path

from review_processor.ozon_fbs_supplies import (
    ozon_supply_list_row_tone,
    resolve_fbs_supply_row_tone,
)

ROOT = Path(__file__).resolve().parents[1]
OZ = ROOT / "review_processor" / "ozon_fbs_supplies.py"
WB = ROOT / "review_processor" / "wb_fbs.py"
WEB = ROOT / "review_processor" / "web.py"
OZ_JS = ROOT / "web_static" / "ozon_fbs.js"
APP_JS = ROOT / "web_static" / "app.js"
CSS = ROOT / "web_static" / "style.css"
HTML = ROOT / "web_templates" / "app.html"


def test_resolve_row_tone_priority() -> None:
    assert resolve_fbs_supply_row_tone(gm_statuses=["formed"], ttn_id=0) == "warn"
    assert resolve_fbs_supply_row_tone(gm_statuses=["formed"], ttn_id=9) == "warn"
    assert (
        resolve_fbs_supply_row_tone(
            gm_statuses=["formed", "acceptance_in_progress"], ttn_id=9
        )
        == "warn"
    )
    assert (
        resolve_fbs_supply_row_tone(
            gm_statuses=["acceptance_in_progress"], ttn_id=0
        )
        == ""
    )
    assert (
        resolve_fbs_supply_row_tone(gm_statuses=["finished"], ttn_id=0) == ""
    )
    assert (
        resolve_fbs_supply_row_tone(
            gm_statuses=["acceptance_in_progress", "finished"], ttn_id=5
        )
        == "ok"
    )
    assert resolve_fbs_supply_row_tone(gm_statuses=[], ttn_id=5) == ""


def test_ozon_list_tone_red_without_cargo_and_driver() -> None:
    assert (
        ozon_supply_list_row_tone(
            gm_statuses=[], ttn_id=0, has_cargo=False, has_driver=False
        )
        == "warn"
    )
    assert (
        ozon_supply_list_row_tone(
            gm_statuses=[], ttn_id=0, has_cargo=True, has_driver=False
        )
        == ""
    )
    assert (
        ozon_supply_list_row_tone(
            gm_statuses=[], ttn_id=0, has_cargo=False, has_driver=True
        )
        == ""
    )
    assert (
        ozon_supply_list_row_tone(
            gm_statuses=["formed"], ttn_id=0, has_cargo=True, has_driver=True
        )
        == "warn"
    )
    assert (
        ozon_supply_list_row_tone(
            gm_statuses=["finished"], ttn_id=5, has_cargo=True, has_driver=True
        )
        == "ok"
    )


def test_ozon_enrich_skips_unknown_gm_as_formed() -> None:
    """Missing live GM status must not invent «formed» (false pale-red)."""
    oz = OZ.read_text(encoding="utf-8")
    enrich = oz.split("def enrich_ozon_supply_items_row_tones", 1)[1].split(
        "\ndef list_awaiting_deliver_supplies", 1
    )[0]
    assert "treat as formed" not in enrich
    assert "gm_statuses.append(\"formed\")" not in enrich
    assert "Only known live statuses" in enrich
    assert "if st:" in enrich
    assert "gm_statuses.append(st)" in enrich
    # Local archive (arrow → завершённые) counts as accepted for row tone.
    assert "list_locally_archived_container_ids" in enrich
    assert 'gm_statuses.append("finished")' in enrich
    assert "locally_archived" in enrich


def test_enrich_local_archive_clears_warn_for_formed_gm() -> None:
    """formed GM that was archived locally must not keep the supply pale-red."""
    from unittest.mock import MagicMock, patch

    from review_processor.ozon_fbs_supplies import enrich_ozon_supply_items_row_tones

    repo = MagicMock()
    client = MagicMock()
    items = [{"supply_id": "S1", "ttn_id": 0, "has_driver": True}]

    with (
        patch(
            "review_processor.ozon_fbs_containers.list_locally_archived_container_ids",
            return_value={101},
        ),
        patch(
            "review_processor.ozon_fbs_containers._active_local_order_counts_by_container",
            return_value={101: 2},
        ),
        patch(
            "review_processor.ozon_fbs_containers.resolve_supply_warehouse_id",
            return_value=(55, "WH"),
        ),
        patch(
            "review_processor.ozon_fbs_containers._list_containers_cached",
            return_value={
                "items": [{"container_id": 101, "status": "formed"}],
            },
        ),
    ):
        enrich_ozon_supply_items_row_tones(
            repo, user_id=1, source_id=2, items=items, client=client
        )

    assert items[0]["gm_has_formed"] is False
    assert items[0]["gm_all_accepted"] is True
    assert items[0]["row_tone"] == ""


def test_enrich_formed_gm_without_local_archive_stays_warn() -> None:
    from unittest.mock import MagicMock, patch

    from review_processor.ozon_fbs_supplies import enrich_ozon_supply_items_row_tones

    repo = MagicMock()
    client = MagicMock()
    items = [{"supply_id": "S1", "ttn_id": 0, "has_driver": True}]

    with (
        patch(
            "review_processor.ozon_fbs_containers.list_locally_archived_container_ids",
            return_value=set(),
        ),
        patch(
            "review_processor.ozon_fbs_containers._active_local_order_counts_by_container",
            return_value={101: 2},
        ),
        patch(
            "review_processor.ozon_fbs_containers.resolve_supply_warehouse_id",
            return_value=(55, "WH"),
        ),
        patch(
            "review_processor.ozon_fbs_containers._list_containers_cached",
            return_value={
                "items": [{"container_id": 101, "status": "formed"}],
            },
        ),
    ):
        enrich_ozon_supply_items_row_tones(
            repo, user_id=1, source_id=2, items=items, client=client
        )

    assert items[0]["gm_has_formed"] is True
    assert items[0]["row_tone"] == "warn"


def test_ozon_backend_enriches_tones() -> None:
    oz = OZ.read_text(encoding="utf-8")
    web = WEB.read_text(encoding="utf-8")
    assert "def resolve_fbs_supply_row_tone" in oz
    assert "def enrich_ozon_supply_items_row_tones" in oz
    assert "enrich_ozon_supply_items_row_tones" in oz.split(
        "def _list_supplies_tab_response", 1
    )[1].split("def resolve_fbs_supply_row_tone", 1)[0]
    block = oz.split("def _list_supplies_tab_response", 1)[1].split(
        "def resolve_fbs_supply_row_tone", 1
    )[0]
    assert 'str(tab or "").strip() == oz.TAB_DELIVERING and page_items:' in block
    assert "TAB_AWAITING_DELIVER, oz.TAB_DELIVERING" not in block
    api = web.split("def ozon_fbs_list_supplies", 1)[1].split("\n    @app.", 1)[0]
    assert "OzonFbsClient" in api
    assert "client=client" in api
    assert "page=page" in api
    assert "page_size=page_size" in api


def test_wb_delivery_row_tone_from_boxes_and_scan() -> None:
    wb = WB.read_text(encoding="utf-8")
    assert "def _enrich_delivery_supply_row_tones" in wb
    assert "resolve_fbs_supply_row_tone" in wb
    assert "TAB_DELIVERY and items" in wb
    enrich = wb.split("def _enrich_delivery_supply_row_tones", 1)[1].split(
        "\ndef ", 1
    )[0]
    assert "boxes_count" in enrich
    assert "scan_dt" in enrich
    assert "row_tone" in enrich


def test_ui_row_classes_and_cache_bump() -> None:
    oz_js = OZ_JS.read_text(encoding="utf-8")
    app_js = APP_JS.read_text(encoding="utf-8")
    css = CSS.read_text(encoding="utf-8")
    html = HTML.read_text(encoding="utf-8")
    assert "fbs-supply-row-warn" in oz_js
    assert "fbs-supply-row-ok" in oz_js
    assert "row_tone" in oz_js
    render = oz_js.split("function renderSuppliesTable", 1)[1].split(
        "function productCompositionHtml", 1
    )[0]
    assert "isDeliveringSuppliesTab()\n        ? String(s.row_tone" in render
    assert "fbs-supply-row-warn" in render
    assert "fbs-supply-row-ok" in render
    assert "fbs-supply-row-warn" in app_js
    assert "fbs-supply-row-ok" in app_js
    assert ".fbs-supply-row-warn" in css
    assert ".fbs-supply-row-ok" in css
    assert "#fff1f2" in css
    assert "#f0fdf4" in css
    assert 'src="/static/ozon_fbs.js?v=' in html
    assert 'src="/static/app.js?v=' in html
    assert 'href="/static/style.css?v=' in html
