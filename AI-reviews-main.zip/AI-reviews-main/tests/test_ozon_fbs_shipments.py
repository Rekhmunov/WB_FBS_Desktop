"""Tests for Ozon FBS «Отгрузки» (carriage / act) helpers."""

from __future__ import annotations

import unittest
from datetime import date
from unittest.mock import MagicMock

from review_processor.ozon_fbs_shipments import (
    _block_matches_departure,
    _carriage_status_label,
    _carriage_delivery_blocks,
    _carriage_departure_date,
    _collected_label,
    _delivery_method_rows,
    _departure_iso,
    _friendly_ozon_api_error,
    _merge_delivery_methods,
    _normalize_block,
    build_shipments_view,
    compose_shipment_barcode_label_png,
    fetch_warehouse_barcode,
    pick_default_delivery_method,
    render_shipment_barcode_print_html,
)


class OzonFbsShipmentsHelpersTests(unittest.TestCase):
    def test_departure_iso(self) -> None:
        self.assertEqual(_departure_iso(date(2026, 8, 25)), "2026-08-25T00:00:00.000Z")
        self.assertEqual(_carriage_departure_date(date(2026, 8, 25)), "2026-08-25")

    def test_delivery_method_rows_v2_top_level(self) -> None:
        rows, has_next, cursor = _delivery_method_rows(
            {
                "delivery_methods": [
                    {"delivery_method_id": 5, "name": "Метод 5"},
                ],
                "has_next": False,
                "cursor": "abc",
            }
        )
        self.assertEqual(len(rows), 1)
        self.assertFalse(has_next)
        self.assertEqual(cursor, "abc")

    def test_carriage_blocks_v2_methods(self) -> None:
        blocks = _carriage_delivery_blocks(
            {
                "methods": [
                    {"warehouse_name": "Склад", "carriages": []},
                ]
            }
        )
        self.assertEqual(len(blocks), 1)
        self.assertEqual(blocks[0]["warehouse_name"], "Склад")

    def test_status_labels(self) -> None:
        self.assertEqual(_carriage_status_label(""), "Не сформирована")
        self.assertEqual(_carriage_status_label("new"), "Ожидает подтверждения")
        self.assertEqual(_carriage_status_label("formed"), "Сформирована")
        self.assertEqual(_carriage_status_label("Не сформирована"), "Не сформирована")
        self.assertEqual(_carriage_status_label("Сформирована"), "Сформирована")
        self.assertEqual(
            _carriage_status_label("Ожидает подтверждения"), "Ожидает подтверждения"
        )

    def test_delivery_method_rows_v2(self) -> None:
        rows, has_next, cursor = _delivery_method_rows(
            {
                "result": {
                    "delivery_methods": [
                        {"delivery_method_id": 5, "name": "Метод 5"},
                    ],
                    "has_next": False,
                }
            }
        )
        self.assertEqual(len(rows), 1)
        self.assertFalse(has_next)
        self.assertEqual(cursor, "")

    def test_carriage_blocks_v2_nested(self) -> None:
        blocks = _carriage_delivery_blocks(
            {
                "result": {
                    "delivery_methods": [
                        {"warehouse_name": "Склад", "carriages": []},
                    ]
                }
            }
        )
        self.assertEqual(len(blocks), 1)
        self.assertEqual(blocks[0]["warehouse_name"], "Склад")

    def test_friendly_role_error(self) -> None:
        err = _friendly_ozon_api_error(RuntimeError("Ozon HTTP 403: role missing"))
        self.assertIn("API-ключ Ozon", str(err))

    def test_friendly_incomplete_carriages(self) -> None:
        err = _friendly_ozon_api_error(
            RuntimeError("Ozon HTTP 400: there_are_incomplete_carriages")
        )
        self.assertIn("незакрытые отгрузки", str(err).casefold())

    def test_collected_label(self) -> None:
        self.assertEqual(
            _collected_label(
                {"mandatory_packaged_count": 16, "mandatory_postings_count": 18}
            ),
            "16 из 18",
        )

    def test_collected_label_includes_optional_pool(self) -> None:
        # Seller portal: mandatory 1249/1249 + optional 317 of 541 → 1566 из 1790.
        self.assertEqual(
            _collected_label(
                {
                    "mandatory_packaged_count": 1249,
                    "mandatory_postings_count": 1249,
                    "optional_packaged_count": 317,
                    "postings_for_another_carriage_count": 541,
                }
            ),
            "1566 из 1790",
        )

    def test_collected_label_optional_only_uses_carriage_postings(self) -> None:
        self.assertEqual(
            _collected_label(
                {
                    "mandatory_packaged_count": 0,
                    "mandatory_postings_count": 0,
                    "optional_packaged_count": 275,
                    "carriage_postings_count": 401,
                }
            ),
            "275 из 401",
        )

    def test_collected_label_draft_carriage_as_optional_pool(self) -> None:
        self.assertEqual(
            _collected_label(
                {
                    "mandatory_packaged_count": 1249,
                    "mandatory_postings_count": 1249,
                    "optional_packaged_count": 317,
                    "carriage_postings_count": 1249,
                    "carriages": [
                        {"id": 1, "postings_count": 1249, "status": "formed"},
                        {"id": 0, "postings_count": 541, "status": ""},
                    ],
                }
            ),
            "1566 из 1790",
        )

    def test_pick_self_delivery_method(self) -> None:
        methods = [
            {"id": 1, "name": "Курьер Ozon"},
            {"id": 2, "name": "Доставка Ozon самостоятельно, Кинешма"},
            {"id": 3, "name": "ПВЗ"},
        ]
        picked = pick_default_delivery_method(methods)
        self.assertEqual(picked["id"], 2)

    def test_merge_delivery_methods_from_posting_fallback(self) -> None:
        methods = _merge_delivery_methods(
            [],
            {"id": 102, "name": "Доставка Ozon самостоятельно, Кинешма"},
        )
        self.assertEqual(len(methods), 1)
        self.assertEqual(methods[0]["id"], 102)

    def test_block_matches_departure_filters_other_days(self) -> None:
        day = date(2026, 8, 26)
        self.assertTrue(
            _block_matches_departure({"departure_date": "2026-08-26T00:00:00Z"}, day)
        )
        self.assertFalse(
            _block_matches_departure({"departure_date": "2026-08-25T00:00:00Z"}, day)
        )

    def test_render_barcode_print_html_58x40(self) -> None:
        html = render_shipment_barcode_print_html(
            supply_name="Поставка 1",
            warehouse_name="Кинешма",
            barcode_text="123",
            barcode_image_base64="abc",
        )
        self.assertIn("58mm 40mm", html)
        # Invalid/tiny base64 cannot be composed — digits still rendered under bars.
        self.assertIn("123", html)
        self.assertIn('class="code"', html)

    def test_compose_barcode_label_includes_digits(self) -> None:
        from io import BytesIO

        from PIL import Image

        buf = BytesIO()
        Image.new("RGB", (200, 60), (0, 0, 0)).save(buf, format="PNG")
        b64 = __import__("base64").b64encode(buf.getvalue()).decode("ascii")
        composed = compose_shipment_barcode_label_png(
            barcode_image_base64=b64, barcode_text="1020005028015630"
        )
        self.assertIsNotNone(composed)
        assert composed is not None
        out = Image.open(BytesIO(composed))
        self.assertGreater(out.height, 60)
        self.assertGreaterEqual(out.width, 200)

    def test_compose_barcode_label_print_is_taller(self) -> None:
        from io import BytesIO

        from PIL import Image

        buf = BytesIO()
        Image.new("RGB", (200, 40), (0, 0, 0)).save(buf, format="PNG")
        b64 = __import__("base64").b64encode(buf.getvalue()).decode("ascii")
        screen = compose_shipment_barcode_label_png(
            barcode_image_base64=b64, barcode_text="1020005028015630", for_print=False
        )
        printed = compose_shipment_barcode_label_png(
            barcode_image_base64=b64, barcode_text="1020005028015630", for_print=True
        )
        self.assertIsNotNone(screen)
        self.assertIsNotNone(printed)
        assert screen is not None and printed is not None
        screen_img = Image.open(BytesIO(screen))
        print_img = Image.open(BytesIO(printed))
        self.assertGreater(print_img.height, screen_img.height)
        self.assertAlmostEqual(print_img.height / print_img.width, 40 / 58, delta=0.08)

    def test_normalize_empty_carriages_draft(self) -> None:
        block = _normalize_block(
            {
                "warehouse_name": "Кинешма_ВарФабрик_ОЗОН",
                "dropoff_point_type": "SortCenter",
                "first_mile_type": "dropoff",
                "dropoff_address": "Ивановская обл...",
                "mandatory_packaged_count": 16,
                "mandatory_postings_count": 18,
                "timeslot_to": "21:00",
                "recommended_time_local": "20:00",
                "warehouse_city": "Кинешма",
                "departure_date": "2026-08-25T00:00:00Z",
                "carriages": [],
            }
        )
        self.assertEqual(block["dropoff_point_type_label"], "Сортировочный центр")
        self.assertEqual(block["shipment_method_label"], "В пункт приема")
        self.assertEqual(block["collected_label"], "16 из 18")
        self.assertEqual(block["acceptance_label"], "до 21:00 (Кинешма)")
        self.assertEqual(block["hint"], "")
        self.assertEqual(len(block["carriages"]), 1)
        self.assertEqual(block["carriages"][0]["status_label"], "Не сформирована")
        self.assertTrue(block["carriages"][0]["can_form"])
        self.assertIn("августа", block["day_label"])

    def test_normalize_open_carriage_new_status(self) -> None:
        client = MagicMock()
        client.carriage_get.return_value = {"status": "formed", "carriage_id": 119882557}
        block = _normalize_block(
            {
                "dropoff_point_type": "SortCenter",
                "first_mile_type": "dropoff",
                "timeslot_to": "21:00",
                "warehouse_city": "Кинешма",
                "carriages": [
                    {"id": 119882557, "status": "new", "postings_count": 261},
                ],
            },
            client=client,
        )
        c = block["carriages"][0]
        self.assertEqual(c["label"], "Отгрузка 119882557")
        self.assertEqual(c["status_label"], "Сформирована")
        self.assertTrue(c["is_formed"])
        self.assertFalse(c["can_form"])
        client.carriage_get.assert_called_once_with(carriage_id=119882557)

    def test_normalize_v2_defaults_assembly_list_true(self) -> None:
        block = _normalize_block(
            {
                "dropoff_point_type": "SortCenter",
                "first_mile_type": "dropoff",
                "carriages": [
                    {
                        "id": 1,
                        "status": "formed",
                        "postings_count": 2,
                        "available_actions": ["get_details", "get_assembly_list"],
                    }
                ],
            },
            client=None,
        )
        self.assertTrue(block["assembly_list_availability"])

    def test_client_v2_request_bodies(self) -> None:
        from unittest.mock import MagicMock

        from review_processor.ozon_fbs import OzonFbsClient

        client = OzonFbsClient.__new__(OzonFbsClient)
        client.post_json = MagicMock(return_value={})
        OzonFbsClient.delivery_method_list(
            client, warehouse_id=1020005028015630, status="ACTIVE", limit=50
        )
        dm_body = client.post_json.call_args.args[1]
        self.assertEqual(dm_body["filter"]["warehouse_ids"], ["1020005028015630"])
        self.assertEqual(dm_body["filter"]["status"], ["ACTIVE"])
        self.assertNotIn("offset", dm_body)

        client.post_json.reset_mock()
        OzonFbsClient.carriage_delivery_list(
            client,
            delivery_method_id=1020005028015630,
            departure_date="2026-08-31T00:00:00.000Z",
        )
        cdl_body = client.post_json.call_args.args[1]
        self.assertEqual(
            cdl_body["filter"],
            {
                "delivery_method_id": 1020005028015630,
                "departure_date": "2026-08-31",
            },
        )
        self.assertNotIn("delivery_method_id", cdl_body)

    def test_build_shipments_view_prefers_self_delivery(self) -> None:
        client = MagicMock()
        client.delivery_method_list.return_value = {
            "has_next": False,
            "result": [
                {"id": 11, "name": "Другой метод", "status": "ACTIVE", "warehouse_id": 1},
                {
                    "id": 22,
                    "name": "Доставка на ОЗОН самостоятельно",
                    "status": "ACTIVE",
                    "warehouse_id": 1,
                },
            ],
        }
        client.carriage_delivery_list.return_value = {
            "result": [
                {
                    "delivery_method_id": 22,
                    "delivery_method_name": "Доставка на ОЗОН самостоятельно",
                    "warehouse_name": "Склад А",
                    "warehouse_id": 1,
                    "departure_date": "2026-08-25",
                    "dropoff_point_type": "SortCenter",
                    "first_mile_type": "dropoff",
                    "timeslot_to": "21:00",
                    "mandatory_packaged_count": 2,
                    "mandatory_postings_count": 2,
                    "carriages": [
                        {"id": "100", "postings_count": 2, "status": "formed"}
                    ],
                }
            ]
        }
        client.carriage_get.return_value = {"status": "formed", "carriage_id": 100}
        client.fbs_act_get_barcode_text.return_value = {"result": "1020005028015630"}
        from io import BytesIO
        import base64 as b64mod

        from PIL import Image

        png_buf = BytesIO()
        Image.new("RGB", (180, 50), (0, 0, 0)).save(png_buf, format="PNG")
        client.fbs_act_get_barcode.return_value = {
            "file_content": b64mod.b64encode(png_buf.getvalue()).decode("ascii"),
            "content_type": "image/png",
        }

        view = build_shipments_view(
            client=client,
            warehouse_id=1,
            warehouse_name="Склад А",
            departure=date(2026, 8, 25),
        )
        self.assertTrue(view["ok"])
        self.assertEqual(view["selected_delivery_method_id"], 22)
        self.assertEqual(view["barcode"]["barcode_text"], "1020005028015630")
        self.assertTrue(view["barcode"]["barcode_label_base64"])
        self.assertEqual(
            view["blocks"][0]["carriages"][0]["barcode"]["barcode_text"],
            "1020005028015630",
        )
        self.assertEqual(
            view["blocks"][0]["carriages"][0]["status_label"], "Сформирована"
        )
        client.carriage_delivery_list.assert_called_once()
        args = client.carriage_delivery_list.call_args.kwargs
        self.assertEqual(args["delivery_method_id"], 22)
        self.assertEqual(args["departure_date"], "2026-08-25")

    def test_build_shipments_view_barcode_per_formed_carriage(self) -> None:
        from io import BytesIO
        import base64 as b64mod

        from PIL import Image

        client = MagicMock()
        client.delivery_method_list.return_value = {
            "delivery_methods": [
                {"id": 22, "name": "Доставка на ОЗОН самостоятельно", "status": "ACTIVE"}
            ],
            "has_next": False,
        }
        client.carriage_delivery_list.return_value = {
            "methods": [
                {
                    "delivery_method_id": 22,
                    "departure_date": "2026-08-25",
                    "dropoff_point_type": "SortCenter",
                    "first_mile_type": "dropoff",
                    "carriages": [
                        {"id": 100, "postings_count": 10, "status": "formed"},
                        {"id": 200, "postings_count": 5, "status": "formed"},
                        {"id": 0, "postings_count": 3, "status": ""},
                    ],
                }
            ]
        }
        client.carriage_get.side_effect = lambda **kw: {
            "status": "formed",
            "carriage_id": kw["carriage_id"],
        }

        def _text(**kw):
            return {"result": f"BC-{kw['carriage_id']}"}

        def _img(**kw):
            buf = BytesIO()
            Image.new("RGB", (120, 40), (0, 0, 0)).save(buf, format="PNG")
            return {
                "file_content": b64mod.b64encode(buf.getvalue()).decode("ascii"),
                "content_type": "image/png",
            }

        client.fbs_act_get_barcode_text.side_effect = _text
        client.fbs_act_get_barcode.side_effect = _img

        view = build_shipments_view(
            client=client,
            warehouse_id=1,
            warehouse_name="Склад А",
            departure=date(2026, 8, 25),
        )
        carriages = view["blocks"][0]["carriages"]
        self.assertEqual(carriages[0]["barcode"]["barcode_text"], "BC-100")
        self.assertEqual(carriages[1]["barcode"]["barcode_text"], "BC-200")
        self.assertIsNone(carriages[2].get("barcode"))
        self.assertEqual(view["barcode"]["barcode_text"], "BC-100")
        self.assertEqual(client.fbs_act_get_barcode_text.call_count, 2)

    def test_build_shipments_view_surfaces_open_carriage_other_day(self) -> None:
        client = MagicMock()
        client.delivery_method_list.return_value = {
            "delivery_methods": [
                {"id": 22, "name": "Доставка на ОЗОН самостоятельно", "status": "ACTIVE"}
            ],
            "has_next": False,
        }
        client.carriage_delivery_list.return_value = {
            "methods": [
                {
                    "delivery_method_id": 22,
                    "departure_date": "2026-08-27",
                    "dropoff_point_type": "SortCenter",
                    "first_mile_type": "dropoff",
                    "timeslot_to": "21:00",
                    "warehouse_city": "Кинешма",
                    "carriages": [
                        {"id": 119882557, "status": "new", "postings_count": 10}
                    ],
                }
            ]
        }
        client.carriage_get.return_value = {"status": "formed"}
        view = build_shipments_view(
            client=client,
            warehouse_id=1,
            warehouse_name="Склад А",
            departure=date(2026, 8, 28),
        )
        self.assertTrue(view["ok"])
        self.assertTrue(view["has_open_carriages_blocking"])
        self.assertFalse(view["message"])
        self.assertFalse(view["blocks"][0]["carriages"][0]["can_form"])

    def test_build_shipments_view_uses_fallback_delivery_method(self) -> None:
        client = MagicMock()
        client.delivery_method_list.return_value = {
            "delivery_methods": [],
            "has_next": False,
        }
        client.carriage_delivery_list.return_value = {
            "methods": [
                {
                    "delivery_method_id": 102,
                    "delivery_method_name": "Доставка на ОЗОН самостоятельно",
                    "warehouse_name": "Склад А",
                    "departure_date": "2026-08-25",
                    "carriages": [],
                }
            ]
        }
        view = build_shipments_view(
            client=client,
            warehouse_id=1,
            warehouse_name="Склад А",
            departure=date(2026, 8, 25),
            fallback_delivery_method={
                "id": 102,
                "name": "Доставка Ozon самостоятельно, Кинешма",
            },
        )
        self.assertTrue(view["ok"])
        self.assertEqual(view["selected_delivery_method_id"], 102)
        self.assertEqual(len(view["delivery_methods"]), 1)
        client.carriage_delivery_list.assert_called_once()


class OzonFbsWarehouseBarcodeTests(unittest.TestCase):
    def test_fetch_warehouse_barcode_uses_warehouse_id(self) -> None:
        from io import BytesIO
        import base64 as b64mod

        from PIL import Image

        client = MagicMock()
        client.fbs_act_get_barcode_text.return_value = {"result": "1020005028015630"}
        png_buf = BytesIO()
        Image.new("RGB", (180, 50), (0, 0, 0)).save(png_buf, format="PNG")
        client.fbs_act_get_barcode.return_value = {
            "file_content": b64mod.b64encode(png_buf.getvalue()).decode("ascii"),
            "content_type": "image/png",
        }
        bc = fetch_warehouse_barcode(client, warehouse_id=1020005028015630)
        self.assertEqual(bc["barcode_text"], "1020005028015630")
        self.assertEqual(bc["warehouse_id"], 1020005028015630)
        self.assertEqual(bc["kind"], "warehouse")
        self.assertTrue(bc.get("barcode_label_base64"))
        client.fbs_act_get_barcode_text.assert_called_once_with(
            carriage_id=1020005028015630
        )
        client.fbs_act_get_barcode.assert_called_once_with(
            carriage_id=1020005028015630
        )

    def test_fetch_warehouse_barcode_text_fallback(self) -> None:
        client = MagicMock()
        client.fbs_act_get_barcode_text.side_effect = RuntimeError("no act")
        client.fbs_act_get_barcode.side_effect = RuntimeError("no act")
        bc = fetch_warehouse_barcode(client, warehouse_id=1020005028015630)
        self.assertEqual(bc["barcode_text"], "1020005028015630")
        self.assertEqual(bc["warehouse_id"], 1020005028015630)


if __name__ == "__main__":
    unittest.main()
