"""Markup for supply / GM cargo summary (WB + Ozon FBS)."""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TEMPLATES = ROOT / "web_templates"
STATIC = ROOT / "web_static"


def test_supply_and_gm_cargo_summary_markup() -> None:
    app_html = (TEMPLATES / "app.html").read_text(encoding="utf-8")
    style = (STATIC / "style.css").read_text(encoding="utf-8")
    app_js = (STATIC / "app.js").read_text(encoding="utf-8")
    ozon_js = (STATIC / "ozon_fbs.js").read_text(encoding="utf-8")

    for eid in (
        "wbFbsSupplyDetailCargo",
        "wbFbsCreateTrbxCargo",
        "ozonFbsSupplyDetailCargo",
        "ozonFbsContainersCargo",
    ):
        assert f'id="{eid}"' in app_html

    assert ".wb-fbs-sd-cargo" in style
    assert ".wb-fbs-sd-cargo-label" in style
    assert ".wb-fbs-sd-cargo-inline" in style
    assert ".wb-fbs-create-trbx-header-main" in style
    # Cargo stays next to ID/QR chips (meta must not flex-grow and push it to search).
    assert "flex: 0 1 auto" in style
    assert "Do not grow" in style or "next to ID/QR" in style
    assert ".wb-fbs-trbx-cargo.wb-fbs-trbx-cargo-inline" in style
    assert "align-items: center" in style
    # Meta chips / actions match QR control height.
    assert ".wb-fbs-sd-chip" in style
    chip = style[style.find(".wb-fbs-sd-chip {"): style.find(".wb-fbs-sd-chip {") + 280]
    assert "min-height: 36px" in chip
    assert "height: 36px" in chip


    assert "function _wbFbsRenderCargoSummary(" in app_js
    assert "function _wbFbsCargoSummaryLabel(" in app_js
    assert "function _wbFbsFormatCargoQty(" in app_js
    assert "wb-fbs-sd-cargo-chip" in app_js
    # WB supply modal: cargo chip is first in meta (left of МГТ / QR), not by search.
    assert 'wb-fbs-sd-chip wb-fbs-sd-chip-qr' in app_js
    assert '_wbFbsRenderCargoSummary("wbFbsSupplyDetailCargo", null)' in app_js
    assert "wbFbsSupplyDetailCargo" in app_js
    assert "wbFbsCreateTrbxCargo" in app_js
    assert "слева от МГТ" in app_js
    # Same cargo line format as Ozon; no redundant «Заказы N» under the title.
    assert "Товаров:" in app_js
    assert "Паллет:" in app_js
    assert "Коробов:" in app_js
    assert " шт. | " in app_js
    assert "Заказы ${_wbFbsEsc(supply.order_count" not in app_js
    assert "order_count chip removed" in app_js
    # Printer control must stay inside the QR chip border.
    qr_css = style[style.find(".wb-fbs-sd-chip-qr {"): style.find(".wb-fbs-sd-chip-qr {") + 220]
    assert "overflow: hidden" in qr_css
    assert "padding: 0 2px 0 12px" in qr_css
    assert "function _ozonFbsRenderCargoSummary(" in ozon_js
    assert "function _ozonFbsCargoSummaryText(" in ozon_js
    assert "function _ozonFbsFormatCargoQty(" in ozon_js
    assert "Товаров:" in ozon_js
    assert "Паллет:" in ozon_js
    assert "Коробов:" in ozon_js
    assert " шт. | " in ozon_js
    assert "ozonFbsSupplyDetailCargo" in ozon_js
    assert "ozonFbsContainersCargo" in ozon_js
    assert "ozonFbsSupplyDetailMovedAt" in app_html
    assert "_ozonFbsRenderMovedToDelivering" in ozon_js
    # Supply modal: no redundant «Отправлений N» chip under the title.
    assert 'Отправлений ${esc(supply.order_count' not in ozon_js
    assert "Отправлений ${" not in ozon_js


def test_ozon_cargo_summary_inline_with_meta_and_title() -> None:
    """Ozon: cargo summary sits left of ID chip on the same meta row."""
    app_html = (TEMPLATES / "app.html").read_text(encoding="utf-8")
    cargo_idx = app_html.find('id="ozonFbsSupplyDetailCargo"')
    meta_idx = app_html.find('id="ozonFbsSupplyDetailMeta"')
    assert cargo_idx > 0
    assert meta_idx > cargo_idx  # cargo left of ID meta
    neighborhood = app_html[max(0, cargo_idx - 400) : meta_idx + 80]
    assert "wb-fbs-sd-meta-row" in neighborhood
    assert "wb-fbs-sd-cargo-inline" in neighborhood

    c_idx = app_html.find('id="ozonFbsContainersCargo"')
    assert c_idx > 0
    c_nb = app_html[max(0, c_idx - 350) : c_idx + 180]
    assert "wb-fbs-create-trbx-header-main" in c_nb
    assert "wb-fbs-trbx-cargo-inline" in c_nb
    assert 'id="ozonFbsContainersTitle"' in c_nb


def test_wb_cargo_summary_inline_before_mgt_and_in_gm_header() -> None:
    """WB: cargo chip first in meta (JS); slot stays on meta row; GM cargo in header."""
    app_html = (TEMPLATES / "app.html").read_text(encoding="utf-8")
    app_js = (STATIC / "app.js").read_text(encoding="utf-8")
    cargo_idx = app_html.find('id="wbFbsSupplyDetailCargo"')
    assert cargo_idx > 0
    neighborhood = app_html[max(0, cargo_idx - 350) : cargo_idx + 220]
    assert "wb-fbs-sd-meta-row" in neighborhood
    assert "wb-fbs-sd-cargo-inline" in neighborhood
    assert 'id="wbFbsSupplyDetailMeta"' in neighborhood
    # Chip order in renderWbFbsSupplyDetail: cargo summary before cargo_label (МГТ).
    render_fn = app_js.find("function renderWbFbsSupplyDetail(")
    assert render_fn > 0
    chunk = app_js[render_fn : render_fn + 2200]
    cargo_chip = chunk.find("wb-fbs-sd-cargo-chip")
    mgt_chip = chunk.find("supply.cargo_label")
    assert cargo_chip > 0 and mgt_chip > 0
    assert cargo_chip < mgt_chip

    modal_start = app_html.find('id="wbFbsCreateTrbxModal"')
    assert modal_start > 0
    modal = app_html[modal_start : modal_start + 2500]
    assert "wb-fbs-create-trbx-lead" not in modal
    assert "1 короб = 1 грузоместо" not in modal
    assert "Сделайте это до передачи" not in modal
    c_idx = modal.find('id="wbFbsCreateTrbxCargo"')
    assert c_idx > 0
    c_nb = modal[max(0, c_idx - 400) : c_idx + 160]
    assert "wb-fbs-create-trbx-header-main" in c_nb
    assert "wb-fbs-trbx-cargo-inline" in c_nb
    assert 'id="wbFbsCreateTrbxTitle"' in c_nb
