"""WB FBS «Возвраты» — scan journal and goods-return sync."""

from __future__ import annotations

import contextlib
import json
import threading
import unittest
from datetime import date
from unittest.mock import MagicMock, patch

from review_processor import wb_fbs_returns as returns
from review_processor import wb_fbs as wb


def _fake_wb_jwt(*, uid: int = 1, scopes: int = wb.WB_SCOPE_ANALYTICS | wb.WB_SCOPE_MARKETPLACE) -> str:
    import base64
    import json

    header = base64.urlsafe_b64encode(b'{"alg":"ES256"}').decode().rstrip("=")
    payload = base64.urlsafe_b64encode(
        json.dumps({"uid": uid, "s": scopes}, separators=(",", ":")).encode()
    ).decode().rstrip("=")
    return f"{header}.{payload}.sig"


class WbJwtScopeBitmaskTests(unittest.TestCase):
    """WB docs «Bit position N» is bit index N (value 2**N), not 2**(N-1)."""

    def test_analytics_bit_matches_live_goods_return_token(self):
        # Live cabinet: BuyersReturns+ReadOnly alone → 403; +Analytics → 200.
        buyers_only = 1073743872  # bits 11, 30
        with_analytics = 1073743876  # bits 2, 11, 30
        self.assertEqual(wb.WB_SCOPE_ANALYTICS, 1 << 2)
        self.assertEqual(wb.WB_SCOPE_BUYERS_RETURNS, 1 << 11)
        self.assertFalse(wb.wb_token_has_scope(_fake_wb_jwt(scopes=buyers_only), wb.WB_GOODS_RETURN_SCOPES))
        self.assertTrue(wb.wb_token_has_scope(_fake_wb_jwt(scopes=with_analytics), wb.WB_GOODS_RETURN_SCOPES))
        labels = wb.wb_token_scope_labels(_fake_wb_jwt(scopes=with_analytics))
        self.assertIn("Аналитика", labels)
        self.assertIn("Возвраты покупателей", labels)
        self.assertNotIn("Цены", labels)

    def test_marketplace_only_is_not_goods_return(self):
        token = _fake_wb_jwt(scopes=wb.WB_SCOPE_MARKETPLACE)
        self.assertFalse(wb.wb_token_has_goods_return_scope(token))
        self.assertEqual(wb.wb_token_scope_labels(token), ["Маркетплейс"])


class GoodsReturnWindowTests(unittest.TestCase):
    def test_iter_goods_return_windows_splits_90_days(self):
        windows = returns.iter_goods_return_windows("2026-01-01", "2026-03-31")
        self.assertEqual(len(windows), 3)
        self.assertEqual(windows[0][0], "2026-01-01")
        self.assertEqual(windows[-1][1], "2026-03-31")
        for win_from, win_to in windows:
            span = (
                date.fromisoformat(win_to) - date.fromisoformat(win_from)
            ).days + 1
            self.assertLessEqual(span, returns.GOODS_RETURN_MAX_WINDOW_DAYS)

    def test_iter_goods_return_windows_single_month(self):
        windows = returns.iter_goods_return_windows("2026-08-01", "2026-08-20")
        self.assertEqual(windows, [("2026-08-01", "2026-08-20")])

    def test_clamp_goods_return_sync_range_limits_to_90_days(self):
        df, dt, clamped = returns.clamp_goods_return_sync_range(
            "2025-01-01", "2026-08-27"
        )
        self.assertTrue(clamped)
        span = (
            date.fromisoformat(dt) - date.fromisoformat(df)
        ).days + 1
        self.assertLessEqual(span, returns.GOODS_RETURN_DEFAULT_TOTAL_DAYS)


class GoodsReturnUpsertTests(unittest.TestCase):
    def test_upsert_skips_unchanged_srid(self):
        repo = MagicMock()
        repo._sql = lambda sql: sql
        repo._row_to_dict = lambda row: dict(row)

        class _Result:
            def __init__(self, payload):
                self._payload = payload

            def fetchone(self):
                return self._payload[0] if self._payload else None

        raw = json.dumps({"orderId": 1, "srid": "s1", "status": "ok"})
        values = (1, 2, 1, "st", "", "", None, "s1", "ok", "", "", "", "", raw, "now")
        conn = MagicMock()
        conn.execute = MagicMock(return_value=_Result([{"raw_json": raw}]))
        outcome = returns._upsert_goods_return_row(
            conn,
            repo,
            user_id=1,
            source_id=2,
            values=values,
            raw_json=raw,
            srid="s1",
            order_id=1,
            sticker_id="st",
        )
        self.assertEqual(outcome, "unchanged")
        self.assertEqual(conn.execute.call_count, 1)

    def test_values_from_row_accepts_item_returns_field_names(self):
        row = {
            "orderId": 42,
            "stickerId": "st-1",
            "srid": "srid-1",
            "sku": "203001",
            "shkId": 987612345,
            "nmId": 111,
            "returnStatus": "В пути в пвз",
            "returnReason": "брак",
            "readyToReturnDt": None,
            "completedDt": None,
            "orderDt": "2026-08-24",
        }
        parsed = returns._goods_return_values_from_row(
            row, user_id=1, source_id=2, synced_at="now"
        )
        self.assertIsNotNone(parsed)
        values, _raw, srid, order_id, sticker_id = parsed
        self.assertEqual(srid, "srid-1")
        self.assertEqual(order_id, 42)
        self.assertEqual(sticker_id, "st-1")
        self.assertEqual(values[4], "203001")  # barcode from sku
        self.assertEqual(values[5], "987612345")  # shk_id
        self.assertEqual(values[8], "В пути в пвз")  # status
        self.assertEqual(values[9], "брак")  # reason
        self.assertEqual(values[12], "2026-08-24")


class ItemReturnsFetchTests(unittest.TestCase):
    def test_normalize_item_return_row_maps_legacy_fields(self):
        normalized = returns._normalize_item_return_row(
            {
                "sku": "SKU-1",
                "returnStatus": "active-status",
                "returnReason": "reason-x",
                "orderId": 1,
            },
            list_status="active",
        )
        self.assertEqual(normalized["barcode"], "SKU-1")
        self.assertEqual(normalized["status"], "active-status")
        self.assertEqual(normalized["reason"], "reason-x")
        self.assertEqual(normalized["sku"], "SKU-1")
        self.assertEqual(normalized["isStatusActive"], 1)
        archived = returns._normalize_item_return_row(
            {"sku": "2", "returnStatus": "done"}, list_status="archive"
        )
        self.assertEqual(archived["isStatusActive"], 0)

    @patch("review_processor.wb_fbs_returns.time.sleep")
    @patch("review_processor.wb_fbs_returns.urllib.request.urlopen")
    def test_fetch_goods_return_report_uses_item_returns_active_and_archive(
        self, urlopen_mock, sleep_mock
    ):
        responses = [
            {
                "count": 1,
                "report": [
                    {
                        "orderId": 1,
                        "srid": "a1",
                        "sku": "111",
                        "returnStatus": "В пути",
                        "stickerId": "st-a",
                    }
                ],
            },
            {
                "count": 1,
                "report": [
                    {
                        "orderId": 2,
                        "srid": "b1",
                        "sku": "222",
                        "returnStatus": "Выдан",
                        "stickerId": "st-b",
                    }
                ],
            },
        ]
        calls: list[str] = []

        class _Resp:
            def __init__(self, payload: dict):
                self.status = 200
                self._payload = json.dumps(payload).encode("utf-8")

            def read(self):
                return self._payload

            def getcode(self):
                return 200

            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

        def _open(req, timeout=60):
            calls.append(str(req.full_url))
            return _Resp(responses[len(calls) - 1])

        urlopen_mock.side_effect = _open
        rows = returns.fetch_goods_return_report(
            api_key="token",
            date_from="2026-08-01",
            date_to="2026-08-20",
        )
        self.assertEqual(len(calls), 2)
        self.assertIn("/api/analytics/v1/item-returns?", calls[0])
        self.assertIn("status=active", calls[0])
        self.assertIn("limit=1000", calls[0])
        self.assertIn("offset=0", calls[0])
        self.assertIn("status=archive", calls[1])
        self.assertNotIn("/api/v1/analytics/goods-return", calls[0])
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["barcode"], "111")
        self.assertEqual(rows[0]["status"], "В пути")
        self.assertEqual(rows[0]["isStatusActive"], 1)
        self.assertEqual(rows[1]["barcode"], "222")
        self.assertEqual(rows[1]["isStatusActive"], 0)
        sleep_mock.assert_called_once_with(returns.GOODS_RETURN_REQUEST_INTERVAL_SEC)

    @patch("review_processor.wb_fbs_returns.time.sleep")
    @patch("review_processor.wb_fbs_returns.urllib.request.urlopen")
    def test_fetch_goods_return_report_handles_204_empty(self, urlopen_mock, sleep_mock):
        class _Resp:
            status = 204

            def read(self):
                return b""

            def getcode(self):
                return 204

            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

        urlopen_mock.return_value = _Resp()
        rows = returns.fetch_goods_return_report(
            api_key="token",
            date_from="2026-08-01",
            date_to="2026-08-02",
        )
        self.assertEqual(rows, [])
        self.assertEqual(urlopen_mock.call_count, 2)
        sleep_mock.assert_called_once()

    @patch("review_processor.wb_fbs_returns.time.sleep")
    @patch("review_processor.wb_fbs_returns._fetch_item_returns_page")
    def test_fetch_goods_return_report_paginates_until_exhausted(self, page_mock, sleep_mock):
        page_mock.side_effect = [
            ([{"orderId": 1, "srid": "p1", "sku": "1", "returnStatus": "a"}] * 1000, 1001),
            ([{"orderId": 2, "srid": "p2", "sku": "2", "returnStatus": "a"}], 1001),
            ([], 0),
        ]
        rows = returns.fetch_goods_return_report(
            api_key="token",
            date_from="2026-08-01",
            date_to="2026-08-10",
        )
        self.assertEqual(page_mock.call_count, 3)
        self.assertEqual(page_mock.call_args_list[0].kwargs["status"], "active")
        self.assertEqual(page_mock.call_args_list[0].kwargs["offset"], 0)
        self.assertEqual(page_mock.call_args_list[1].kwargs["offset"], 1000)
        self.assertEqual(page_mock.call_args_list[2].kwargs["status"], "archive")
        self.assertEqual(len(rows), 1001)
        self.assertEqual(sleep_mock.call_count, 2)


class GoodsReturnMatchTests(unittest.TestCase):
    def _repo_with_goods_returns(self, rows: list[dict]):
        repo = MagicMock()
        repo._sql = lambda sql: sql
        repo._row_to_dict = lambda row: dict(row)

        class _Result:
            def __init__(self, payload):
                self._payload = payload

            def fetchall(self):
                return self._payload

        conn = MagicMock()
        conn.execute = MagicMock(side_effect=lambda sql, params=None: _Result(rows))
        repo._connect.return_value.__enter__ = MagicMock(return_value=conn)
        repo._connect.return_value.__exit__ = MagicMock(return_value=False)
        return repo

    @patch("review_processor.wb_fbs_returns.wb.ensure_wb_fbs_tables")
    @patch("review_processor.wb_fbs_returns.ensure_wb_fbs_returns_tables")
    def test_find_goods_return_by_sticker_id(self, _ensure_ret, _ensure_wb):
        repo = self._repo_with_goods_returns(
            [
                {
                    "sticker_id": "44556677",
                    "wb_order_id": 900001,
                    "barcode": "",
                    "shk_id": "",
                }
            ]
        )
        hit = returns.find_goods_return_by_scan(
            repo, user_id=1, source_id=2, scan="44556677"
        )
        self.assertIsNotNone(hit)
        self.assertEqual(hit["wb_order_id"], 900001)

    @patch("review_processor.wb_fbs_returns.wb.ensure_wb_fbs_tables")
    @patch("review_processor.wb_fbs_returns.ensure_wb_fbs_returns_tables")
    def test_find_goods_return_by_barcode(self, _ensure_ret, _ensure_wb):
        repo = self._repo_with_goods_returns(
            [
                {
                    "sticker_id": "",
                    "wb_order_id": 900002,
                    "barcode": "2000000000123",
                    "shk_id": "",
                }
            ]
        )
        hit = returns.find_goods_return_by_scan(
            repo, user_id=1, source_id=2, scan="2000000000123"
        )
        self.assertIsNotNone(hit)
        self.assertEqual(hit["wb_order_id"], 900002)

    @patch("review_processor.wb_fbs_returns.wb.ensure_wb_fbs_tables")
    @patch("review_processor.wb_fbs_returns.ensure_wb_fbs_returns_tables")
    def test_find_goods_return_by_srid(self, _ensure_ret, _ensure_wb):
        repo = self._repo_with_goods_returns(
            [
                {
                    "sticker_id": "",
                    "srid": "abc123def456",
                    "wb_order_id": 900003,
                    "barcode": "",
                    "shk_id": "",
                }
            ]
        )
        hit = returns.find_goods_return_by_scan(
            repo, user_id=1, source_id=2, scan="abc123def456"
        )
        self.assertIsNotNone(hit)
        self.assertEqual(hit["wb_order_id"], 900003)


class ReturnScanDuplicateTests(unittest.TestCase):
    @patch("review_processor.wb_fbs_returns._insert_return_scan")
    @patch("review_processor.wb_fbs_returns._kiz_codes_for_order", return_value=[])
    @patch("review_processor.wb_fbs_returns._product_from_order", return_value={})
    @patch("review_processor.wb_fbs_returns._resolve_order_row", return_value=None)
    @patch("review_processor.wb_fbs_returns._return_scan_duplicate")
    def test_return_sticker_duplicate(self, dup, _order, _prod, _kiz, _insert):
        dup.return_value = {
            "id": 11,
            "scan_type": "return_sticker",
            "return_sticker_id": "12345",
            "matched_order_ids_json": "[]",
            "product_barcodes_json": "[]",
        }
        repo = MagicMock()
        result = returns._process_return_sticker_scan(
            repo,
            user_id=1,
            source_id=2,
            api_key="k",
            scan="12345",
            goods_row={"sticker_id": "12345", "wb_order_id": 1},
        )
        _insert.assert_not_called()
        self.assertFalse(result["ok"])
        self.assertEqual(result["error"], "duplicate")


class ReturnStickerKizLinkTests(unittest.TestCase):
    @patch("review_processor.wb_fbs_returns._insert_return_scan")
    @patch("review_processor.wb_fbs_returns._kiz_codes_for_order")
    @patch("review_processor.wb_fbs_returns._product_from_order", return_value={"product_name": "Товар"})
    @patch("review_processor.wb_fbs_returns._resolve_order_row")
    @patch("review_processor.wb_fbs_returns._return_scan_duplicate", return_value=None)
    def test_return_sticker_passes_srid_for_kiz_lookup(
        self, _dup, resolve_order, _prod, kiz_lookup, insert
    ):
        resolve_order.return_value = {
            "order_id": 5525061048,
            "sticker_part_a": "1",
            "sticker_part_b": "2345",
            "sticker_barcode": "qr",
        }
        kiz_lookup.return_value = ["010467012345678921CIRC"]
        insert.return_value = {
            "id": 21,
            "scan_type": "return_sticker",
            "order_id": 5525061048,
            "kiz_code": "010467012345678921CIRC",
            "matched_order_ids_json": "[]",
            "product_barcodes_json": "[]",
        }
        repo = MagicMock()
        result = returns._process_return_sticker_scan(
            repo,
            user_id=1,
            source_id=2,
            api_key="k",
            scan="99887766",
            goods_row={
                "sticker_id": "99887766",
                "wb_order_id": 5525061048,
                "srid": "eI.i0a39f75abc.1.0",
            },
        )
        self.assertTrue(result["ok"])
        kiz_lookup.assert_called_once()
        kwargs = kiz_lookup.call_args.kwargs
        self.assertEqual(kwargs["order_id"], 5525061048)
        self.assertEqual(kwargs["srid_hint"], "eI.i0a39f75abc.1.0")
        self.assertEqual(result["item"]["kiz_code"], "010467012345678921CIRC")


class KizScanTests(unittest.TestCase):
    @patch("review_processor.wb_fbs_returns._insert_return_scan")
    @patch("review_processor.wb_fbs_returns._product_from_gtin", return_value={})
    @patch("review_processor.wb_fbs_returns._catalog_barcodes_index", return_value={})
    @patch("review_processor.wb_fbs_returns.kiz_restore.find_kiz_in_local_database")
    @patch("review_processor.wb_fbs_returns.kiz_restore.looks_like_kiz_scan", return_value=True)
    @patch("review_processor.wb_fbs_returns.kiz_restore.normalize_kiz_mark", side_effect=lambda x: x)
    @patch("review_processor.wb_fbs_returns.kiz_restore.extract_gtin14", return_value="04670123456789")
    def test_kiz_scan_gtin_not_in_catalog_warns(
        self,
        _gtin,
        _norm,
        _looks,
        db_hit,
        _catalog,
        _prod,
        insert,
    ):
        db_hit.return_value = {"found": False, "order_ids": []}
        insert.return_value = {"id": 6, "scan_type": "kiz", "kiz_code": "010467012345678921X"}
        repo = MagicMock()
        result = returns.process_return_scan(
            repo,
            user_id=1,
            source_id=2,
            api_key="k",
            scan="010467012345678921X",
        )
        self.assertTrue(result["ok"])
        self.assertIn("GTIN не найден в каталоге товаров", result["item"].get("warning", ""))

    @patch("review_processor.wb_fbs_returns._insert_return_scan")
    @patch("review_processor.wb_fbs_returns._product_from_gtin", return_value={})
    @patch("review_processor.wb_fbs_returns.kiz_restore.find_kiz_in_local_database")
    @patch("review_processor.wb_fbs_returns.kiz_restore.looks_like_kiz_scan", return_value=True)
    @patch("review_processor.wb_fbs_returns.kiz_restore.normalize_kiz_mark", side_effect=lambda x: x)
    @patch("review_processor.wb_fbs_returns.kiz_restore.extract_gtin14", return_value="04670123456789")
    def test_kiz_scan_not_in_local_db_warns(
        self,
        _gtin,
        _norm,
        _looks,
        db_hit,
        _prod,
        insert,
    ):
        db_hit.return_value = {"found": False, "order_ids": []}
        insert.return_value = {"id": 5, "scan_type": "kiz", "kiz_code": "010467012345678921X"}
        repo = MagicMock()
        result = returns.process_return_scan(
            repo,
            user_id=1,
            source_id=2,
            api_key="k",
            scan="010467012345678921X",
        )
        self.assertTrue(result["ok"])
        self.assertIn("warning", result["item"])


class ReturnCatalogFieldsTests(unittest.TestCase):
    def test_catalog_fields_from_product(self):
        out = returns._catalog_fields_from_product(
            {
                "barcodes": ["2038564013653", "4670123456789"],
                "barcode_label_name": "Этикетка",
            }
        )
        self.assertEqual(out["catalog_barcodes"], ["2038564013653", "4670123456789"])
        self.assertEqual(out["barcode_label_name"], "Этикетка")

    def test_enrich_return_scan_catalog_fields_by_article(self):
        repo = MagicMock()
        repo.list_product_photos.return_value = [
            {
                "supplier_article": "art-1",
                "barcodes": ["2038564013653"],
                "barcode_label_name": "Под этикетку",
            }
        ]
        item = returns._enrich_return_scan_catalog_fields(
            repo,
            user_id=1,
            item={"product_article": "art-1"},
        )
        self.assertEqual(item["catalog_barcodes"], ["2038564013653"])
        self.assertEqual(item["barcode_label_name"], "Под этикетку")

    def test_scan_item_for_api_enriches_catalog_barcodes(self):
        repo = MagicMock()
        repo.list_product_photos.return_value = [
            {
                "supplier_article": "art-1",
                "barcodes": ["2038564013653"],
                "barcode_label_name": "Под этикетку",
            }
        ]
        row = {
            "id": 7,
            "product_article": "art-1",
            "matched_order_ids_json": "[]",
            "product_barcodes_json": "[]",
        }
        item = returns._scan_item_for_api(repo, user_id=1, row=row)
        self.assertEqual(item["catalog_barcodes"], ["2038564013653"])
        self.assertEqual(item["id"], 7)


class GoodsReturnHttpErrorTests(unittest.TestCase):
    def test_format_retry_hint_seconds(self):
        hint = returns._format_wb_retry_hint("1800")
        self.assertIn("30 мин", hint)

    def test_format_retry_hint_unix_timestamp_msk(self):
        # 2026-08-25 00:47:17 UTC = 03:47 MSK
        hint = returns._format_wb_retry_hint("1787618837")
        self.assertIn("МСК", hint)
        self.assertIn("03:47", hint)

    def test_format_goods_return_http_error_429(self):
        err = returns.format_wb_goods_return_http_error(
            code=429,
            body='{"status":429}',
            retry_after="900",
        )
        self.assertIn("не выполнена", str(err))
        self.assertIn("Повторите после", str(err))
        self.assertIn("МСК", str(err))
        self.assertNotIn("29 мин", str(err))
        self.assertEqual(err.code, 429)
        self.assertGreaterEqual(err.retry_seconds, 895)
        self.assertLessEqual(err.retry_seconds, 900)

    def test_format_goods_return_http_error_429_unix_timestamp(self):
        # 2026-08-25 00:47:17 UTC = 03:47:17 MSK
        err = returns.format_wb_goods_return_http_error(
            code=429,
            body='{"status":429}',
            retry_after="1787618837",
        )
        self.assertIn("03:47:17 МСК", str(err))
        self.assertIn("25.08.2026", str(err))

    def test_parse_wb_retry_seconds_plain(self):
        parsed = returns._parse_wb_retry_seconds("540")
        self.assertGreaterEqual(parsed, 535)
        self.assertLessEqual(parsed, 540)

    @patch("review_processor.wb_fbs_returns.fetch_goods_return_report")
    @patch("review_processor.wb_fbs_returns._goods_return_token_rate_slot")
    @patch("review_processor.wb_fbs_returns.time.sleep")
    def test_fetch_goods_return_report_rated_fails_fast_on_429(
        self, sleep_mock, slot_mock, fetch_mock
    ):
        slot_mock.side_effect = lambda **kwargs: contextlib.nullcontext()
        fetch_mock.side_effect = returns.GoodsReturnHttpError(
            "429", code=429, retry_after="1800", retry_seconds=1800
        )
        with self.assertRaises(returns.GoodsReturnHttpError) as ctx:
            returns.fetch_goods_return_report_rated(
                api_key="test-key",
                date_from="2026-08-01",
                date_to="2026-08-31",
                source_id=19,
            )
        self.assertEqual(ctx.exception.code, 429)
        self.assertEqual(fetch_mock.call_count, 1)
        sleep_mock.assert_not_called()


class ListReturnScansTests(unittest.TestCase):
    def test_return_scans_search_sql_empty(self):
        clause, params = returns._return_scans_search_sql("")
        self.assertEqual(clause, "")
        self.assertEqual(params, [])

    def test_return_scans_search_sql_pattern(self):
        clause, params = returns._return_scans_search_sql("5525")
        self.assertIn("ILIKE", clause)
        self.assertEqual(len(params), 10)
        self.assertTrue(all(p == "%5525%" for p in params))

    @patch("review_processor.wb_fbs_returns._enrich_return_scan_catalog_fields", side_effect=lambda _repo, **kwargs: kwargs["item"])
    @patch("review_processor.wb_fbs_returns._catalog_by_article_index", return_value={})
    @patch("review_processor.wb_fbs_returns.ensure_wb_fbs_returns_tables")
    def test_list_return_scans_has_more(self, _ensure, _catalog, _enrich):
        repo = MagicMock()
        row = {
            "id": 1,
            "user_id": 1,
            "source_id": 2,
            "scanned_at": "2025-01-01T00:00:00+00:00",
            "scan_type": "return_sticker",
            "scan_raw": "x",
            "return_sticker_id": "",
            "order_id": 1,
            "assembly_sticker_barcode": "",
            "assembly_sticker_number": "",
            "kiz_code": "",
            "matched_order_ids_json": "[]",
            "product_name": "",
            "product_article": "",
            "product_photo": "",
            "product_barcodes_json": "[]",
            "gtin14": "",
            "duplicate_of_id": None,
        }
        conn = MagicMock()
        conn.execute.return_value.fetchall.return_value = [row, row]
        repo._connect.return_value.__enter__.return_value = conn
        repo._row_to_dict.side_effect = lambda r: dict(r)
        repo._sql.side_effect = lambda q: q

        result = returns.list_return_scans(
            repo,
            user_id=1,
            source_id=2,
            limit=1,
            offset=0,
        )
        self.assertTrue(result["has_more"])
        self.assertEqual(len(result["items"]), 1)


class ReturnOrderPreviewTests(unittest.TestCase):
    @patch("review_processor.wb_fbs_returns._kiz_codes_for_order", return_value=["010467012345678921PREV"])
    @patch("review_processor.wb_fbs_returns._product_from_order", return_value={"product_name": "Товар", "product_article": "art-1"})
    @patch("review_processor.wb_fbs_returns._goods_return_srid_hint", return_value="eI.test.1.0")
    @patch("review_processor.wb_fbs_returns._resolve_order_row")
    def test_build_return_order_preview(self, resolve_order, _srid, _prod, _kiz):
        resolve_order.return_value = {
            "order_id": 5525061048,
            "sticker_part_a": "1",
            "sticker_part_b": "9999",
            "sticker_barcode": "qr1",
        }
        repo = MagicMock()
        out = returns.build_return_order_preview(
            repo,
            user_id=1,
            source_id=2,
            order_id=5525061048,
            api_key="k",
        )
        self.assertTrue(out["found"])
        item = out["item"]
        self.assertTrue(item["preview"])
        self.assertIsNone(item["id"])
        self.assertEqual(item["scan_type"], "lookup")
        self.assertEqual(item["order_id"], 5525061048)
        self.assertEqual(item["kiz_code"], "010467012345678921PREV")

    @patch("review_processor.wb_fbs_returns._resolve_order_row", return_value=None)
    def test_build_return_order_preview_not_found(self, _resolve):
        repo = MagicMock()
        out = returns.build_return_order_preview(
            repo, user_id=1, source_id=2, order_id=999, api_key="k"
        )
        self.assertFalse(out["found"])


class ExportCsvTests(unittest.TestCase):
    def test_export_return_scans_csv_has_bom(self):
        csv_text = returns.export_return_scans_csv(
            [
                {
                    "scanned_at": "2026-01-01T10:00:00+00:00",
                    "scan_type": "return_sticker",
                    "order_id": 1,
                    "return_sticker_id": "99",
                    "assembly_sticker_number": "13640",
                    "kiz_code": "KIZ",
                    "product_name": "Товар",
                    "product_article": "art-1",
                    "product_barcodes": ["123"],
                }
            ]
        )
        self.assertTrue(csv_text.startswith("\ufeff"))
        self.assertIn("Товар", csv_text)

    def test_export_goods_returns_csv_has_bom_and_fields(self):
        csv_text = returns.export_goods_returns_csv(
            [
                {
                    "wb_order_id": 900001,
                    "sticker_id": "54628560521",
                    "barcode": "1680063403480",
                    "shk_id": "23411783472",
                    "srid": "ad3817664d3046c5a8d55054d8be96d6",
                    "nm_id": 12862181,
                    "status": "Готов к выдаче",
                    "reason": "Цвет",
                    "order_dt": "2026-08-20",
                    "ready_to_return_dt": "2026-08-21",
                    "completed_dt": "",
                    "synced_at": "2026-08-27T10:00:00+00:00",
                    "raw_json": json.dumps(
                        {
                            "returnType": "Возврат товара",
                            "brand": "TestBrand",
                            "subjectName": "Рубашки",
                            "dstOfficeAddress": "Москва",
                        },
                        ensure_ascii=False,
                    ),
                }
            ]
        )
        self.assertTrue(csv_text.startswith("\ufeff"))
        self.assertIn("54628560521", csv_text)
        self.assertIn("TestBrand", csv_text)
        self.assertIn("stickerId", csv_text)

    @patch("review_processor.wb_fbs_returns.ensure_wb_fbs_returns_tables")
    def test_list_goods_returns_date_filter(self, _ensure):
        repo = MagicMock()
        repo._sql = lambda sql: sql

        class _Result:
            def fetchall(self):
                return [{"wb_order_id": 1, "sticker_id": "99", "raw_json": "{}"}]

        conn = MagicMock()
        conn.execute = MagicMock(return_value=_Result())
        repo._connect.return_value.__enter__ = MagicMock(return_value=conn)
        repo._connect.return_value.__exit__ = MagicMock(return_value=False)
        repo._row_to_dict = lambda row: dict(row)

        rows = returns.list_goods_returns(
            repo,
            user_id=1,
            source_id=2,
            date_from="2026-08-01",
            date_to="2026-08-31",
        )
        self.assertEqual(len(rows), 1)
        sql = conn.execute.call_args[0][0]
        self.assertIn("order_dt", sql)


class GoodsReturnRateLimitTests(unittest.TestCase):
    def setUp(self):
        returns._goods_return_token_locks.clear()
        returns._goods_return_token_last_request.clear()
        returns._goods_return_token_blocked_until.clear()

    def test_analytics_token_key_prefers_uid(self):
        token = _fake_wb_jwt(uid=42)
        self.assertEqual(returns._analytics_token_key(token), "uid:42")

    def test_analytics_token_key_hash_fallback(self):
        key = returns._analytics_token_key("not-a-jwt-token")
        self.assertTrue(key.startswith("hash:"))

    def test_parse_wb_retry_seconds_plain(self):
        parsed = returns._parse_wb_retry_seconds("540")
        self.assertGreaterEqual(parsed, 535)
        self.assertLessEqual(parsed, 540)

    def test_parse_wb_retry_seconds_unix_timestamp(self):
        future = int(__import__("time").time()) + 120
        parsed = returns._parse_wb_retry_seconds(str(future))
        self.assertGreaterEqual(parsed, 110)
        self.assertLessEqual(parsed, 130)

    def test_format_goods_return_http_error_429_has_retry_seconds(self):
        err = returns.format_wb_goods_return_http_error(
            code=429,
            body='{"status":429}',
            retry_after="900",
        )
        self.assertIsInstance(err, returns.GoodsReturnHttpError)
        self.assertEqual(err.code, 429)
        self.assertGreaterEqual(err.retry_seconds, 895)
        self.assertLessEqual(err.retry_seconds, 900)

    @patch("review_processor.wb_fbs_returns.time.sleep")
    @patch("review_processor.wb_fbs_returns.fetch_goods_return_report")
    def test_fetch_goods_return_report_rated_fails_on_429(self, fetch_report, sleep_mock):
        token = _fake_wb_jwt(uid=7)
        err429 = returns.GoodsReturnHttpError(
            "Синхронизация возвратов WB не выполнена",
            code=429,
            retry_after="1800",
            retry_seconds=1800,
        )
        fetch_report.side_effect = err429
        with self.assertRaises(returns.GoodsReturnHttpError):
            returns.fetch_goods_return_report_rated(
                api_key=token,
                date_from="2026-08-01",
                date_to="2026-08-10",
                source_id=19,
            )
        self.assertEqual(fetch_report.call_count, 1)
        sleep_mock.assert_not_called()

    @patch("review_processor.wb_fbs_returns.time.sleep")
    @patch("review_processor.wb_fbs_returns.fetch_goods_return_report")
    def test_fetch_goods_return_report_rated_enforces_token_cooldown(self, fetch_report, sleep_mock):
        token = _fake_wb_jwt(uid=99)
        fetch_report.return_value = []
        returns._goods_return_token_last_request["uid:99"] = __import__("time").monotonic()
        returns.fetch_goods_return_report_rated(
            api_key=token,
            date_from="2026-08-01",
            date_to="2026-08-02",
            source_id=1,
        )
        sleep_mock.assert_called()
        wait_arg = sleep_mock.call_args[0][0]
        self.assertGreater(wait_arg, 0)
        self.assertLessEqual(wait_arg, returns.GOODS_RETURN_REQUEST_INTERVAL_SEC)

    @patch("review_processor.wb_fbs_returns.fetch_goods_return_report")
    def test_fetch_goods_return_report_rated_sets_block_on_429(self, fetch_report):
        token = _fake_wb_jwt(uid=8)
        fetch_report.side_effect = returns.GoodsReturnHttpError(
            "429",
            code=429,
            retry_after="600",
            retry_seconds=600,
        )
        with self.assertRaises(returns.GoodsReturnHttpError):
            returns.fetch_goods_return_report_rated(
                api_key=token,
                date_from="2026-08-01",
                date_to="2026-08-10",
                source_id=19,
            )
        status = returns.goods_return_rate_limit_status(api_key=token)
        self.assertTrue(status.get("blocked"))
        self.assertGreater(status.get("seconds_remaining", 0), 550)

    @patch("review_processor.wb_fbs_returns.fetch_goods_return_report")
    def test_ensure_goods_return_not_rate_limited_blocks_without_wb_call(self, fetch_report):
        token = _fake_wb_jwt(uid=9)
        returns._set_goods_return_token_block(
            api_key=token,
            retry_after="1200",
        )
        with self.assertRaises(returns.GoodsReturnHttpError) as ctx:
            returns.ensure_goods_return_not_rate_limited(api_key=token)
        self.assertEqual(ctx.exception.code, 429)
        fetch_report.assert_not_called()

    @patch("review_processor.wb_fbs_returns.fetch_goods_return_report")
    def test_fetch_goods_return_report_rated_skips_wb_while_blocked(self, fetch_report):
        token = _fake_wb_jwt(uid=10)
        returns._set_goods_return_token_block(api_key=token, retry_after="1800")
        with self.assertRaises(returns.GoodsReturnHttpError):
            returns.fetch_goods_return_report_rated(
                api_key=token,
                date_from="2026-08-01",
                date_to="2026-08-02",
                source_id=1,
            )
        fetch_report.assert_not_called()


class GoodsReturnSourceFilterTests(unittest.TestCase):
    def test_goods_return_row_matches_source_by_order_id(self):
        matchers = {"order_ids": {9001}, "nm_ids": {100}}
        self.assertTrue(
            returns._goods_return_row_matches_source(
                order_id=9001,
                srid="",
                nm_id=100,
                matchers=matchers,
                srid_to_order={},
            )
        )
        self.assertFalse(
            returns._goods_return_row_matches_source(
                order_id=9002,
                srid="",
                nm_id=100,
                matchers=matchers,
                srid_to_order={},
            )
        )

    def test_goods_return_row_matches_source_by_srid(self):
        matchers = {"order_ids": {9001}, "nm_ids": set()}
        self.assertTrue(
            returns._goods_return_row_matches_source(
                order_id=0,
                srid="abc.1.0",
                nm_id=None,
                matchers=matchers,
                srid_to_order={"abc.1.0": 9001},
            )
        )

    def test_goods_return_row_matches_source_by_nm_when_no_order(self):
        matchers = {"order_ids": set(), "nm_ids": {555}}
        self.assertTrue(
            returns._goods_return_row_matches_source(
                order_id=0,
                srid="",
                nm_id=555,
                matchers=matchers,
                srid_to_order={},
            )
        )

    def test_goods_return_row_matches_source_by_barcode(self):
        matchers = {"order_ids": set(), "nm_ids": set(), "barcodes": {"2001900289005"}}
        self.assertTrue(
            returns._goods_return_row_matches_source(
                order_id=0,
                srid="",
                nm_id=None,
                barcode="2001900289005",
                matchers=matchers,
                srid_to_order={},
            )
        )

    def test_goods_return_row_matches_confirmed_marketplace_order(self):
        matchers = {"order_ids": set(), "nm_ids": set(), "barcodes": set()}
        self.assertTrue(
            returns._goods_return_row_matches_source(
                order_id=777,
                srid="",
                nm_id=None,
                matchers=matchers,
                srid_to_order={},
                confirmed_order_ids={777},
            )
        )

    def test_goods_return_row_matches_srid_via_confirmed_order(self):
        matchers = {"order_ids": set(), "nm_ids": set(), "barcodes": set()}
        self.assertTrue(
            returns._goods_return_row_matches_source(
                order_id=0,
                srid="abchex",
                nm_id=None,
                matchers=matchers,
                srid_to_order={"abchex": 888},
                confirmed_order_ids={888},
            )
        )

    def test_resolve_goods_return_api_key_prefers_source(self):
        source = _fake_wb_jwt(uid=11, scopes=wb.WB_SCOPE_ANALYTICS | wb.WB_SCOPE_MARKETPLACE)
        fallback = _fake_wb_jwt(uid=22, scopes=wb.WB_SCOPE_ANALYTICS)
        key, src, trust = returns.resolve_goods_return_api_key(
            source_api_key=source,
            fallback_analytics_key=fallback,
        )
        self.assertEqual(key, source)
        self.assertEqual(src, "source")
        self.assertTrue(trust)

    def test_resolve_goods_return_api_key_falls_back_to_settings(self):
        fallback = _fake_wb_jwt(uid=11, scopes=wb.WB_SCOPE_ANALYTICS)
        key, src, trust = returns.resolve_goods_return_api_key(
            source_api_key="",
            fallback_analytics_key=fallback,
        )
        self.assertEqual(key, fallback)
        self.assertEqual(src, "settings")
        self.assertFalse(trust)

    def test_resolve_goods_return_api_key_uses_settings_when_source_marketplace_only(self):
        source = _fake_wb_jwt(uid=11, scopes=wb.WB_SCOPE_MARKETPLACE)
        fallback = _fake_wb_jwt(uid=11, scopes=wb.WB_SCOPE_ANALYTICS)
        key, src, trust = returns.resolve_goods_return_api_key(
            source_api_key=source,
            fallback_analytics_key=fallback,
        )
        self.assertEqual(key, fallback)
        self.assertEqual(src, "settings")
        self.assertTrue(trust)

    def test_resolve_goods_return_api_key_uses_source_analytics_first(self):
        source = _fake_wb_jwt(uid=11, scopes=wb.WB_SCOPE_MARKETPLACE)
        source_analytics = _fake_wb_jwt(uid=11, scopes=wb.WB_SCOPE_ANALYTICS)
        fallback = _fake_wb_jwt(uid=22, scopes=wb.WB_SCOPE_ANALYTICS)
        key, src, trust = returns.resolve_goods_return_api_key(
            source_api_key=source,
            source_analytics_api_key=source_analytics,
            fallback_analytics_key=fallback,
        )
        self.assertEqual(key, source_analytics)
        self.assertEqual(src, "source_analytics")
        self.assertTrue(trust)

    def test_resolve_goods_return_api_key_rejects_mismatched_settings(self):
        source = _fake_wb_jwt(uid=11, scopes=wb.WB_SCOPE_MARKETPLACE)
        fallback = _fake_wb_jwt(uid=22, scopes=wb.WB_SCOPE_ANALYTICS)
        with self.assertRaises(RuntimeError) as ctx:
            returns.resolve_goods_return_api_key(
                source_api_key=source,
                fallback_analytics_key=fallback,
            )
        self.assertIn("другому кабинету", str(ctx.exception))

    def test_goods_return_report_trusted_for_source_key(self):
        self.assertTrue(returns.goods_return_report_trusted("source"))
        self.assertFalse(returns.goods_return_report_trusted("settings"))
        self.assertFalse(returns.goods_return_report_trusted(""))

    def test_goods_return_row_trusted_accepts_without_local_order(self):
        matchers = {"order_ids": set(), "nm_ids": set(), "barcodes": set()}
        self.assertTrue(
            returns._goods_return_row_matches_source(
                order_id=0,
                srid="abchex123",
                nm_id=100,
                matchers=matchers,
                srid_to_order={},
                trust_report=True,
            )
        )

    @patch("review_processor.wb_fbs_returns._purge_foreign_goods_returns_in_range", return_value=0)
    @patch("review_processor.wb_fbs_returns.fetch_goods_return_report_rated")
    @patch("review_processor.wb_fbs_returns.ensure_wb_fbs_returns_tables")
    @patch("review_processor.wb_fbs_returns._load_source_goods_return_matchers")
    def test_sync_goods_returns_trusted_source_stores_unmatched_rows(
        self,
        load_matchers,
        _ensure,
        fetch_report,
        _purge,
    ):
        load_matchers.return_value = {"order_ids": set(), "nm_ids": set(), "barcodes": set()}
        fetch_report.return_value = [
            {"orderId": 0, "nmId": 555, "srid": "hexsrid", "stickerId": "999"},
        ]
        repo = MagicMock()
        repo._sql = lambda sql: sql
        conn = MagicMock()
        repo._connect.return_value.__enter__ = MagicMock(return_value=conn)
        repo._connect.return_value.__exit__ = MagicMock(return_value=False)

        with patch(
            "review_processor.wb_fbs_returns._upsert_goods_return_row",
            return_value="inserted",
        ) as upsert:
            out = returns.sync_goods_returns(
                repo,
                user_id=1,
                source_id=10,
                api_key="source-key",
                date_from="2026-08-01",
                date_to="2026-08-10",
                api_key_source="source",
                trust_report=True,
                api_key_candidates=[("source-key", "source")],
            )

        self.assertEqual(out["skipped_foreign"], 0)
        self.assertTrue(out["report_trusted"])
        self.assertEqual(upsert.call_count, 1)

    @patch("review_processor.wb_fbs_returns._purge_foreign_goods_returns_in_range", return_value=0)
    @patch("review_processor.wb_fbs_returns.fetch_goods_return_report_rated")
    @patch("review_processor.wb_fbs_returns.ensure_wb_fbs_returns_tables")
    @patch("review_processor.wb_fbs_returns._load_source_goods_return_matchers")
    def test_sync_goods_returns_skips_foreign_rows(
        self,
        load_matchers,
        _ensure,
        fetch_report,
        _purge,
    ):
        load_matchers.return_value = {"order_ids": {9001}, "nm_ids": {100}, "barcodes": set()}
        fetch_report.return_value = [
            {"orderId": 9001, "nmId": 100, "srid": "keep.1.0", "stickerId": "111"},
            {"orderId": 9002, "nmId": 200, "srid": "skip.1.0", "stickerId": "222"},
        ]
        repo = MagicMock()
        repo._sql = lambda sql: sql
        conn = MagicMock()
        repo._connect.return_value.__enter__ = MagicMock(return_value=conn)
        repo._connect.return_value.__exit__ = MagicMock(return_value=False)

        with patch(
            "review_processor.wb_fbs_returns.wb.order_ids_by_srids",
            return_value={"keep.1.0": 9001, "skip.1.0": 9002},
        ), patch(
            "review_processor.wb_fbs_returns._upsert_goods_return_row",
            return_value="inserted",
        ) as upsert:
            out = returns.sync_goods_returns(
                repo,
                user_id=1,
                source_id=10,
                api_key="k",
                date_from="2026-08-01",
                date_to="2026-08-10",
                trust_report=False,
                api_key_candidates=[("k", "settings")],
            )

        self.assertEqual(out["skipped_foreign"], 1)
        self.assertEqual(upsert.call_count, 1)
        self.assertEqual(upsert.call_args.kwargs["order_id"], 9001)

    @patch("review_processor.wb_fbs_returns._purge_foreign_goods_returns_in_range", return_value=0)
    @patch("review_processor.wb_fbs_returns.fetch_goods_return_report_rated")
    @patch("review_processor.wb_fbs_returns.ensure_wb_fbs_returns_tables")
    @patch("review_processor.wb_fbs_returns._load_source_goods_return_matchers")
    def test_sync_goods_returns_warning_when_settings_key_mismatch(
        self,
        load_matchers,
        _ensure,
        fetch_report,
        _purge,
    ):
        load_matchers.return_value = {"order_ids": set(), "nm_ids": set(), "barcodes": set()}
        fetch_report.return_value = [
            {"orderId": 9001, "nmId": 100, "srid": "x", "stickerId": "111"},
        ]
        repo = MagicMock()
        repo._sql = lambda sql: sql
        conn = MagicMock()
        repo._connect.return_value.__enter__ = MagicMock(return_value=conn)
        repo._connect.return_value.__exit__ = MagicMock(return_value=False)

        with patch(
            "review_processor.wb_fbs_returns.wb.order_ids_by_srids",
            return_value={},
        ):
            out = returns.sync_goods_returns(
                repo,
                user_id=1,
                source_id=10,
                api_key="settings-key",
                date_from="2026-08-01",
                date_to="2026-08-10",
                api_key_source="settings",
                trust_report=False,
                api_key_candidates=[("settings-key", "settings")],
            )

        self.assertIn("глобальным ключом", out["warning"])
        self.assertEqual(out["api_key_source"], "settings")

    def test_start_goods_return_sync_async_runs_in_background(self):
        returns._goods_return_jobs.clear()
        done = threading.Event()
        result_holder: dict[str, object] = {}

        def _sync():
            result_holder["value"] = {"synced": 3, "ok": True}
            done.set()
            return result_holder["value"]

        started = returns.start_goods_return_sync_async(
            user_id=1,
            source_id=10,
            sync_callable=_sync,
        )
        self.assertTrue(started.get("async"))
        self.assertEqual(started.get("status"), "running")
        self.assertTrue(done.wait(5), "background sync did not finish")
        job = returns.get_goods_return_sync_job(user_id=1, source_id=10)
        self.assertIsNotNone(job)
        assert job is not None
        self.assertEqual(job.get("status"), "ok")
        self.assertEqual(job.get("result"), {"synced": 3, "ok": True})

    def test_start_goods_return_sync_async_already_running(self):
        returns._goods_return_jobs.clear()
        gate = threading.Event()
        gate.clear()

        def _sync():
            gate.wait(10)
            return {"synced": 1}

        first = returns.start_goods_return_sync_async(
            user_id=1,
            source_id=10,
            sync_callable=_sync,
        )
        self.assertFalse(first.get("already_running"))
        second = returns.start_goods_return_sync_async(
            user_id=1,
            source_id=10,
            sync_callable=_sync,
        )
        self.assertTrue(second.get("already_running"))
        gate.set()


class RestoreScanTests(unittest.TestCase):
    @patch("review_processor.wb_fbs_returns.process_return_scan")
    @patch("review_processor.wb_fbs_returns.find_goods_return_by_scan")
    @patch("review_processor.wb_fbs_returns.kiz_restore.looks_like_kiz_scan", return_value=False)
    def test_restore_scan_hits_first_source(self, _looks, find_goods, process):
        find_goods.side_effect = [
            {"sticker_id": "445566", "wb_order_id": 1001},
            None,
        ]
        process.return_value = {
            "ok": True,
            "item": {
                "id": 7,
                "scan_type": "return_sticker",
                "order_id": 1001,
                "kiz_code": "010467012345678921X",
            },
        }
        repo = MagicMock()
        sources = [{"id": 19, "name": "A"}, {"id": 21, "name": "B"}]
        result = returns.process_restore_scan(
            repo, user_id=1, sources=sources, scan="445566"
        )
        self.assertTrue(result["ok"])
        self.assertFalse(result["duplicate"])
        self.assertEqual(result["source_id"], 19)
        self.assertEqual(result["source_name"], "A")
        process.assert_called_once()
        self.assertEqual(process.call_args.kwargs["source_id"], 19)
        self.assertEqual(process.call_args.kwargs["api_key"], "")

    @patch("review_processor.wb_fbs_returns.process_return_scan")
    @patch("review_processor.wb_fbs_returns.find_goods_return_by_scan")
    @patch("review_processor.wb_fbs_returns.kiz_restore.looks_like_kiz_scan", return_value=False)
    def test_restore_scan_duplicate_printable(self, _looks, find_goods, process):
        find_goods.return_value = {"sticker_id": "445566", "wb_order_id": 1001}
        process.return_value = {
            "ok": False,
            "error": "duplicate",
            "message": "already",
            "item": {"id": 11, "scan_type": "return_sticker", "kiz_code": "01X"},
        }
        repo = MagicMock()
        result = returns.process_restore_scan(
            repo,
            user_id=1,
            sources=[{"id": 21, "name": "B"}],
            scan="445566",
        )
        self.assertTrue(result["ok"])
        self.assertTrue(result["duplicate"])
        self.assertEqual(result["item"]["id"], 11)
        self.assertIn("распечатать", result["message"].lower())

    @patch("review_processor.wb_fbs_returns.find_goods_return_by_scan")
    @patch("review_processor.wb_fbs_returns.kiz_restore.looks_like_kiz_scan", return_value=False)
    def test_restore_scan_ambiguous_across_sources(self, _looks, find_goods):
        find_goods.side_effect = [
            {"sticker_id": "1", "wb_order_id": 100},
            {"sticker_id": "1", "wb_order_id": 200},
        ]
        repo = MagicMock()
        result = returns.process_restore_scan(
            repo,
            user_id=1,
            sources=[{"id": 19, "name": "A"}, {"id": 21, "name": "B"}],
            scan="999",
        )
        self.assertFalse(result["ok"])
        self.assertEqual(result["error"], "ambiguous")

    @patch("review_processor.wb_fbs_returns.kiz_restore.find_orders_by_sticker_scan")
    @patch("review_processor.wb_fbs_returns.find_goods_return_by_scan", return_value=None)
    @patch("review_processor.wb_fbs_returns.kiz_restore.looks_like_kiz_scan", return_value=False)
    def test_restore_scan_not_found_mentions_sync(self, _looks, _goods, sticker):
        sticker.return_value = {"row": None, "ambiguous": False}
        repo = MagicMock()
        result = returns.process_restore_scan(
            repo,
            user_id=1,
            sources=[{"id": 21, "name": "B"}],
            scan="nope",
        )
        self.assertFalse(result["ok"])
        self.assertEqual(result["error"], "not_found")
        self.assertIn("ВБ ФБС", result["message"])
        self.assertIn("Синхр", result["message"])

    @patch("review_processor.wb_fbs_returns.process_return_scan")
    @patch("review_processor.wb_fbs_returns.kiz_restore.find_kiz_in_local_database")
    @patch("review_processor.wb_fbs_returns.kiz_restore.normalize_kiz_mark", side_effect=lambda x: x)
    @patch("review_processor.wb_fbs_returns.kiz_restore.looks_like_kiz_scan", return_value=True)
    def test_restore_kiz_uses_matching_source(self, _looks, _norm, find_kiz, process):
        find_kiz.side_effect = [
            {"found": False, "order_ids": []},
            {"found": True, "order_ids": [555]},
        ]
        process.return_value = {
            "ok": True,
            "item": {"id": 3, "scan_type": "kiz", "order_id": 555, "kiz_code": "01X"},
        }
        repo = MagicMock()
        result = returns.process_restore_scan(
            repo,
            user_id=1,
            sources=[{"id": 19, "name": "A"}, {"id": 21, "name": "B"}],
            scan="010467012345678921X",
        )
        self.assertTrue(result["ok"])
        self.assertEqual(result["source_id"], 21)
        self.assertEqual(process.call_args.kwargs["api_key"], "")

    def test_restore_cache_info_counts(self):
        repo = MagicMock()
        repo._sql = lambda sql: sql
        repo._row_to_dict = lambda row: dict(row)

        class _Result:
            def __init__(self, payload):
                self._payload = payload

            def fetchone(self):
                return self._payload

        conn = MagicMock()
        conn.execute = MagicMock(
            side_effect=[
                _Result({"cnt": 12, "last_synced_at": "2026-09-01T10:00:00+00:00"}),
                _Result({"cnt": 0, "last_synced_at": None}),
            ]
        )
        repo._connect.return_value.__enter__ = MagicMock(return_value=conn)
        repo._connect.return_value.__exit__ = MagicMock(return_value=False)
        with patch("review_processor.wb_fbs_returns.ensure_wb_fbs_returns_tables"):
            info = returns.restore_cache_info(
                repo,
                user_id=1,
                sources=[{"id": 21, "name": "B"}, {"id": 19, "name": "A"}],
            )
        self.assertEqual(info["total_goods_rows"], 12)
        self.assertEqual(info["sources"][0]["goods_rows"], 12)
        self.assertEqual(info["sources"][1]["goods_rows"], 0)


class RestoreReturnStickerProductEnrichTests(unittest.TestCase):
    """Return sticker restore must hydrate name/photo/ШК from local order."""

    def test_enrich_keeps_order_barcodes_without_catalog_match(self):
        repo = MagicMock()
        repo.list_product_photos.return_value = []
        item = {
            "product_article": "art-x",
            "product_name": "Наматрасник",
            "product_barcodes": ["2051501276324"],
            "catalog_barcodes": ["2051501276324"],
        }
        out = returns._enrich_return_scan_catalog_fields(
            repo, user_id=1, item=dict(item)
        )
        self.assertEqual(out["catalog_barcodes"], ["2051501276324"])
        self.assertEqual(out["product_name"], "Наматрасник")

    def test_resolve_order_falls_back_to_other_source(self):
        repo = MagicMock()
        order = {
            "order_id": 5463703395,
            "source_id": 7,
            "article": "nambambbort180200greybort18020030",
            "nm_id": 1067501678,
            "skus_json": '["2051501276324"]',
        }
        with patch(
            "review_processor.wb_fbs_returns.kiz_restore.resolve_order_for_restore",
            return_value=None,
        ), patch(
            "review_processor.wb_fbs_returns._find_local_order_any_source",
            return_value=order,
        ) as find_any:
            row = returns._resolve_order_row(
                repo, user_id=1, source_id=2, order_id=5463703395, api_key=""
            )
        self.assertEqual(row["order_id"], 5463703395)
        find_any.assert_called_once()

    @patch("review_processor.wb_fbs_returns._insert_return_scan")
    @patch("review_processor.wb_fbs_returns._kiz_codes_for_order", return_value=[])
    @patch("review_processor.wb_fbs_returns._return_scan_duplicate", return_value=None)
    @patch("review_processor.wb_fbs_returns._resolve_order_row")
    def test_return_sticker_fills_product_from_order(
        self, resolve_order, _dup, _kiz, insert
    ):
        resolve_order.return_value = {
            "order_id": 5463703395,
            "article": "nambambbort180200greybort18020030",
            "nm_id": 1067501678,
            "skus_json": '["2051501276324"]',
            "sticker_part_a": "5669411",
            "sticker_part_b": "5771",
            "sticker_barcode": "",
        }
        repo = MagicMock()
        repo.get_product_name_by_article.return_value = {
            "nambambbort180200greybort18020030": "Наматрасник стеганый 180х200",
            "1067501678": "Наматрасник стеганый 180х200",
        }
        repo.get_product_photo_map.return_value = {
            "nambambbort180200greybort18020030": "/api/products/photo/9",
        }
        repo.list_product_photos.return_value = [
            {
                "id": 9,
                "name": "Наматрасник стеганый 180х200",
                "supplier_article": "nambambbort180200greybort18020030",
                "wb_nmid": "1067501678",
                "barcodes": ["2051501276324"],
                "photo_path": "/x.jpg",
                "barcode_label_name": "",
            }
        ]

        captured = {}

        def _insert(*_a, **kwargs):
            payload = kwargs["payload"]
            captured["payload"] = payload
            return {"id": 1, **payload}

        insert.side_effect = _insert
        result = returns._process_return_sticker_scan(
            repo,
            user_id=1,
            source_id=2,
            api_key="",
            scan="54628560521",
            goods_row={
                "sticker_id": "54628560521",
                "wb_order_id": 5463703395,
                "barcode": "2051501276324",
                "nm_id": 1067501678,
                "srid": "",
            },
        )
        self.assertTrue(result["ok"])
        payload = captured["payload"]
        self.assertEqual(payload["product_name"], "Наматрасник стеганый 180х200")
        self.assertEqual(payload["product_article"], "nambambbort180200greybort18020030")
        self.assertIn("2051501276324", payload.get("product_barcodes") or [])
        self.assertTrue(payload.get("product_photo"))
        self.assertIn("2051501276324", payload.get("catalog_barcodes") or [])

    @patch("review_processor.wb_fbs_returns._update_return_scan_product_fields")
    @patch("review_processor.wb_fbs_returns.find_goods_return_by_scan", return_value=None)
    @patch("review_processor.wb_fbs_returns._resolve_order_row")
    def test_refresh_duplicate_row_backfills_product(self, resolve_order, _goods, _update):
        resolve_order.return_value = {
            "order_id": 5463703395,
            "article": "nambambbort180200greybort18020030",
            "nm_id": 1067501678,
            "skus_json": '["2051501276324"]',
        }
        repo = MagicMock()
        repo.get_product_name_by_article.return_value = {
            "nambambbort180200greybort18020030": "Наматрасник стеганый 180х200",
        }
        repo.get_product_photo_map.return_value = {
            "nambambbort180200greybort18020030": "/api/products/photo/9",
        }
        repo.list_product_photos.return_value = []
        item = {
            "id": 55,
            "source_id": 2,
            "order_id": 5463703395,
            "product_name": "",
            "product_article": "",
            "product_photo": "",
            "product_barcodes": [],
            "catalog_barcodes": [],
        }
        out = returns._refresh_scan_item_product_from_order(
            repo, user_id=1, item=item
        )
        self.assertEqual(out["product_name"], "Наматрасник стеганый 180х200")
        self.assertEqual(out["product_article"], "nambambbort180200greybort18020030")
        self.assertIn("2051501276324", out["product_barcodes"])
        self.assertIn("2051501276324", out["catalog_barcodes"])




class RestoreScanModeExpansionTests(unittest.TestCase):
    """WB order id / Ozon posting / catalog barcode restore modes."""

    @patch("review_processor.wb_fbs_returns._kiz_codes_for_order", return_value=[])
    @patch("review_processor.wb_fbs_returns._goods_return_srid_hint", return_value="")
    @patch("review_processor.wb_fbs_returns.wb.get_order_by_id")
    @patch("review_processor.wb_fbs_returns.kiz_restore.find_orders_by_sticker_scan")
    @patch("review_processor.wb_fbs_returns.find_goods_return_by_scan", return_value=None)
    @patch("review_processor.wb_fbs_returns.kiz_restore.looks_like_kiz_scan", return_value=False)
    def test_restore_scan_wb_order_id(self, _looks, _goods, sticker, get_order, _srid, _kiz):
        sticker.return_value = {"row": None, "ambiguous": False, "matches": []}
        get_order.return_value = {
            "order_id": 5463703395,
            "source_id": 19,
            "article": "ART-1",
            "nm_id": 111,
            "skus_json": '["4601234567890"]',
            "sticker_part_a": "12",
            "sticker_part_b": "34",
            "sticker_barcode": "",
        }
        repo = MagicMock()
        repo.get_product_name_by_article.return_value = {"ART-1": "Товар WB"}
        repo.get_product_photo_map.return_value = {"ART-1": "/api/products/photo/1"}
        repo.list_product_photos.return_value = []
        repo.list_supply_sources.return_value = []
        result = returns.process_restore_scan(
            repo,
            user_id=1,
            sources=[{"id": 19, "name": "WB A"}],
            scan="5463703395",
        )
        self.assertTrue(result["ok"])
        item = result["item"]
        self.assertEqual(item["scan_type"], returns.SCAN_LOOKUP)
        self.assertEqual(item["order_id"], 5463703395)
        self.assertEqual(item["product_name"], "Товар WB")
        self.assertIn("4601234567890", item.get("product_barcodes") or [])
        self.assertIn("4601234567890", item.get("catalog_barcodes") or [])
        details = item.get("details") or {}
        self.assertIsInstance(details, dict)
        self.assertEqual(details.get("order_id"), 5463703395)
        self.assertIn("tab_label", details)
        self.assertIn("status_label", details)
        sticker.return_value = {"row": None, "ambiguous": False, "matches": []}
        posting = {
            "posting_number": "0123456789-0001-1",
            "offer_id": "ART-1",
            "sku": "999",
            "product_name": "Товар Ozon",
            "barcodes_json": '["4601234567890"]',
            "marking_codes_json": '["010460123456789021ABCD"]',
            "sticker_barcode": "PKG1",
            "sticker_part_a": "",
            "sticker_part_b": "",
            "sticker_lower_barcode": "",
        }
        repo = MagicMock()
        repo.list_supply_sources.return_value = [
            {"id": 55, "name": "Ozon", "marketplace": "ozon_fbs"}
        ]
        repo.get_product_name_by_article.return_value = {}
        repo.get_product_name_by_ozon_sku.return_value = {}
        repo.get_product_photo_map.return_value = {}
        repo.get_product_barcodes_map.return_value = {}
        repo.list_product_photos.return_value = []
        with patch("review_processor.ozon_fbs.is_ozon_fbs_source", return_value=True),              patch("review_processor.ozon_fbs.parse_posting_number_query", return_value="0123456789-0001-1"),              patch("review_processor.ozon_fbs.get_posting_by_number", return_value=posting),              patch("review_processor.wb_fbs_returns.wb.get_order_by_id", return_value=None),              patch("review_processor.wb_fbs_returns._find_local_order_any_source", return_value=None):
            result = returns.process_restore_scan(
                repo,
                user_id=1,
                sources=[{"id": 19, "name": "WB A"}],
                scan="0123456789-0001-1",
            )
        self.assertTrue(result["ok"])
        item = result["item"]
        self.assertEqual(item["scan_type"], returns.SCAN_OZON)
        self.assertEqual(item["order_id"], "0123456789-0001-1")
        self.assertEqual(item["product_name"], "Товар Ozon")
        self.assertTrue(item.get("kiz_code"))
        self.assertIn("4601234567890", item.get("catalog_barcodes") or [])
        details = item.get("details") or {}
        self.assertIsInstance(details, dict)
        self.assertEqual(details.get("posting_number"), "0123456789-0001-1")
        self.assertIn("tab_label", details)
        self.assertIn("status_label", details)

    @patch("review_processor.wb_fbs_returns.kiz_restore.find_orders_by_sticker_scan")
    @patch("review_processor.wb_fbs_returns.find_goods_return_by_scan", return_value=None)
    @patch("review_processor.wb_fbs_returns.kiz_restore.looks_like_kiz_scan", return_value=False)
    def test_restore_scan_catalog_barcode(self, _looks, _goods, sticker):
        sticker.return_value = {"row": None, "ambiguous": False, "matches": []}
        repo = MagicMock()
        repo.list_supply_sources.return_value = []
        repo.list_product_photos.return_value = [
            {
                "id": 3,
                "name": "Товар каталога",
                "supplier_article": "ART-1",
                "barcodes": ["4601234567890"],
                "photo_path": "/x.jpg",
                "barcode_label_name": "Label",
            }
        ]
        with patch("review_processor.wb_fbs_returns.wb.get_order_by_id", return_value=None),              patch("review_processor.wb_fbs_returns._find_local_order_any_source", return_value=None):
            result = returns.process_restore_scan(
                repo,
                user_id=1,
                sources=[{"id": 19, "name": "WB A"}],
                scan="4601234567890",
            )
        self.assertTrue(result["ok"])
        item = result["item"]
        self.assertEqual(item["scan_type"], returns.SCAN_CATALOG)
        self.assertIsNone(item.get("order_id"))
        self.assertEqual(item["product_name"], "Товар каталога")
        self.assertEqual(item.get("kiz_code") or "", "")
        self.assertIn("4601234567890", item.get("catalog_barcodes") or [])
        self.assertFalse(item.get("details"))

    @patch("review_processor.wb_fbs_returns.kiz_restore.find_orders_by_sticker_scan")
    @patch("review_processor.wb_fbs_returns.find_goods_return_by_scan", return_value=None)
    @patch("review_processor.wb_fbs_returns.kiz_restore.looks_like_kiz_scan", return_value=False)
    def test_restore_scan_priority_order_over_catalog(self, _looks, _goods, sticker):
        """Numeric scan that matches both WB order and catalog prefers order."""
        sticker.return_value = {"row": None, "ambiguous": False, "matches": []}
        repo = MagicMock()
        repo.list_supply_sources.return_value = []
        repo.list_product_photos.return_value = [
            {
                "id": 3,
                "name": "Каталог",
                "supplier_article": "ART-1",
                "barcodes": ["5463703395"],
                "photo_path": "",
                "barcode_label_name": "",
            }
        ]
        repo.get_product_name_by_article.return_value = {"ART-1": "Заказной товар"}
        repo.get_product_photo_map.return_value = {}
        with patch(
            "review_processor.wb_fbs_returns.wb.get_order_by_id",
            return_value={
                "order_id": 5463703395,
                "source_id": 19,
                "article": "ART-1",
                "nm_id": 1,
                "skus_json": '["5463703395"]',
                "sticker_part_a": "",
                "sticker_part_b": "",
                "sticker_barcode": "",
            },
        ), patch("review_processor.wb_fbs_returns._kiz_codes_for_order", return_value=[]),              patch("review_processor.wb_fbs_returns._goods_return_srid_hint", return_value=""):
            result = returns.process_restore_scan(
                repo,
                user_id=1,
                sources=[{"id": 19, "name": "WB A"}],
                scan="5463703395",
            )
        self.assertTrue(result["ok"])
        self.assertEqual(result["item"]["scan_type"], returns.SCAN_LOOKUP)
        self.assertEqual(result["item"]["product_name"], "Заказной товар")




if __name__ == "__main__":
    unittest.main()
