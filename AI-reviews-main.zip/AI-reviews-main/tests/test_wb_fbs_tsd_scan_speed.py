"""TSD scan path must not block on network — parity with desktop modal autosave."""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TSD_JS = ROOT / "web_static" / "wb_fbs_tsd.js"


def test_tsd_scan_enter_uses_background_autosave_not_await() -> None:
    js = TSD_JS.read_text(encoding="utf-8")
    start = js.find("async function onScanEnter")
    end = js.find("async function onRoute", start)
    assert start > 0 and end > start
    body = js[start:end]
    assert "scheduleKizLocalAutosave" in body
    assert "schedulePickLocalAutosave" in body
    assert "patchScanAfterSuccess" in body
    assert "patchScanAfterStickerMatch" in body
    assert "await saveKizLocal" not in body
    assert "await savePickLocal" not in body


def test_tsd_scan_has_incremental_patch_helpers() -> None:
    js = TSD_JS.read_text(encoding="utf-8")
    for name in (
        "scheduleKizLocalAutosave",
        "schedulePickLocalAutosave",
        "awaitLocalAutosaves",
        "captureScanBaselines",
        "patchScanCard",
        "patchScanAfterSuccess",
        "refreshScanChrome",
        "buildScanCardHtml",
    ):
        assert f"function {name}" in js


def test_tsd_explicit_save_waits_for_autosave_chain() -> None:
    js = TSD_JS.read_text(encoding="utf-8")
    kiz_start = js.find("async function saveKizPushAll")
    kiz_end = js.find("/** Explicit «Сохранить» for pick", kiz_start)
    pick_start = js.find("async function savePickLocalAll")
    pick_end = js.find("function noteSessionScanned", pick_start)
    assert kiz_start > 0 and kiz_end > kiz_start
    assert pick_start > 0 and pick_end > pick_start
    assert "await awaitLocalAutosaves()" in js[kiz_start:kiz_end]
    assert "await awaitLocalAutosaves()" in js[pick_start:pick_end]


def test_tsd_back_arrow_smart_saves_session_then_leaves() -> None:
    js = TSD_JS.read_text(encoding="utf-8")
    start = js.find("async function leaveScanScreen")
    end = js.find("function scanProgress", start)
    assert start > 0 and end > start
    body = js[start:end]
    assert "confirm(" not in body
    assert "Закрыть без сохранения" not in js
    assert "await awaitLocalAutosaves()" in body
    assert "hasPendingKizLeaveSave()" in body
    assert "leaveSave: true" in body
    assert "saveKizPushAll({ silent: true, leaveSave: true })" in body
    assert "savePickLocalAll({ silent: true })" in body


def test_tsd_autosave_conflict_adopts_server_not_force_overwrite() -> None:
    """Concurrent PC save must not be wiped by TSD autosave force-retry."""
    js = TSD_JS.read_text(encoding="utf-8")
    kiz_start = js.find("async function saveKizLocal")
    kiz_end = js.find("async function savePickLocal", kiz_start)
    assert kiz_start > 0 and kiz_end > kiz_start
    kiz_body = js[kiz_start:kiz_end]
    assert "result.conflict" in kiz_body
    assert "force-overwrite" in kiz_body or "Do NOT force-overwrite" in kiz_body
    assert "if (!retrying) return saveKizLocal" not in kiz_body
    assert "Array.isArray(result.kiz_codes)" in kiz_body
    assert "state.baselineKizByOrder[scanId] = serverCodes.slice()" in kiz_body

    pick_start = kiz_end
    pick_end = js.find("function captureScanBaselines", pick_start)
    assert pick_end > pick_start
    pick_body = js[pick_start:pick_end]
    assert "result.conflict" in pick_body
    assert "if (!retrying) return savePickLocal" not in pick_body
    assert "Adopt server pick" in pick_body or "adopt server" in pick_body.lower()
    assert "delete state.forceSaveByOrder[pickKey]" in pick_body


def test_tsd_bulk_save_is_chunked_against_504() -> None:
    js = TSD_JS.read_text(encoding="utf-8")
    kiz_start = js.find("async function saveKizPushAll")
    kiz_end = js.find("async function savePickLocalAll", kiz_start)
    assert kiz_start > 0 and kiz_end > kiz_start
    kiz_body = js[kiz_start:kiz_end]
    assert "const CHUNK =" in kiz_body
    assert "items.slice(i, i + CHUNK)" in kiz_body
    # Conflict must adopt server + clear force, not arm overwrite of PC.
    assert 'status = "conflict"' in kiz_body
    assert "state.forceSaveByOrder[id] = true" not in kiz_body
    assert "state.baselineKizByOrder[id] = serverCodes.slice()" in kiz_body

    pick_start = kiz_end
    pick_end = js.find("function noteSessionScanned", pick_start)
    assert pick_end > pick_start
    pick_body = js[pick_start:pick_end]
    assert "const CHUNK = 40" in pick_body
    assert "items.slice(i, i + CHUNK)" in pick_body
    assert 'status = "conflict"' in pick_body
    assert "state.forceSaveByOrder[pickKey] = true" not in pick_body


def test_tsd_back_arrow_pick_stays_on_conflict_or_busy() -> None:
    js = TSD_JS.read_text(encoding="utf-8")
    start = js.find("async function leaveScanScreen")
    end = js.find("function scanProgress", start)
    assert start > 0 and end > start
    body = js[start:end]
    assert 'result.status === "conflict"' in body or 'result.status === "busy"' in body
    assert 'result.status === "busy"' in body
    # KIZ back saves only this session; stay on conflict/busy/error/cancelled.
    assert "leaveSave: true" in body
    assert 'result.status === "error"' in body
    assert 'result.status === "cancelled"' in body


def test_tsd_clear_kiz_uses_background_autosave() -> None:
    js = TSD_JS.read_text(encoding="utf-8")
    start = js.find("async function clearKizCodes")
    end = js.find("function syncSourceSelectVisibility", start)
    assert start > 0 and end > start
    body = js[start:end]
    assert "scheduleKizLocalAutosave" in body
    assert "await saveKizLocal" not in body
    assert "refreshScanChrome" in body


def test_tsd_gs_preserve_unchanged_in_wire_scan_input() -> None:
    js = TSD_JS.read_text(encoding="utf-8")
    start = js.find("function wireScanInput")
    end = js.find("function wireScanFooter", start)
    assert start > 0 and end > start
    body = js[start:end]
    assert "isGsKeyEvent" in body
    assert "insertGsIntoInput" in body
    assert "\\u001D" in js
    assert "\\u2194" in js


def test_tsd_autosave_conflict_no_retry_refreshes_ui() -> None:
    """After conflict adopt, autosave must not retry and must refresh the card."""
    js = TSD_JS.read_text(encoding="utf-8")
    assert "err.conflict = true" in js

    kiz_start = js.find("async function flushKizLocalAutosave")
    kiz_end = js.find("async function flushPickLocalAutosave", kiz_start)
    assert kiz_start > 0 and kiz_end > kiz_start
    kiz_body = js[kiz_start:kiz_end]
    assert "e && e.conflict" in kiz_body
    assert 'patchScanCard("kiz")' in kiz_body
    # After local autosave, mark draft unsynced so floppy/leave still push to WB
    # (parity with web modal _wbFbsKizFlushLocalAutosave).
    assert "kiz_wb_synced = false" in kiz_body
    assert 'refreshScanChrome("kiz")' in kiz_body
    # No background WB auto-push — only floppy / leave push to WB.
    assert "scheduleKizWbAutoPush" not in js
    assert "flushKizWbAutoPush" not in js
    assert "wbAutoPushChain" not in js
    assert "cancelPendingWbAutoPushes" not in js
    # Local autosave chain must not await WB traffic.
    local_sched = js[
        js.find("function scheduleKizLocalAutosave") : js.find(
            "function schedulePickLocalAutosave"
        )
    ]
    assert "flushKizLocalAutosave" in local_sched
    assert "set_order_sgtin" not in local_sched
    # Floppy/leave still own explicit WB push after local flush.
    push_all = js[
        js.find("async function saveKizPushAll") : js.find(
            "async function saveKizPushAll"
        )
        + 1200
    ]
    assert "await awaitLocalAutosaves()" in push_all
    assert "cancelPendingWbAutoPushes" not in push_all
    # retry only for non-conflict errors
    assert "if (attempt < 1)" in kiz_body
    assert kiz_body.find("e && e.conflict") < kiz_body.find("if (attempt < 1)")

    pick_start = kiz_end
    pick_end = js.find("async function saveKizPushAll", pick_start)
    assert pick_end > pick_start
    pick_body = js[pick_start:pick_end]
    assert "e && e.conflict" in pick_body
    assert 'patchScanCard("pick")' in pick_body
    assert pick_body.find("e && e.conflict") < pick_body.find("if (attempt < 1)")


def test_tsd_local_save_does_not_force_via_retry_flag() -> None:
    js = TSD_JS.read_text(encoding="utf-8")
    kiz_start = js.find("async function saveKizLocal")
    kiz_end = js.find("async function savePickLocal", kiz_start)
    kiz_body = js[kiz_start:kiz_end]
    assert "opts._retry" not in kiz_body
    assert "|| retrying" not in kiz_body

    pick_start = kiz_end
    pick_end = js.find("function captureScanBaselines", pick_start)
    if pick_end < 0:
        pick_end = js.find("function captureScanBaselines", pick_start)
    if pick_end < 0:
        pick_end = js.find("async function flushKizLocalAutosave", pick_start)
    pick_body = js[pick_start:pick_end]
    assert "opts._retry" not in pick_body
    assert "|| retrying" not in pick_body
