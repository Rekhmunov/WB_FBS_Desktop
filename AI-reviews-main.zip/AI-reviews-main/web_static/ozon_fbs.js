/**
 * OZON FBS section — isolated from WB FBS and Ozon FBO.
 * Local supplies on «Ожидают отгрузки» mirror WB FBS collect rules (Feedpilot-only).
 */
(function () {
  "use strict";

  const TAB_COUNT_IDS = {
    awaiting_packaging: "ozonFbsCountAwaitingPackaging",
    awaiting_deliver: "ozonFbsCountAwaitingDeliver",
    delivering: "ozonFbsCountDelivering",
    arbitration: "ozonFbsCountArbitration",
    delivered: "ozonFbsCountDelivered",
    cancelled: "ozonFbsCountCancelled",
  };

  /** Hidden in UI for now (sync still tracks counts). */
  const OZON_FBS_HIDDEN_TABS = new Set(["arbitration", "delivered", "cancelled"]);

  const OZON_FBS_TAB_LABELS = {
    awaiting_packaging: "Ожидают сборки",
    awaiting_deliver: "Ожидают отгрузки",
    delivering: "Доставляются",
    arbitration: "Спорные",
    delivered: "Доставлены",
    cancelled: "Отменены",
  };

  const state = {
    sources: [],
    sourceId: null,
    tab: "awaiting_packaging",
    page: 1,
    pageSize: 50,
    total: 0,
    counts: {},
    items: [],
    selected: new Set(),
    search: "",
    searchTimer: null,
    syncPollTimer: null,
    detailPosting: null,
    detailPayload: null,
    shipAllBusy: false,
    syncBusy: false,
    viewMode: "orders", // orders | supplies
    /** Exact posting-number hit across tabs (WB-like toolbar escape hatch). */
    lookupMode: false,
    lookupMeta: null,
    /** Guards stale async search/lookup results. */
    loadSeq: 0,
  };

  const collectState = {
    preview: null,
    sourceId: null,
    busy: false,
    pollTimer: null,
  };

  const splitState = {
    busy: false,
    pollTimer: null,
    progressText: "",
    lastOk: false,
    lastSingleAfter: 0,
  };

  const supplyDetailState = {
    supplyId: null,
    sourceId: null,
    supply: null,
    selected: new Set(),
    /** Tab scope for this open (awaiting_deliver / delivering); filters orders/print. */
    postingTab: null,
    /** False until supply detail (orders) finished loading. */
    ordersReady: false,
  };

  const _OZON_FBS_DETAIL_ACTION_IDS = [
    "ozonFbsSupplyDetailPickingBtn",
    "ozonFbsSupplyDetailStickersBtn",
    "ozonFbsSupplyDetailStickersMenuBtn",
    "ozonFbsSupplyDetailNewStickersBtn",
    "ozonFbsSupplyDetailNewStickersMenuBtn",
    "ozonFbsSupplyDetailTrbxBtn",
    "ozonFbsSupplyDetailKizBtn",
    "ozonFbsSupplyDetailKizRefreshBtn",
    "ozonFbsSupplyDetailPickVerifyBtn",
    "ozonFbsSupplyDetailPickRefreshBtn",
    "ozonFbsSupplyDetailCancelledBtn",
    "ozonFbsSupplyDetailDriverBtn",
    "ozonFbsSupplyDetailMoveDeliveringBtn",
  ];

  const ozonFbsCancelledState = {
    rows: [],
    loading: false,
    lastError: "",
    refreshGen: 0,
  };

  const stickersCategoryState = {
    groups: [],
    selected: new Set(),
    loading: false,
    /** When true, category print uses v3 package-label («Стикеры»). */
    newLabels: false,
  };

  const shipmentsState = {
    supplyId: null,
    sourceId: null,
    data: null,
    loading: false,
    forming: false,
    /** @type {number|null} selected formed carriage for ШК preview/print */
    selectedCarriageId: null,
  };

  const containersState = {
    supplyId: null,
    sourceId: null,
    warehouseId: null,
    items: [],
    loading: false,
    busy: false,
    showScAccepted: false,
    onlyThisSupply: false,
    expandedId: null,
    detailsCache: {},
    detailsLoadingId: null,
  };

  function permissions() {
    return window.APP_PERMISSIONS || {};
  }

  function canView() {
    const p = permissions();
    return p.can_view_ozon_fbs_supplies || (p.can_view_supplies && p.is_tenant_owner);
  }

  function esc(s) {
    const d = document.createElement("div");
    d.textContent = String(s ?? "");
    return d.innerHTML;
  }

  /** Ozon sticker: always highlight 4 chars immediately left of the first «-». */
  function formatOzonPostingNumberHtml(postingNumber) {
    const s = String(postingNumber || "").trim();
    if (!s) return "—";
    const hi = (text) => `<span class="ozon-fbs-posting-tail">${esc(text)}</span>`;
    const dash = s.indexOf("-");
    if (dash > 0) {
      const head = s.slice(0, dash);
      const tail = s.slice(dash); // includes leading «-…»
      if (head.length >= 4) {
        return `${esc(head.slice(0, -4))}${hi(head.slice(-4))}${esc(tail)}`;
      }
      return `${hi(head)}${esc(tail)}`;
    }
    if (s.length > 4) {
      return `${esc(s.slice(0, -4))}${hi(s.slice(-4))}`;
    }
    return hi(s);
  }

  /** Instance label ``ii…``: last 4 chars use the same large tail as the posting number. */
  function formatOzonScanitHtml(scanit) {
    const s = String(scanit || "").trim();
    if (!s) return "";
    const hi = (text) => `<span class="ozon-fbs-posting-tail">${esc(text)}</span>`;
    if (s.length > 4) {
      return `${esc(s.slice(0, -4))}${hi(s.slice(-4))}`;
    }
    return hi(s);
  }

  function _ozonFbsCopyIconBtnHtml(value, { title, className } = {}) {
    const raw = String(value || "").trim();
    if (!raw) return "";
    const safe = esc(raw).replace(/'/g, "&#39;");
    const btnTitle = String(title || "Скопировать").trim() || "Скопировать";
    const extraCls = String(className || "").trim();
    const cls = [
      "ozon-fbs-posting-icon-btn",
      "ozon-fbs-posting-copy",
      extraCls,
    ].filter(Boolean).join(" ");
    return (
      `<span class="ozon-fbs-modal-posting-actions">` +
        `<button type="button" class="${cls}"` +
        ` title="${esc(btnTitle)}"` +
        ` aria-label="${esc(btnTitle)} ${safe}"` +
        ` onclick="event.stopPropagation(); copyOzonFbsModalPostingNumber('${safe}', this)">` +
          `<svg class="ozon-fbs-posting-icon-btn-ico" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">` +
            `<path fill="currentColor" d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/>` +
          `</svg>` +
        `</button>` +
      `</span>`
    );
  }

  function _ozonFbsPostingCopyBtnHtml(postingNumber) {
    return _ozonFbsCopyIconBtnHtml(postingNumber, {
      title: "Скопировать стикер",
    });
  }

  function _ozonFbsScanitCopyBtnHtml(scanit) {
    return _ozonFbsCopyIconBtnHtml(scanit, {
      title: "Скопировать этикетку",
      className: "ozon-fbs-scanit-copy",
    });
  }

  function _ozonFbsScanitUnderOrderHtml(row) {
    const scanit = String(row?.sticker_scanit || "").trim();
    const inner = formatOzonScanitHtml(scanit);
    if (!inner) return "";
    return (
      `<div class="wb-fbs-sd-order-id ozon-fbs-scanit-line ozon-fbs-modal-posting-id">` +
        `<span class="ozon-fbs-modal-posting-num">${inner}</span>` +
        _ozonFbsScanitCopyBtnHtml(scanit) +
      `</div>`
    );
  }

  function detailText(detail) {
    if (detail == null) return "";
    if (typeof detail === "string") return detail;
    if (Array.isArray(detail)) {
      return detail.map((x) => (typeof x === "string" ? x : (x?.msg || x?.message || JSON.stringify(x)))).join("; ");
    }
    if (typeof detail === "object") {
      if (detail.message) return String(detail.message);
      if (detail.msg) return String(detail.msg);
    }
    try { return JSON.stringify(detail); } catch (_) { return String(detail); }
  }

  function fmtDate(iso) {
    if (!iso) return "—";
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return "—";
    return d.toLocaleDateString("ru-RU", { day: "2-digit", month: "2-digit", year: "numeric" });
  }

  function agoLabel(iso) {
    if (!iso) return "";
    const t = Date.parse(iso);
    if (!Number.isFinite(t)) return "";
    const sec = Math.max(0, Math.floor((Date.now() - t) / 1000));
    if (sec < 60) return `${sec} сек назад`;
    const min = Math.floor(sec / 60);
    if (min < 60) return `${min} мин назад`;
    const h = Math.floor(min / 60);
    const rem = min % 60;
    if (h < 48) return rem ? `${h} ч ${rem} мин назад` : `${h} ч назад`;
    const days = Math.floor(h / 24);
    return `${days} дн назад`;
  }

  /** Order time for supply-detail modal only (oldest → newest). */
  function _ozonFbsOrderTimeMs(row) {
    const raw = String(row?.created_at_ozon || row?.in_process_at || "").trim();
    if (!raw) return Number.POSITIVE_INFINITY;
    const t = Date.parse(raw);
    return Number.isFinite(t) ? t : Number.POSITIVE_INFINITY;
  }

  /**
   * Sort postings oldest-first for the supply detail modal table.
   * Does not mutate the source array; picking lists / stickers use other APIs.
   */
  function sortSupplyDetailOrdersOldestFirst(rows) {
    return (rows || []).slice().sort((a, b) => {
      const da = _ozonFbsOrderTimeMs(a);
      const db = _ozonFbsOrderTimeMs(b);
      if (da !== db) return da - db;
      return String(a?.posting_number || "").localeCompare(
        String(b?.posting_number || ""),
        "ru"
      );
    });
  }

  function jsonHeaders() {
    const h = { "Content-Type": "application/json" };
    const csrf = typeof window.getCsrfToken === "function" ? window.getCsrfToken() : "";
    if (csrf) h["X-CSRF-Token"] = csrf;
    return h;
  }

  function isSuppliesTab() {
    // Exact posting lookup always renders a single order row, even on supply tabs.
    if (state.lookupMode) return false;
    return state.tab === "awaiting_deliver" || state.tab === "delivering";
  }

  function parsePostingNumberQuery(search) {
    const q = String(search || "").trim().replace(/\s+/g, "");
    // Full posting …-0199-1 or order number …-0199 (package siblings).
    if (/^\d{6,}-\d{3,}-\d{1,4}$/.test(q)) return q;
    if (/^\d{6,}-\d{3,}$/.test(q)) return q;
    if (_ozonFbsLooksLikeScanit(q)) return q;
    return "";
  }

  function clearLookupMode() {
    state.lookupMode = false;
    state.lookupMeta = null;
    _ozonFbsRenderLookupDetail(null);
  }

  function _ozonFbsLookupDash(value) {
    const s = String(value || "").trim();
    return s || "—";
  }

  function _ozonFbsLookupDetailRows(details) {
    if (!details || typeof details !== "object") return [];
    const kiz = Array.isArray(details.kiz_codes)
      ? details.kiz_codes.map((c) => String(c || "").trim()).filter(Boolean)
      : [];
    const pickOk = !!details.pick_verified && !!String(details.pick_barcode || "").trim();
    const containerLabel = String(details.container_label || "").trim();
    const containerStatus = String(details.container_status_label || "").trim();
    const containerDate = String(details.container_warehouse_date || "").trim();
    let gmValue = "—";
    if (containerLabel) {
      gmValue = containerLabel;
      if (containerStatus) gmValue += ` · ${containerStatus}`;
    }
    const rows = [
      ["Вкладка", _ozonFbsLookupDash(details.tab_label)],
      ["Статус Ozon", _ozonFbsLookupDash(details.status_label || details.status)],
      ["Поставка", _ozonFbsLookupDash(details.supply_id)],
      ["Стикер", _ozonFbsLookupDash(details.sticker_barcode || details.sticker_scanit)],
      ["КИЗ", kiz.length ? kiz.join(", ") : "не сохранён"],
      ["Проверка ШК", pickOk ? String(details.pick_barcode) : "не проверен"],
      ["Грузоместо", gmValue],
    ];
    if (containerLabel && (containerDate || details.container_sc_accepted)) {
      rows.push([
        "ГМ на СЦ",
        containerDate
          ? (details.container_sc_accepted ? `принято ${containerDate}` : containerDate)
          : (details.container_sc_accepted ? "принято на СЦ" : "—"),
      ]);
    }
    if (details.in_process_at) rows.push(["Дата заказа товара", details.in_process_at]);
    if (details.shipment_date) rows.push(["Крайний срок сдачи", details.shipment_date]);
    if (details.delivering_date) rows.push(["Передано в доставку", details.delivering_date]);
    return rows;
  }

  /** Ozon order_number is often posting_number without the trailing "-N". */
  function _ozonFbsOrderNumberIsRedundant(orderNumber, postingNumber) {
    const order = String(orderNumber || "").trim();
    const posting = String(postingNumber || "").trim();
    if (!order) return true;
    if (!posting) return false;
    if (order === posting) return true;
    return posting.startsWith(`${order}-`) || posting.startsWith(order);
  }

  function _ozonFbsRenderLookupDetail(details, { viaText = "" } = {}) {
    const box = document.getElementById("ozonFbsLookupDetail");
    if (!box) return;
    if (!details) {
      box.hidden = true;
      box.innerHTML = "";
      return;
    }
    const pn = String(details.posting_number || "");
    const offer = String(details.offer_id || "").trim();
    const orderNumber = String(details.order_number || "").trim();
    const productName = String(details.product_name || offer || "—").trim() || "—";
    const showOrder = !_ozonFbsOrderNumberIsRedundant(orderNumber, pn);
    const subParts = [];
    if (offer) subParts.push(`Арт. ${offer}`);
    if (showOrder) subParts.push(`заказ ${orderNumber}`);
    const rows = _ozonFbsLookupDetailRows(details)
      .map(
        ([k, v]) =>
          `<div class="ozon-fbs-lookup-k">${esc(k)}</div><div class="ozon-fbs-lookup-v">${esc(v)}</div>`
      )
      .join("");
    box.hidden = false;
    // No repeated posting number here — the table row already shows the full id.
    box.innerHTML = `
      <div class="ozon-fbs-lookup-detail-head">
        <div class="ozon-fbs-lookup-detail-title">Детали отправления</div>
        <div class="wb-fbs-product-name">${esc(productName)}</div>
        ${subParts.length ? `<div class="wb-fbs-product-sub">${esc(subParts.join(" · "))}</div>` : ""}
      </div>
      <div class="ozon-fbs-lookup-detail-grid">${rows}</div>
      ${viaText ? `<div class="ozon-fbs-lookup-detail-meta">${esc(viaText)}</div>` : ""}
    `;
  }

  async function lookupPostingByNumber(postingNumber, { seq, refresh = true } = {}) {
    const params = new URLSearchParams({
      source_id: String(state.sourceId),
      posting_number: String(postingNumber),
    });
    if (!refresh) params.set("refresh", "0");
    const res = await fetch(`/api/ozon-fbs/postings/find?${params}`);
    const data = await res.json().catch(() => ({}));
    if (seq != null && seq !== state.loadSeq) return null;
    if (!res.ok) {
      throw new Error(detailText(data.detail) || "Не удалось найти отправление");
    }
    return data;
  }

  function applyLookupResult(data, postingNumber) {
    const items = Array.isArray(data?.items) && data.items.length
      ? data.items.filter((it) => it && typeof it === "object")
      : (data?.item && typeof data.item === "object" ? [data.item] : []);
    if (!data?.found || !items.length) {
      clearLookupMode();
      return false;
    }
    const item = items[0];
    const multi = items.length > 1;
    const details = !multi && data.details && typeof data.details === "object"
      ? data.details
      : null;
    const tab = String(data.tab || details?.tab || item.tab || "").trim();
    const supplyId = String(
      (details && details.supply_id) || item.supply_id || ""
    ).trim();
    const queryLabel = String(data.query || postingNumber || "").trim();
    state.lookupMode = true;
    state.lookupMeta = {
      posting_number: String(data.posting_number || postingNumber),
      query: queryLabel,
      tab,
      source: String(data.source || ""),
      message: String(data.message || ""),
      supply_id: supplyId,
      match_count: items.length,
    };
    state.items = items;
    state.total = items.length;
    state.page = 1;
    state.selected.clear();
    if (data.counts) updateTabCounts(data.counts);
    // Keep operator on a visible tab button; do not open hidden tabs.
    // Multi-match may span tabs — stay on current visible tab.
    if (!multi && tab && !OZON_FBS_HIDDEN_TABS.has(tab) && state.tab !== tab) {
      state.tab = tab;
      document.querySelectorAll("#ozonFbsTabs .wb-fbs-tab").forEach((btn) => {
        btn.classList.toggle("active", btn.dataset.tab === tab);
      });
    }
    syncTableMode();
    renderTable(items);
    syncPackagingActionButtons();
    const tabLabel = String(
      details?.tab_label || OZON_FBS_TAB_LABELS[tab] || tab || "—"
    ).trim();
    const statusLabel = String(
      details?.status_label || item.status_label || item.status || ""
    ).trim();
    const via = data.status_refreshed || data.source === "local+api"
      ? "статус обновлён из Ozon"
      : (data.message && String(data.message).startsWith("Статус из базы")
        ? "статус из базы (API недоступен)"
        : (multi ? `найдено ${items.length} по запросу ${queryLabel || postingNumber}` : "найдено в базе"));
    const info = document.getElementById("ozonFbsInfo");
    if (info) info.textContent = `Всего: ${items.length}`;
    if (multi) {
      _ozonFbsRenderLookupDetail(null);
    } else if (details) {
      _ozonFbsRenderLookupDetail(details, { viaText: via });
    } else {
      _ozonFbsRenderLookupDetail({
        posting_number: postingNumber,
        product_name: item.product_name || item.offer_id || "—",
        offer_id: item.offer_id || "",
        order_number: item.order_number || item.order_id || "",
        tab_label: tabLabel,
        status_label: statusLabel,
        supply_id: supplyId,
        sticker_barcode: item.sticker_barcode || "",
        sticker_scanit: item.sticker_scanit || "",
        kiz_codes: [],
        pick_verified: false,
        pick_barcode: "",
        container_label: "",
      }, { viaText: via });
    }
    const pageInfo = document.getElementById("ozonFbsPageInfo");
    if (pageInfo) pageInfo.textContent = "1 / 1";
    const pager = document.querySelector("#section-ozon-fbs .supplies-pagination");
    if (pager) pager.style.display = "";
    const prev = document.getElementById("ozonFbsPrevBtn");
    const next = document.getElementById("ozonFbsNextBtn");
    if (prev) prev.disabled = true;
    if (next) next.disabled = true;
    return true;
  }

  function isDeliveringSuppliesTab() {
    return state.tab === "delivering";
  }

  /**
   * Composition lock for «Доставляются»: нельзя менять состав/название.
   * «Товары с/без КИЗ» для менеджеров — только индикаторы статуса;
   * главному пользователю модалки можно открывать (просмотр / правка).
   */
  function isSupplyDetailReadOnly() {
    return Boolean(supplyDetailState.supply?.read_only) || isDeliveringSuppliesTab();
  }

  function _ozonFbsIsTenantOwner() {
    return typeof isTenantOwner === "function" && isTenantOwner();
  }

  function _ozonFbsCanOpenKizPickWhileReadOnly() {
    return _ozonFbsIsTenantOwner();
  }

  function _ozonFbsKizPickLockedAsToneOnly() {
    return isSupplyDetailReadOnly() && !_ozonFbsCanOpenKizPickWhileReadOnly();
  }

  function _ozonFbsCanOpenDriverWhileReadOnly() {
    // Delivering detail is otherwise read-only, but any FBS user may still set the driver.
    return true;
  }

  function _ozonFbsDriverLockedAsToneOnly() {
    return isSupplyDetailReadOnly() && !_ozonFbsCanOpenDriverWhileReadOnly();
  }

  function _ozonFbsSyncSupplyDetailToneOnlySplits(toneOnly) {
    const tip =
      "Только индикатор статуса — изменение недоступно: отправления уже в доставке";
    const defaults = {
      ozonFbsSupplyDetailKizBtn: "Товары с КИЗ — коды маркировки «Честный знак»",
      ozonFbsSupplyDetailPickVerifyBtn: "Товары без КИЗ — проверка штрихкодов",
      ozonFbsSupplyDetailDriverBtn: "Водитель поставки: выбрать из справочника и гос. номер ТС",
    };
    Object.keys(defaults).forEach((id) => {
      const el = document.getElementById(id);
      if (!el) return;
      // Driver uses its own lock (unlocked for all users in delivering).
      const locked =
        id === "ozonFbsSupplyDetailDriverBtn" ? _ozonFbsDriverLockedAsToneOnly() : !!toneOnly;
      if (locked) {
        el.classList.add("is-tone-only");
        // Do not override wait-orders lock.
        if (!el.classList.contains("is-wait-orders")) {
          el.setAttribute("aria-disabled", "true");
          el.tabIndex = -1;
          el.setAttribute("title", tip);
        }
      } else {
        el.classList.remove("is-tone-only");
        if (!el.classList.contains("is-wait-orders") && _ozonFbsSupplyActionsReady()) {
          el.removeAttribute("aria-disabled");
          el.removeAttribute("tabindex");
          el.setAttribute("title", defaults[id]);
        }
      }
    });
  }

  function syncSupplyDetailReadOnlyMode(readOnly) {
    const modal = document.getElementById("ozonFbsSupplyDetailModal");
    const actions = modal?.querySelector(".wb-fbs-sd-actions");
    const checkTh = modal?.querySelector("th.wb-fbs-sd-col-check");
    const actTh = modal?.querySelector("th.wb-fbs-sd-col-act");
    if (modal) modal.classList.toggle("wb-fbs-sd--readonly", !!readOnly);
    // Keep action bar visible so KIZ/pick status buttons remain visible on delivering.
    if (actions) actions.hidden = false;
    if (checkTh) checkTh.hidden = !!readOnly;
    if (actTh) actTh.hidden = !!readOnly;
    document.querySelectorAll("#ozonFbsSupplyDetailColgroup col[data-fixed]").forEach((col) => {
      col.style.display = readOnly ? "none" : "";
    });
    const moveBtn = document.getElementById("ozonFbsSupplyDetailMoveDeliveringBtn");
    // Local «Перенести в доставку» only from «Ожидают отгрузки» (never on delivering).
    const hideMove =
      !!readOnly
      || isDeliveringSuppliesTab()
      || String(supplyDetailState.postingTab || "").trim() === "delivering";
    if (moveBtn) moveBtn.hidden = hideMove;
    const moveWrap = document.getElementById("ozonFbsMoveDeliveringGateWrap");
    if (moveWrap) moveWrap.hidden = hideMove;
    const info = document.getElementById("ozonFbsSupplyDetailInfo");
    if (info) {
      if (readOnly) {
        info.hidden = false;
        info.textContent =
          "Состав поставки изменению не подлежит — отправления уже в доставке.";
        info.classList.remove("is-ok");
        info.classList.add("is-warn");
      } else {
        info.hidden = true;
        info.textContent = "";
        info.classList.remove("is-ok", "is-warn");
      }
    }
    // Delivering: KIZ/pick stay as green status tones but must not open editors.
    _ozonFbsSyncSupplyDetailToneOnlySplits(_ozonFbsKizPickLockedAsToneOnly());
    _ozonFbsSyncMoveDeliveringEnabled();
  }

  function colspan() {
    if (!isSuppliesTab()) return state.lookupMode ? 5 : 4;
    if (isDeliveringSuppliesTab()) return 8;
    return 7;
  }

  async function loadSources() {
    const sel = document.getElementById("ozonFbsSourceSelect");
    if (!sel) return;
    try {
      const res = await fetch("/api/ozon-fbs/sources");
      const data = await res.json();
      state.sources = Array.isArray(data) ? data : [];
      const prev = state.sourceId;
      sel.innerHTML = state.sources.length
        ? state.sources.map((s) =>
            `<option value="${esc(s.id)}">${esc(s.name || ("Источник " + s.id))}</option>`
          ).join("")
        : '<option value="">Нет активных источников OZON ФБС</option>';
      if (prev && state.sources.some((s) => Number(s.id) === Number(prev))) {
        sel.value = String(prev);
        state.sourceId = Number(prev);
      } else if (state.sources.length) {
        state.sourceId = Number(state.sources[0].id);
        sel.value = String(state.sourceId);
      } else {
        state.sourceId = null;
      }
    } catch (e) {
      sel.innerHTML = '<option value="">Ошибка загрузки источников</option>';
      state.sourceId = null;
    }
    if (typeof syncFbsSourcePicker === "function") syncFbsSourcePicker("ozonFbsSource");
  }

  function updateTabCounts(counts) {
    const next = counts && typeof counts === "object" ? { ...counts } : {};
    // Keep last known multi if a response omitted it (older payloads / supplies).
    if (
      next.awaiting_packaging_multi == null &&
      state.counts &&
      state.counts.awaiting_packaging_multi != null
    ) {
      next.awaiting_packaging_multi = state.counts.awaiting_packaging_multi;
      if (
        next.awaiting_packaging_multi_extra == null &&
        state.counts.awaiting_packaging_multi_extra != null
      ) {
        next.awaiting_packaging_multi_extra = state.counts.awaiting_packaging_multi_extra;
      }
    }
    // Keep open supplies count — find/supplies payloads often omit it, and wiping
    // it hides «Добавить к существующей» on the selection bottom bar.
    if (
      next.open_supplies == null &&
      state.counts &&
      state.counts.open_supplies != null
    ) {
      next.open_supplies = state.counts.open_supplies;
    }
    state.counts = next;
    Object.keys(TAB_COUNT_IDS).forEach((tab) => {
      const el = document.getElementById(TAB_COUNT_IDS[tab]);
      if (el) el.textContent = String(state.counts[tab] || 0);
    });
    syncPackagingActionButtons();
    updateBottomBar();
  }

  function multiAwaitingCount() {
    const fromCounts = Math.max(0, Number(state.counts.awaiting_packaging_multi || 0) || 0);
    if (fromCounts > 0) return fromCounts;
    // Fallback: current packaging page rows (same for owner and managers).
    if (state.tab === "awaiting_packaging" && !isSuppliesTab() && Array.isArray(state.items)) {
      const fromItems = state.items.filter((row) => {
        if (!row || row.supply_id) return false;
        if (row.is_multi_unit === true) return true;
        return Math.max(0, Number(row.unit_count || 0) || 0) > 1;
      }).length;
      if (fromItems > 0) return fromItems;
    }
    return 0;
  }

  function isSupplyOpenBlocked() {
    // Block opening local supplies during sync/split/collect/ship-all.
    return Boolean(
      state.syncBusy || collectState.busy || splitState.busy || state.shipAllBusy
    );
  }

  function supplyOpenBlockedTitle() {
    if (state.syncBusy) return "Дождитесь окончания синхронизации";
    if (splitState.busy) return "Дождитесь окончания разделения мультизаказов";
    if (collectState.busy || state.shipAllBusy) return "Дождитесь окончания сборки заказов";
    return "Дождитесь окончания операции";
  }

  function syncSupplyOpenLinks() {
    const blocked = isSupplyOpenBlocked();
    const tip = blocked ? supplyOpenBlockedTitle() : "";
    document.querySelectorAll("#ozonFbsOrdersTbody .wb-fbs-supply-name[data-supply-open]").forEach((el) => {
      el.classList.toggle("is-disabled", blocked);
      if (blocked) {
        el.setAttribute("aria-disabled", "true");
        el.setAttribute("title", tip);
        el.removeAttribute("tabindex");
        el.removeAttribute("role");
      } else {
        el.removeAttribute("aria-disabled");
        el.removeAttribute("title");
        el.setAttribute("tabindex", "0");
        el.setAttribute("role", "button");
      }
    });
  }

  function syncPackagingActionButtons() {
    const splitBtn = document.getElementById("ozonFbsSplitMultiBtn");
    const shipBtn = document.getElementById("ozonFbsShipAllBtn");
    const n = Number(state.counts.awaiting_packaging || 0);
    const multi = multiAwaitingCount();
    const syncBusy = Boolean(state.syncBusy);
    const busy =
      syncBusy ||
      Boolean(state.shipAllBusy) ||
      Boolean(collectState.busy) ||
      Boolean(splitState.busy);
    // Visible on the three operational tabs when multi remain (same for all roles).
    const onMainTabs =
      state.tab === "awaiting_packaging" ||
      state.tab === "awaiting_deliver" ||
      state.tab === "delivering";
    const syncTitle = "Идёт синхронизация, подождите";
    if (splitBtn) {
      const showSplit = onMainTabs && multi > 0;
      splitBtn.hidden = !showSplit;
      splitBtn.style.display = showSplit ? "" : "none";
      splitBtn.disabled = !state.sourceId || !showSplit || busy;
      if (syncBusy && showSplit) {
        splitBtn.title = syncTitle;
      } else if (showSplit) {
        splitBtn.title = `Разделить мультизаказы (${multi}) на одинарные без сборки`;
      } else {
        splitBtn.title = "Нет мультизаказов в «Ожидают сборки»";
      }
      splitBtn.textContent = splitState.busy
        ? (splitState.progressText || "Разделение…")
        : "Разделить мультизаказы";
    }
    if (shipBtn) {
      const blockedByMulti = multi > 0;
      shipBtn.disabled = !state.sourceId || n <= 0 || busy || blockedByMulti;
      if (syncBusy) {
        shipBtn.title = syncTitle;
      } else if (blockedByMulti) {
        shipBtn.title = "Сначала нужно разделить мультизаказы";
      } else if (n > 0) {
        shipBtn.title =
          `Собрать все отправления в «Ожидают сборки» (${n}) и создать локальную поставку`;
      } else {
        shipBtn.title = "Нет отправлений в «Ожидают сборки»";
      }
    }
    syncSupplyOpenLinks();
  }

  function syncShipAllButton() {
    syncPackagingActionButtons();
  }

  function syncSelectAll() {
    const selAll = document.getElementById("ozonFbsSelectAll");
    if (!selAll) return;
    const key = isSuppliesTab() ? "supply_id" : "posting_number";
    const ids = state.items.map((x) => String(x[key] || "").trim()).filter(Boolean);
    const allOnPage = ids.length > 0 && ids.every((id) => state.selected.has(id));
    const someOnPage = ids.some((id) => state.selected.has(id));
    selAll.checked = allOnPage;
    selAll.indeterminate = !allOnPage && someOnPage;
  }

  function onCheckboxChange() {
    document.querySelectorAll("#ozonFbsOrdersTable .wb-fbs-row-cb").forEach((cb) => {
      const id = String(cb.dataset.supplyId || cb.dataset.posting || "").trim();
      if (!id) return;
      if (cb.checked) state.selected.add(id);
      else state.selected.delete(id);
    });
    syncSelectAll();
    updateBottomBar();
  }

  function toggleSelectAll(checked) {
    document.querySelectorAll("#ozonFbsOrdersTable .wb-fbs-row-cb").forEach((cb) => {
      cb.checked = !!checked;
      const id = String(cb.dataset.supplyId || cb.dataset.posting || "").trim();
      if (!id) return;
      if (checked) state.selected.add(id);
      else state.selected.delete(id);
    });
    const selAll = document.getElementById("ozonFbsSelectAll");
    if (selAll) selAll.indeterminate = false;
    updateBottomBar();
  }

  function selectedCountLabel(n) {
    const abs = Math.abs(Number(n) || 0) % 100;
    const last = abs % 10;
    let word;
    if (isSuppliesTab()) {
      word = "поставок";
      if (!(abs > 10 && abs < 20)) {
        if (last === 1) word = "поставка";
        else if (last >= 2 && last <= 4) word = "поставки";
      }
    } else {
      word = "отправлений";
      if (!(abs > 10 && abs < 20)) {
        if (last === 1) word = "отправление";
        else if (last >= 2 && last <= 4) word = "отправления";
      }
    }
    return `Выбрано ${n} ${word}`;
  }

  function updateBottomBar() {
    const bar = document.getElementById("ozonFbsBottomBar");
    const label = document.getElementById("ozonFbsSelectedLabel");
    const packActions = document.getElementById("ozonFbsBottomPackagingActions");
    const deliverActions = document.getElementById("ozonFbsBottomDeliveringActions");
    const addBtn = document.getElementById("ozonFbsAddToSupplyBtn");
    const n = state.selected.size;
    // Packaging postings: new / add-to-existing supply.
    // Delivering supplies: move selected supplies back to awaiting_deliver.
    const isPackaging = state.tab === "awaiting_packaging" && !isSuppliesTab();
    const isDeliveringSupplies = isDeliveringSuppliesTab();
    const showBar = n > 0 && (isPackaging || isDeliveringSupplies);
    if (label) label.textContent = selectedCountLabel(n);
    if (packActions) packActions.classList.toggle("hidden", !isPackaging);
    if (deliverActions) deliverActions.classList.toggle("hidden", !isDeliveringSupplies);
    if (addBtn) {
      const openSupplies = Number((state.counts && state.counts.open_supplies) || 0);
      addBtn.classList.toggle("hidden", !(isPackaging && n > 0 && openSupplies > 0));
    }
    if (bar) bar.classList.toggle("hidden", !showBar);
  }

  function clearSelection() {
    state.selected.clear();
    document.querySelectorAll("#ozonFbsOrdersTable .wb-fbs-row-cb").forEach((cb) => {
      cb.checked = false;
    });
    syncSelectAll();
    updateBottomBar();
  }

  function syncTableMode() {
    const supplies = isSuppliesTab();
    const nextMode = supplies
      ? (isDeliveringSuppliesTab() ? "supplies-delivering" : "supplies-awaiting")
      : (state.lookupMode ? "orders-lookup" : "orders");
    const modeChanged = state.viewMode !== nextMode;
    state.viewMode = nextMode;
    const table = document.getElementById("ozonFbsOrdersTable");
    const colgroup = document.getElementById("ozonFbsColgroup");
    const thead = table?.querySelector("thead tr");
    const search = document.getElementById("ozonFbsSearchFilter");
    if (table) {
      table.classList.toggle("wb-fbs-table--supplies", supplies);
      table.classList.toggle("wb-fbs-table--assembly", supplies);
      // Wrap cell text only on «Доставляются», where columns are user-resizable.
      table.classList.toggle("fbs-col-wrap", isDeliveringSuppliesTab());
    }
    if (search) {
      search.placeholder = supplies
        ? "Поиск по поставке, складу или номеру отправления…"
        : "Поиск по отправлению, артикулу, ШК…";
    }
    if (!colgroup || !thead) {
      initDeliveringColumnResizer();
      return;
    }
    if (!modeChanged && colgroup.children.length) {
      initDeliveringColumnResizer();
      return;
    }
    if (supplies) {
      const showActions = true;
      const delivering = isDeliveringSuppliesTab();
      const rh = delivering ? '<span class="col-resize-handle"></span>' : "";
      colgroup.innerHTML = `
        <col data-fixed="1" class="wb-fbs-col-check" style="width:40px" />
        <col data-col="0" class="wb-fbs-col-supply" style="width:26%" />
        <col data-col="1" class="wb-fbs-col-qr" style="width:16%" />
        <col data-col="2" class="wb-fbs-col-orders" style="width:14%" />
        <col data-col="3" class="wb-fbs-col-status" style="width:${delivering ? "14%" : "16%"}" />
        ${delivering ? '<col data-col="4" class="wb-fbs-col-driver" style="width:16%" />' : ""}
        <col data-col="${delivering ? "5" : "4"}" class="wb-fbs-col-wh" style="width:${delivering ? "14%" : "22%"}" />
        ${showActions ? '<col data-fixed="1" class="wb-fbs-col-act" style="width:48px" />' : ""}
      `;
      thead.innerHTML = `
        <th class="wb-fbs-th-check"><input type="checkbox" id="ozonFbsSelectAll" onchange="toggleSelectAllOzonFbs(this.checked)" title="Выбрать все на странице" /></th>
        <th data-col="0">Поставка${rh}</th>
        <th data-col="1">ID поставки${rh}</th>
        <th data-col="2">Заказы${rh}</th>
        <th data-col="3">${delivering ? "Этап сборки/Статус ТН" : "Этап сборки"}${rh}</th>
        ${delivering ? `<th data-col="4">Водитель${rh}</th>` : ""}
        <th data-col="${delivering ? "5" : "4"}">Склад${rh}</th>
        ${showActions ? '<th class="wb-fbs-th-act"></th>' : ""}
      `;
      initDeliveringColumnResizer();
    } else {
      const showAct = !!state.lookupMode;
      colgroup.innerHTML = `
        <col data-fixed="1" class="wb-fbs-col-check" style="width:40px" />
        <col data-col="0" class="wb-fbs-col-order" />
        <col data-col="1" class="wb-fbs-col-product" />
        <col data-col="2" class="wb-fbs-col-wh" />
        ${showAct ? '<col data-fixed="1" class="wb-fbs-col-act" style="width:48px" />' : ""}
      `;
      thead.innerHTML = `
        <th class="wb-fbs-th-check"><input type="checkbox" id="ozonFbsSelectAll" onchange="toggleSelectAllOzonFbs(this.checked)" title="Выбрать все на странице" /></th>
        <th data-col="0">Отправление<span class="col-resize-handle"></span></th>
        <th data-col="1">Товар<span class="col-resize-handle"></span></th>
        <th data-col="2">Склад<span class="col-resize-handle"></span></th>
        ${showAct ? '<th class="wb-fbs-th-act"></th>' : ""}
      `;
      initColumnResizer();
    }
  }

  function _ozonFbsRenameMenuIconHtml() {
    return `<span class="wb-fbs-menu-ico" aria-hidden="true">
      <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M11.5 3.5l3 3L6.75 14.25H3.75v-3L11.5 3.5z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round" fill="none"/>
        <path d="M10.25 4.75l3 3" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/>
      </svg>
    </span>`;
  }

  function _ozonFbsTtnMenuIconHtml() {
    return `<span class="wb-fbs-menu-ico" aria-hidden="true">
      <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M4 2.5h7.5L16 7v8.5H4V2.5z" stroke="currentColor" stroke-width="1.4" fill="none"/>
        <path d="M11.5 2.5V7H16" stroke="currentColor" stroke-width="1.4" fill="none"/>
        <path d="M6.5 10h5M6.5 12.5h5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/>
      </svg>
    </span>`;
  }

  function _ozonFbsTtnPrintMenuIconHtml() {
    return `<span class="wb-fbs-menu-ico" aria-hidden="true">
      <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M5 7V3.5h8V7" stroke="currentColor" stroke-width="1.4" fill="none"/>
        <path d="M5 11.5H3.5A1.5 1.5 0 0 1 2 10V8.5A1.5 1.5 0 0 1 3.5 7h11A1.5 1.5 0 0 1 16 8.5V10a1.5 1.5 0 0 1-1.5 1.5H13" stroke="currentColor" stroke-width="1.4" fill="none"/>
        <rect x="5" y="11" width="8" height="4.5" stroke="currentColor" stroke-width="1.4"/>
      </svg>
    </span>`;
  }

  function _ozonFbsSupplyRowActionsHtml(supply) {
    const row = supply && typeof supply === "object" ? supply : { supply_id: supply };
    const sid = String(row.supply_id || "").trim();
    if (!sid) return "";
    const safeKey = _ozonFbsPostingMenuKey(`s_${sid}`);
    const src = Number(row.source_id || state.sourceId || 0);
    if (isDeliveringSuppliesTab()) {
      const ttnId = Number(row.ttn_id || 0);
      const xmlItems = typeof ttnLogisticsXmlMenuItemsHtml === "function"
        ? ttnLogisticsXmlMenuItemsHtml(ttnId, {
            closeJs: "closeOzonFbsRowMenus()",
            iconHtml: typeof _wbFbsTtnXmlMenuIconHtml === "function"
              ? _wbFbsTtnXmlMenuIconHtml()
              : _ozonFbsTtnMenuIconHtml(),
          })
        : "";
      const printItem = ttnId > 0
        ? `<button type="button" class="wb-fbs-row-menu-item" role="menuitem"
                  onclick="printTtnRecord(${ttnId})">
            ${_ozonFbsTtnPrintMenuIconHtml()}
            Распечатать ТН
          </button>`
        : "";
      return `<div class="wb-fbs-row-menu-wrap" id="ozonFbsRowMenuWrap_${safeKey}">
        <button type="button" class="icon-btn secondary wb-fbs-row-menu-btn" title="Действия"
                onclick="toggleOzonFbsRowMenu(event, '${esc(safeKey)}')" aria-haspopup="menu">⋮</button>
        <div id="ozonFbsRowMenu_${safeKey}" class="wb-fbs-row-menu" data-supply-id="${esc(sid)}" role="menu">
          <button type="button" class="wb-fbs-row-menu-item" role="menuitem"
                  onclick="ozonFbsFormTtn('${esc(sid)}', ${src}).catch((e)=>alert(e.message||e))">
            ${_ozonFbsTtnMenuIconHtml()}
            Сформировать ТН
          </button>
          ${xmlItems}
          ${printItem}
        </div>
      </div>`;
    }
    return `<div class="wb-fbs-row-menu-wrap" id="ozonFbsRowMenuWrap_${safeKey}">
      <button type="button" class="icon-btn secondary wb-fbs-row-menu-btn" title="Действия"
              onclick="toggleOzonFbsRowMenu(event, '${esc(safeKey)}')" aria-haspopup="menu">⋮</button>
      <div id="ozonFbsRowMenu_${safeKey}" class="wb-fbs-row-menu" data-supply-id="${esc(sid)}" role="menu">
        <button type="button" class="wb-fbs-row-menu-item" role="menuitem"
                onclick="openOzonFbsRenameSupplyModal('${esc(sid)}')">
          ${_ozonFbsRenameMenuIconHtml()}
          Переименовать поставку
        </button>
      </div>
    </div>`;
  }

  async function ozonFbsFormTtn(supplyId, sourceId) {
    closeOzonFbsRowMenus();
    const sid = String(supplyId || "").trim();
    const src = Number(sourceId || state.sourceId || 0);
    if (!sid || !src) {
      alert("Не указан источник поставки");
      return;
    }
    if (typeof _openTtnModal !== "function") {
      alert("Модалка ТН недоступна");
      return;
    }
    const res = await fetch(
      `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/ttn-prefill?source_id=${src}`
    ).catch(() => null);
    if (!res || !res.ok) {
      const err = await res?.json().catch(() => ({})) || {};
      alert(err.detail || "Не удалось подготовить ТН");
      return;
    }
    const data = await res.json().catch(() => ({}));
    const record = data.record || null;
    if (!record) {
      alert("Не удалось подготовить ТН");
      return;
    }
    if (typeof window.setTtnOpenedFromFbsTab === "function") {
      window.setTtnOpenedFromFbsTab("ozon");
    }
    const existingId = Number(data.existing_ttn_id || record.id || 0);
    await _openTtnModal(existingId ? "edit" : "create", record);
    const info = document.getElementById("ttnCreateInfo");
    const warnings = Array.isArray(data.warnings) ? data.warnings.filter(Boolean) : [];
    if (info && warnings.length) {
      info.textContent = warnings.join(" ");
      info.style.color = "#b45309";
    }
  }

  function openOzonFbsRenameSupplyModal(supplyId) {
    closeOzonFbsRowMenus();
    const sid = String(supplyId || "").trim();
    if (!sid || !state.sourceId || isDeliveringSuppliesTab()) return;
    const row = state.items.find((x) => String(x.supply_id || "").trim() === sid);
    const detailName = (
      supplyDetailState.supply && String(supplyDetailState.supply.supply_id || "") === sid
    )
      ? String(supplyDetailState.supply.name || "").trim()
      : "";
    const input = document.getElementById("ozonFbsRenameSupplyInput");
    const err = document.getElementById("ozonFbsRenameSupplyError");
    const saveBtn = document.getElementById("ozonFbsRenameSupplySaveBtn");
    if (err) {
      err.hidden = true;
      err.textContent = "";
    }
    if (saveBtn) saveBtn.disabled = false;
    if (input) {
      input.value = detailName || String(row?.name || "").trim();
      input.dataset.supplyId = sid;
      input.onkeydown = (ev) => {
        if (ev.key === "Enter") {
          ev.preventDefault();
          submitOzonFbsRenameSupply();
        } else if (ev.key === "Escape") {
          ev.preventDefault();
          closeOzonFbsRenameSupplyModal();
        }
      };
    }
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsRenameSupplyModal", true);
    } else {
      document.getElementById("ozonFbsRenameSupplyModal")?.classList.remove("hidden");
    }
    setTimeout(() => {
      input?.focus();
      input?.select();
    }, 0);
  }

  function closeOzonFbsRenameSupplyModal() {
    const input = document.getElementById("ozonFbsRenameSupplyInput");
    if (input) input.dataset.supplyId = "";
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsRenameSupplyModal", false);
    } else {
      document.getElementById("ozonFbsRenameSupplyModal")?.classList.add("hidden");
    }
  }

  async function submitOzonFbsRenameSupply() {
    const input = document.getElementById("ozonFbsRenameSupplyInput");
    const err = document.getElementById("ozonFbsRenameSupplyError");
    const saveBtn = document.getElementById("ozonFbsRenameSupplySaveBtn");
    const sid = String(input?.dataset.supplyId || "").trim();
    const name = String(input?.value || "").trim();
    if (!sid || !state.sourceId) return;
    if (!name) {
      if (err) {
        err.hidden = false;
        err.textContent = "Укажите название поставки";
      }
      input?.focus();
      return;
    }
    if (name.length > 128) {
      if (err) {
        err.hidden = false;
        err.textContent = "Название не длиннее 128 символов";
      }
      return;
    }
    if (saveBtn) saveBtn.disabled = true;
    if (err) {
      err.hidden = true;
      err.textContent = "";
    }
    try {
      const res = await fetch(`/api/ozon-fbs/supplies/${encodeURIComponent(sid)}`, {
        method: "PATCH",
        headers: jsonHeaders(),
        body: JSON.stringify({ source_id: state.sourceId, name }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      const newName = String(data.name || name).trim();
      const row = state.items.find((x) => String(x.supply_id || "").trim() === sid);
      if (row) row.name = newName;
      if (supplyDetailState.supply && String(supplyDetailState.supply.supply_id || "") === sid) {
        supplyDetailState.supply.name = newName;
        const title = document.getElementById("ozonFbsSupplyDetailTitle");
        if (title) title.textContent = newName;
      }
      closeOzonFbsRenameSupplyModal();
      if (isSuppliesTab()) renderSuppliesTable(state.items);
      if (data.split) {
        const kept = String(data.delivering_name || "").trim();
        const n = Number(data.delivering_count || 0);
        showSyncInfo(
          kept
            ? `Поставка переименована: ${newName}. В «Доставляются» осталось «${kept}» (${n} отпр.)`
            : `Поставка переименована: ${newName}. Отправления в доставке сохранены под старым названием`
        );
      } else {
        showSyncInfo(`Поставка переименована: ${newName}`);
      }
    } catch (e) {
      if (err) {
        err.hidden = false;
        err.textContent = String(e.message || e);
      } else {
        alert(String(e.message || e));
      }
    } finally {
      if (saveBtn) saveBtn.disabled = false;
    }
  }

  function _ozonFbsSupplyStageCell(supply) {
    const status = String(supply?.status_label || "Сборка заказов");
    const stage = `<span class="wb-fbs-supply-status is-assembly">${esc(status)}</span>`;
    if (!isDeliveringSuppliesTab()) return stage;
    const formed = Number(supply?.ttn_id || 0) > 0;
    const ttnLabel = formed ? "Сформирована" : "Несформирована";
    const ttnCls = formed ? "is-done" : "is-ttn-none";
    return `<div class="fbs-supply-status-stack">${stage}<span class="wb-fbs-supply-status ${ttnCls}">${esc(ttnLabel)}</span></div>`;
  }

  function renderSuppliesTable(items) {
    const tbody = document.getElementById("ozonFbsOrdersTbody");
    if (!tbody) return;
    state.items = Array.isArray(items) ? items : [];
    if (!state.items.length) {
      const emptyMsg = isDeliveringSuppliesTab()
        ? "Нет отправлений в доставке."
        : "Нет локальных поставок. Соберите заказы синей кнопкой на вкладке «Ожидают сборки».";
      tbody.innerHTML = `<tr><td colspan="${colspan()}" class="wb-fbs-empty">${esc(emptyMsg)}</td></tr>`;
      syncSelectAll();
      return;
    }
    const openBlocked = isSupplyOpenBlocked();
    const openTip = openBlocked ? supplyOpenBlockedTitle() : "";
    tbody.innerHTML = state.items.map((s) => {
      const sid = String(s.supply_id || "").trim();
      const checked = state.selected.has(sid) ? "checked" : "";
      const created = s.created_at || "";
      const createdMeta = created
        ? `<div class="wb-fbs-order-meta">от ${esc(fmtDate(created))}</div>`
        : "";
      const ordersCount = Number(s.order_count || 0);
      const actionsTd = `<td class="wb-fbs-td-act">${_ozonFbsSupplyRowActionsHtml(s)}</td>`;
      const nameCls = openBlocked
        ? "wb-fbs-supply-name is-link is-disabled"
        : "wb-fbs-supply-name is-link";
      const nameTitle = openBlocked ? ` title="${esc(openTip)}"` : "";
      const nameTab = openBlocked ? "" : ' tabindex="0"';
      const nameAria = openBlocked ? ' aria-disabled="true"' : ' role="button"';
      const tone = isDeliveringSuppliesTab()
        ? String(s.row_tone || "").trim()
        : "";
      const rowCls = tone === "warn"
        ? " class=\"fbs-supply-row-warn\""
        : (tone === "ok" ? " class=\"fbs-supply-row-ok\"" : "");
      const driverLabel = _ozonFbsSupplyDriverLabel(s);
      const driverCell = isDeliveringSuppliesTab()
        ? `<td class="wb-fbs-td-driver"><div class="fbs-supply-driver-label">Водитель</div><div class="fbs-supply-driver${_ozonFbsDriverHasAssignment(s) ? "" : " is-empty"}" title="${esc(driverLabel)}">${esc(driverLabel)}</div></td>`
        : "";
      return `<tr${rowCls}>
        <td class="wb-fbs-td-check"><input type="checkbox" class="wb-fbs-row-cb" data-supply-id="${esc(sid)}" ${checked} onchange="onOzonFbsCheckboxChange()" /></td>
        <td class="wb-fbs-td-supply">
          <div class="${nameCls}" data-supply-open="1"${nameAria}${nameTab}${nameTitle}
               onclick="openOzonFbsSupplyDetailModal('${esc(sid)}')"
               onkeydown="if(event.key==='Enter')openOzonFbsSupplyDetailModal('${esc(sid)}')">${esc(s.name || ("Поставка " + sid))}</div>
          ${createdMeta}
          <div class="ozon-fbs-mobile-supply-id" title="ID поставки">${esc(sid)}</div>
          <div class="ozon-fbs-mobile-meta">${esc(s.warehouse_label || "—")}</div>
        </td>
        <td class="wb-fbs-td-qr"><div class="wb-fbs-supply-qr" title="${esc(sid)}">${esc(sid || "—")}</div></td>
        <td class="wb-fbs-td-orders">
          <div class="wb-fbs-supply-orders">${esc(ordersCount)}</div>
          <div class="wb-fbs-order-meta">отправлений</div>
        </td>
        <td class="wb-fbs-td-status">${_ozonFbsSupplyStageCell(s)}</td>
        ${driverCell}
        <td class="wb-fbs-td-wh">
          <div class="wb-fbs-wh-name" title="${esc(s.warehouse_label || "")}">${esc(s.warehouse_label || "—")}</div>
        </td>
        ${actionsTd}
      </tr>`;
    }).join("");
    syncSelectAll();
    updateBottomBar();
  }

  function productCompositionHtml(row) {
    const units = Math.max(0, Number(row?.unit_count || row?.quantity || 0) || 0);
    const lines = Array.isArray(row?.products_brief) ? row.products_brief : [];
    const lineCount = Math.max(
      Number(row?.line_count || 0) || 0,
      lines.length
    );
    const badges = [];
    if (units > 1) {
      badges.push(
        `<span class="wb-fbs-badge qty" title="Единиц в отправлении">${esc(String(units))} шт.</span>`
      );
    }
    if (lineCount > 1) {
      badges.push(
        `<span class="wb-fbs-badge cargo" title="Разных товарных позиций">${esc(String(lineCount))} поз.</span>`
      );
    }
    const badgeHtml = badges.length
      ? `<div class="wb-fbs-badges wb-fbs-product-qty">${badges.join("")}</div>`
      : "";
    let extraHtml = "";
    if (lines.length > 1) {
      extraHtml =
        `<div class="wb-fbs-product-extra">` +
        lines
          .slice(1)
          .map((p) => {
            const offer = String(p.offer_id || "").trim();
            const sku = String(p.sku || "").trim();
            const art = offer || sku || "—";
            const q = Math.max(1, Number(p.quantity) || 1);
            const nm = String(p.name || art || "—").trim() || "—";
            const qtyBit = q > 1 ? ` ×${q}` : "";
            return `<div class="wb-fbs-product-extra-line" title="${esc(nm)}">+ ${esc(nm)}${esc(qtyBit)} <span class="wb-fbs-order-meta">Арт. ${esc(art)}</span></div>`;
          })
          .join("") +
        `</div>`;
    }
    return badgeHtml + extraHtml;
  }

  function _ozonFbsLookupRowActionsHtml(postingNumber) {
    const pn = String(postingNumber || "").trim();
    if (!pn || !state.lookupMode) return "";
    const menuKey = _ozonFbsPostingMenuKey(`lookup_${pn}`);
    return `<td class="wb-fbs-sd-col-act">
      <div class="wb-fbs-row-menu-wrap" id="ozonFbsRowMenuWrap_${menuKey}">
        <button type="button" class="icon-btn secondary wb-fbs-row-menu-btn" title="Действия"
                onclick="toggleOzonFbsRowMenu(event, '${menuKey}')" aria-haspopup="menu">⋮</button>
        <div id="ozonFbsRowMenu_${menuKey}" class="wb-fbs-row-menu" data-posting="${esc(pn)}" role="menu">
          <button type="button" class="wb-fbs-row-menu-item" role="menuitem"
                  onclick="openOzonFbsMovePostingModal('${esc(pn)}')">
            Переместить в поставку
          </button>
          <button type="button" class="wb-fbs-row-menu-item" role="menuitem"
                  data-ozon-action="print-sticker" data-posting="${esc(pn)}">
            Напечатать стикер
          </button>
        </div>
      </div>
    </td>`;
  }

  function renderTable(items) {
    const tbody = document.getElementById("ozonFbsOrdersTbody");
    if (!tbody) return;
    state.items = Array.isArray(items) ? items : [];
    if (!state.items.length) {
      tbody.innerHTML = `<tr><td colspan="${colspan()}" class="wb-fbs-empty">Нет отправлений в этой вкладке</td></tr>`;
      syncSelectAll();
      return;
    }
    tbody.innerHTML = state.items.map((row) => {
      const pnRaw = String(row.posting_number || "").trim();
      const pn = esc(pnRaw);
      const checked = state.selected.has(pnRaw) ? "checked" : "";
      const created = row.created_at_ozon || row.in_process_at || "";
      const ago = agoLabel(created);
      const badges = [];
      if (ago) badges.push(`<span class="wb-fbs-badge time">${esc(ago)}</span>`);
      // Do not show order_number next to the time badge: for Ozon it is usually
      // the posting number without the last segment and duplicates the id above.
      const photo = row.product_photo
        ? `<img class="wb-fbs-product-photo" src="${esc(row.product_photo)}" alt="" width="144" height="144" loading="lazy">`
        : `<span class="wb-fbs-product-ph" aria-hidden="true"></span>`;
      const barcodes = Array.isArray(row.barcodes) ? row.barcodes : [];
      const barcodeHtml = barcodes.length
        ? `<div class="wb-fbs-barcodes" title="Штрихкод товара">${barcodes.map((b) =>
            `<div class="wb-fbs-barcode">${esc(b)}</div>`
          ).join("")}</div>`
        : "";
      const offer = String(row.offer_id || "").trim();
      const sku = String(row.sku || "").trim();
      const productName = row.product_name_display || row.product_name || offer || "—";
      const composition = productCompositionHtml(row);
      const whLabel = row.warehouse_label || row.warehouse_name || "—";
      const whId = row.warehouse_id != null && String(row.warehouse_id).trim()
        ? String(row.warehouse_id).trim()
        : "";
      const actCell = _ozonFbsLookupRowActionsHtml(pnRaw);
      const packagingOrders =
        state.tab === "awaiting_packaging" && !isSuppliesTab();
      let exemplarBadge = "";
      if (packagingOrders) {
        const badge = String(row.pre_ship_exemplar_badge || "");
        if (badge === "needed") {
          exemplarBadge =
            `<button type="button" class="wb-fbs-badge ozon-exemplar-needed"`
            + ` onclick="openOzonFbsPackagingExemplarModal('${pn}')"`
            + ` title="Нужны КИЗ и ГТД до сборки (юрлицо)">⚠ Маркировка не добавлена</button>`;
        } else if (badge === "ok") {
          exemplarBadge =
            `<button type="button" class="wb-fbs-badge ozon-exemplar-ok"`
            + ` onclick="openOzonFbsPackagingExemplarModal('${pn}')"`
            + ` title="КИЗ и ГТД переданы в Ozon">Маркировка добавлена</button>`;
        }
      }
      // «Ожидают сборки»: plain posting number + ii… scanit under it (last-4 large).
      const orderIdHtml = packagingOrders
        ? esc(pnRaw)
        : formatOzonPostingNumberHtml(pnRaw);
      const scanitUnderHtml = packagingOrders
        ? _ozonFbsScanitUnderOrderHtml(row)
        : "";
      return `<tr data-posting="${pn}">
      <td class="wb-fbs-td-check"><input type="checkbox" class="wb-fbs-row-cb" data-posting="${pn}" ${checked} onchange="onOzonFbsCheckboxChange()" /></td>
      <td class="wb-fbs-td-order">
        <div class="wb-fbs-order-id">${orderIdHtml}</div>
        ${scanitUnderHtml}
        <div class="wb-fbs-order-meta">от ${esc(fmtDate(created))}</div>
        ${exemplarBadge}
        ${badges.length ? `<div class="wb-fbs-badges">${badges.join("")}</div>` : ""}
        ${whLabel && whLabel !== "—" ? `<div class="ozon-fbs-mobile-wh">${esc(whLabel)}${whId ? " · ID " + esc(whId) : ""}</div>` : ""}
      </td>
      <td class="wb-fbs-td-product">
        <div class="wb-fbs-product">
          ${photo}
          <div class="wb-fbs-product-text">
            <div class="wb-fbs-product-name" title="${esc(productName)}">${esc(productName)}</div>
            <div class="wb-fbs-product-sub">Арт. ${esc(offer || "—")}${sku ? " · SKU " + esc(sku) : ""}</div>
            ${composition}
            ${barcodeHtml}
          </div>
        </div>
      </td>
      <td class="wb-fbs-td-wh">
        <div class="wb-fbs-wh-name" title="${esc(whLabel)}">${esc(whLabel)}</div>
        <div class="wb-fbs-order-meta">${whId ? "ID " + esc(whId) : ""}</div>
      </td>
      ${actCell}
    </tr>`;
    }).join("");
    syncSelectAll();
    updateBottomBar();
  }

  async function loadPostings(resetPage) {
    if (!canView()) return;
    if (resetPage) state.page = 1;
    clearLookupMode();
    syncTableMode();
    const tbody = document.getElementById("ozonFbsOrdersTbody");
    if (tbody) tbody.innerHTML = `<tr><td colspan="${colspan()}" class="wb-fbs-empty">Загрузка…</td></tr>`;
    if (!state.sourceId) {
      if (tbody) tbody.innerHTML = `<tr><td colspan="${colspan()}" class="wb-fbs-empty">Добавьте источник OZON ФБС в настройках</td></tr>`;
      return;
    }

    const suppliesMode = isSuppliesTab();
    const deliveringSupplies = suppliesMode && isDeliveringSuppliesTab();
    const pnQuery = parsePostingNumberQuery(state.search);
    const params = new URLSearchParams({
      source_id: String(state.sourceId),
      tab: state.tab,
      page: String(state.page),
      page_size: String(state.pageSize),
    });
    // Delivering supplies: server search + pagination. Orders tab: server search.
    // Awaiting-deliver supplies: still filtered client-side (no server page).
    if (state.search && !pnQuery && (!suppliesMode || deliveringSupplies)) {
      params.set("search", state.search);
    }
    const seq = ++state.loadSeq;

    try {
      // Posting / order number → /find (cross-tab + status refresh from Ozon).
      // Order number (…-0059) may return several package siblings stacked.
      if (pnQuery) {
        if (tbody) {
          tbody.innerHTML = `<tr><td colspan="${colspan()}" class="wb-fbs-empty">Ищем ${esc(pnQuery)}…</td></tr>`;
        }
        const infoPending = document.getElementById("ozonFbsInfo");
        if (infoPending) infoPending.textContent = `Поиск ${pnQuery}…`;
        const lookup = await lookupPostingByNumber(pnQuery, { seq });
        if (seq !== state.loadSeq) return;
        if (lookup && applyLookupResult(lookup, pnQuery)) return;
        state.items = [];
        state.total = 0;
        if (lookup?.counts) updateTabCounts(lookup.counts);
        syncTableMode();
        if (suppliesMode) renderSuppliesTable([]);
        else renderTable([]);
        syncPackagingActionButtons();
        const infoMiss = document.getElementById("ozonFbsInfo");
        if (infoMiss) {
          infoMiss.textContent = lookup?.message
            || `Отправление ${pnQuery} не найдено в локальной базе`;
        }
        const pageInfoMiss = document.getElementById("ozonFbsPageInfo");
        if (pageInfoMiss) pageInfoMiss.textContent = "1 / 1";
        const prevMiss = document.getElementById("ozonFbsPrevBtn");
        const nextMiss = document.getElementById("ozonFbsNextBtn");
        if (prevMiss) prevMiss.disabled = true;
        if (nextMiss) nextMiss.disabled = true;
        return;
      }

      const url = suppliesMode
        ? `/api/ozon-fbs/supplies?${params}`
        : `/api/ozon-fbs/postings?${params}`;
      const res = await fetch(url);
      const data = await res.json();
      if (seq !== state.loadSeq) return;
      if (!res.ok) throw new Error(detailText(data.detail) || "Ошибка загрузки");

      let items = data.items || [];
      if (suppliesMode && state.search && !deliveringSupplies) {
        const q = state.search.toLowerCase();
        items = items.filter((s) => {
          const hay = [
            s.name, s.supply_id, s.warehouse_label,
            ...(Array.isArray(s.posting_numbers) ? s.posting_numbers : []),
          ].map((x) => String(x || "").toLowerCase()).join(" ");
          if (hay.includes(q)) return true;
          const tail = _ozonFbsSearchPostingDigitTail(q);
          if (!tail) return false;
          const sidDigits = String(s.supply_id || "").replace(/\D+/g, "");
          if (sidDigits.endsWith(tail)) return true;
          return (Array.isArray(s.posting_numbers) ? s.posting_numbers : []).some((pn) =>
            String(pn || "").replace(/\D+/g, "").endsWith(tail)
          );
        });
      }

      updateTabCounts(data.counts || {});

      state.total = suppliesMode
        ? (deliveringSupplies ? Number(data.total || 0) : items.length)
        : Number(data.total || 0);
      if (deliveringSupplies && Number.isFinite(Number(data.page)) && Number(data.page) > 0) {
        state.page = Math.max(1, Math.round(Number(data.page)));
      }
      if (suppliesMode) {
        const adopted = Number(data.adopted_orphans || 0);
        if (adopted > 0) {
          const created = Array.isArray(data.adopt_created_supplies)
            ? data.adopt_created_supplies
            : [];
          const names = created.map((s) => s.name || s.supply_id).filter(Boolean);
          const adoptMsg = isDeliveringSuppliesTab()
            ? (names.length
              ? `Оформлено ${adopted} отпр. без поставки → «${names.join("», «")}»`
              : `Оформлено ${adopted} отправлений без поставки в «Без локальной поставки»`)
            : (names.length
              ? `Оформлено ${adopted} отпр. без поставки → ${names.join(", ")}`
              : `Оформлено ${adopted} отправлений без поставки в локальные поставки`);
          showSyncInfo(adoptMsg);
        }
        renderSuppliesTable(items);
      } else {
        renderTable(items);
      }
      syncPackagingActionButtons();

      const info = document.getElementById("ozonFbsInfo");
      if (info) {
        info.textContent = suppliesMode
          ? `Поставок: ${state.total}`
          : `Всего: ${state.total}`;
      }
      const pageInfo = document.getElementById("ozonFbsPageInfo");
      const pager = document.querySelector("#section-ozon-fbs .supplies-pagination");
      // Orders + «Доставляются» supplies: server pager. Awaiting-deliver supplies: all rows.
      if (suppliesMode && !deliveringSupplies) {
        if (pageInfo) pageInfo.textContent = "";
        if (pager) pager.style.display = "none";
      } else {
        if (pager) pager.style.display = "";
        const maxPage = Math.max(1, Math.ceil(state.total / state.pageSize) || 1);
        if (pageInfo) pageInfo.textContent = `Стр. ${state.page} / ${maxPage}`;
        const prev = document.getElementById("ozonFbsPrevBtn");
        const next = document.getElementById("ozonFbsNextBtn");
        if (prev) prev.disabled = state.page <= 1;
        if (next) next.disabled = state.page >= maxPage;
      }
    } catch (e) {
      if (seq !== state.loadSeq) return;
      if (tbody) {
        tbody.innerHTML = `<tr><td colspan="${colspan()}" class="wb-fbs-empty" style="color:#b91c1c">${esc(e.message)}</td></tr>`;
      }
    }
  }

  const DELIVERING_COL_WIDTHS_PREFIX = "ozon_fbs_delivering_col_widths_v1";
  const DELIVERING_DEFAULT_WIDTHS = [26, 16, 14, 14, 16, 14];
  let deliveringColResizerInited = false;

  function deliveringColWidthsKey() {
    const email = String(document.querySelector(".sidebar-user-email")?.textContent || "")
      .trim()
      .toLowerCase();
    return email
      ? `${DELIVERING_COL_WIDTHS_PREFIX}:${email}`
      : DELIVERING_COL_WIDTHS_PREFIX;
  }

  function deliveringResizableCols() {
    return Array.from(document.querySelectorAll("#ozonFbsColgroup col")).filter(
      (c) => !c.dataset.fixed
    );
  }

  function applyDeliveringColWidths(widths) {
    deliveringResizableCols().forEach((col, i) => {
      if (widths[i] !== undefined) col.style.width = `${widths[i]}%`;
    });
  }

  function getDeliveringColWidths() {
    return deliveringResizableCols().map(
      (col, i) => parseFloat(col.style.width) || DELIVERING_DEFAULT_WIDTHS[i] || 10
    );
  }

  function initDeliveringColumnResizer() {
    const table = document.getElementById("ozonFbsOrdersTable");
    if (!table || !isDeliveringSuppliesTab()) return;
    let widths = DELIVERING_DEFAULT_WIDTHS.slice();
    try {
      const saved = JSON.parse(localStorage.getItem(deliveringColWidthsKey()) || "null");
      if (Array.isArray(saved) && saved.length === widths.length) {
        widths = saved.map((n, i) => {
          const v = Number(n);
          return Number.isFinite(v) && v > 0 ? v : widths[i];
        });
      }
    } catch (_) {
      /* ignore */
    }
    applyDeliveringColWidths(widths);
    if (deliveringColResizerInited) return;
    deliveringColResizerInited = true;

    let startX = 0;
    let colIdx = 0;
    let startWidths = [];
    let activeHandle = null;

    function onMouseMove(e) {
      const tableEl = document.getElementById("ozonFbsOrdersTable");
      if (!tableEl || !isDeliveringSuppliesTab()) return;
      const tableW = tableEl.offsetWidth || 1;
      const deltaPct = ((e.clientX - startX) / tableW) * 100;
      const newWidths = startWidths.slice();
      const minPct = 8;
      const nextIdx = colIdx < newWidths.length - 1 ? colIdx + 1 : colIdx - 1;
      let newCur = Math.max(minPct, startWidths[colIdx] + deltaPct);
      let newNext = Math.max(minPct, startWidths[nextIdx] - deltaPct);
      if (newNext < minPct) {
        newCur = startWidths[colIdx] + (startWidths[nextIdx] - minPct);
        newNext = minPct;
      }
      newWidths[colIdx] = Math.round(newCur * 10) / 10;
      newWidths[nextIdx] = Math.round(newNext * 10) / 10;
      applyDeliveringColWidths(newWidths);
    }

    function onMouseUp() {
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
      if (activeHandle) activeHandle.classList.remove("dragging");
      activeHandle = null;
      if (!isDeliveringSuppliesTab()) return;
      try {
        localStorage.setItem(deliveringColWidthsKey(), JSON.stringify(getDeliveringColWidths()));
      } catch (_) {
        /* ignore */
      }
    }

    table.addEventListener("mousedown", (e) => {
      if (!isDeliveringSuppliesTab()) return;
      const handle = e.target?.closest?.(".col-resize-handle");
      if (!handle || !table.contains(handle)) return;
      e.preventDefault();
      e.stopPropagation();
      const th = handle.parentElement;
      colIdx = parseInt(th.getAttribute("data-col") || "0", 10);
      startX = e.clientX;
      startWidths = getDeliveringColWidths();
      if (!startWidths.length || colIdx < 0 || colIdx >= startWidths.length) return;
      activeHandle = handle;
      document.addEventListener("mousemove", onMouseMove);
      document.addEventListener("mouseup", onMouseUp);
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
      handle.classList.add("dragging");
    });
  }

  const COL_WIDTHS_PREFIX = "ozon_fbs_col_widths_v2";
  const DEFAULT_WIDTHS = [24, 56, 20];
  let colResizerInited = false;

  function colWidthsKey() {
    const email = String(document.querySelector(".sidebar-user-email")?.textContent || "")
      .trim()
      .toLowerCase();
    return email ? `${COL_WIDTHS_PREFIX}:${email}` : COL_WIDTHS_PREFIX;
  }

  function applyColWidths(widths) {
    const cols = Array.from(document.querySelectorAll("#ozonFbsColgroup col")).filter(
      (c) => !c.dataset.fixed
    );
    cols.forEach((col, i) => {
      if (widths[i] !== undefined) col.style.width = `${widths[i]}%`;
    });
  }

  function getColWidths() {
    const cols = Array.from(document.querySelectorAll("#ozonFbsColgroup col")).filter(
      (c) => !c.dataset.fixed
    );
    return cols.map((col, i) => parseFloat(col.style.width) || DEFAULT_WIDTHS[i] || 10);
  }

  function initColumnResizer() {
    const table = document.getElementById("ozonFbsOrdersTable");
    if (!table || isSuppliesTab()) return;

    let widths = DEFAULT_WIDTHS.slice();
    try {
      const saved = JSON.parse(localStorage.getItem(colWidthsKey()) || "null");
      if (Array.isArray(saved) && saved.length === widths.length) widths = saved;
      else if (Array.isArray(saved)) localStorage.removeItem(colWidthsKey());
    } catch (_) {
      /* ignore */
    }
    applyColWidths(widths);

    if (colResizerInited) return;
    colResizerInited = true;

    let startX = 0;
    let colIdx = 0;
    let startWidths = [];
    let activeHandle = null;

    function onMouseMove(e) {
      const tableEl = document.getElementById("ozonFbsOrdersTable");
      if (!tableEl || isSuppliesTab()) return;
      const tableW = tableEl.offsetWidth || 1;
      const deltaPct = ((e.clientX - startX) / tableW) * 100;
      const newWidths = startWidths.slice();
      const minPct = 8;
      const nextIdx = colIdx < newWidths.length - 1 ? colIdx + 1 : colIdx - 1;
      let newCur = Math.max(minPct, startWidths[colIdx] + deltaPct);
      let newNext = Math.max(minPct, startWidths[nextIdx] - deltaPct);
      if (newNext < minPct) {
        newCur = startWidths[colIdx] + (startWidths[nextIdx] - minPct);
        newNext = minPct;
      }
      newWidths[colIdx] = Math.round(newCur * 10) / 10;
      newWidths[nextIdx] = Math.round(newNext * 10) / 10;
      applyColWidths(newWidths);
    }

    function onMouseUp() {
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
      if (activeHandle) activeHandle.classList.remove("dragging");
      activeHandle = null;
      try {
        localStorage.setItem(colWidthsKey(), JSON.stringify(getColWidths()));
      } catch (_) {
        /* ignore */
      }
    }

    table.addEventListener("mousedown", (e) => {
      if (isSuppliesTab()) return;
      const handle = e.target?.closest?.(".col-resize-handle");
      if (!handle) return;
      e.preventDefault();
      e.stopPropagation();
      const th = handle.parentElement;
      colIdx = parseInt(th.getAttribute("data-col") || "0", 10);
      startX = e.clientX;
      startWidths = getColWidths();
      activeHandle = handle;
      document.addEventListener("mousemove", onMouseMove);
      document.addEventListener("mouseup", onMouseUp);
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
      handle.classList.add("dragging");
    });
  }

  /** Generic % column resizer with per-user localStorage (modal tables). */
  function createOzonFbsModalColResizer({
    tableId,
    colgroupId,
    storagePrefix,
    defaultWidths,
  }) {
    let inited = false;
    const defaults = Array.isArray(defaultWidths) ? defaultWidths.slice() : [];

    function storageKey() {
      const email = String(document.querySelector(".sidebar-user-email")?.textContent || "")
        .trim()
        .toLowerCase();
      return email ? `${storagePrefix}:${email}` : storagePrefix;
    }

    function resizableCols() {
      return Array.from(
        document.querySelectorAll(`#${colgroupId} col`)
      ).filter((c) => !c.dataset.fixed);
    }

    function apply(widths) {
      resizableCols().forEach((col, i) => {
        if (widths[i] !== undefined) col.style.width = `${widths[i]}%`;
      });
    }

    function get() {
      return resizableCols().map(
        (col, i) => parseFloat(col.style.width) || defaults[i] || 10
      );
    }

    function restore() {
      let widths = defaults.slice();
      try {
        const saved = JSON.parse(localStorage.getItem(storageKey()) || "null");
        if (Array.isArray(saved) && saved.length === widths.length) widths = saved;
        else if (Array.isArray(saved)) localStorage.removeItem(storageKey());
      } catch (_) {
        /* ignore */
      }
      apply(widths);
    }

    function init() {
      const table = document.getElementById(tableId);
      if (!table) return;
      restore();
      if (inited) return;
      inited = true;

      let startX = 0;
      let colIdx = 0;
      let startWidths = [];
      let activeHandle = null;

      function onMouseMove(e) {
        const tableEl = document.getElementById(tableId);
        if (!tableEl) return;
        const tableW = tableEl.offsetWidth || 1;
        const deltaPct = ((e.clientX - startX) / tableW) * 100;
        const newWidths = startWidths.slice();
        const minPct = 8;
        const nextIdx = colIdx < newWidths.length - 1 ? colIdx + 1 : colIdx - 1;
        let newCur = Math.max(minPct, startWidths[colIdx] + deltaPct);
        let newNext = Math.max(minPct, startWidths[nextIdx] - deltaPct);
        if (newNext < minPct) {
          newCur = startWidths[colIdx] + (startWidths[nextIdx] - minPct);
          newNext = minPct;
        }
        newWidths[colIdx] = Math.round(newCur * 10) / 10;
        newWidths[nextIdx] = Math.round(newNext * 10) / 10;
        apply(newWidths);
      }

      function onMouseUp() {
        document.removeEventListener("mousemove", onMouseMove);
        document.removeEventListener("mouseup", onMouseUp);
        document.body.style.cursor = "";
        document.body.style.userSelect = "";
        if (activeHandle) activeHandle.classList.remove("dragging");
        activeHandle = null;
        try {
          localStorage.setItem(storageKey(), JSON.stringify(get()));
        } catch (_) {
          /* ignore */
        }
      }

      table.addEventListener("mousedown", (e) => {
        const handle = e.target?.closest?.(".col-resize-handle");
        if (!handle || !table.contains(handle)) return;
        e.preventDefault();
        e.stopPropagation();
        const th = handle.parentElement;
        colIdx = parseInt(th.getAttribute("data-col") || "0", 10);
        startX = e.clientX;
        startWidths = get();
        activeHandle = handle;
        document.addEventListener("mousemove", onMouseMove);
        document.addEventListener("mouseup", onMouseUp);
        document.body.style.cursor = "col-resize";
        document.body.style.userSelect = "none";
        handle.classList.add("dragging");
      });
    }

    return { init, restore };
  }

  const ozonFbsSupplyDetailColResizer = createOzonFbsModalColResizer({
    tableId: "ozonFbsSupplyDetailTable",
    colgroupId: "ozonFbsSupplyDetailColgroup",
    storagePrefix: "ozon_fbs_sd_col_widths_v1",
    defaultWidths: [32, 60],
  });
  const ozonFbsKizColResizer = createOzonFbsModalColResizer({
    tableId: "ozonFbsKizTable",
    colgroupId: "ozonFbsKizColgroup",
    storagePrefix: "ozon_fbs_kiz_col_widths_v2",
    defaultWidths: [18, 30, 28, 18],
  });
  const ozonFbsPickColResizer = createOzonFbsModalColResizer({
    tableId: "ozonFbsPickTable",
    colgroupId: "ozonFbsPickColgroup",
    storagePrefix: "ozon_fbs_pick_col_widths_v2",
    defaultWidths: [18, 30, 26, 18],
  });

  /* ── Split multi (without assemble) ── */

  function closeSplitResultModal() {
    document.getElementById("ozonFbsSplitResultModal")?.classList.add("hidden");
    const shouldRefresh = !!splitState.lastOk || Number(splitState.lastSingleAfter || 0) > 0;
    splitState.lastOk = false;
    splitState.lastSingleAfter = 0;
    if (shouldRefresh) {
      // Local refresh of awaiting_packaging only — no full Ozon sync.
      if (state.tab !== "awaiting_packaging") setTab("awaiting_packaging");
      else loadPostings(true);
    }
  }

  function showSplitResult(data) {
    const modal = document.getElementById("ozonFbsSplitResultModal");
    const title = document.getElementById("ozonFbsSplitResultTitle");
    const body = document.getElementById("ozonFbsSplitResultBody");
    if (!modal || !body) {
      alert(data?.message || "Готово");
      return;
    }
    const ok = !!data?.ok;
    const singleAfter = Number(data?.single_after || 0);
    splitState.lastOk = ok && !(data?.errors || []).length;
    splitState.lastSingleAfter = singleAfter;
    if (title) title.textContent = ok ? "Разделение завершено" : "Есть проблемы";
    const details = Array.isArray(data?.details) ? data.details : [];
    const errors = Array.isArray(data?.errors) ? data.errors : [];
    let html = `<p class="${ok ? "wb-fbs-collect-mgt-result-ok" : "wb-fbs-collect-mgt-result-err"}">${esc(data?.message || "")}</p>`;
    html += `<p>Было мультизаказов: ${esc(String(data?.multi_before ?? details.length))} · стало одинарных: ${esc(String(singleAfter))}</p>`;
    if (details.length) {
      html += "<ul>" + details.map((d) => {
        const from = d.posting_number || "";
        const to = Array.isArray(d.posting_numbers) ? d.posting_numbers : [];
        return `<li>${formatOzonPostingNumberHtml(from)} → ${to.map((x) => formatOzonPostingNumberHtml(x)).join(", ")}</li>`;
      }).join("") + "</ul>";
    }
    if (errors.length) {
      html += `<p class="wb-fbs-collect-mgt-result-err">Ошибки:</p><ul class="wb-fbs-collect-mgt-result-err">` +
        errors.map((e) => {
          if (typeof e === "string") return `<li>${esc(e)}</li>`;
          return `<li>${formatOzonPostingNumberHtml(e.posting_number || "")}: ${esc(e.error || "")}</li>`;
        }).join("") + "</ul>";
    }
    body.innerHTML = html;
    modal.classList.remove("hidden");
  }

  async function pollSplitStatus() {
    try {
      const res = await fetch("/api/ozon-fbs/split-multi/status");
      const st = await res.json().catch(() => ({}));
      const running = Boolean(st.in_progress);
      const done = Number(st.done || 0);
      const total = Number(st.total || 0);
      splitState.progressText =
        total > 0 ? `Разделение ${done}/${total}` : (st.message || "Разделение…");
      showSyncInfo(running ? splitState.progressText : String(st.message || ""));
      if (running) {
        splitState.busy = true;
        syncPackagingActionButtons();
        splitState.pollTimer = setTimeout(pollSplitStatus, 1000);
        return;
      }
      clearTimeout(splitState.pollTimer);
      splitState.pollTimer = null;
      splitState.busy = false;
      splitState.progressText = "";
      syncPackagingActionButtons();
      showSplitResult({
        ok: !!st?.ok && !(st?.errors || []).length,
        message: String(st?.message || ""),
        errors: Array.isArray(st?.errors) ? st.errors : [],
        details: Array.isArray(st?.details) ? st.details : [],
        multi_before: Number(st?.multi_before || 0),
        single_after: Number(st?.single_after || 0),
      });
    } catch (_e) {
      splitState.pollTimer = setTimeout(pollSplitStatus, 1500);
    }
  }

  async function splitMulti() {
    if (
      !state.sourceId ||
      state.syncBusy ||
      splitState.busy ||
      collectState.busy ||
      state.shipAllBusy
    ) {
      return;
    }
    if (multiAwaitingCount() <= 0) {
      alert("Нет мультизаказов в «Ожидают сборки»");
      return;
    }
    splitState.busy = true;
    splitState.progressText = "Подготовка…";
    syncPackagingActionButtons();
    showSyncInfo("Запуск разделения мультизаказов…");
    try {
      const res = await fetch("/api/ozon-fbs/split-multi/execute", {
        method: "POST",
        headers: jsonHeaders(),
        body: JSON.stringify({ source_id: Number(state.sourceId) }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || "Не удалось запустить разделение");
      showSyncInfo("Разделение запущено…");
      pollSplitStatus();
    } catch (e) {
      splitState.busy = false;
      splitState.progressText = "";
      syncPackagingActionButtons();
      const err = e.message || String(e);
      showSyncInfo(err, "error");
      alert(err);
    }
  }

  /* ── Packaging exemplar (КИЗ+ГТД before ship, юрлица) ── */

  const packagingExemplarState = {
    postingNumber: "",
    payload: null,
    busy: false,
    gtdManual: false,
    gtdLookupHint: "",
  };

  function _ozonFbsPackagingExemplarModalIsOpen() {
    const modal = document.getElementById("ozonFbsPackagingExemplarModal");
    return !!(modal && !modal.classList.contains("hidden"));
  }

  function closeOzonFbsPackagingExemplarModal() {
    if (packagingExemplarState.busy) return;
    document.getElementById("ozonFbsPackagingExemplarModal")?.classList.add("hidden");
    packagingExemplarState.postingNumber = "";
    packagingExemplarState.payload = null;
    packagingExemplarState.gtdManual = false;
    packagingExemplarState.gtdLookupHint = "";
    void _ozonFbsScanComOnModalClosed();
  }

  function _packagingExemplarSetInfo(text, tone) {
    const el = document.getElementById("ozonFbsPackagingExemplarInfo");
    if (!el) return;
    const msg = String(text || "").trim();
    el.hidden = !msg;
    el.textContent = msg;
    el.classList.toggle("is-ok", tone === "ok");
    el.classList.toggle("is-error", tone === "error");
  }

  function _packagingExemplarRenderBody(data) {
    const body = document.getElementById("ozonFbsPackagingExemplarBody");
    const meta = document.getElementById("ozonFbsPackagingExemplarMeta");
    if (meta) {
      const pn = String(data.posting_number || "");
      const name = String(data.product_name || "");
      meta.innerHTML =
        `<div class="pn">${formatOzonPostingNumberHtml(pn)}</div>`
        + (name ? `<div class="name">${esc(name)}</div>` : "");
    }
    if (!body) return;
    const qty = Math.max(Number(data.quantity || 1) || 1, 1);
    const codes = Array.isArray(data.kiz_codes) ? data.kiz_codes.slice() : [];
    while (codes.length < qty) codes.push("");
    packagingExemplarState.payload = { ...data, kiz_codes: codes };
    const gtd = String(data.gtd_number || "");
    const readonly = packagingExemplarState.gtdManual ? "" : "readonly";
    let kizHtml = "";
    for (let i = 0; i < qty; i += 1) {
      kizHtml += `<div class="ozon-fbs-packaging-exemplar-kiz-row">
        <span class="idx">${i + 1}</span>
        <input type="text" id="ozonFbsPackagingKiz_${i}" autocomplete="off"
               value="${esc(codes[i] || "")}"
               placeholder="Сканируйте КИЗ"
               oninput="onOzonFbsPackagingExemplarKizInput(${i})"
               onkeydown="onOzonFbsPackagingExemplarKizKey(event, ${i})" />
      </div>`;
    }
    const hint = packagingExemplarState.gtdLookupHint
      ? `<p class="ozon-fbs-packaging-exemplar-hint ${packagingExemplarState.gtdLookupHintTone || ""}">${esc(packagingExemplarState.gtdLookupHint)}</p>`
      : `<p class="ozon-fbs-packaging-exemplar-hint">ГТД подставится из базы по короткому КИ после скана. Если не найдена — включите ручной ввод.</p>`;
    body.innerHTML = `
      <div class="ozon-fbs-packaging-exemplar-field">
        <label>КИЗ (${qty})</label>
        <div class="ozon-fbs-packaging-exemplar-kiz-list">${kizHtml}</div>
      </div>
      <div class="ozon-fbs-packaging-exemplar-field">
        <label for="ozonFbsPackagingGtd">ГТД</label>
        <input type="text" id="ozonFbsPackagingGtd" autocomplete="off"
               value="${esc(gtd)}" ${readonly}
               placeholder="Номер ГТД" />
        <label class="ozon-fbs-packaging-exemplar-manual">
          <input type="checkbox" id="ozonFbsPackagingGtdManual"
                 ${packagingExemplarState.gtdManual ? "checked" : ""}
                 onchange="onOzonFbsPackagingExemplarManualGtd(this)" />
          Ввести ГТД вручную
        </label>
        ${hint}
      </div>`;
  }

  async function _packagingExemplarLookupGtd(fromIdx) {
    if (packagingExemplarState.gtdManual) return;
    const input = document.getElementById(`ozonFbsPackagingKiz_${fromIdx}`);
    const raw = String(input?.value || "").trim();
    if (!raw || raw.length < 16) return;
    try {
      const res = await fetch(
        `/api/supply-gtd/lookup?kiz=${encodeURIComponent(raw)}`
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok) return;
      const gtdInput = document.getElementById("ozonFbsPackagingGtd");
      if (data.found && data.item && data.item.gtd_number) {
        const num = String(data.item.gtd_number || "");
        if (gtdInput) gtdInput.value = num;
        if (packagingExemplarState.payload) {
          packagingExemplarState.payload.gtd_number = num;
        }
        packagingExemplarState.gtdLookupHint = `Найдена ГТД ${num}`;
        packagingExemplarState.gtdLookupHintTone = "is-ok";
      } else {
        packagingExemplarState.gtdLookupHint =
          String(data.message || "КИЗ не найден в базе ГТД — включите ручной ввод");
        packagingExemplarState.gtdLookupHintTone = "is-warn";
      }
      const hintEl = document.querySelector(
        "#ozonFbsPackagingExemplarBody .ozon-fbs-packaging-exemplar-hint"
      );
      if (hintEl) {
        hintEl.textContent = packagingExemplarState.gtdLookupHint;
        hintEl.classList.toggle("is-ok", packagingExemplarState.gtdLookupHintTone === "is-ok");
        hintEl.classList.toggle("is-warn", packagingExemplarState.gtdLookupHintTone === "is-warn");
      }
    } catch (_e) {
      /* ignore lookup errors */
    }
  }

  function onOzonFbsPackagingExemplarKizInput(idx) {
    const input = document.getElementById(`ozonFbsPackagingKiz_${idx}`);
    if (!input || !packagingExemplarState.payload) return;
    const codes = Array.isArray(packagingExemplarState.payload.kiz_codes)
      ? packagingExemplarState.payload.kiz_codes
      : [];
    codes[idx] = String(input.value || "");
    packagingExemplarState.payload.kiz_codes = codes;
    // Debounced lookup on longer scans.
    clearTimeout(onOzonFbsPackagingExemplarKizInput._t);
    onOzonFbsPackagingExemplarKizInput._t = setTimeout(() => {
      _packagingExemplarLookupGtd(idx);
    }, 280);
  }

  /** Apply a scanned KIZ into the packaging-exemplar modal (keyboard Enter or COM). */
  function processOzonFbsPackagingExemplarKizScan(raw) {
    if (!_ozonFbsPackagingExemplarModalIsOpen() || !packagingExemplarState.payload) {
      return false;
    }
    const value = String(raw || "").replace(/[\r\n]+$/g, "");
    if (!value.replace(/\s+/g, "")) return false;
    const qty = Math.max(Number(packagingExemplarState.payload.quantity || 1) || 1, 1);
    let targetIdx = -1;
    const active = document.activeElement;
    const activeId = String(active && active.id || "");
    if (activeId.startsWith("ozonFbsPackagingKiz_")) {
      const n = Number(activeId.slice("ozonFbsPackagingKiz_".length));
      if (Number.isFinite(n) && n >= 0 && n < qty) targetIdx = n;
    }
    if (targetIdx < 0) {
      for (let i = 0; i < qty; i += 1) {
        const el = document.getElementById(`ozonFbsPackagingKiz_${i}`);
        if (el && !String(el.value || "").trim()) {
          targetIdx = i;
          break;
        }
      }
    }
    if (targetIdx < 0) targetIdx = 0;
    const input = document.getElementById(`ozonFbsPackagingKiz_${targetIdx}`);
    if (!input) return false;
    input.value = value;
    onOzonFbsPackagingExemplarKizInput(targetIdx);
    for (let i = targetIdx + 1; i < qty; i += 1) {
      const next = document.getElementById(`ozonFbsPackagingKiz_${i}`);
      if (next && !String(next.value || "").trim()) {
        next.focus();
        return true;
      }
    }
    input.focus();
    try { input.select(); } catch (_e) { /* ignore */ }
    return true;
  }

  function onOzonFbsPackagingExemplarKizKey(event, idx) {
    if (!event || event.key !== "Enter") return;
    event.preventDefault();
    const input =
      event.target || document.getElementById(`ozonFbsPackagingKiz_${idx}`);
    processOzonFbsPackagingExemplarKizScan(input && input.value);
  }

  function onOzonFbsPackagingExemplarManualGtd(el) {
    packagingExemplarState.gtdManual = !!(el && el.checked);
    const gtdInput = document.getElementById("ozonFbsPackagingGtd");
    if (gtdInput) {
      if (packagingExemplarState.gtdManual) {
        gtdInput.removeAttribute("readonly");
        gtdInput.focus();
      } else {
        gtdInput.setAttribute("readonly", "readonly");
      }
    }
  }

  async function openOzonFbsPackagingExemplarModal(postingNumber) {
    const pn = String(postingNumber || "").trim();
    if (!pn || !state.sourceId) return;
    const modal = document.getElementById("ozonFbsPackagingExemplarModal");
    if (!modal) return;
    packagingExemplarState.postingNumber = pn;
    packagingExemplarState.gtdManual = false;
    packagingExemplarState.gtdLookupHint = "";
    packagingExemplarState.payload = null;
    _packagingExemplarSetInfo("Загрузка…");
    const body = document.getElementById("ozonFbsPackagingExemplarBody");
    if (body) body.innerHTML = "";
    const meta = document.getElementById("ozonFbsPackagingExemplarMeta");
    if (meta) meta.innerHTML = "";
    modal.classList.remove("hidden");
    const saveBtn = document.getElementById("ozonFbsPackagingExemplarSaveBtn");
    if (saveBtn) saveBtn.disabled = true;
    try {
      const res = await fetch(
        `/api/ozon-fbs/postings/${encodeURIComponent(pn)}/packaging-exemplar`
        + `?source_id=${encodeURIComponent(state.sourceId)}`
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(detailText(data.detail) || "Не удалось открыть маркировку");
      }
      packagingExemplarState.gtdManual = false;
      _packagingExemplarRenderBody(data);
      _packagingExemplarSetInfo("");
      if (saveBtn) saveBtn.disabled = false;
      const first = document.getElementById("ozonFbsPackagingKiz_0");
      if (first) first.focus();
      void _ozonFbsScanComOnModalOpened();
    } catch (e) {
      _packagingExemplarSetInfo(e.message || String(e), "error");
      if (saveBtn) saveBtn.disabled = true;
      void _ozonFbsScanComOnModalOpened();
    }
  }

  async function saveOzonFbsPackagingExemplar() {
    const pn = packagingExemplarState.postingNumber;
    if (!pn || !state.sourceId || packagingExemplarState.busy) return;
    const qty = Math.max(
      Number(packagingExemplarState.payload?.quantity || 1) || 1,
      1
    );
    const codes = [];
    for (let i = 0; i < qty; i += 1) {
      const el = document.getElementById(`ozonFbsPackagingKiz_${i}`);
      const v = String(el?.value || "").trim();
      if (v) codes.push(v);
    }
    if (codes.length < qty) {
      _packagingExemplarSetInfo(`Заполните все поля КИЗ (${qty})`, "error");
      return;
    }
    const gtd = String(
      document.getElementById("ozonFbsPackagingGtd")?.value || ""
    ).trim();
    if (!gtd) {
      _packagingExemplarSetInfo(
        "Укажите ГТД (из базы по КИЗ или вручную)",
        "error"
      );
      return;
    }
    const saveBtn = document.getElementById("ozonFbsPackagingExemplarSaveBtn");
    packagingExemplarState.busy = true;
    if (saveBtn) {
      saveBtn.disabled = true;
      saveBtn.textContent = "Сохранение…";
    }
    _packagingExemplarSetInfo("Передаём в Ozon…");
    try {
      const res = await fetch(
        `/api/ozon-fbs/postings/${encodeURIComponent(pn)}/packaging-exemplar`
        + `?source_id=${encodeURIComponent(state.sourceId)}`,
        {
          method: "PUT",
          headers: jsonHeaders(),
          body: JSON.stringify({ kiz_codes: codes, gtd_number: gtd }),
        }
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(detailText(data.detail) || "Ошибка сохранения");
      }
      _packagingExemplarSetInfo(data.message || "Сохранено", "ok");
      // Update row badge in current list without full reload when possible.
      const row = (state.items || []).find(
        (r) => String(r.posting_number || "") === pn
      );
      if (row) {
        row.pre_ship_exemplar_badge = "ok";
        row.marking_ozon_synced = true;
        row.marking_gtd_number = gtd;
        row.pre_ship_gtd_required = true;
        renderTable(state.items);
      } else {
        await loadPostings(false);
      }
      setTimeout(() => {
        packagingExemplarState.busy = false;
        closeOzonFbsPackagingExemplarModal();
      }, 600);
    } catch (e) {
      _packagingExemplarSetInfo(e.message || String(e), "error");
      packagingExemplarState.busy = false;
    } finally {
      if (saveBtn) {
        saveBtn.disabled = false;
        saveBtn.textContent = "Сохранить";
      }
    }
  }

  /* ── Collect (ship-all + local supplies) ── */

  function closeCollectModal() {
    if (collectState.busy) return;
    document.getElementById("ozonFbsCollectModal")?.classList.add("hidden");
    collectState.preview = null;
    collectState.sourceId = null;
    const err = document.getElementById("ozonFbsCollectErr");
    if (err) {
      err.hidden = true;
      err.textContent = "";
    }
    const title = document.getElementById("ozonFbsCollectTitle");
    if (title) title.textContent = "Собрать все заказы";
    const lead = document.getElementById("ozonFbsCollectLead");
    if (lead) {
      lead.hidden = true;
      lead.textContent = "";
    }
  }

  function closeCollectResultModal() {
    document.getElementById("ozonFbsCollectResultModal")?.classList.add("hidden");
  }

  /** Ozon /v4/posting/fbs/ship common errors → operator text + what to do. */
  const OZON_SHIP_ERROR_HINTS = {
    EXEMPLAR_INFO_NOT_FILLED_COMPLETELY: {
      text: "Ozon требует данные экземпляров перед сборкой: обязательный КИЗ и/или ГТД.",
      action:
        "Если у заказа бейдж «⚠ Маркировка не добавлена» — внесите КИЗ (и ГТД для юрлица), сохраните и повторите «Собрать все». Если маркировка только возможная (не обязательная) — повторите сборку: такие заказы собираются без КИЗ.",
    },
    PRE_SHIP_EXEMPLAR_REQUIRED: {
      text: "Заказ юрлица пропущен: КИЗ/ГТД ещё не переданы в Ozon.",
      action:
        "Откройте бейдж «⚠ Маркировка не добавлена» у отправления, сохраните КИЗ и ГТД, затем соберите снова.",
    },
    EXEMPLAR_INFO_ALREADY_DEFINED: {
      text: "Данные экземпляров по этому заказу уже переданы в Ozon.",
      action: "Повторно вводить КИЗ не нужно. Обновите список (синхронизация) и при необходимости соберите снова.",
    },
    MANDATORY_MARK_REDUNDANT: {
      text: "Для этого товара код маркировки передавать не нужно.",
      action: "Уберите лишний КИЗ у отправления и повторите сборку.",
    },
    GTD_MUST_BE_SPECIFIED_FOR_PRODUCT_COUNTRY: {
      text: "Не указан номер ГТД для товара.",
      action: "В модалке маркировки на сборке укажите ГТД. Если декларации нет в базе — включите ручной ввод.",
    },
    GTD_IS_REQUIRED_ONLY_FOR_LEGAL_CUSTOMER: {
      text: "ГТД для этого заказа передавать не нужно (покупатель не юрлицо).",
      action: "Уберите ГТД у отправления и повторите сборку.",
    },
    POSTING_NOT_FOUND: {
      text: "Отправления нет в кабинете Ozon.",
      action: "Запустите синхронизацию. Если заказ исчез — он отменён или удалён в Ozon.",
    },
    POSTING_ALREADY_CANCELLED: {
      text: "Заказ уже отменён в Ozon.",
      action: "Собирать его не нужно. Обновите список синхронизацией.",
    },
    POSTING_ALREADY_SHIPPED: {
      text: "Заказ уже собран в Ozon.",
      action: "Синхронизируйте раздел — отправление должно появиться в «Ожидают отгрузки».",
    },
    HAS_INCORRECT_STATUS: {
      text: "У заказа неподходящий статус для сборки.",
      action: "Синхронизируйте раздел и соберите только отправления из «Ожидают сборки».",
    },
    HAS_INCORRECT_PRODUCT_QUANTITY: {
      text: "Неверное количество товара или SKU в запросе сборки.",
      action: "Синхронизируйте заказ и повторите сборку. Если ошибка останется — проверьте состав заказа в кабинете Ozon.",
    },
    UNKNOWN_PRODUCT_DEFINED: {
      text: "Указан неверный идентификатор товара (SKU Ozon).",
      action: "Синхронизируйте заказы. Если ошибка повторяется — проверьте карточку товара в кабинете Ozon.",
    },
    UNKNOW_PRODUCT: {
      text: "Указан неверный идентификатор товара (SKU Ozon).",
      action: "Синхронизируйте заказы. Если ошибка повторяется — проверьте карточку товара в кабинете Ozon.",
    },
    SHIP_FBP_POSTINGS_IS_FORBIDDEN: {
      text: "Это отправление FBP — сборка FBS для него не нужна.",
      action: "Пропустите этот заказ. При необходимости обновите список синхронизацией.",
    },
    TRANSITION_IS_NOT_POSSIBLE: {
      text: "Нельзя перевести заказ в следующий статус (неверный порядок статусов).",
      action: "Синхронизируйте раздел и проверьте статус заказа в кабинете Ozon.",
    },
    HAS_INCORRECT_TPL_INTEGRATION_TYPE: {
      text: "Нельзя менять статус: доставка через интегрированную службу (rFBS).",
      action: "С этим заказом работайте по правилам rFBS в кабинете Ozon.",
    },
    SHIP_NOT_AVAILABLE: {
      text: "Сборка недоступна: Ozon ещё не принял данные экземпляров.",
      action: "Проверьте маркировку (КИЗ/ГТД) на сборке, подождите немного и повторите «Собрать все заказы».",
    },
  };

  function extractOzonApiErrorCode(raw) {
    const s = String(raw || "");
    if (!s) return "";
    const fromJson = s.match(/"message"\s*:\s*"([^"]+)"/i);
    if (fromJson) {
      let code = String(fromJson[1] || "").trim().toUpperCase().replace(/\s+/g, "_");
      if (code === "UNKNOWN_PRODUCT" || code === "UNKNOW_PRODUCT") {
        return "UNKNOWN_PRODUCT_DEFINED";
      }
      if (OZON_SHIP_ERROR_HINTS[code]) return code;
      const keys = Object.keys(OZON_SHIP_ERROR_HINTS).sort((a, b) => b.length - a.length);
      for (const k of keys) {
        if (code.includes(k)) return k;
      }
    }
    const upper = s.toUpperCase();
    const keys = Object.keys(OZON_SHIP_ERROR_HINTS).sort((a, b) => b.length - a.length);
    for (const k of keys) {
      if (upper.includes(k)) return k;
    }
    if (/UNKNOWN_PRODUCT|UNKNOW_PRODUCT/.test(upper)) return "UNKNOWN_PRODUCT_DEFINED";
    if (/SHIP_NOT_AVAILABLE|SHIP-NOT-AVAILABLE/.test(upper)) return "SHIP_NOT_AVAILABLE";
    return "";
  }

  function humanizeOzonCollectError(raw) {
    const textRaw = String(raw || "").trim();
    const code = extractOzonApiErrorCode(textRaw);
    const hint = code ? OZON_SHIP_ERROR_HINTS[code] : null;
    if (hint) {
      return { code, text: hint.text, action: hint.action, raw: textRaw };
    }
    const httpMatch = textRaw.match(/^Ozon HTTP\s+(\d+):\s*([\s\S]+)$/i);
    if (httpMatch) {
      let body = String(httpMatch[2] || "").trim();
      try {
        const parsed = JSON.parse(body);
        if (parsed && typeof parsed === "object" && parsed.message != null) {
          body = String(parsed.message);
        }
      } catch (_e) {
        /* keep body */
      }
      return {
        code: "",
        text: `Ошибка Ozon (HTTP ${httpMatch[1]}): ${body}`,
        action:
          "Проверьте статус отправления в кабинете Ozon, синхронизируйте раздел и повторите сборку.",
        raw: textRaw,
      };
    }
    if (/^ozon network error/i.test(textRaw)) {
      return {
        code: "",
        text: "Нет связи с Ozon при сборке.",
        action: "Проверьте интернет и повторите «Собрать все заказы».",
        raw: textRaw,
      };
    }
    return {
      code: "",
      text: textRaw || "Неизвестная ошибка",
      action: textRaw ? "" : "Повторите сборку или обратитесь в поддержку.",
      raw: textRaw,
    };
  }

  function formatCollectErrorItemHtml(err) {
    let posting = "";
    let raw = "";
    let forcedCode = "";
    if (typeof err === "string") {
      raw = err;
      const m = err.match(/^(\S+):\s*([\s\S]+)$/);
      if (m && /[-\d]/.test(m[1]) && /ozon|exemplar|posting|http|ошиб|пропущ/i.test(m[2])) {
        posting = m[1];
        raw = m[2];
      }
    } else if (err && typeof err === "object") {
      posting = String(err.posting_number || "").trim();
      raw = String(err.error || err.message || "").trim();
      forcedCode = String(err.code || "").trim().toUpperCase();
    }
    const h = forcedCode && OZON_SHIP_ERROR_HINTS[forcedCode]
      ? {
          code: forcedCode,
          text: OZON_SHIP_ERROR_HINTS[forcedCode].text,
          action: OZON_SHIP_ERROR_HINTS[forcedCode].action,
          raw,
        }
      : humanizeOzonCollectError(raw);
    const pnHtml = posting && posting !== "—" && posting !== "?"
      ? `${formatOzonPostingNumberHtml(posting)}: `
      : "";
    const tip = h.raw && h.raw !== h.text ? ` title="${esc(h.raw)}"` : "";
    let html = `<li class="ozon-fbs-collect-err-item"${tip}>`;
    html += `<div class="ozon-fbs-collect-err-main">${pnHtml}${esc(h.text)}</div>`;
    if (h.action) {
      html += `<div class="ozon-fbs-collect-err-action">Что сделать: ${esc(h.action)}</div>`;
    }
    html += "</li>";
    return html;
  }

  function showCollectResult(data) {
    const modal = document.getElementById("ozonFbsCollectResultModal");
    const title = document.getElementById("ozonFbsCollectResultTitle");
    const body = document.getElementById("ozonFbsCollectResultBody");
    if (!modal || !body) {
      alert(data?.message || "Готово");
      return;
    }
    const ok = !!data?.ok;
    if (title) title.textContent = ok ? "Готово" : "Есть проблемы";
    const errors = Array.isArray(data?.errors) ? data.errors : [];
    const groupLines = Array.isArray(data?.group_lines) ? data.group_lines : [];
    const created = Array.isArray(data?.created_supplies) ? data.created_supplies : [];
    let html = `<p class="${ok ? "ozon-fbs-collect-result-ok" : "ozon-fbs-collect-result-err"}">${esc(data?.message || "")}</p>`;
    if (groupLines.length) {
      html += "<ul>" + groupLines.map((g) => `<li>${esc(g)}</li>`).join("") + "</ul>";
    }
    if (created.length) {
      html += `<p class="ozon-fbs-collect-result-section-title">Созданы поставки:</p><ul>` +
        created.map((s) => `<li>${esc(s.name || s.supply_id || "")}</li>`).join("") + "</ul>";
    }
    if (errors.length) {
      html += `<p class="ozon-fbs-collect-result-err ozon-fbs-collect-result-section-title">Ошибки:</p>` +
        `<ul class="ozon-fbs-collect-err-list">` +
        errors.map((e) => formatCollectErrorItemHtml(e)).join("") + "</ul>";
    }
    body.innerHTML = html;
    body.classList.add("ozon-fbs-collect-result-body");
    modal.classList.remove("hidden");
  }

  function shipSplitPreviewNote(preview) {
    // Collect no longer splits on ship — multi must be split beforehand.
    const multi = Number(preview?.multi_posting_count || 0);
    if (multi <= 0 && !preview?.block_collect) return "";
    if (multi > 0 || preview?.block_collect) {
      return `Есть мультизаказы (${multi || "—"}) — сначала нажмите «Разделить мультизаказы».`;
    }
    return "";
  }

  function renderCollectModal(preview) {
    const body = document.getElementById("ozonFbsCollectBody");
    const lead = document.getElementById("ozonFbsCollectLead");
    const title = document.getElementById("ozonFbsCollectTitle");
    const err = document.getElementById("ozonFbsCollectErr");
    if (err) {
      err.hidden = true;
      err.textContent = "";
    }
    const groups = Array.isArray(preview?.groups) ? preview.groups : [];
    const existing = new Set(
      (Array.isArray(preview?.existing_names) ? preview.existing_names : [])
        .map((x) => String(x || "").trim()).filter(Boolean)
    );
    const postingCount = Number(preview?.posting_count || preview?.mgt_count || 0);
    if (title) {
      title.textContent = postingCount > 0
        ? `Собрать все заказы: ${postingCount} шт.`
        : "Собрать все заказы";
    }
    // Count lives in the title. Keep lead only for multi-posting split note.
    const splitNote = shipSplitPreviewNote(preview);
    if (lead) {
      if (splitNote) {
        lead.hidden = false;
        lead.textContent = splitNote;
      } else {
        lead.hidden = true;
        lead.textContent = "";
      }
    }
    if (!body) return;
    if (!groups.length) {
      body.innerHTML = `<div class="ozon-fbs-collect-empty">Нет заказов для сборки.</div>`;
      return;
    }
    const showGroupHead = groups.length > 1;
    body.innerHTML = groups.map((g, idx) => {
      const gkey = String(g.group_key || `g${idx}`);
      const mode = String(g.mode || "create");
      const label = String(g.label || "Склад");
      const count = Number(g.order_count || 0);
      let inner = "";
      if (mode === "create") {
        const name = String(g.suggested_name || "");
        const conflict = existing.has(name.trim());
        inner = `
          <div class="ozon-fbs-collect-field">
            <label for="ozonFbsCollectName_${esc(gkey)}">Название новой поставки</label>
            <input type="text" id="ozonFbsCollectName_${esc(gkey)}" data-group-key="${esc(gkey)}"
                   value="${esc(name)}" autocomplete="off"
                   oninput="ozonFbsCollectNameInput(this)" />
            <p class="ozon-fbs-collect-warn" id="ozonFbsCollectWarn_${esc(gkey)}" ${conflict ? "" : "hidden"}>
              Поставка с таким названием уже есть — измените название.
            </p>
          </div>`;
      } else if (mode === "choose") {
        const supplies = Array.isArray(g.compatible_supplies) ? g.compatible_supplies : [];
        const suggested = String(g.suggested_name || "");
        const conflict = existing.has(suggested.trim());
        inner = `
          <div class="ozon-fbs-collect-field">
            <div class="ozon-fbs-collect-field-label">Куда собрать заказы</div>
            <div class="ozon-fbs-collect-supplies" role="radiogroup" aria-label="Куда собрать заказы">
              ${supplies.map((s, si) => {
                const sid = String(s.supply_id || "");
                const sname = String(s.name || sid);
                const meta = [
                  s.is_empty ? "пустая" : "открытая",
                  `${Number(s.orders_count || 0)} отпр.`,
                ].filter(Boolean).join(" · ");
                return `
                  <label class="ozon-fbs-collect-supply">
                    <span class="ozon-fbs-collect-supply-main">
                      <input type="radio" name="ozonFbsCollectSupply_${esc(gkey)}" value="${esc(sid)}"
                             ${si === 0 ? "checked" : ""}
                             onchange="ozonFbsCollectTargetChanged('${esc(gkey)}')" />
                      <span class="ozon-fbs-collect-supply-name">${esc(sname)}</span>
                    </span>
                    <span class="ozon-fbs-collect-supply-meta">${esc(meta)}</span>
                  </label>`;
              }).join("")}
              <label class="ozon-fbs-collect-supply">
                <span class="ozon-fbs-collect-supply-main">
                  <input type="radio" name="ozonFbsCollectSupply_${esc(gkey)}" value="__new__"
                         ${supplies.length ? "" : "checked"}
                         onchange="ozonFbsCollectTargetChanged('${esc(gkey)}')" />
                  <span class="ozon-fbs-collect-supply-name">Создать новую поставку</span>
                </span>
                <span class="ozon-fbs-collect-supply-meta">отдельная поставка для этих заказов</span>
              </label>
            </div>
          </div>
          <div class="ozon-fbs-collect-field ozon-fbs-collect-new-name" id="ozonFbsCollectNewWrap_${esc(gkey)}"
               ${supplies.length ? "hidden" : ""}>
            <label for="ozonFbsCollectName_${esc(gkey)}">Название новой поставки</label>
            <input type="text" id="ozonFbsCollectName_${esc(gkey)}" data-group-key="${esc(gkey)}"
                   value="${esc(suggested)}" autocomplete="off"
                   oninput="ozonFbsCollectNameInput(this)" />
            <p class="ozon-fbs-collect-warn" id="ozonFbsCollectWarn_${esc(gkey)}" ${conflict ? "" : "hidden"}>
              Поставка с таким названием уже есть — измените название.
            </p>
          </div>`;
      } else {
        // Legacy add_one (should not appear after preview always uses choose/create).
        const sid = String(g.default_supply_id || "");
        const match = (Array.isArray(g.compatible_supplies) ? g.compatible_supplies : [])
          .find((s) => String(s.supply_id || "") === sid);
        const sname = match ? String(match.name || sid) : sid;
        inner = `<div class="ozon-fbs-collect-auto">Будет добавлено в поставку «${esc(sname)}».</div>`;
      }
      const head = showGroupHead
        ? `<div class="ozon-fbs-collect-group-head">
            <h4 class="ozon-fbs-collect-group-title">${esc(label)}</h4>
            <p class="ozon-fbs-collect-group-meta">${esc(`${count} отпр.`)}</p>
          </div>`
        : "";
      return `
        <section class="ozon-fbs-collect-group" data-group-key="${esc(gkey)}" data-mode="${esc(mode)}" data-label="${esc(label)}">
          ${head}
          ${inner}
        </section>`;
    }).join("");
  }


  function collectTargetChanged(gkey) {
    const key = String(gkey || "");
    const wrap = document.getElementById(`ozonFbsCollectNewWrap_${key}`);
    if (!wrap) return;
    const checked = document.querySelector(`input[name="ozonFbsCollectSupply_${key}"]:checked`);
    const isNew = String(checked?.value || "") === "__new__";
    wrap.hidden = !isNew;
    if (isNew) {
      const input = document.getElementById(`ozonFbsCollectName_${key}`);
      if (input) {
        try { input.focus(); } catch (_e) {}
      }
    }
  }

  function collectNameInput(input) {
    if (!input) return;
    const preview = collectState.preview;
    const existing = new Set(
      (Array.isArray(preview?.existing_names) ? preview.existing_names : [])
        .map((x) => String(x || "").trim()).filter(Boolean)
    );
    const gkey = String(input.dataset.groupKey || input.id.replace(/^ozonFbsCollectName_/, ""));
    const warn = document.getElementById(`ozonFbsCollectWarn_${gkey}`);
    if (!warn) return;
    const name = String(input.value || "").trim();
    warn.hidden = !(name && existing.has(name));
  }

  function collectDecisions() {
    const preview = collectState.preview;
    const groups = Array.isArray(preview?.groups) ? preview.groups : [];
    const decisions = [];
    const errors = [];
    const existing = new Set(
      (Array.isArray(preview?.existing_names) ? preview.existing_names : [])
        .map((x) => String(x || "").trim()).filter(Boolean)
    );
    const usedNames = new Set();
    for (const g of groups) {
      const gkey = String(g.group_key || "");
      const mode = String(g.mode || "create");
      const label = g.label || "Склад";
      if (mode === "create") {
        const input = document.getElementById(`ozonFbsCollectName_${gkey}`);
        const name = String(input?.value || g.suggested_name || "").trim();
        if (!name) {
          errors.push(`${label}: укажите название поставки`);
          continue;
        }
        if (existing.has(name) || usedNames.has(name)) {
          errors.push(`${label}: поставка «${name}» уже есть — измените название`);
          continue;
        }
        usedNames.add(name);
        decisions.push({ group_key: gkey, action: "create", name });
      } else if (mode === "choose") {
        const checked = document.querySelector(`input[name="ozonFbsCollectSupply_${gkey}"]:checked`);
        const supplyId = String(checked?.value || "").trim();
        if (!supplyId) {
          errors.push(`${label}: выберите поставку`);
          continue;
        }
        if (supplyId === "__new__") {
          const input = document.getElementById(`ozonFbsCollectName_${gkey}`);
          const name = String(input?.value || g.suggested_name || "").trim();
          if (!name) {
            errors.push(`${label}: укажите название новой поставки`);
            continue;
          }
          if (existing.has(name) || usedNames.has(name)) {
            errors.push(`${label}: поставка «${name}» уже есть — измените название`);
            continue;
          }
          usedNames.add(name);
          decisions.push({ group_key: gkey, action: "create", name });
        } else {
          decisions.push({ group_key: gkey, action: "add", supply_id: supplyId });
        }
      } else {
        decisions.push({
          group_key: gkey,
          action: "add",
          supply_id: String(g.default_supply_id || ""),
        });
      }
    }
    return { decisions, errors };
  }

  async function executeCollect(decisions, sourceId) {
    const sid = Number(sourceId || collectState.sourceId || state.sourceId || 0);
    if (!sid) throw new Error("Выберите источник");
    const res = await fetch("/api/ozon-fbs/ship-all/execute", {
      method: "POST",
      headers: jsonHeaders(),
      body: JSON.stringify({ source_id: sid, decisions }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(detailText(data.detail) || "Ошибка сборки");
    return data;
  }

  function _collectResultFromStatus(st) {
    return {
      ok: !!st?.ok && !(st?.errors || []).length,
      message: String(st?.message || ""),
      errors: Array.isArray(st?.errors) ? st.errors : [],
      group_lines: Array.isArray(st?.group_lines) ? st.group_lines : [],
      created_supplies: Array.isArray(st?.created_supplies) ? st.created_supplies : [],
      shipped: Number(st?.shipped || 0),
      failed: Number(st?.failed || 0),
      total: Number(st?.total || 0),
      goto_awaiting_deliver: !!st?.goto_awaiting_deliver,
    };
  }

  async function pollCollectStatus() {
    try {
      const res = await fetch("/api/ozon-fbs/ship-all/status");
      const st = await res.json().catch(() => ({}));
      const running = Boolean(st.in_progress);
      const done = Number(st.done || 0);
      const total = Number(st.total || 0);
      const msg = String(st.message || "");
      const progress =
        total > 0 ? `Сборка… ${done} из ${total}` : (msg || "Сборка…");
      showSyncInfo(running ? progress : msg);
      const btn = document.getElementById("ozonFbsShipAllBtn");
      if (btn && running) btn.textContent = total > 0 ? `Сборка ${done}/${total}` : "Сборка…";
      if (running) {
        collectState.busy = true;
        state.shipAllBusy = true;
        syncShipAllButton();
        collectState.pollTimer = setTimeout(pollCollectStatus, 1000);
        return;
      }
      clearTimeout(collectState.pollTimer);
      collectState.pollTimer = null;
      collectState.busy = false;
      state.shipAllBusy = false;
      syncShipAllButton();
      if (btn) btn.textContent = "Собрать все заказы";
      const data = _collectResultFromStatus(st);
      closeCollectModal();
      showCollectResult(data);
      if (data.goto_awaiting_deliver) setTab("awaiting_deliver");
      else await loadPostings(true);
    } catch (_e) {
      collectState.pollTimer = setTimeout(pollCollectStatus, 1500);
    }
  }

  async function shipAll() {
    if (
      !state.sourceId ||
      state.syncBusy ||
      state.shipAllBusy ||
      collectState.busy ||
      splitState.busy
    ) {
      return;
    }
    if (multiAwaitingCount() > 0) {
      alert("Сначала нужно разделить мультизаказы");
      return;
    }
    const n = Number(state.counts.awaiting_packaging || 0);
    if (n <= 0) {
      alert("Нет отправлений в «Ожидают сборки»");
      return;
    }
    const btn = document.getElementById("ozonFbsShipAllBtn");
    const confirmBtn = document.getElementById("ozonFbsCollectConfirmBtn");
    collectState.busy = true;
    state.shipAllBusy = true;
    collectState.sourceId = state.sourceId;
    syncShipAllButton();
    if (btn) btn.textContent = "Подготовка…";
    try {
      const res = await fetch(`/api/ozon-fbs/ship-all/preview?source_id=${encodeURIComponent(state.sourceId)}`);
      const preview = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(preview.detail) || "Не удалось подготовить сборку");
      if (preview.block_collect || preview.ok === false) {
        const msg = preview.message || "Сначала нужно разделить мультизаказы";
        alert(msg);
        await loadPostings(false);
        return;
      }
      if (!(preview.posting_count || preview.mgt_count)) {
        alert("Нет отправлений в «Ожидают сборки»");
        await loadPostings(false);
        return;
      }
      collectState.preview = preview;
      if (!preview.needs_modal) {
        if (btn) btn.textContent = "Сборка…";
        showSyncInfo("Запуск сборки…");
        const decisions = (preview.groups || []).map((g) => ({
          group_key: String(g.group_key || ""),
          action: "add",
          supply_id: String(g.default_supply_id || ""),
        }));
        await executeCollect(decisions, state.sourceId);
        showSyncInfo("Сборка запущена…");
        pollCollectStatus();
        return;
      }
      renderCollectModal(preview);
      document.getElementById("ozonFbsCollectModal")?.classList.remove("hidden");
      if (confirmBtn) confirmBtn.disabled = false;
      collectState.busy = false;
      state.shipAllBusy = false;
      if (btn) btn.textContent = "Собрать все заказы";
      syncShipAllButton();
    } catch (e) {
      collectState.sourceId = null;
      const err = e.message || String(e);
      showSyncInfo(err);
      alert(err);
      collectState.busy = false;
      state.shipAllBusy = false;
      if (btn) btn.textContent = "Собрать все заказы";
      syncShipAllButton();
    }
  }

  async function confirmCollect() {
    if (collectState.busy) return;
    if (!collectState.preview) return;
    const errEl = document.getElementById("ozonFbsCollectErr");
    const confirmBtn = document.getElementById("ozonFbsCollectConfirmBtn");
    const sourceId = collectState.sourceId || state.sourceId;
    const { decisions, errors } = collectDecisions();
    if (errors.length) {
      if (errEl) {
        errEl.hidden = false;
        errEl.textContent = errors.join("\n");
      }
      return;
    }
    collectState.busy = true;
    state.shipAllBusy = true;
    if (confirmBtn) confirmBtn.disabled = true;
    syncShipAllButton();
    showSyncInfo("Запуск сборки…");
    try {
      await executeCollect(decisions, sourceId);
      document.getElementById("ozonFbsCollectModal")?.classList.add("hidden");
      showSyncInfo("Сборка запущена…");
      pollCollectStatus();
    } catch (e) {
      const msg = e.message || String(e);
      if (errEl) {
        errEl.hidden = false;
        errEl.textContent = msg;
      } else {
        alert(msg);
      }
      collectState.busy = false;
      state.shipAllBusy = false;
      if (confirmBtn) confirmBtn.disabled = false;
      syncShipAllButton();
    }
  }

  /* ── Supply detail modal ── */

  function _ozonFbsClearRuLayoutGuard() {
    // Document-level key swallow — must clear even if marking UI was bypassed.
    try {
      if (typeof _wbFbsKizRuLayoutSwallowKeys === "function") {
        document.removeEventListener("keydown", _wbFbsKizRuLayoutSwallowKeys, true);
      }
    } catch (_e) {
      /* ignore */
    }
    if (typeof setModalVisibility === "function") {
      setModalVisibility("wbFbsKizRuLayoutModal", false);
    } else {
      document.getElementById("wbFbsKizRuLayoutModal")?.classList.add("hidden");
    }
    if (typeof wbFbsKizState === "object" && wbFbsKizState) {
      wbFbsKizState.ruLayoutFocusId = null;
      wbFbsKizState.ruLayoutPreserveValue = false;
      wbFbsKizState.ruLayoutOpenedAt = 0;
    }
  }

  function _ozonFbsPickModalIsOpen() {
    const modal = document.getElementById("ozonFbsPickVerifyModal");
    return !!(modal && !modal.classList.contains("hidden"));
  }

  function _ozonFbsSupplyDetailHideNewWarn() {
    const el = document.getElementById("ozonFbsSupplyDetailNewWarn");
    if (el) el.hidden = true;
  }

  function _ozonFbsSupplyDetailUpdateNewWarn() {
    const el = document.getElementById("ozonFbsSupplyDetailNewWarn");
    if (!el) return;
    // Only when opening a local supply from «Ожидают отгрузки» (parity with WB «На сборке»).
    const postingTab = String(supplyDetailState.postingTab || "").trim();
    if (postingTab !== "awaiting_deliver" && state.tab !== "awaiting_deliver") {
      el.hidden = true;
      return;
    }
    const counts = state.counts || {};
    const packagingCount = Number(counts.awaiting_packaging || 0);
    // Opening a supply already means collect started; warn if packaging still has leftovers.
    // Do not require awaiting_deliver>0 — local supplies can exist while that tab count is 0.
    el.hidden = packagingCount <= 0;
  }

  function closeSupplyDetailModal() {
    // Nested marking first (async autosave) — same pattern as WB supply close.
    // Closing supply alone used to leave RU-layout swallow active → wedge "dead".
    if (typeof _ozonFbsKizModalIsOpen === "function" && _ozonFbsKizModalIsOpen()) {
      return Promise.resolve(closeOzonFbsKizModal()).then(() => closeSupplyDetailModal());
    }
    if (_ozonFbsPickModalIsOpen()) {
      closeOzonFbsPickVerifyModal();
    }
    _ozonFbsClearRuLayoutGuard();
    closeOzonFbsRowMenus();
    _ozonFbsCloseMovedToDeliveringHistory();
    document.getElementById("ozonFbsSupplyDetailModal")?.classList.add("hidden");
    syncSupplyDetailReadOnlyMode(false);
    closeStickersMenu();
    closeNewStickersMenu();
    _ozonFbsSupplyDetailHideNewWarn();
    _ozonFbsRenderMovedToDelivering(null);
    supplyDetailState.supplyId = null;
    supplyDetailState.sourceId = null;
    supplyDetailState.supply = null;
    supplyDetailState.selected = new Set();
    supplyDetailState.postingTab = null;
    _ozonFbsSupplyDetailSetActionsReady(false);
    _ozonFbsSyncDriverBtn();
    updateSupplyDetailBottomBar();
  }

  function supplyDetailReady() {
    return Boolean(supplyDetailState.supplyId && supplyDetailState.sourceId);
  }

  /**
   * Disable supply-detail action buttons until orders are loaded.
   * Uses aria-disabled (not native disabled) so the hover tooltip still works.
   */
  function _ozonFbsSupplyDetailSetActionsReady(ready) {
    supplyDetailState.ordersReady = !!ready;
    const tip = "Дождитесь загрузки заказов";
    _OZON_FBS_DETAIL_ACTION_IDS.forEach((id) => {
      const el = document.getElementById(id);
      if (!el) return;
      if (!ready) {
        if (el.dataset.waitTitleSaved === undefined) {
          el.dataset.waitTitleSaved = el.getAttribute("title") || "";
        }
        el.setAttribute("aria-disabled", "true");
        el.classList.add("is-wait-orders");
        el.setAttribute("title", tip);
        el.tabIndex = -1;
      } else {
        el.removeAttribute("aria-disabled");
        el.classList.remove("is-wait-orders");
        el.removeAttribute("tabindex");
        const saved = el.dataset.waitTitleSaved;
        if (saved !== undefined) {
          if (saved) el.setAttribute("title", saved);
          else el.removeAttribute("title");
          delete el.dataset.waitTitleSaved;
        }
      }
    });
    if (!ready) {
      closeStickersMenu();
      closeNewStickersMenu();
    }
    _ozonFbsSyncPickVerifyBtn(supplyDetailState.supply?.orders || []);
    // Delivering: managers see KIZ/pick as tones; tenant owner may open modals.
    _ozonFbsSyncSupplyDetailToneOnlySplits(_ozonFbsKizPickLockedAsToneOnly());
    _ozonFbsSyncMoveDeliveringEnabled();
  }

  function supplyDetailSelectedCountLabel(n) {
    const abs = Math.abs(Number(n) || 0) % 100;
    const last = abs % 10;
    let word = "отправлений";
    if (!(abs > 10 && abs < 20)) {
      if (last === 1) word = "отправление";
      else if (last >= 2 && last <= 4) word = "отправления";
    }
    return `Выбрано ${n} ${word}`;
  }

  function supplyDetailSelectedPostingNumbers() {
    if (isSupplyDetailReadOnly()) return [];
    return [...supplyDetailState.selected]
      .map((x) => String(x || "").trim())
      .filter(Boolean);
  }

  function updateSupplyDetailBottomBar() {
    const bar = document.getElementById("ozonFbsSupplyDetailBottomBar");
    const label = document.getElementById("ozonFbsSupplyDetailSelectedLabel");
    const modal = document.getElementById("ozonFbsSupplyDetailModal");
    const card = modal?.querySelector(".wb-fbs-supply-detail-modal");
    const n = isSupplyDetailReadOnly() ? 0 : supplyDetailState.selected.size;
    const show = n > 0 && !isSupplyDetailReadOnly();
    if (label) label.textContent = supplyDetailSelectedCountLabel(n);
    if (bar) bar.classList.toggle("hidden", !show);
    if (card) card.classList.toggle("has-sd-selection", show);
  }

  function clearSupplyDetailSelection() {
    supplyDetailState.selected = new Set();
    document.querySelectorAll("#ozonFbsSupplyDetailTbody .wb-fbs-sd-cb").forEach((cb) => {
      cb.checked = false;
    });
    syncSupplyDetailSelectAll();
    updateSupplyDetailBottomBar();
  }

  function onSupplyDetailCheckboxChange() {
    document.querySelectorAll("#ozonFbsSupplyDetailTbody .wb-fbs-sd-cb").forEach((cb) => {
      const pn = String(cb.dataset.posting || "").trim();
      if (!pn) return;
      if (cb.checked) supplyDetailState.selected.add(pn);
      else supplyDetailState.selected.delete(pn);
    });
    syncSupplyDetailSelectAll();
    updateSupplyDetailBottomBar();
  }

  function syncSupplyDetailSelectAll() {
    const selAll = document.getElementById("ozonFbsSupplyDetailSelectAll");
    if (!selAll) return;
    const ids = Array.from(
      document.querySelectorAll("#ozonFbsSupplyDetailTbody .wb-fbs-sd-cb")
    ).map((cb) => String(cb.dataset.posting || "").trim()).filter(Boolean);
    const allOn = ids.length > 0 && ids.every((id) => supplyDetailState.selected.has(id));
    const someOn = ids.some((id) => supplyDetailState.selected.has(id));
    selAll.checked = allOn;
    selAll.indeterminate = !allOn && someOn;
  }

  function toggleSelectAllSupplyDetail(checked) {
    document.querySelectorAll("#ozonFbsSupplyDetailTbody .wb-fbs-sd-cb").forEach((cb) => {
      cb.checked = !!checked;
      const pn = String(cb.dataset.posting || "").trim();
      if (!pn) return;
      if (checked) supplyDetailState.selected.add(pn);
      else supplyDetailState.selected.delete(pn);
    });
    const selAll = document.getElementById("ozonFbsSupplyDetailSelectAll");
    if (selAll) selAll.indeterminate = false;
    updateSupplyDetailBottomBar();
  }

  function _ozonFbsPostingMenuKey(postingNumber) {
    const pn = String(postingNumber || "").trim();
    if (!pn) return "x";
    return pn.replace(/[^a-zA-Z0-9_-]/g, "_");
  }

  function _ozonFbsRestoreRowMenu(menu) {
    if (!menu) return;
    menu.classList.remove("open");
    menu.style.top = "";
    menu.style.left = "";
    const wrapId = menu.dataset.wrapId;
    const wrap = wrapId ? document.getElementById(wrapId) : null;
    if (wrap) {
      wrap.querySelectorAll(`#${CSS.escape(menu.id)}`).forEach((el) => {
        if (el !== menu) el.remove();
      });
      if (menu.parentElement !== wrap) wrap.appendChild(menu);
    }
  }

  /** Drop ported row menus before table re-render (prevents duplicate ⋮ menus). */
  function _ozonFbsPrepareRowMenuRender() {
    closeOzonFbsRowMenus();
    document.querySelectorAll(".wb-fbs-row-menu[data-ported='1']").forEach((menu) => {
      menu.dataset.ported = "";
      menu.classList.remove("open");
      menu.remove();
    });
  }

  function closeOzonFbsRowMenus(exceptKey = null) {
    document.querySelectorAll(
      ".wb-fbs-row-menu.open[id^='ozonFbsRowMenu_'], "
      + ".wb-fbs-row-menu[data-ported='1'][id^='ozonFbsRowMenu_']"
    ).forEach((menu) => {
      const key = String(menu.id || "").replace(/^ozonFbsRowMenu_/, "");
      if (exceptKey != null && key === String(exceptKey) && menu.classList.contains("open")) {
        return;
      }
      menu.dataset.ported = "";
      _ozonFbsRestoreRowMenu(menu);
    });
  }

  function _ozonFbsPositionRowMenu(menu, anchorEl) {
    const rect = anchorEl.getBoundingClientRect();
    const menuW = Math.max(menu.offsetWidth || 220, 220);
    const menuH = menu.offsetHeight || 96;
    let left = rect.right - menuW;
    if (left < 8) left = 8;
    if (left + menuW > window.innerWidth - 8) left = Math.max(8, window.innerWidth - menuW - 8);
    let top = rect.bottom + 4;
    if (top + menuH > window.innerHeight - 8) {
      top = Math.max(8, rect.top - menuH - 4);
    }
    menu.style.top = `${Math.round(top)}px`;
    menu.style.left = `${Math.round(left)}px`;
  }

  function toggleOzonFbsRowMenu(event, menuKey) {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    const key = String(menuKey || "").trim();
    const btn = event?.currentTarget || event?.target?.closest?.(".wb-fbs-row-menu-btn");
    const menu = document.getElementById(`ozonFbsRowMenu_${key}`);
    if (!menu || !btn) return;
    _ozonFbsSyncRowMenuContent(menu);
    const willOpen = !menu.classList.contains("open");
    closeOzonFbsRowMenus(willOpen ? key : null);
    if (!willOpen) {
      menu.dataset.ported = "";
      _ozonFbsRestoreRowMenu(menu);
      return;
    }
    const wrap = menu.closest(".wb-fbs-row-menu-wrap") || menu.parentElement;
    if (wrap) {
      if (!wrap.id) wrap.id = `ozonFbsRowMenuWrap_${key}`;
      menu.dataset.wrapId = wrap.id;
    }
    document.body.appendChild(menu);
    menu.dataset.ported = "1";
    menu.classList.add("open");
    _ozonFbsPositionRowMenu(menu, btn);
    requestAnimationFrame(() => _ozonFbsPositionRowMenu(menu, btn));
  }

  async function openPrintPdf(url, popupBlockedMsg) {
    // Open in the same user gesture — window.open after await is often blocked.
    const printWin = window.open("about:blank", "_blank");
    if (!printWin) {
      throw new Error(popupBlockedMsg || "Разрешите всплывающие окна");
    }
    try {
      const res = await fetch(url, { credentials: "same-origin" });
      if (!res.ok) {
        let detail = "";
        try {
          const data = await res.json();
          detail = detailText(data.detail);
        } catch (_) {
          detail = await res.text().catch(() => "");
        }
        throw new Error(detail || `Ошибка печати (${res.status})`);
      }
      const blob = await res.blob();
      const blobUrl = URL.createObjectURL(blob);
      try {
        printWin.location.href = blobUrl;
      } catch (_e) {
        printWin.location = blobUrl;
      }
      setTimeout(() => URL.revokeObjectURL(blobUrl), 120000);
    } catch (e) {
      const err = String(e.message || e);
      try {
        if (printWin && !printWin.closed) {
          printWin.document.open();
          printWin.document.write(`<!doctype html><html lang="ru"><head><meta charset="utf-8"/>
<title>Ошибка печати</title></head><body style="font-family:system-ui;padding:32px">
<h1>Не удалось подготовить стикер</h1>
<p>${err.replace(/[<>&]/g, (c) => ({"<":"&lt;",">":"&gt;","&":"&amp;"}[c]))}</p>
</body></html>`);
          printWin.document.close();
        }
      } catch (_e) { /* ignore */ }
      throw e;
    }
  }

  function _ozonFbsLookupSupplyIdForPosting(postingNumber) {
    const pn = String(postingNumber || "").trim();
    if (!pn) return "";
    if (
      state.lookupMode
      && state.lookupMeta
      && String(state.lookupMeta.posting_number || "").trim() === pn
    ) {
      const fromMeta = String(state.lookupMeta.supply_id || "").trim();
      if (fromMeta) return fromMeta;
    }
    const row = (state.items || []).find(
      (x) => String(x?.posting_number || "").trim() === pn
    );
    return String(row?.supply_id || "").trim();
  }

  async function ozonFbsRemoveCancelledPostingFromSupply(event, postingNumber) {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    closeOzonFbsRowMenus();
    const pn = String(postingNumber || "").trim();
    const supplyId = String(supplyDetailState.supplyId || "").trim();
    const sourceId = Number(supplyDetailState.sourceId || state.sourceId || 0) || 0;
    if (!pn || !supplyId || !sourceId) {
      alert("Не удалось определить отправление или поставку");
      return;
    }
    if (
      !window.confirm(
        "Удалить отправление " +
          pn +
          " из поставки?\n\nТовар исчезнет из списков КИЗ / без КИЗ. При переводе в «Доставляются» склад списан не будет."
      )
    ) {
      return;
    }
    try {
      const resp = await fetch(
        "/api/ozon-fbs/supplies/" +
          encodeURIComponent(supplyId) +
          "/postings/" +
          encodeURIComponent(pn) +
          "/remove-cancelled",
        {
          method: "POST",
          headers: jsonHeaders(),
          body: JSON.stringify({ source_id: sourceId }),
        }
      );
      const data = await resp.json().catch(() => ({}));
      if (!resp.ok) {
        throw new Error(detailText(data.detail) || detailText(data) || "Не удалось удалить из поставки");
      }
      _ozonFbsRemovePostingFromOpenModals(pn);
      if (supplyDetailState.supply && Array.isArray(supplyDetailState.supply.orders)) {
        supplyDetailState.supply.orders = supplyDetailState.supply.orders.filter(
          (o) => String((o && o.posting_number) || "").trim() !== pn
        );
        if (Array.isArray(supplyDetailState.supply.posting_numbers)) {
          supplyDetailState.supply.posting_numbers =
            supplyDetailState.supply.posting_numbers.filter(
              (x) => String(x || "").trim() !== pn
            );
        }
        const n = supplyDetailState.supply.orders.length;
        supplyDetailState.supply.order_count = n;
        if (supplyDetailState.selected && typeof supplyDetailState.selected.delete === "function") {
          supplyDetailState.selected.delete(pn);
        }
        renderSupplyDetail(supplyDetailState.supply);
      }
      if (Array.isArray(ozonFbsCancelledState.rows) && ozonFbsCancelledState.rows.length) {
        const before = ozonFbsCancelledState.rows.length;
        ozonFbsCancelledState.rows = ozonFbsCancelledState.rows.filter(
          (r) => String((r && r.posting_number) || "").trim() !== pn
        );
        if (ozonFbsCancelledState.rows.length !== before) {
          renderOzonFbsCancelledOrdersTable();
        }
      }
      _ozonFbsSyncCancelledBtn();
      _ozonFbsSupplyDetailUpdateNewWarn();
      const msg = String(data.message || ("Отправление " + pn + " удалено из поставки"));
      showSyncInfo(msg);
    } catch (e) {
      alert(e.message || String(e));
    }
  }

  function printOnePostingStickerFromDetail(event, postingNumber) {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    closeOzonFbsRowMenus();
    const pn = String(postingNumber || "").trim();
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    if (!pn || !sourceId) {
      alert("Не удалось определить отправление или источник OZON ФБС");
      return;
    }
    // Supply detail / КИЗ / без КИЗ ⋮ → v3 «Стикеры».
    if (supplyDetailReady()) {
      openStickersPrint([pn], { newLabels: true });
      return;
    }
    // Lookup ⋮: posting already in a local supply → same async v3 job (no modal).
    const lookupSupplyId = _ozonFbsLookupSupplyIdForPosting(pn);
    if (lookupSupplyId) {
      openStickersPrint([pn], {
        newLabels: true,
        supplyId: lookupSupplyId,
        sourceId,
      });
      return;
    }
    // Lookup ⋮ without local supply → v3 PDF (package-label create+get).
    const url =
      `/api/ozon-fbs/postings/stickers-print?source_id=${sourceId}` +
      `&posting_numbers=${encodeURIComponent(pn)}`;
    openPrintPdf(url, "Разрешите всплывающие окна для стикера")
      .catch((e) => alert(String(e.message || e)));
  }

  function cancelBadgeHtml(row, { lead } = {}) {
    const label = String(row?.cancel_reason_label || "").trim();
    if (!label) return "";
    const leadCls = lead ? " is-lead" : "";
    return `<div class="wb-fbs-cancel-reason${leadCls}" title="${esc(label)}">${esc(label)}</div>`;
  }

  function _ozonFbsRowIsCancelled(row) {
    if (!row) return false;
    if (row.cancelled) return true;
    if (String(row.cancel_reason_label || "").trim()) return true;
    // Align with backend posting_row_is_cancelled (status/tab).
    const tab = String(row.tab || "").trim().toLowerCase();
    const status = String(row.status || "").trim().toLowerCase();
    if (tab === "cancelled") return true;
    if (status === "cancelled" || status === "cancelled_from_split_pending") return true;
    return false;
  }

  function _ozonFbsActiveModalRows(rows) {
    return (rows || []).filter((r) => !_ozonFbsRowIsCancelled(r));
  }


  function _ozonFbsFormatCargoQty(value) {
    const n = Number(value);
    if (!Number.isFinite(n)) return "0";
    if (Math.abs(n - Math.round(n)) < 1e-9) return String(Math.round(n));
    return n.toFixed(2).replace(".", ",");
  }

  /** Supply/GM cargo line: Товаров: N шт. | Паллет: X шт. | Коробов: Y шт. */
  function _ozonFbsCargoSummaryText(summary) {
    if (!summary || typeof summary !== "object") return "";
    const products = Number(summary.products || 0);
    const pallets = Number(summary.pallets || 0);
    const boxes = Number(summary.boxes || 0);
    const hasLegacy = !!String(summary.summary_label || summary.pallets_label || "").trim();
    if (products <= 0 && !hasLegacy) return "";
    return (
      `Товаров: ${_ozonFbsFormatCargoQty(products)} шт. | `
      + `Паллет: ${_ozonFbsFormatCargoQty(pallets)} шт. | `
      + `Коробов: ${_ozonFbsFormatCargoQty(boxes)} шт.`
    );
  }

  function _ozonFbsRenderCargoSummary(elId, summary) {
    const el = document.getElementById(elId);
    if (!el) return;
    const label = _ozonFbsCargoSummaryText(summary);
    if (!label) {
      el.hidden = true;
      el.innerHTML = "";
      return;
    }
    el.hidden = false;
    el.innerHTML =
      `<span class="wb-fbs-sd-cargo-label" title="Расчёт по товарам этой поставки (как после синхронизации)">${esc(label)}</span>`;
  }

  function _ozonFbsCloseMovedToDeliveringHistory() {
    const el = document.getElementById("ozonFbsSupplyDetailMovedAt");
    if (!el) return;
    const btn = el.querySelector(".ozon-fbs-sd-moved-hist-btn");
    const panel = el.querySelector(".ozon-fbs-sd-moved-hist");
    if (btn) btn.setAttribute("aria-expanded", "false");
    if (panel) panel.hidden = true;
  }

  function _ozonFbsRenderMovedToDelivering(supply) {
    const el = document.getElementById("ozonFbsSupplyDetailMovedAt");
    if (!el) return;
    const display = String(supply?.moved_to_delivering_at_display || "").trim();
    const history = Array.isArray(supply?.moved_to_delivering_history)
      ? supply.moved_to_delivering_history.filter(
          (h) => h && String(h.at_display || "").trim()
        )
      : [];
    if (!display) {
      el.hidden = true;
      el.innerHTML = "";
      return;
    }
    const showHist = history.length > 1;
    let html =
      `<span class="wb-fbs-sd-cargo-label" title="Дата нажатия «Перенести в доставку»">`
      + `Перенесена в доставку: ${esc(display)}</span>`;
    if (showHist) {
      const items = history
        .map(
          (h) =>
            `<div class="ozon-fbs-sd-moved-hist-item" role="listitem">${esc(
              String(h.at_display || "").trim()
            )}</div>`
        )
        .join("");
      html +=
        `<span class="ozon-fbs-sd-moved-wrap">`
        + `<button type="button" class="ozon-fbs-sd-moved-hist-btn" aria-expanded="false" `
        + `aria-label="История переносов в доставку" title="История переносов">▾</button>`
        + `<div class="ozon-fbs-sd-moved-hist" hidden role="list">${items}</div>`
        + `</span>`;
    }
    el.hidden = false;
    el.innerHTML = html;
    const btn = el.querySelector(".ozon-fbs-sd-moved-hist-btn");
    const panel = el.querySelector(".ozon-fbs-sd-moved-hist");
    if (btn && panel) {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        const open = panel.hidden;
        panel.hidden = !open;
        btn.setAttribute("aria-expanded", open ? "true" : "false");
      });
    }
  }

  function renderSupplyDetail(data) {
    closeOzonFbsRowMenus();
    _ozonFbsCloseMovedToDeliveringHistory();
    const supply = data || supplyDetailState.supply;
    if (!supply) return;
    if (data) supplyDetailState.supply = data;
    const readOnly = isSupplyDetailReadOnly();
    syncSupplyDetailReadOnlyMode(readOnly);
    const detailColspan = readOnly ? 2 : 4;
    const title = document.getElementById("ozonFbsSupplyDetailTitle");
    const wh = document.getElementById("ozonFbsSupplyDetailWarehouse");
    const meta = document.getElementById("ozonFbsSupplyDetailMeta");
    const tbody = document.getElementById("ozonFbsSupplyDetailTbody");
    const sid = String(supply.supply_id || "").trim();
    if (title) title.textContent = supply.name || (`Поставка ${sid}`);
    const renameBtn = document.getElementById("ozonFbsSupplyDetailRenameBtn");
    if (renameBtn) renameBtn.hidden = !!readOnly;
    if (wh) wh.textContent = String(supply.warehouse_label || "—").trim() || "—";
    if (meta) {
      // Same pattern as WB FBS: ID chip + printer opens ШК поставки modal.
      meta.innerHTML = sid
        ? `<span class="wb-fbs-sd-chip wb-fbs-sd-chip-qr">` +
          `<span class="wb-fbs-sd-qr-text">ID ${esc(sid)}</span>` +
          `<button type="button" class="wb-fbs-sd-qr-print" ` +
          `title="Распечатать ШК поставки" ` +
          `aria-label="Распечатать ШК поставки ${esc(sid)}" ` +
          `onclick="openOzonFbsShipmentsModal().catch((e)=>alert(e.message||e))">` +
          `<svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true">` +
          `<path d="M4 6V2.5A.5.5 0 0 1 4.5 2h7a.5.5 0 0 1 .5.5V6M4 12H3a1.5 1.5 0 0 1-1.5-1.5v-3A1.5 1.5 0 0 1 3 6h10a1.5 1.5 0 0 1 1.5 1.5v3A1.5 1.5 0 0 1 13 12h-1" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>` +
          `<path d="M4 10.5h8V14a.5.5 0 0 1-.5.5h-7A.5.5 0 0 1 4 14v-3.5z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/>` +
          `<path d="M11.5 8.25h.01" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>` +
          `</svg>` +
          `</button>` +
          `</span>`
        : "";
    }

    _ozonFbsRenderCargoSummary("ozonFbsSupplyDetailCargo", supply.cargo_summary);
    _ozonFbsRenderMovedToDelivering(supply);
    _ozonFbsSyncDriverBtn();
    const allOrdersRaw = Array.isArray(supply.orders) ? supply.orders : [];
    // Modal-only: oldest orders on top. Print endpoints keep their own order.
    const allOrders = sortSupplyDetailOrdersOldestFirst(allOrdersRaw);
    const kizSplit = document.getElementById("ozonFbsKizSplit");
    const kizBtn = document.getElementById("ozonFbsSupplyDetailKizBtn");
    const kizRefreshBtn = document.getElementById("ozonFbsSupplyDetailKizRefreshBtn");
    // KIZ + Pick stay visible for status tones even when composition is locked (delivering).
    const needsKiz = allOrders.some((o) => o && o.kiz_required && !_ozonFbsRowIsCancelled(o));
    if (kizSplit) kizSplit.hidden = !allOrders.length;
    if (kizBtn) kizBtn.hidden = !allOrders.length;
    if (kizRefreshBtn) kizRefreshBtn.hidden = !needsKiz;
    if (!needsKiz) _ozonFbsKizSplitSetTone("");
    else _ozonFbsKizSplitSetTone(_ozonFbsKizToneFromSupply(supply));
    _ozonFbsSyncPickVerifyBtn(allOrders);
    _ozonFbsSyncKizPickBtnLabels({ orders: allOrders });
    const needsPick = allOrders.some((o) => o && !o.kiz_required && !_ozonFbsRowIsCancelled(o));
    if (!needsPick) _ozonFbsPickSplitSetTone("");
    else _ozonFbsPickSplitSetTone(_ozonFbsPickToneFromSupply(supply));
    const searchQ = String(document.getElementById("ozonFbsSupplyDetailSearchFilter")?.value || "").trim().toLowerCase();
    const orders = searchQ
      ? allOrders.filter((o) => _ozonFbsSupplyDetailRowMatchesSearch(o, searchQ))
      : allOrders;
    if (!tbody) return;
    if (!allOrders.length) {
      tbody.innerHTML = `<tr><td colspan="${detailColspan}" class="wb-fbs-empty">В поставке нет отправлений</td></tr>`;
      supplyDetailState.selected = new Set();
      const selAllGone = document.getElementById("ozonFbsSupplyDetailSelectAll");
      if (selAllGone) {
        selAllGone.checked = false;
        selAllGone.indeterminate = false;
      }
      updateSupplyDetailBottomBar();
      return;
    }
    if (!orders.length) {
      tbody.innerHTML = `<tr><td colspan="${detailColspan}" class="wb-fbs-empty">Нет отправлений по выбранному фильтру</td></tr>`;
      if (!readOnly) {
        const aliveFiltered = new Set(
          allOrders.map((o) => String(o.posting_number || "").trim()).filter(Boolean)
        );
        supplyDetailState.selected = new Set(
          [...supplyDetailState.selected].filter((pn) => aliveFiltered.has(pn))
        );
      } else {
        supplyDetailState.selected = new Set();
      }
      const selAllEmpty = document.getElementById("ozonFbsSupplyDetailSelectAll");
      if (selAllEmpty) {
        selAllEmpty.checked = false;
        selAllEmpty.indeterminate = false;
      }
      updateSupplyDetailBottomBar();
      return;
    }
    tbody.innerHTML = orders.map((o) => {
      const pn = String(o.posting_number || "").trim();
      const checked = supplyDetailState.selected.has(pn) ? "checked" : "";
      const photo = o.product_photo
        ? `<img class="wb-fbs-product-photo" src="${esc(o.product_photo)}" alt="" width="72" height="72" loading="lazy">`
        : `<span class="wb-fbs-product-ph" aria-hidden="true"></span>`;
      const barcodes = Array.isArray(o.barcodes) ? o.barcodes : [];
      const barcodeHtml = barcodes.length
        ? `<div class="wb-fbs-barcodes" title="Штрихкод товара">${barcodes.map((b) =>
            `<div class="wb-fbs-barcode">${esc(b)}</div>`
          ).join("")}</div>`
        : "";
      const offer = String(o.offer_id || "").trim();
      const sku = String(o.sku || "").trim();
      const pname = o.product_name || offer || "—";
      const composition = productCompositionHtml(o);
      const created = o.created_at_ozon || o.in_process_at || "";
      const ago = agoLabel(created);
      const badges = [];
      if (ago) badges.push(`<span class="wb-fbs-badge time">${esc(ago)}</span>`);
      const cancelLabel = String(o.cancel_reason_label || "").trim();
      const rowCls = cancelLabel || _ozonFbsRowIsCancelled(o) ? "wb-fbs-sd-click-row is-cancelled" : "wb-fbs-sd-click-row";
      const checkCell = readOnly
        ? ""
        : `<td class="wb-fbs-sd-td-check"><input type="checkbox" class="wb-fbs-sd-cb" data-posting="${esc(pn)}" ${checked}
                   onchange="onOzonFbsSupplyDetailCheckboxChange()" /></td>`;
      const sdMenuKey = _ozonFbsPostingMenuKey(`sd_${pn}`);
      const removeCancelledSd = _ozonFbsRowIsCancelled(o) || cancelLabel
        ? `<button type="button" class="wb-fbs-row-menu-item" role="menuitem"
                  onclick="ozonFbsRemoveCancelledPostingFromSupply(event, '${esc(pn)}')">
             Удалить товар из поставки
           </button>`
        : "";
      const actCell = readOnly
        ? ""
        : `<td class="wb-fbs-sd-col-act">
          <div class="wb-fbs-row-menu-wrap" id="ozonFbsRowMenuWrap_${sdMenuKey}">
            <button type="button" class="icon-btn secondary wb-fbs-row-menu-btn" title="Действия"
                    onclick="toggleOzonFbsRowMenu(event, '${sdMenuKey}')" aria-haspopup="menu">⋮</button>
            <div id="ozonFbsRowMenu_${sdMenuKey}" class="wb-fbs-row-menu" data-posting="${esc(pn)}" data-mode="sd" role="menu">
              <button type="button" class="wb-fbs-row-menu-item" role="menuitem"
                      data-ozon-action="print-sticker" data-posting="${esc(pn)}">
                Напечатать стикер
              </button>
              ${removeCancelledSd}
            </div>
          </div>
        </td>`;
      return `<tr class="${rowCls}">
        ${checkCell}
        <td class="wb-fbs-sd-td-order">
          <div class="wb-fbs-sd-order-id ozon-fbs-modal-posting-id">
            <span class="ozon-fbs-modal-posting-num">${esc(pn) || "—"}</span>
            ${_ozonFbsPostingCopyBtnHtml(pn)}
          </div>
          ${_ozonFbsScanitUnderOrderHtml(o)}
          <div class="wb-fbs-order-meta">от ${esc(fmtDate(created))}</div>
          ${badges.length ? `<div class="wb-fbs-badges">${badges.join("")}</div>` : ""}
        </td>
        <td class="wb-fbs-sd-td-product">
          <div class="wb-fbs-product">
            ${photo}
            <div class="wb-fbs-product-text">
              <div class="wb-fbs-product-name" title="${esc(pname)}">${esc(pname)}</div>
              <div class="wb-fbs-product-sub">Арт. ${esc(offer || "—")}${sku ? " · SKU " + esc(sku) : ""}</div>
              ${composition}
              ${barcodeHtml}
              ${kizBadgeHtml(o)}
            </div>
          </div>
        </td>
        ${actCell}
      </tr>`;
    }).join("");
    if (!readOnly) {
      // Drop selections that are no longer in this supply (e.g. after move).
      const alive = new Set(
        allOrders.map((o) => String(o.posting_number || "").trim()).filter(Boolean)
      );
      supplyDetailState.selected = new Set(
        [...supplyDetailState.selected].filter((pn) => alive.has(pn))
      );
      syncSupplyDetailSelectAll();
    } else {
      supplyDetailState.selected = new Set();
    }
    updateSupplyDetailBottomBar();
  }

  function _ozonFbsSupplyPostingTabParam() {
    const tab = String(supplyDetailState.postingTab || "").trim();
    return tab ? `&posting_tab=${encodeURIComponent(tab)}` : "";
  }

  function _ozonFbsAppendPostingTab(params) {
    const tab = String(supplyDetailState.postingTab || "").trim();
    if (tab && params && typeof params.set === "function") {
      params.set("posting_tab", tab);
    }
    return params;
  }

  async function openSupplyDetailModal(supplyId) {
    const sid = String(supplyId || "").trim();
    if (!sid || !state.sourceId) return;
    if (isSupplyOpenBlocked()) {
      alert(supplyOpenBlockedTitle());
      return;
    }
    supplyDetailState.supplyId = sid;
    supplyDetailState.sourceId = state.sourceId;
    supplyDetailState.selected = new Set();
    supplyDetailState.postingTab = isSuppliesTab() ? String(state.tab || "").trim() : null;
    _ozonFbsSupplyDetailSetActionsReady(false);
    _ozonFbsKizSplitSetTone("");
    _ozonFbsPickSplitSetTone("");
    _ozonFbsSyncDriverBtn();
    const kizSplitOpen = document.getElementById("ozonFbsKizSplit");
    if (kizSplitOpen) kizSplitOpen.hidden = true;
    const pickSplitOpen = document.getElementById("ozonFbsPickSplit");
    if (pickSplitOpen) pickSplitOpen.hidden = true;
    const modal = document.getElementById("ozonFbsSupplyDetailModal");
    const title = document.getElementById("ozonFbsSupplyDetailTitle");
    const tbody = document.getElementById("ozonFbsSupplyDetailTbody");
    const search = document.getElementById("ozonFbsSupplyDetailSearchFilter");
    if (search) search.value = "";
    if (title) title.textContent = "Загрузка…";
    _ozonFbsRenderCargoSummary("ozonFbsSupplyDetailCargo", null);
    _ozonFbsRenderMovedToDelivering(null);
    _ozonFbsSupplyDetailHideNewWarn();
    const readOnly = isDeliveringSuppliesTab();
    syncSupplyDetailReadOnlyMode(readOnly);
    _ozonFbsSyncCancelledBtn();
    _ozonFbsSyncOwnerOnlyNewStickersBtn();
    const detailColspan = readOnly ? 2 : 4;
    if (tbody) tbody.innerHTML = `<tr><td colspan="${detailColspan}" class="wb-fbs-empty">Загрузка…</td></tr>`;
    if (modal) modal.classList.remove("hidden");
    ozonFbsSupplyDetailColResizer.init();
    try {
      const tabParam = _ozonFbsSupplyPostingTabParam();
      const res = await fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/detail?source_id=${state.sourceId}${tabParam}`
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || "Не найдено");
      renderSupplyDetail(data);
      _ozonFbsSupplyDetailSetActionsReady(true);
      _ozonFbsSupplyDetailUpdateNewWarn();
      // Load warehouse cargo places early so green tone / GM button can require confirms.
      const refreshTonesAfterGm = () => {
        _ozonFbsKizSplitSetTone(_ozonFbsKizToneFromSupply(supplyDetailState.supply));
        _ozonFbsPickSplitSetTone(_ozonFbsPickToneFromSupply(supplyDetailState.supply));
        _ozonFbsSyncContainersBtn();
        _ozonFbsSyncMoveDeliveringEnabled();
      };
      if (typeof window._ozonFbsContainerInvalidate === "function") {
        void Promise.resolve(window._ozonFbsContainerInvalidate())
          .catch(() => false)
          .then(() => refreshTonesAfterGm());
      } else {
        refreshTonesAfterGm();
      }
      // Same ok/error rules as «Обновить», without requiring a click.
      _ozonFbsAutoRefreshSplitTones();
    } catch (e) {
      _ozonFbsSupplyDetailSetActionsReady(false);
      _ozonFbsSupplyDetailHideNewWarn();
      if (title) title.textContent = "Ошибка";
      if (tbody) {
        tbody.innerHTML = `<tr><td colspan="${detailColspan}" class="wb-fbs-empty" style="color:#b91c1c">${esc(e.message)}</td></tr>`;
      }
    }
  }

  function _ozonFbsCancelledSetInfo(text, kind) {
    const el = document.getElementById("ozonFbsCancelledOrdersInfo");
    if (!el) return;
    const msg = String(text || "").trim();
    el.hidden = !msg;
    el.textContent = msg;
    el.classList.toggle("is-ok", !!msg && kind === "ok");
  }

  async function _ozonFbsRefreshOpenSupplyDetail() {
    const sid = String(supplyDetailState.supplyId || "").trim();
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    if (!sid || !sourceId) return;
    try {
      const tabParam = _ozonFbsSupplyPostingTabParam();
      const res = await fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/detail?source_id=${sourceId}${tabParam}`
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok) return;
      renderSupplyDetail(data);
      _ozonFbsKizSplitSetTone(_ozonFbsKizToneFromSupply(supplyDetailState.supply));
      _ozonFbsPickSplitSetTone(_ozonFbsPickToneFromSupply(supplyDetailState.supply));
      _ozonFbsSupplyDetailUpdateNewWarn();
    } catch (_e) { /* ignore */ }
  }

  function _ozonFbsApplyStickerCancelledRows(rows) {
    const list = Array.isArray(rows) ? rows.filter((r) => r && r.cancelled) : [];
    if (!list.length) return;
    _ozonFbsCancelledMergeIntoDetail(list);
    _ozonFbsKizSplitSetTone(_ozonFbsKizToneFromSupply(supplyDetailState.supply));
    _ozonFbsPickSplitSetTone(_ozonFbsPickToneFromSupply(supplyDetailState.supply));
    _ozonFbsSupplyDetailUpdateNewWarn();
  }

  function _ozonFbsCancelledMergeIntoDetail(rows) {
    const supply = supplyDetailState.supply;
    if (!supply || !Array.isArray(supply.orders) || !Array.isArray(rows)) return;
    const byPn = new Map();
    rows.forEach((row) => {
      const pn = String(row?.posting_number || "").trim();
      if (pn) byPn.set(pn, row);
    });
    if (!byPn.size) return;
    let changed = false;
    supply.orders.forEach((o) => {
      const pn = String(o?.posting_number || "").trim();
      const upd = byPn.get(pn);
      if (!upd) return;
      const label = String(upd.cancel_reason_label || "").trim();
      if (label) {
        o.cancel_reason_label = label;
        o.cancelled = true;
        changed = true;
      }
      if (upd.status) o.status = String(upd.status);
      if (upd.tab) o.tab = String(upd.tab);
    });
    if (changed) renderSupplyDetail(supply);
  }

  /** Per-row status check from KIZ / pick-verify modals (live Ozon refresh). */
  const ozonFbsPostingStatusState = {
    busy: false,
    postingNumber: "",
    cancelled: false,
    statusLabel: "",
    mode: "", // kiz | pick
  };

  function _ozonFbsPostingStatusSetVisible(show) {
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsPostingStatusModal", !!show);
      return;
    }
    const modal = document.getElementById("ozonFbsPostingStatusModal");
    if (!modal) return;
    modal.classList.toggle("hidden", !show);
  }

  function _ozonFbsPostingStatusRender({ title, html, kind } = {}) {
    const titleEl = document.getElementById("ozonFbsPostingStatusTitle");
    const body = document.getElementById("ozonFbsPostingStatusBody");
    const card = document.querySelector(
      "#ozonFbsPostingStatusModal .ozon-fbs-posting-status-modal"
    );
    if (titleEl) titleEl.textContent = title || "Статус заказа";
    if (body) body.innerHTML = html || "";
    if (card) {
      card.classList.toggle("is-error", kind === "error" || kind === "cancelled");
      card.classList.toggle("is-ok", kind === "ok");
      card.classList.toggle("is-cancelled", kind === "cancelled");
    }
    _ozonFbsPostingStatusSetVisible(true);
  }

  function _ozonFbsPostingStatusBusy(pn, busy) {
    const safe = CSS.escape(String(pn || "").trim());
    if (!safe) return;
    document
      .querySelectorAll(
        `.ozon-fbs-posting-status-refresh[aria-label*="${safe}"], ` +
        `button.ozon-fbs-posting-status-refresh[onclick*="${safe}"]`
      )
      .forEach((btn) => {
        btn.classList.toggle("is-spinning", !!busy);
        btn.disabled = !!busy;
      });
  }

  function _ozonFbsRemovePostingFromOpenModals(postingNumber) {
    const pn = String(postingNumber || "").trim();
    if (!pn) return;
    let kizChanged = false;
    let pickChanged = false;
    if (Array.isArray(ozonFbsKizState.rows) && ozonFbsKizState.rows.length) {
      const before = ozonFbsKizState.rows.length;
      ozonFbsKizState.rows = ozonFbsKizState.rows.filter(
        (r) => String(r?.posting_number || "").trim() !== pn
      );
      kizChanged = ozonFbsKizState.rows.length !== before;
      if (kizChanged) {
        if (ozonFbsKizState.errors) delete ozonFbsKizState.errors[pn];
        if (String(ozonFbsKizState.pendingPosting || "").trim() === pn) {
          ozonFbsKizState.pendingPosting = null;
        }
        _ozonFbsKizRebuildIndexes();
        renderOzonFbsKizTable();
      }
    }
    if (Array.isArray(ozonFbsPickState.rows) && ozonFbsPickState.rows.length) {
      const before = ozonFbsPickState.rows.length;
      ozonFbsPickState.rows = ozonFbsPickState.rows.filter(
        (r) => String(r?.posting_number || "").trim() !== pn
      );
      pickChanged = ozonFbsPickState.rows.length !== before;
      if (pickChanged) {
        if (ozonFbsPickState.errors) delete ozonFbsPickState.errors[pn];
        if (String(ozonFbsPickState.pendingPosting || "").trim() === pn) {
          ozonFbsPickState.pendingPosting = null;
        }
        renderOzonFbsPickVerifyTable();
      }
    }
    if (kizChanged || pickChanged) {
      _ozonFbsKizSplitSetTone(_ozonFbsKizToneFromSupply(supplyDetailState.supply));
      _ozonFbsPickSplitSetTone(_ozonFbsPickToneFromSupply(supplyDetailState.supply));
      _ozonFbsSupplyDetailUpdateNewWarn();
    }
  }

  function _ozonFbsRefreshOpenModalsAfterCancelFlag() {
    // Keep cancelled rows in KIZ / pick modals; only refresh filters + counters.
    if (Array.isArray(ozonFbsKizState.rows) && ozonFbsKizState.rows.length) {
      _ozonFbsKizRebuildIndexes();
      renderOzonFbsKizTable();
      _ozonFbsKizUpdateFilterCounts();
      _ozonFbsKizUpdateScanCounter();
    }
    if (Array.isArray(ozonFbsPickState.rows) && ozonFbsPickState.rows.length) {
      renderOzonFbsPickVerifyTable();
      _ozonFbsPickUpdateFilterCounts();
      _ozonFbsPickUpdateScanCounter();
    }
    if (typeof window._ozonFbsContainerUpdateCounters === "function") {
      try {
        window._ozonFbsContainerUpdateCounters();
      } catch (_e) {
        /* ignore */
      }
    }
    _ozonFbsKizSplitSetTone(_ozonFbsKizToneFromSupply(supplyDetailState.supply));
    _ozonFbsPickSplitSetTone(_ozonFbsPickToneFromSupply(supplyDetailState.supply));
    _ozonFbsSupplyDetailUpdateNewWarn();
  }

  function closeOzonFbsPostingStatusModal() {
    if (ozonFbsPostingStatusState.busy) return;
    ozonFbsPostingStatusState.postingNumber = "";
    ozonFbsPostingStatusState.cancelled = false;
    ozonFbsPostingStatusState.statusLabel = "";
    ozonFbsPostingStatusState.mode = "";
    _ozonFbsPostingStatusSetVisible(false);
    // Frozen composition: cancelled stay in modal/supply until pick-list + stickers reset.
  }

  function _ozonFbsCopyTextFallback(text) {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.left = "-9999px";
    document.body.appendChild(ta);
    ta.select();
    try {
      document.execCommand("copy");
    } finally {
      document.body.removeChild(ta);
    }
  }

  async function copyOzonFbsModalPostingNumber(postingNumber, btnEl) {
    const pn = String(postingNumber || "").trim();
    if (!pn) return;
    const markCopied = () => {
      const btn = btnEl && btnEl.classList ? btnEl : null;
      if (!btn) return;
      btn.classList.add("is-copied");
      const isScanit = btn.classList.contains("ozon-fbs-scanit-copy");
      const fallbackTitle = isScanit ? "Скопировать этикетку" : "Скопировать стикер";
      const prev = btn.getAttribute("title") || fallbackTitle;
      btn.setAttribute("title", "Скопировано");
      window.setTimeout(() => {
        btn.classList.remove("is-copied");
        btn.setAttribute("title", prev === "Скопировано" ? fallbackTitle : prev);
      }, 1200);
    };
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(pn);
      } else {
        _ozonFbsCopyTextFallback(pn);
      }
      markCopied();
    } catch (_e) {
      try {
        _ozonFbsCopyTextFallback(pn);
        markCopied();
      } catch (__e) {
        /* ignore */
      }
    }
  }

  /** In-flight silent status checks (GM cleared by Ozon) — do not block scan UI. */
  const ozonFbsSilentStatusInflight = new Set();

  /**
   * Apply cancel flag without stealing scan focus: bump «Отменённые», patch row.
   * No toasts / status modal.
   */
  function _ozonFbsApplyCancelledQuiet(pn, cancelLabel) {
    const posting = String(pn || "").trim();
    if (!posting) return;
    const label = String(cancelLabel || "Отменено").trim() || "Отменено";
    const active = document.activeElement;
    const activeId = active && active.id ? String(active.id) : "";
    const activePn = active && active.dataset ? String(active.dataset.posting || "") : "";
    const selStart = active && typeof active.selectionStart === "number" ? active.selectionStart : null;
    const selEnd = active && typeof active.selectionEnd === "number" ? active.selectionEnd : null;

    _ozonFbsCancelledMergeIntoDetail([
      {
        posting_number: posting,
        cancel_reason_label: label,
        cancelled: true,
        tab: "cancelled",
        status: "cancelled",
      },
    ]);
    for (const row of [...(ozonFbsKizState.rows || []), ...(ozonFbsPickState.rows || [])]) {
      if (String(row?.posting_number || "").trim() !== posting) continue;
      row.cancelled = true;
      row.cancel_reason_label = label;
      row.tab = "cancelled";
      row.status = "cancelled";
      // GM drop on cancel is not an assembly error.
      row.container_sync_error = "";
    }

    // Prefer light DOM patch; fall back to full refresh with focus restore.
    const patched = _ozonFbsPatchCancelledRowDom(posting);
    if (!patched) {
      _ozonFbsRefreshOpenModalsAfterCancelFlag();
    } else {
      if (typeof _ozonFbsKizUpdateFilterCounts === "function") _ozonFbsKizUpdateFilterCounts();
      if (typeof _ozonFbsPickUpdateFilterCounts === "function") _ozonFbsPickUpdateFilterCounts();
      if (typeof _ozonFbsKizUpdateScanCounter === "function") _ozonFbsKizUpdateScanCounter();
      if (typeof _ozonFbsPickUpdateScanCounter === "function") _ozonFbsPickUpdateScanCounter();
      if (typeof window._ozonFbsContainerUpdateCounters === "function") {
        try { window._ozonFbsContainerUpdateCounters(); } catch (_e) { /* ignore */ }
      }
      _ozonFbsKizSplitSetTone(_ozonFbsKizToneFromSupply(supplyDetailState.supply));
      _ozonFbsPickSplitSetTone(_ozonFbsPickToneFromSupply(supplyDetailState.supply));
      _ozonFbsSupplyDetailUpdateNewWarn();
    }

    requestAnimationFrame(() => {
      let el = activeId ? document.getElementById(activeId) : null;
      if (!el && activePn) {
        el = document.querySelector(
          `#ozonFbsKizTbody [data-posting="${CSS.escape(activePn)}"].wb-fbs-kiz-code-input,` +
          `#ozonFbsPickTbody [data-posting="${CSS.escape(activePn)}"] input,` +
          `#ozonFbsKizStickerScan, #ozonFbsPickStickerScan`
        );
      }
      if (!el) {
        el = document.getElementById("ozonFbsKizStickerScan")
          || document.getElementById("ozonFbsPickStickerScan");
      }
      if (el && typeof el.focus === "function") {
        try {
          el.focus();
          if (selStart != null && typeof el.setSelectionRange === "function") {
            el.setSelectionRange(selStart, selEnd != null ? selEnd : selStart);
          }
        } catch (_e) { /* ignore */ }
      }
    });
  }

  function _ozonFbsPatchCancelledRowDom(pn) {
    const posting = String(pn || "").trim();
    if (!posting) return false;
    const rows = document.querySelectorAll(
      `#ozonFbsKizTbody tr.wb-fbs-kiz-row[data-posting="${CSS.escape(posting)}"],` +
      `#ozonFbsPickTbody tr.wb-fbs-kiz-row[data-posting="${CSS.escape(posting)}"]`
    );
    if (!rows.length) return false;
    let any = false;
    rows.forEach((tr) => {
      any = true;
      tr.classList.add("is-cancelled");
      tr.querySelectorAll("input.wb-fbs-kiz-code-input, input.wb-fbs-pick-code-input").forEach((inp) => {
        inp.readOnly = true;
        inp.tabIndex = -1;
      });
      tr.querySelectorAll("button.wb-fbs-kiz-remove, button.wb-fbs-pick-remove").forEach((btn) => {
        btn.disabled = true;
      });
      tr.querySelectorAll("button.wb-fbs-kiz-add").forEach((btn) => {
        btn.remove();
      });
      const menu = tr.querySelector(".wb-fbs-row-menu[data-mode='kiz'], .wb-fbs-row-menu[data-mode='pick']");
      if (menu && typeof _ozonFbsSyncRowMenuContent === "function") {
        _ozonFbsSyncRowMenuContent(menu);
      }
    });
    return any;
  }

  async function refreshOzonFbsModalPostingStatus(postingNumber, opts) {
    const silent = !!(opts && opts.silent);
    const pn = String(postingNumber || "").trim();
    if (!pn) return;
    if (!silent && ozonFbsPostingStatusState.busy) return;
    if (silent) {
      if (ozonFbsSilentStatusInflight.has(pn)) return;
      const existing = [...(ozonFbsKizState.rows || []), ...(ozonFbsPickState.rows || [])]
        .find((r) => String(r?.posting_number || "").trim() === pn);
      if (existing && _ozonFbsRowIsCancelled(existing)) return;
      ozonFbsSilentStatusInflight.add(pn);
    }
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    if (!sourceId) {
      if (!silent) {
        _ozonFbsPostingStatusRender({
          title: "Статус заказа",
          html: `<p class="ozon-fbs-move-delivering-text">Не выбран источник Ozon</p>`,
          kind: "error",
        });
      }
      if (silent) ozonFbsSilentStatusInflight.delete(pn);
      return;
    }
    if (!silent) {
      ozonFbsPostingStatusState.busy = true;
      ozonFbsPostingStatusState.postingNumber = pn;
      ozonFbsPostingStatusState.cancelled = false;
      ozonFbsPostingStatusState.statusLabel = "";
      _ozonFbsPostingStatusBusy(pn, true);
      _ozonFbsPostingStatusRender({
        title: "Проверка статуса",
        html: `<p class="ozon-fbs-move-delivering-text">Проверяем отправление ${esc(pn)} на Ozon…</p>`,
        kind: "ok",
      });
    }
    try {
      const data = await lookupPostingByNumber(pn, { refresh: true });
      if (!data?.found || !data.item) {
        throw new Error(String(data?.message || "Отправление не найдено"));
      }
      const item = data.item || {};
      const details = data.details && typeof data.details === "object" ? data.details : {};
      const status = String(
        details.status || item.status || ""
      ).trim().toLowerCase();
      const tab = String(details.tab || item.tab || data.tab || "").trim().toLowerCase();
      const statusLabel = String(
        details.status_label
        || item.status_label
        || OZON_FBS_TAB_LABELS[tab]
        || status
        || "—"
      ).trim();
      const cancelLabel = String(
        details.cancel_reason_label
        || item.cancel_reason_label
        || ""
      ).trim();
      const cancelled =
        !!item.cancelled
        || !!details.cancelled
        || tab === "cancelled"
        || status === "cancelled"
        || status === "cancelled_from_split_pending"
        || !!cancelLabel;

      if (!silent) {
        ozonFbsPostingStatusState.cancelled = cancelled;
        ozonFbsPostingStatusState.statusLabel = statusLabel;
      }

      if (cancelled) {
        if (silent) {
          _ozonFbsApplyCancelledQuiet(pn, cancelLabel || "Отменено");
        } else {
          _ozonFbsCancelledMergeIntoDetail([
            {
              posting_number: pn,
              status: status || item.status || "",
              tab: tab || item.tab || "",
              cancel_reason_label: cancelLabel || "Отменено",
              cancelled,
            },
          ]);
          for (const row of [...(ozonFbsKizState.rows || []), ...(ozonFbsPickState.rows || [])]) {
            if (String(row?.posting_number || "").trim() !== pn) continue;
            row.status = status || row.status;
            row.tab = tab || row.tab;
            row.cancelled = true;
            row.cancel_reason_label = cancelLabel || "Отменено";
            row.container_sync_error = "";
          }
          _ozonFbsRefreshOpenModalsAfterCancelFlag();
          // Short ack only — no long instructions (they distract while scanning).
          _ozonFbsPostingStatusRender({
            title: "Заказ отменён",
            html:
              `<p class="ozon-fbs-move-delivering-text">` +
              `Отправление <strong>${esc(pn)}</strong> — отменено` +
              (cancelLabel ? ` (${esc(cancelLabel)})` : "") +
              `.</p>`,
            kind: "cancelled",
          });
        }
      } else if (!silent) {
        for (const row of [...(ozonFbsKizState.rows || []), ...(ozonFbsPickState.rows || [])]) {
          if (String(row?.posting_number || "").trim() !== pn) continue;
          row.status = status || row.status;
          row.tab = tab || row.tab;
        }
        _ozonFbsPostingStatusRender({
          title: "Статус заказа",
          html:
            `<p class="ozon-fbs-move-delivering-text">` +
            `Отправление <strong>${esc(pn)}</strong></p>` +
            `<p class="ozon-fbs-move-delivering-text">` +
            `Текущий статус: <strong>${esc(statusLabel)}</strong>` +
            `</p>`,
          kind: "ok",
        });
      }
    } catch (e) {
      if (!silent) {
        ozonFbsPostingStatusState.cancelled = false;
        _ozonFbsPostingStatusRender({
          title: "Не удалось проверить",
          html: `<p class="ozon-fbs-move-delivering-text">${esc(String(e.message || e))}</p>`,
          kind: "error",
        });
      }
      // Silent failures stay silent — do not interrupt scanning.
    } finally {
      if (silent) {
        ozonFbsSilentStatusInflight.delete(pn);
      } else {
        ozonFbsPostingStatusState.busy = false;
        _ozonFbsPostingStatusBusy(pn, false);
      }
    }
  }


  function renderOzonFbsCancelledOrdersTable() {
    const tbody = document.getElementById("ozonFbsCancelledOrdersTbody");
    if (!tbody) return;
    const rows = Array.isArray(ozonFbsCancelledState.rows) ? ozonFbsCancelledState.rows : [];
    if (!rows.length) {
      let emptyMsg = "Отменённых отправлений в поставке нет";
      if (ozonFbsCancelledState.loading) emptyMsg = "Проверяем статусы на Ozon…";
      else if (ozonFbsCancelledState.lastError) emptyMsg = "Не удалось проверить статусы";
      tbody.innerHTML = `<tr><td colspan="2" class="wb-fbs-empty">${esc(emptyMsg)}</td></tr>`;
      return;
    }
    tbody.innerHTML = rows.map((r) => {
      const pn = String(r.posting_number || "").trim();
      const photo = r.product_photo
        ? `<img class="wb-fbs-product-photo" src="${esc(r.product_photo)}" alt="" width="56" height="56" loading="lazy">`
        : `<span class="wb-fbs-product-ph" aria-hidden="true"></span>`;
      const offerArt = [r.offer_id ? `Арт. ${r.offer_id}` : "", r.sku ? `SKU ${r.sku}` : ""]
        .filter(Boolean)
        .join(" · ");
      const barcodes = Array.isArray(r.barcodes) ? r.barcodes : [];
      const barcodeHtml = barcodes.length
        ? `<div class="wb-fbs-kiz-barcodes" title="Штрихкод товара">${barcodes.map((b) =>
            `<div class="wb-fbs-kiz-barcode">${esc(b)}</div>`
          ).join("")}</div>`
        : "";
      return `<tr class="wb-fbs-kiz-row" data-posting="${esc(pn)}">
        <td>
          <div class="wb-fbs-kiz-order-id">${formatOzonPostingNumberHtml(pn)}</div>
          <div class="wb-fbs-kiz-order-date">от ${esc(r.created_date || "—")}</div>
        </td>
        <td>
          <div class="wb-fbs-product">
            ${photo}
            <div class="wb-fbs-product-text">
              <div class="wb-fbs-product-name" title="${esc(r.product_name || r.offer_id || "")}">${esc(r.product_name || r.offer_id || "—")}</div>
              <div class="wb-fbs-product-sub">${esc(offerArt || "—")}</div>
              ${productCompositionHtml(r)}
              ${barcodeHtml}
              ${cancelBadgeHtml(r)}
            </div>
          </div>
        </td>
      </tr>`;
    }).join("");
  }

  async function refreshOzonFbsCancelledOrders() {
    if (typeof isTenantOwner === "function" && !isTenantOwner()) return;
    const sid = String(supplyDetailState.supplyId || "").trim();
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    if (!sid || !sourceId || ozonFbsCancelledState.loading) return;
    const refreshGen = Number(ozonFbsCancelledState.refreshGen || 0) + 1;
    ozonFbsCancelledState.refreshGen = refreshGen;
    ozonFbsCancelledState.loading = true;
    ozonFbsCancelledState.lastError = "";
    const btn = document.getElementById("ozonFbsCancelledOrdersRefreshBtn");
    if (btn) btn.disabled = true;
    _ozonFbsCancelledSetInfo("");
    if (!ozonFbsCancelledState.rows.length) {
      renderOzonFbsCancelledOrdersTable();
    }
    try {
      const merged = [];
      const seen = new Set();
      let offset = 0;
      let done = false;
      let postingCount = 0;
      let checkedTotal = 0;
      const allWarnings = [];
      while (!done) {
        if (ozonFbsCancelledState.refreshGen !== refreshGen) return;
        const params = new URLSearchParams({
          source_id: String(sourceId),
          check_offset: String(offset),
        });
        _ozonFbsAppendPostingTab(params);
        if (checkedTotal > 0 || offset > 0) {
          _ozonFbsCancelledSetInfo(
            `Проверка отменённых на Ozon… ${checkedTotal}/${postingCount || "?"}`,
            "ok"
          );
        }
        const res = await fetch(
          `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/cancelled?${params}`
        );
        const data = await res.json().catch(() => ({}));
        if (!res.ok || data.ok === false) {
          throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
        }
        if (ozonFbsCancelledState.refreshGen !== refreshGen) return;
        postingCount = Number(data.posting_count || postingCount || 0);
        checkedTotal += Number(data.checked || 0);
        const chunkRows = Array.isArray(data.rows) ? data.rows : [];
        for (const row of chunkRows) {
          const pn = String(row?.posting_number || "").trim();
          if (!pn || seen.has(pn)) continue;
          seen.add(pn);
          merged.push(row);
        }
        const warnings = Array.isArray(data.warnings) ? data.warnings : [];
        allWarnings.push(...warnings);
        done = data.done === true || Number(data.remaining || 0) <= 0;
        offset = Number(data.next_offset != null ? data.next_offset : offset + Number(data.checked || 0));
        if (!done && Number(data.checked || 0) <= 0) {
          done = true;
        }
        ozonFbsCancelledState.rows = merged.slice();
        renderOzonFbsCancelledOrdersTable();
        if (!done) {
          _ozonFbsCancelledSetInfo(
            `Проверка отменённых на Ozon… ${checkedTotal}/${postingCount}`,
            "ok"
          );
        }
      }
      if (ozonFbsCancelledState.refreshGen !== refreshGen) return;
      ozonFbsCancelledState.lastError = "";
      ozonFbsCancelledState.rows = merged;
      renderOzonFbsCancelledOrdersTable();
      _ozonFbsCancelledMergeIntoDetail(ozonFbsCancelledState.rows);
      if (allWarnings.length) {
        _ozonFbsCancelledSetInfo(
          `Часть отправлений проверена по локальным данным (${allWarnings.length})`,
          "ok"
        );
      } else {
        _ozonFbsCancelledSetInfo("");
      }
    } catch (e) {
      if (ozonFbsCancelledState.refreshGen !== refreshGen) return;
      const msg = String(e.message || e);
      ozonFbsCancelledState.lastError = msg;
      if (!ozonFbsCancelledState.rows.length) renderOzonFbsCancelledOrdersTable();
      _ozonFbsCancelledSetInfo(msg);
    } finally {
      if (ozonFbsCancelledState.refreshGen === refreshGen) {
        ozonFbsCancelledState.loading = false;
        if (btn) btn.disabled = false;
        if (!ozonFbsCancelledState.rows.length) renderOzonFbsCancelledOrdersTable();
      }
    }
  }

  function openOzonFbsCancelledOrdersModal() {
    if (typeof isTenantOwner === "function" && !isTenantOwner()) {
      alert("Отмененные заказы доступны только главному пользователю");
      return;
    }
    const sid = String(supplyDetailState.supplyId || "").trim();
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    if (!sid || !sourceId || !_ozonFbsSupplyActionsReady()) return;
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsCancelledOrdersModal", true);
    } else {
      document.getElementById("ozonFbsCancelledOrdersModal")?.classList.remove("hidden");
    }
    ozonFbsCancelledState.rows = [];
    ozonFbsCancelledState.lastError = "";
    ozonFbsCancelledState.loading = true;
    _ozonFbsCancelledSetInfo("");
    renderOzonFbsCancelledOrdersTable();
    ozonFbsCancelledState.loading = false;
    refreshOzonFbsCancelledOrders().catch(() => {});
  }

  function closeOzonFbsCancelledOrdersModal() {
    ozonFbsCancelledState.refreshGen = Number(ozonFbsCancelledState.refreshGen || 0) + 1;
    ozonFbsCancelledState.loading = false;
    ozonFbsCancelledState.lastError = "";
    ozonFbsCancelledState.rows = [];
    const btn = document.getElementById("ozonFbsCancelledOrdersRefreshBtn");
    if (btn) btn.disabled = false;
    _ozonFbsCancelledSetInfo("");
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsCancelledOrdersModal", false);
    } else {
      document.getElementById("ozonFbsCancelledOrdersModal")?.classList.add("hidden");
    }
  }

  async function openPrintHtml(url, popupBlockedMsg) {
    const res = await fetch(url, { credentials: "same-origin" });
    if (!res.ok) {
      let detail = "";
      try {
        const data = await res.json();
        detail = detailText(data.detail);
      } catch (_) {
        detail = await res.text().catch(() => "");
      }
      throw new Error(detail || `Ошибка печати (${res.status})`);
    }
    const html = await res.text();
    const blob = new Blob([html], { type: "text/html;charset=utf-8" });
    const blobUrl = URL.createObjectURL(blob);
    const win = window.open(blobUrl, "_blank");
    if (!win) {
      URL.revokeObjectURL(blobUrl);
      throw new Error(popupBlockedMsg || "Разрешите всплывающие окна");
    }
    setTimeout(() => URL.revokeObjectURL(blobUrl), 120000);
    try { win.focus(); } catch (_e) { /* ignore */ }
    const missingCount = Number(res.headers.get("X-Feedpilot-Stickers-Missing-Count") || 0);
    if (missingCount > 0) {
      const expected = res.headers.get("X-Feedpilot-Stickers-Expected") || "?";
      const loaded = res.headers.get("X-Feedpilot-Stickers-Loaded") || "?";
      const missingRaw = String(res.headers.get("X-Feedpilot-Stickers-Missing") || "").trim();
      const reason = String(res.headers.get("X-Feedpilot-Stickers-Missing-Reason") || "").trim();
      const preview = missingRaw
        ? missingRaw.split(",").slice(0, 5).join(", ")
        : "";
      const suffix = missingCount > 5 ? ` … (+${missingCount - 5})` : "";
      const info = document.getElementById("ozonFbsSupplyDetailInfo");
      if (info) {
        const msg = Number(loaded) === 0
          ? (
            `Не удалось загрузить этикетки Ozon (${expected}). `
            + `Печать открыта в соседней вкладке.`
            + (preview ? ` Отправления: ${preview}${suffix}.` : "")
            + (reason ? ` ${reason}` : "")
          )
          : (
            `Стикеры: загружено ${loaded} из ${expected}. `
            + `Пропущено ${missingCount}`
            + (preview ? ` (${preview}${suffix})` : "")
            + `. Печать открыта в соседней вкладке.`
            + (reason ? ` ${reason}` : "")
          );
        info.hidden = false;
        info.textContent = msg;
        info.classList.toggle("is-ok", false);
        info.classList.toggle("is-warn", true);
      }
      // Server may have persisted Ozon-cancelled postings during diagnosis.
      void _ozonFbsRefreshOpenSupplyDetail();
    }
  }

  function openPickingList() {
    const sid = String(supplyDetailState.supplyId || "").trim();
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    if (!sid || !sourceId || !_ozonFbsSupplyActionsReady()) return;
    const btn = document.getElementById("ozonFbsSupplyDetailPickingBtn");
    if (btn) btn.disabled = true;
    const url =
      `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/picking-list` +
      `?source_id=${sourceId}${_ozonFbsSupplyPostingTabParam()}`;
    openPrintHtml(url, "Разрешите всплывающие окна для листа подбора")
      .catch((e) => alert(String(e.message || e)))
      .finally(() => {
        if (!_ozonFbsSupplyActionsReady()) return;
        if (btn) btn.disabled = false;
      });
  }

  function closeStickersMenu() {
    const menu = document.getElementById("ozonFbsStickersMenu");
    const caret = document.getElementById("ozonFbsSupplyDetailStickersMenuBtn");
    if (menu) menu.hidden = true;
    if (caret) caret.setAttribute("aria-expanded", "false");
  }

  function closeNewStickersMenu() {
    const menu = document.getElementById("ozonFbsNewStickersMenu");
    const caret = document.getElementById("ozonFbsSupplyDetailNewStickersMenuBtn");
    if (menu) menu.hidden = true;
    if (caret) caret.setAttribute("aria-expanded", "false");
  }

  function toggleStickersMenu(event) {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    if (!_ozonFbsSupplyActionsReady()) return;
    closeNewStickersMenu();
    const menu = document.getElementById("ozonFbsStickersMenu");
    const caret = document.getElementById("ozonFbsSupplyDetailStickersMenuBtn");
    if (!menu || !caret) return;
    const willOpen = menu.hidden;
    menu.hidden = !willOpen;
    caret.setAttribute("aria-expanded", willOpen ? "true" : "false");
  }

  function toggleNewStickersMenu(event) {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    if (!_ozonFbsSupplyActionsReady()) return;
    closeStickersMenu();
    const menu = document.getElementById("ozonFbsNewStickersMenu");
    const caret = document.getElementById("ozonFbsSupplyDetailNewStickersMenuBtn");
    if (!menu || !caret) return;
    const willOpen = menu.hidden;
    menu.hidden = !willOpen;
    caret.setAttribute("aria-expanded", willOpen ? "true" : "false");
  }

  function openStickersPrint(postingNumbers, options) {
    const opts = options && typeof options === "object" ? options : {};
    // Lookup may pass supplyId/sourceId without an open supply modal.
    const sid = String(opts.supplyId || supplyDetailState.supplyId || "").trim();
    const sourceId = opts.sourceId || supplyDetailState.sourceId || state.sourceId;
    const standalone = !!opts.supplyId;
    if (!sid || !sourceId) return;
    if (!standalone && !_ozonFbsSupplyActionsReady()) return;
    closeStickersMenu();
    closeNewStickersMenu();
    const newLabels = !!opts.newLabels;
    const oldBtn = document.getElementById("ozonFbsSupplyDetailStickersBtn");
    const newBtn = document.getElementById("ozonFbsSupplyDetailNewStickersBtn");
    const caret = document.getElementById("ozonFbsSupplyDetailStickersMenuBtn");
    const newCaret = document.getElementById("ozonFbsSupplyDetailNewStickersMenuBtn");
    // newLabels=true → primary «Стикеры» (v3); false → «Старые стикеры».
    const activeBtn = newLabels ? newBtn : oldBtn;
    const idleLabel = newLabels ? "Стикеры" : "Старые стикеры";
    const waitLabel = newLabels ? "Стикеры…" : "Старые стикеры…";
    const setBtnBusy = (busy, text) => {
      if (oldBtn) {
        oldBtn.disabled = !!busy;
        if (!newLabels) oldBtn.textContent = busy ? (text || waitLabel) : idleLabel;
      }
      if (newBtn) {
        newBtn.disabled = !!busy;
        if (newLabels) newBtn.textContent = busy ? (text || waitLabel) : idleLabel;
      }
      if (caret) caret.disabled = !!busy;
      if (newCaret) newCaret.disabled = !!busy;
    };
    setBtnBusy(true, waitLabel);
    const ids = Array.isArray(postingNumbers)
      ? postingNumbers.map((x) => String(x || "").trim()).filter(Boolean)
      : [];
    // Full print (no filter) → cover+separators.
    // Category print passes includeCoverAndSeparators: true.
    // Row «⋮» single sticker keeps labels-only (default when filtered).
    const includeCover =
      typeof opts.includeCoverAndSeparators === "boolean"
        ? opts.includeCoverAndSeparators
        : ids.length === 0;
    // Lookup standalone must not inherit posting_tab from a previously open supply.
    const tab = standalone
      ? ""
      : String(supplyDetailState.postingTab || "").trim();
    const body = {
      source_id: Number(sourceId),
      order_ids: ids,
      include_cover_and_separators: includeCover,
      new_labels: newLabels,
    };
    if (tab) body.posting_tab = tab;

    // Open print tab immediately (same user gesture) so the operator sees
    // progress there — not a blank tab after a blocking alert on the modal.
    const printWin = window.open("about:blank", "_blank");
    if (!printWin) {
      setBtnBusy(false);
      alert(newLabels
        ? "Разрешите всплывающие окна для стикеров"
        : "Разрешите всплывающие окна для старых стикеров");
      return;
    }
    try {
      printWin.document.open();
      printWin.document.write(`<!doctype html><html lang="ru"><head><meta charset="utf-8"/>
<title>${newLabels ? "Стикеры" : "Старые стикеры"} — загрузка</title>
<style>
  body{margin:0;font-family:system-ui,-apple-system,sans-serif;background:#f8fafc;color:#0f172a}
  .box{max-width:520px;margin:48px auto;padding:24px;background:#fff;border:1px solid #e2e8f0;border-radius:12px}
  h1{margin:0 0 8px;font-size:20px} p{margin:0 0 8px;line-height:1.45;color:#334155}
  #st{font-size:18px;font-weight:700;color:#1d4ed8}
  .hint{color:#64748b;font-size:14px}
</style></head><body><div class="box">
  <h1>${newLabels ? "Подготовка стикеров" : "Подготовка старых стикеров"}</h1>
  <p id="st">Загрузка…</p>
  <p class="hint">Не закрывайте эту вкладку. Диалог печати откроется здесь автоматически.</p>
</div></body></html>`);
      printWin.document.close();
    } catch (_e) { /* cross-window write may fail in rare cases */ }

    const setPrintStatus = (text) => {
      try {
        if (!printWin || printWin.closed) return;
        const el = printWin.document.getElementById("st");
        if (el) el.textContent = String(text || "");
      } catch (_e) { /* ignore */ }
    };

    const setModalNotice = (text, kind) => {
      const info = document.getElementById("ozonFbsSupplyDetailInfo");
      if (!info) return;
      const msg = String(text || "").trim();
      if (!msg) {
        if (!isSupplyDetailReadOnly()) {
          info.hidden = true;
          info.textContent = "";
          info.classList.remove("is-ok", "is-warn");
        }
        return;
      }
      info.hidden = false;
      info.textContent = msg;
      // ok → green, warn → amber, error → default red (.wb-fbs-sd-info)
      info.classList.toggle("is-ok", kind === "ok");
      info.classList.toggle("is-warn", kind === "warn");
    };

    const restoreBtn = () => {
      if (!standalone && !_ozonFbsSupplyActionsReady()) return;
      setBtnBusy(false);
    };

    const writePrintHtml = (html) => {
      if (!printWin || printWin.closed) {
        throw new Error("Вкладка печати была закрыта до готовности стикеров");
      }
      printWin.document.open();
      printWin.document.write(html);
      printWin.document.close();
      try { printWin.focus(); } catch (_e) { /* ignore */ }
    };

    const openResultHtml = async (statusMeta) => {
      const res = await fetch("/api/ozon-fbs/stickers-print/result", {
        credentials: "same-origin",
      });
      if (!res.ok) {
        let detail = "";
        try {
          const data = await res.json();
          detail = detailText(data.detail);
        } catch (_) {
          detail = await res.text().catch(() => "");
        }
        throw new Error(detail || `Ошибка печати (${res.status})`);
      }
      setPrintStatus("Формируем страницы печати…");
      const html = await res.text();
      writePrintHtml(html);

      const missingCount = Number(
        res.headers.get("X-Feedpilot-Stickers-Missing-Count")
        || statusMeta?.missing_count
        || 0
      );
      const readyWord = newLabels ? "Стикеры" : "Старые стикеры";
      if (missingCount > 0) {
        const expected = Number(
          res.headers.get("X-Feedpilot-Stickers-Expected")
          || statusMeta?.expected
          || 0
        ) || "?";
        const loaded = Number(
          res.headers.get("X-Feedpilot-Stickers-Loaded")
          || statusMeta?.loaded
          || 0
        ) || "?";
        const missingRaw = String(
          res.headers.get("X-Feedpilot-Stickers-Missing")
          || (statusMeta?.missing || []).join(",")
          || ""
        ).trim();
        const reasons = Array.isArray(statusMeta?.reasons) ? statusMeta.reasons : [];
        const preview = missingRaw
          ? missingRaw.split(",").slice(0, 5).join(", ")
          : "";
        const reasonShort = reasons[0] ? ` ${reasons[0]}` : "";
        setModalNotice(
          `${readyWord}: загружено ${loaded} из ${expected}. `
          + `Пропущено ${missingCount}`
          + (preview ? ` (${preview})` : "")
          + `. Печать открыта в соседней вкладке.`
          + reasonShort,
          Number(loaded) > 0 ? "warn" : "error"
        );
      } else {
        setModalNotice(
          `${readyWord} готовы — диалог печати открыт в соседней вкладке.`,
          "ok"
        );
      }
    };

    const poll = async () => {
      for (let i = 0; i < 7200; i += 1) {
        await new Promise((r) => setTimeout(r, i === 0 ? 400 : 1000));
        const res = await fetch("/api/ozon-fbs/stickers-print/status", {
          credentials: "same-origin",
        });
        const st = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(detailText(st.detail) || `Ошибка ${res.status}`);
        const done = Number(st.done || 0);
        const total = Number(st.total || 0);
        const msg = String(st.message || waitLabel);
        const progressText =
          total > 0
            ? `${idleLabel} ${Math.min(done, total)}/${total}`
            : (msg.length > 28 ? `${msg.slice(0, 26)}…` : msg);
        if (activeBtn) activeBtn.textContent = progressText;
        setPrintStatus(
          total > 0
            ? `Загружено ${Math.min(done, total)} из ${total}…`
            : (msg || "Загрузка…")
        );
        if (st.in_progress) continue;
        if (st.ok) {
          _ozonFbsApplyStickerCancelledRows(st.cancelled_postings);
          await openResultHtml({
            expected: st.expected_count,
            loaded: st.loaded_count,
            missing_count: Array.isArray(st.missing_posting_numbers)
              ? st.missing_posting_numbers.length
              : 0,
            missing: st.missing_posting_numbers,
            reasons: st.missing_reasons,
          });
          return;
        }
        throw new Error(String(st.error || st.message || "Не удалось загрузить стикеры"));
      }
      throw new Error("Таймаут загрузки стикеров");
    };

    (async () => {
      try {
        const res = await fetch(
          `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/stickers-print/start`,
          {
            method: "POST",
            headers: jsonHeaders(),
            body: JSON.stringify(body),
          }
        );
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(detailText(data.detail) || "Не удалось начать загрузку стикеров");
        setPrintStatus(
          newLabels
            ? "Скачивание этикеток с Ozon…"
            : "Скачивание старых этикеток с Ozon…"
        );
        await poll();
      } catch (e) {
        const err = String(e.message || e);
        setModalNotice(err, "error");
        setPrintStatus(err);
        try {
          if (printWin && !printWin.closed) {
            printWin.document.open();
            printWin.document.write(`<!doctype html><html lang="ru"><head><meta charset="utf-8"/>
<title>Ошибка печати</title></head><body style="font-family:system-ui;padding:32px">
<h1>Не удалось подготовить стикеры</h1>
<p>${String(err).replace(/[<>&]/g, (c) => ({"<":"&lt;",">":"&gt;","&":"&amp;"}[c]))}</p>
<p>Можно закрыть эту вкладку и повторить на странице поставки.</p>
</body></html>`);
            printWin.document.close();
          }
        } catch (_e) { /* ignore */ }
      } finally {
        restoreBtn();
      }
    })();
  }

  function _ozonFbsStickersCategorySetInfo(text, kind) {
    const el = document.getElementById("ozonFbsStickersCategoryInfo");
    if (!el) return;
    const msg = String(text || "").trim();
    if (!msg) {
      el.hidden = true;
      el.textContent = "";
      el.classList.remove("is-error", "is-ok");
      return;
    }
    el.hidden = false;
    el.textContent = msg;
    el.classList.toggle("is-error", kind === "error");
    el.classList.toggle("is-ok", kind === "ok");
  }

  function _ozonFbsStickersCategoryWord(n) {
    const abs = Math.abs(Number(n) || 0) % 100;
    const last = abs % 10;
    if (abs > 10 && abs < 20) return "категорий";
    if (last === 1) return "категория";
    if (last >= 2 && last <= 4) return "категории";
    return "категорий";
  }

  function _ozonFbsStickersCategorySyncUi() {
    const selected = stickersCategoryState.selected;
    const selectedCount = selected.size;
    let postingsTotal = 0;
    for (const g of stickersCategoryState.groups || []) {
      if (!selected.has(String(g.group_key || ""))) continue;
      const fromPostings = Array.isArray(g.posting_numbers)
        ? g.posting_numbers.length
        : (Array.isArray(g.order_ids) ? g.order_ids.length : 0);
      const qty = Number(g.qty);
      postingsTotal += Number.isFinite(qty) && qty > 0 ? qty : fromPostings;
    }
    const selEl = document.getElementById("ozonFbsStickersCategorySelected");
    if (selEl) {
      selEl.textContent =
        `Выбрано: ${selectedCount} ${_ozonFbsStickersCategoryWord(selectedCount)}, ` +
        `Отправлений: ${postingsTotal} шт.`;
    }
    const printBtn = document.getElementById("ozonFbsStickersCategoryPrintBtn");
    if (printBtn) printBtn.disabled = selectedCount <= 0 || stickersCategoryState.loading;
    document.querySelectorAll("#ozonFbsStickersCategoryList .wb-fbs-stickers-cat-row").forEach((row) => {
      const key = String(row.dataset.groupKey || "");
      const checked = selected.has(key);
      row.classList.toggle("is-checked", checked);
      const cb = row.querySelector('input[type="checkbox"]');
      if (cb) cb.checked = checked;
      const fillBtn = row.querySelector(".wb-fbs-stickers-cat-fill");
      if (fillBtn) fillBtn.hidden = !checked;
    });
  }

  function _ozonFbsStickersCategoryRender() {
    const box = document.getElementById("ozonFbsStickersCategoryList");
    if (!box) return;
    const groups = stickersCategoryState.groups || [];
    if (!groups.length) {
      box.innerHTML = `<div class="wb-fbs-empty">${stickersCategoryState.loading ? "Загрузка…" : "Нет товаров для печати"}</div>`;
      _ozonFbsStickersCategorySyncUi();
      return;
    }
    box.innerHTML = groups.map((g, idx) => {
      const key = esc(String(g.group_key || ""));
      const name = esc(String(g.product_name || "—"));
      const qty = Number(g.qty || 0);
      return `<div class="wb-fbs-stickers-cat-row" data-group-key="${key}" data-index="${idx}">
        <input type="checkbox" id="ozonFbsStickersCatCb_${idx}"
               onchange="onOzonFbsStickersCategoryToggleAt(${idx}, this.checked)" />
        <label for="ozonFbsStickersCatCb_${idx}">
          <span class="wb-fbs-stickers-cat-name">${name} — ${qty} шт.</span>
        </label>
        <button type="button" class="wb-fbs-stickers-cat-fill" hidden
                title="Выделить все ниже"
                aria-label="Выделить все ниже"
                onclick="ozonFbsStickersCategoryFillDownAt(${idx})">
          <svg width="14" height="14" viewBox="0 0 12 8" fill="none" aria-hidden="true">
            <path d="M1 1.5L6 6.5L11 1.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </button>
      </div>`;
    }).join("");
    _ozonFbsStickersCategorySyncUi();
  }

  function onOzonFbsStickersCategoryToggleAt(index, checked) {
    const g = (stickersCategoryState.groups || [])[Number(index)];
    const key = String((g && g.group_key) || "");
    if (!key) return;
    if (checked) stickersCategoryState.selected.add(key);
    else stickersCategoryState.selected.delete(key);
    _ozonFbsStickersCategorySyncUi();
  }

  function ozonFbsStickersCategorySelectAll() {
    stickersCategoryState.selected = new Set(
      (stickersCategoryState.groups || []).map((g) => String(g.group_key || "")).filter(Boolean)
    );
    _ozonFbsStickersCategorySyncUi();
  }

  function ozonFbsStickersCategoryClearAll() {
    stickersCategoryState.selected.clear();
    _ozonFbsStickersCategorySyncUi();
  }

  function ozonFbsStickersCategoryFillDownAt(index) {
    const groups = stickersCategoryState.groups || [];
    const start = Number(index);
    if (!Number.isFinite(start) || start < 0 || start >= groups.length) return;
    for (let i = start; i < groups.length; i += 1) {
      const gk = String(groups[i].group_key || "");
      if (gk) stickersCategoryState.selected.add(gk);
    }
    _ozonFbsStickersCategorySyncUi();
  }

  function closeStickersByCategoryModal() {
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsStickersCategoryModal", false);
    } else {
      document.getElementById("ozonFbsStickersCategoryModal")?.classList.add("hidden");
    }
    stickersCategoryState.groups = [];
    stickersCategoryState.selected = new Set();
    stickersCategoryState.loading = false;
    stickersCategoryState.newLabels = false;
    _ozonFbsStickersCategorySetInfo("");
    const box = document.getElementById("ozonFbsStickersCategoryList");
    if (box) box.innerHTML = "";
    const printBtn = document.getElementById("ozonFbsStickersCategoryPrintBtn");
    if (printBtn) printBtn.disabled = true;
    const title = document.getElementById("ozonFbsStickersCategoryTitle");
    if (title) title.textContent = "Печать стикеров по категориям";
  }

  async function openStickersByCategoryModal(options) {
    closeStickersMenu();
    closeNewStickersMenu();
    const opts = options && typeof options === "object" ? options : {};
    const newLabels = !!opts.newLabels;
    const sid = String(supplyDetailState.supplyId || "").trim();
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    if (!sid || !sourceId) return;
    if (!document.getElementById("ozonFbsStickersCategoryModal")) return;
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsStickersCategoryModal", true);
    } else {
      document.getElementById("ozonFbsStickersCategoryModal")?.classList.remove("hidden");
    }
    stickersCategoryState.groups = [];
    stickersCategoryState.selected = new Set();
    stickersCategoryState.loading = true;
    stickersCategoryState.newLabels = newLabels;
    const title = document.getElementById("ozonFbsStickersCategoryTitle");
    if (title) {
      title.textContent = newLabels
        ? "Печать стикеров по категориям"
        : "Печать старых стикеров по категориям";
    }
    _ozonFbsStickersCategorySetInfo("");
    _ozonFbsStickersCategoryRender();
    try {
      const res = await fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/sticker-groups?source_id=${sourceId}${_ozonFbsSupplyPostingTabParam()}`
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      stickersCategoryState.groups = Array.isArray(data.groups) ? data.groups : [];
      if (!stickersCategoryState.groups.length) {
        _ozonFbsStickersCategorySetInfo("В поставке нет товаров для печати", "error");
      } else {
        _ozonFbsStickersCategorySetInfo("");
      }
    } catch (e) {
      _ozonFbsStickersCategorySetInfo(String(e.message || e), "error");
    } finally {
      stickersCategoryState.loading = false;
      _ozonFbsStickersCategoryRender();
    }
  }

  function ozonFbsPrintStickersByCategory() {
    if (stickersCategoryState.loading) return;
    const selected = stickersCategoryState.selected;
    const newLabels = !!stickersCategoryState.newLabels;
    const nums = [];
    for (const g of stickersCategoryState.groups || []) {
      if (!selected.has(String(g.group_key || ""))) continue;
      const ids = Array.isArray(g.posting_numbers)
        ? g.posting_numbers
        : (Array.isArray(g.order_ids) ? g.order_ids : []);
      for (const id of ids) {
        const pn = String(id || "").trim();
        if (pn) nums.push(pn);
      }
    }
    if (!nums.length) return;
    closeStickersByCategoryModal();
    openStickersPrint(nums, {
      includeCoverAndSeparators: true,
      newLabels,
    });
  }

  document.addEventListener(
    "click",
    (e) => {
      const t = e.target;
      if (!(t instanceof Element)) return;
      const stickerBtn = t.closest("[data-ozon-action='print-sticker']");
      if (stickerBtn && stickerBtn.closest("[id^='ozonFbsRowMenu_']")) {
        const pn =
          String(stickerBtn.getAttribute("data-posting") || "").trim() ||
          String(stickerBtn.closest("[data-posting]")?.getAttribute("data-posting") || "").trim();
        if (pn) printOnePostingStickerFromDetail(e, pn);
        return;
      }
    },
    true
  );

  document.addEventListener("click", (e) => {
    const t = e.target;
    if (!(t instanceof Element)) return;
    if (!t.closest("#ozonFbsStickersSplit")) closeStickersMenu();
    if (!t.closest("#ozonFbsNewStickersSplit")) closeNewStickersMenu();
    if (
      !t.closest(".wb-fbs-row-menu-wrap") &&
      !t.closest(".wb-fbs-row-menu[id^='ozonFbsRowMenu_']")
    ) {
      closeOzonFbsRowMenus();
    }
    if (!t.closest("#ozonFbsSupplyDetailMovedAt")) {
      _ozonFbsCloseMovedToDeliveringHistory();
    }
  });

  document.addEventListener("keydown", (event) => {
    if (event.key !== "Escape") return;
    const stickersCat = document.getElementById("ozonFbsStickersCategoryModal");
    if (stickersCat && !stickersCat.classList.contains("hidden")) {
      closeStickersByCategoryModal();
    }
    _ozonFbsCloseMovedToDeliveringHistory();
  });

  function _ozonFbsSyncOwnerOnlyTsdDriverBtns() {
    // «ТСД» and «Для водителя» — owner-only (same as cancelled / quality).
    const can = typeof isTenantOwner === "function" && isTenantOwner();
    for (const id of ["ozonFbsTsdBtn", "ozonFbsDriverPageBtn"]) {
      const btn = document.getElementById(id);
      if (!btn) continue;
      btn.hidden = !can;
      btn.style.display = can ? "" : "none";
    }
  }

  function _ozonFbsSyncOwnerOnlyReturnsBtn() {
    const btn = document.getElementById("ozonFbsKizRestoreBtn");
    if (!btn) return;
    const can = typeof isTenantOwner === "function" && isTenantOwner();
    btn.hidden = !can;
    btn.style.display = can ? "" : "none";
  }

  async function initSection() {
    if (!canView()) return;
    _ozonFbsSyncOwnerOnlyTsdDriverBtns();
    _ozonFbsSyncOwnerOnlyReturnsBtn();
    _ozonFbsSyncOwnerOnlyGear();
    _ozonFbsSyncCancelledBtn();
    _ozonFbsSyncOwnerOnlyNewStickersBtn();
    _ozonFbsSyncOwnerOnlyAllCancellationsBtn();
    _ozonFbsSyncOwnerOnlyFinesBtn();
    syncTableMode();
    initColumnResizer();
    ozonFbsSupplyDetailColResizer.init();
    ozonFbsKizColResizer.init();
    ozonFbsPickColResizer.init();
    await loadSources();
    await loadPostings(true);
    syncShipAllButton();
    // Resume sync UI if a sync is already running (reload / re-enter section).
    try {
      const res = await fetch("/api/ozon-fbs/sync/status");
      const st = await res.json();
      _ozonFbsApplyManualSyncGate(st);
      if (st?.in_progress) {
        setSyncUi(true);
        showSyncInfo(String(st.message || "Синхронизация…"));
        pollSyncStatus();
      }
    } catch (_e) {
      /* ignore */
    }
    _scheduleManualSyncGatePoll();
    _ozonFbsRefreshAutoSyncGear().catch(() => {});
    // Resume split/collect busy UI so supply links stay blocked after reload.
    try {
      const res = await fetch("/api/ozon-fbs/split-multi/status");
      const st = await res.json().catch(() => ({}));
      if (st?.in_progress) {
        splitState.busy = true;
        splitState.progressText = String(st.message || "Разделение…");
        showSyncInfo(splitState.progressText);
        syncPackagingActionButtons();
        pollSplitStatus();
      }
    } catch (_e) {
      /* ignore */
    }
    try {
      const res = await fetch("/api/ozon-fbs/ship-all/status");
      const st = await res.json().catch(() => ({}));
      if (st?.in_progress) {
        collectState.busy = true;
        state.shipAllBusy = true;
        showSyncInfo(String(st.message || "Сборка…"));
        syncShipAllButton();
        pollCollectStatus();
      }
    } catch (_e) {
      /* ignore */
    }
  }

  function _ozonFbsSyncOwnerOnlyGear() {
    const btn = document.getElementById("ozonFbsSyncSettingsBtn");
    if (btn) {
      const can = typeof isTenantOwner === "function" && isTenantOwner();
      btn.hidden = !can;
      btn.style.display = can ? "" : "none";
    }
    if (typeof _ozonFbsKizSyncImportBtn === "function") {
      _ozonFbsKizSyncImportBtn();
    }
  }

  function _ozonFbsAutoSyncMarkGear(enabled) {
    const btn = document.getElementById("ozonFbsSyncSettingsBtn");
    if (btn) btn.classList.toggle("is-auto-on", !!enabled);
  }

  async function _ozonFbsRefreshAutoSyncGear() {
    if (typeof isTenantOwner === "function" && !isTenantOwner()) {
      _ozonFbsAutoSyncMarkGear(false);
      return;
    }
    try {
      const res = await fetch("/api/ozon-fbs/sync-settings");
      if (!res.ok) return;
      const data = await res.json().catch(() => ({}));
      _ozonFbsAutoSyncMarkGear(!!data.enabled);
      _ozonFbsApplyManualSyncGate(data);
    } catch (_e) {
      /* ignore */
    }
  }

  function _ozonFbsAutoSyncFormatLast(iso) {
    const text = String(iso || "").trim();
    if (!text) return "—";
    const d = new Date(text);
    if (Number.isNaN(d.getTime())) {
      return text.slice(0, 16).replace("T", " ");
    }
    return d.toLocaleString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  }

  function _ozonFbsAutoSyncSetLast(iso, autoIso) {
    const el = document.getElementById("ozonFbsAutoSyncLast");
    if (el) el.textContent = `Последняя синхронизация: ${_ozonFbsAutoSyncFormatLast(iso)}`;
    const autoEl = document.getElementById("ozonFbsAutoSyncLastAuto");
    if (autoEl) {
      autoEl.textContent = `Последняя автосинхронизация: ${_ozonFbsAutoSyncFormatLast(autoIso)}`;
    }
  }

  function _ozonFbsAutoSyncApplyEnabledUi() {
    const enabled = !!document.getElementById("ozonFbsAutoSyncEnabled")?.checked;
    const state = document.getElementById("ozonFbsAutoSyncEnabledText");
    if (state) {
      state.textContent = enabled ? "Вкл" : "Выкл";
      state.classList.toggle("is-on", enabled);
    }
    const interval = document.getElementById("ozonFbsAutoSyncInterval");
    const fromEl = document.getElementById("ozonFbsAutoSyncFrom");
    const toEl = document.getElementById("ozonFbsAutoSyncTo");
    if (interval) interval.disabled = !enabled;
    if (fromEl) fromEl.disabled = !enabled;
    if (toEl) toEl.disabled = !enabled;
  }

  function _ozonFbsManualSyncBlockApplyUi() {
    const enabled = !!document.getElementById("ozonFbsManualSyncBlockEnabled")?.checked;
    const state = document.getElementById("ozonFbsManualSyncBlockText");
    if (state) {
      state.textContent = enabled ? "Вкл" : "Выкл";
      state.classList.toggle("is-on", enabled);
    }
    const fromEl = document.getElementById("ozonFbsManualSyncBlockFrom");
    const toEl = document.getElementById("ozonFbsManualSyncBlockTo");
    if (fromEl) fromEl.disabled = !enabled;
    if (toEl) toEl.disabled = !enabled;
  }

  function onOzonFbsAutoSyncToggle() {
    _ozonFbsAutoSyncApplyEnabledUi();
  }
  window.onOzonFbsAutoSyncToggle = onOzonFbsAutoSyncToggle;

  function onOzonFbsManualSyncBlockToggle() {
    _ozonFbsManualSyncBlockApplyUi();
  }
  window.onOzonFbsManualSyncBlockToggle = onOzonFbsManualSyncBlockToggle;

  const manualSyncGateState = {
    blocked: false,
    message: "",
    timer: null,
  };

  function _ozonFbsApplyManualSyncGate(st) {
    const blocked = !!st?.manual_sync_blocked;
    const message = String(st?.manual_sync_block_message || "").trim();
    manualSyncGateState.blocked = blocked;
    manualSyncGateState.message = message;
    const syncBtn = document.getElementById("ozonFbsSyncBtn");
    if (!syncBtn) return;
    if (state.syncBusy) {
      syncBtn.disabled = true;
      return;
    }
    syncBtn.disabled = blocked;
    // Native browser tooltip on hover while Sync is blocked by settings window.
    syncBtn.title = blocked
      ? (message || "Кнопка заблокирована")
      : "";
  }

  function _scheduleManualSyncGatePoll() {
    if (manualSyncGateState.timer) clearTimeout(manualSyncGateState.timer);
    manualSyncGateState.timer = setTimeout(() => {
      fetch("/api/ozon-fbs/sync/status")
        .then((r) => r.json())
        .then((st) => _ozonFbsApplyManualSyncGate(st))
        .catch(() => {})
        .finally(() => _scheduleManualSyncGatePoll());
    }, 30000);
  }

  function _ozonFbsSyncCancelledBtn() {
    // Owner-only (same as «Все отмены»).
    const btn = document.getElementById("ozonFbsSupplyDetailCancelledBtn");
    if (!btn) return;
    const can = typeof isTenantOwner === "function" && isTenantOwner();
    btn.hidden = !can;
    btn.style.display = can ? "" : "none";
  }

  function _ozonFbsSyncOwnerOnlyNewStickersBtn() {
    // «Стикеры» (v3 package-label) доступны всем; split всегда видим.
    const split = document.getElementById("ozonFbsNewStickersSplit");
    const btn = document.getElementById("ozonFbsSupplyDetailNewStickersBtn");
    const caret = document.getElementById("ozonFbsSupplyDetailNewStickersMenuBtn");
    if (split) {
      split.hidden = false;
      split.style.display = "";
    }
    if (btn) {
      btn.hidden = false;
      btn.style.display = "";
    }
    if (caret) {
      caret.hidden = false;
      caret.style.display = "";
    }
  }

  function _ozonFbsSyncOwnerOnlyAllCancellationsBtn() {
    const btn = document.getElementById("ozonFbsAllCancellationsBtn");
    if (!btn) return;
    const can = typeof isTenantOwner === "function" && isTenantOwner();
    btn.hidden = !can;
    btn.style.display = can ? "" : "none";
  }

  function _ozonFbsSyncOwnerOnlyFinesBtn() {
    const btn = document.getElementById("ozonFbsFinesBtn");
    if (!btn) return;
    const can = typeof isTenantOwner === "function" && isTenantOwner();
    btn.hidden = !can;
    btn.style.display = can ? "" : "none";
  }

  function _ozonFbsSyncSettingsSetInfo(text, kind) {
    const el = document.getElementById("ozonFbsSyncSettingsInfo");
    if (!el) return;
    const msg = String(text || "").trim();
    el.hidden = !msg;
    el.textContent = msg;
    el.classList.toggle("is-error", !!msg && kind === "error");
    el.classList.toggle("is-ok", !!msg && kind === "ok");
  }

  const opsLogState = {
    timer: null,
    lastId: 0,
    retentionDays: 3,
    stickToTop: true,
  };

  function _opsLogFormatTime(iso) {
    const raw = String(iso || "").trim();
    if (!raw) return "—";
    const d = new Date(raw);
    if (Number.isNaN(d.getTime())) {
      const m = raw.match(/T(\d{2}:\d{2})/);
      return m ? m[1] : raw.slice(11, 16) || raw;
    }
    const hh = String(d.getHours()).padStart(2, "0");
    const mm = String(d.getMinutes()).padStart(2, "0");
    const ss = String(d.getSeconds()).padStart(2, "0");
    return `${hh}:${mm}:${ss}`;
  }

  function _opsLogEscape(s) {
    return String(s || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function _opsLogRenderRow(item) {
    const level = String(item.level || "info");
    const actor = String(item.actor_name || "").trim();
    const msg = String(item.message || "").trim();
    const actorHtml = actor
      ? ` <span class="ozon-fbs-ops-log-actor">· ${_opsLogEscape(actor)}</span>`
      : "";
    return (
      `<div class="ozon-fbs-ops-log-row${level === "error" ? " is-error" : level === "warn" ? " is-warn" : ""}" data-id="${_opsLogEscape(item.id)}">` +
      `<span class="ozon-fbs-ops-log-time">${_opsLogEscape(_opsLogFormatTime(item.created_at))}</span>` +
      `<span class="ozon-fbs-ops-log-msg">${_opsLogEscape(msg)}${actorHtml}</span>` +
      `</div>`
    );
  }

  function _opsLogSetMeta(text) {
    const el = document.getElementById("ozonFbsOpsLogMeta");
    if (el) el.textContent = String(text || "");
  }

  function _stopOpsLogPoll() {
    if (opsLogState.timer) {
      clearTimeout(opsLogState.timer);
      opsLogState.timer = null;
    }
  }

  function _scheduleOpsLogPoll(delayMs) {
    _stopOpsLogPoll();
    const modal = document.getElementById("ozonFbsSyncSettingsModal");
    if (!modal || modal.classList.contains("hidden")) return;
    opsLogState.timer = setTimeout(() => {
      pollOzonFbsOpsLog().catch(() => {});
    }, Math.max(500, Number(delayMs) || 2000));
  }

  async function pollOzonFbsOpsLog(reset) {
    const modal = document.getElementById("ozonFbsSyncSettingsModal");
    const list = document.getElementById("ozonFbsOpsLogList");
    if (!modal || modal.classList.contains("hidden") || !list) {
      _stopOpsLogPoll();
      return;
    }
    if (reset) {
      opsLogState.lastId = 0;
      opsLogState.stickToTop = true;
      list.innerHTML = `<div class="ozon-fbs-ops-log-empty">Загрузка журнала…</div>`;
    }
    try {
      const after = reset ? 0 : opsLogState.lastId;
      const res = await fetch(
        `/api/ozon-fbs/ops-log?after_id=${encodeURIComponent(after)}&limit=${after ? 100 : 200}`
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      const items = Array.isArray(data.items) ? data.items : [];
      const retention = Number(data.retention_days || data.lookback_days) || opsLogState.retentionDays;
      opsLogState.retentionDays = retention;
      _opsLogSetMeta(`хранение ${retention} дн.`);

      if (reset || after === 0) {
        if (!items.length) {
          list.innerHTML = `<div class="ozon-fbs-ops-log-empty">Пока нет записей</div>`;
        } else {
          // API returns newest-first for initial load.
          list.innerHTML = items.map(_opsLogRenderRow).join("");
        }
      } else if (items.length) {
        const empty = list.querySelector(".ozon-fbs-ops-log-empty");
        if (empty) empty.remove();
        const nearTop = list.scrollTop < 48;
        // Incremental batch is ASC; reverse so newest lands at the top.
        const html = items
          .slice()
          .reverse()
          .map(_opsLogRenderRow)
          .join("");
        list.insertAdjacentHTML("afterbegin", html);
        // Cap DOM rows to avoid unbounded growth while modal stays open.
        const rows = list.querySelectorAll(".ozon-fbs-ops-log-row");
        const maxRows = 500;
        if (rows.length > maxRows) {
          for (let i = maxRows; i < rows.length; i += 1) {
            rows[i].remove();
          }
        }
        if (nearTop || opsLogState.stickToTop) {
          list.scrollTop = 0;
        }
      }
      if (items.length) {
        let maxId = opsLogState.lastId;
        for (const it of items) {
          const lid = Number(it?.id) || 0;
          if (lid > maxId) maxId = lid;
        }
        opsLogState.lastId = maxId;
      } else if (typeof data.last_id === "number" && data.last_id > opsLogState.lastId) {
        opsLogState.lastId = data.last_id;
      }
      if (reset && items.length) {
        list.scrollTop = 0;
      }
    } catch (e) {
      if (reset) {
        list.innerHTML = `<div class="ozon-fbs-ops-log-empty">${_opsLogEscape(String(e.message || e))}</div>`;
      }
      _opsLogSetMeta("ошибка обновления");
    }
    _scheduleOpsLogPoll(2000);
  }

  async function openOzonFbsSyncSettings() {
    if (typeof isTenantOwner === "function" && !isTenantOwner()) {
      alert("Настройки синхронизации доступны только главному пользователю");
      return;
    }
    const modal = document.getElementById("ozonFbsSyncSettingsModal");
    if (!modal) return;
    modal.classList.remove("hidden");
    _ozonFbsSyncSettingsSetInfo("");
    _ozonFbsAutoSyncSetLast(null, null);
    const saveBtn = document.getElementById("ozonFbsSyncSettingsSaveBtn");
    const lookbackEl = document.getElementById("ozonFbsSyncLookback");
    const enabledEl = document.getElementById("ozonFbsAutoSyncEnabled");
    const intervalEl = document.getElementById("ozonFbsAutoSyncInterval");
    const fromEl = document.getElementById("ozonFbsAutoSyncFrom");
    const toEl = document.getElementById("ozonFbsAutoSyncTo");
    const blockEl = document.getElementById("ozonFbsManualSyncBlockEnabled");
    const blockFromEl = document.getElementById("ozonFbsManualSyncBlockFrom");
    const blockToEl = document.getElementById("ozonFbsManualSyncBlockTo");
    if (saveBtn) saveBtn.disabled = true;
    pollOzonFbsOpsLog(true).catch(() => {});
    try {
      const res = await fetch("/api/ozon-fbs/sync-settings");
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      const canEdit = data.can_edit !== false;
      if (lookbackEl) {
        const minD = Number(data.lookback_days_min) || 1;
        const maxD = Number(data.lookback_days_max) || 30;
        lookbackEl.min = String(minD);
        lookbackEl.max = String(maxD);
        let days = Number(data.lookback_days);
        if (!Number.isFinite(days)) days = 3;
        lookbackEl.value = String(Math.min(maxD, Math.max(minD, Math.round(days))));
        lookbackEl.disabled = !canEdit;
        opsLogState.retentionDays = Math.min(maxD, Math.max(minD, Math.round(days)));
        _opsLogSetMeta(`хранение ${opsLogState.retentionDays} дн.`);
      }
      if (enabledEl) {
        enabledEl.checked = !!data.enabled;
        enabledEl.disabled = !canEdit;
      }
      if (intervalEl) {
        const allowed = Array.isArray(data.allowed_intervals_minutes)
          ? data.allowed_intervals_minutes.map(Number)
          : [10, 30, 60, 120, 180, 360, 720, 1440];
        let mins = Number(data.interval_minutes);
        if (!allowed.includes(mins)) mins = 60;
        intervalEl.value = String(mins);
      }
      if (fromEl) fromEl.value = String(data.active_from || "12:00").slice(0, 5);
      if (toEl) toEl.value = String(data.active_to || "06:00").slice(0, 5);
      if (blockEl) {
        blockEl.checked = !!data.manual_sync_block_enabled;
        blockEl.disabled = !canEdit;
      }
      if (blockFromEl) {
        blockFromEl.value = String(data.manual_sync_block_from || "00:00").slice(0, 5);
      }
      if (blockToEl) {
        blockToEl.value = String(data.manual_sync_block_to || "00:00").slice(0, 5);
      }
      _ozonFbsAutoSyncSetLast(data.last_synced_at, data.last_auto_synced_at);
      _ozonFbsAutoSyncApplyEnabledUi();
      _ozonFbsManualSyncBlockApplyUi();
      if (!canEdit) {
        if (intervalEl) intervalEl.disabled = true;
        if (fromEl) fromEl.disabled = true;
        if (toEl) toEl.disabled = true;
        if (blockFromEl) blockFromEl.disabled = true;
        if (blockToEl) blockToEl.disabled = true;
      }
      _ozonFbsAutoSyncMarkGear(!!data.enabled);
      _ozonFbsApplyManualSyncGate(data);
      if (saveBtn) {
        saveBtn.disabled = !canEdit;
        saveBtn.title = canEdit ? "" : "Недостаточно прав для изменения настроек";
      }
    } catch (e) {
      _ozonFbsSyncSettingsSetInfo(String(e.message || e), "error");
      if (saveBtn) saveBtn.disabled = false;
    }
    // Resume progress UI if a status-check job is already running.
    try {
      const stRes = await fetch("/api/ozon-fbs/delivering-status-check/status");
      const st = await stRes.json().catch(() => ({}));
      if (stRes.ok && st?.in_progress) {
        _ozonFbsStatusCheckSetBusy(true);
        _ozonFbsStatusCheckShowModal();
        _ozonFbsStatusCheckRenderProgress(st);
        pollOzonFbsDeliveringStatusCheck();
      }
    } catch (_e) {
      /* ignore */
    }
  }

  function closeOzonFbsSyncSettings() {
    _stopOpsLogPoll();
    const modal = document.getElementById("ozonFbsSyncSettingsModal");
    if (modal) modal.classList.add("hidden");
  }

  async function saveOzonFbsSyncSettings() {
    if (typeof isTenantOwner === "function" && !isTenantOwner()) {
      alert("Настройки синхронизации доступны только главному пользователю");
      return;
    }
    const lookbackRaw = Number(document.getElementById("ozonFbsSyncLookback")?.value);
    const lookbackDays = Number.isFinite(lookbackRaw) ? Math.round(lookbackRaw) : 3;
    if (lookbackDays < 1 || lookbackDays > 30) {
      _ozonFbsSyncSettingsSetInfo("Укажите глубину от 1 до 30 дней", "error");
      return;
    }
    const enabled = !!document.getElementById("ozonFbsAutoSyncEnabled")?.checked;
    const intervalMinutes = Number(document.getElementById("ozonFbsAutoSyncInterval")?.value) || 30;
    const activeFrom = String(document.getElementById("ozonFbsAutoSyncFrom")?.value || "12:00").slice(0, 5);
    const activeTo = String(document.getElementById("ozonFbsAutoSyncTo")?.value || "06:00").slice(0, 5);
    const blockEnabled = !!document.getElementById("ozonFbsManualSyncBlockEnabled")?.checked;
    const blockFrom = String(document.getElementById("ozonFbsManualSyncBlockFrom")?.value || "00:00").slice(0, 5);
    const blockTo = String(document.getElementById("ozonFbsManualSyncBlockTo")?.value || "00:00").slice(0, 5);
    if (blockEnabled && blockFrom === blockTo) {
      _ozonFbsSyncSettingsSetInfo(
        "Для блокировки укажите интервал с разным временем «с» и «до» (МСК)",
        "error"
      );
      return;
    }
    const saveBtn = document.getElementById("ozonFbsSyncSettingsSaveBtn");
    if (saveBtn) saveBtn.disabled = true;
    _ozonFbsSyncSettingsSetInfo("Сохранение…");
    try {
      const res = await fetch("/api/ozon-fbs/sync-settings", {
        method: "PUT",
        headers: jsonHeaders(),
        body: JSON.stringify({
          lookback_days: lookbackDays,
          enabled,
          interval_minutes: intervalMinutes,
          active_from: activeFrom,
          active_to: activeTo,
          manual_sync_block_enabled: blockEnabled,
          manual_sync_block_from: blockFrom,
          manual_sync_block_to: blockTo,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      opsLogState.retentionDays = lookbackDays;
      _opsLogSetMeta(`хранение ${lookbackDays} дн.`);
      _ozonFbsAutoSyncSetLast(data.last_synced_at, data.last_auto_synced_at);
      _ozonFbsAutoSyncMarkGear(!!data.enabled);
      _ozonFbsApplyManualSyncGate(data);
      _ozonFbsSyncSettingsSetInfo(
        `Сохранено. Журнал хранится ${lookbackDays} дн.`,
        "ok"
      );
      pollOzonFbsOpsLog(true).catch(() => {});
    } catch (e) {
      _ozonFbsSyncSettingsSetInfo(String(e.message || e), "error");
    } finally {
      if (saveBtn) saveBtn.disabled = false;
    }
  }

  const statusCheckState = {
    busy: false,
    pollTimer: null,
    jobId: "",
  };

  function _ozonFbsStatusCheckSetBusy(busy) {
    statusCheckState.busy = !!busy;
    const btn = document.getElementById("ozonFbsDeliveringStatusCheckBtn");
    if (btn) {
      btn.disabled = !!busy;
      btn.textContent = busy ? "Проверка…" : "Проверить статус заказов";
    }
  }

  function _ozonFbsStatusCheckShowModal() {
    const modal = document.getElementById("ozonFbsStatusCheckProgressModal");
    if (modal) modal.classList.remove("hidden");
    const closeBtn = document.getElementById("ozonFbsStatusCheckProgressCloseBtn");
    if (closeBtn) closeBtn.classList.add("hidden");
    const stopBtn = document.getElementById("ozonFbsStatusCheckProgressStopBtn");
    if (stopBtn) {
      stopBtn.classList.remove("hidden");
      stopBtn.disabled = false;
      stopBtn.textContent = "Остановить";
    }
    const err = document.getElementById("ozonFbsStatusCheckProgressError");
    if (err) {
      err.textContent = "";
      err.classList.add("hidden");
    }
  }

  function closeOzonFbsStatusCheckProgress() {
    const modal = document.getElementById("ozonFbsStatusCheckProgressModal");
    if (modal) modal.classList.add("hidden");
  }

  async function stopOzonFbsDeliveringStatusCheck() {
    const stopBtn = document.getElementById("ozonFbsStatusCheckProgressStopBtn");
    if (stopBtn) {
      stopBtn.disabled = true;
      stopBtn.textContent = "Остановка…";
    }
    try {
      const res = await fetch("/api/ozon-fbs/delivering-status-check/stop", {
        method: "POST",
        headers: jsonHeaders(),
        body: "{}",
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      if (!data.ok && !data.stopping) {
        // Job not on this process / already finished — restore the button.
        if (stopBtn) {
          stopBtn.disabled = false;
          stopBtn.textContent = "Остановить";
        }
      }
      _ozonFbsSyncSettingsSetInfo(String(data.message || "Остановка…"));
    } catch (e) {
      if (stopBtn) {
        stopBtn.disabled = false;
        stopBtn.textContent = "Остановить";
      }
      _ozonFbsSyncSettingsSetInfo(String(e.message || e), "error");
    }
  }

  function _ozonFbsStatusCheckRenderProgress(st) {
    const done = Math.max(0, Number(st?.done || 0) || 0);
    const total = Math.max(0, Number(st?.total || 0) || 0);
    const pct = total > 0 ? Math.min(100, Math.round((done / total) * 100)) : 0;
    const fill = document.getElementById("ozonFbsStatusCheckProgressFill");
    if (fill) fill.style.width = `${pct}%`;
    const text = document.getElementById("ozonFbsStatusCheckProgressText");
    if (text) {
      text.textContent = total > 0 ? `${done} / ${total}` : String(st?.message || "…");
    }
    const extra = document.getElementById("ozonFbsStatusCheckProgressExtra");
    if (extra) {
      const updated = Number(st?.updated || 0) || 0;
      const errors = Number(st?.errors || 0) || 0;
      const bits = [];
      if (updated > 0) bits.push(`перенесено ${updated}`);
      if (errors > 0) bits.push(`ошибок ${errors}`);
      extra.textContent = bits.join(" · ");
    }
    const title = document.getElementById("ozonFbsStatusCheckProgressTitle");
    if (title) {
      if (!st?.in_progress) {
        title.textContent = "Проверка статусов";
      } else if (st.cancel_requested) {
        const msg = String(st?.message || "Остановка…");
        title.textContent = (msg.startsWith("Остановка") ? msg : `Остановка… ${msg}`).slice(0, 100);
      } else {
        title.textContent = String(st?.message || "Проверка статусов…").slice(0, 100) || "Проверка статусов…";
      }
    }
  }

  function _stopStatusCheckPoll() {
    if (statusCheckState.pollTimer) {
      clearTimeout(statusCheckState.pollTimer);
      statusCheckState.pollTimer = null;
    }
  }

  async function pollOzonFbsDeliveringStatusCheck() {
    try {
      const res = await fetch("/api/ozon-fbs/delivering-status-check/status");
      const st = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(st.detail) || `Ошибка ${res.status}`);
      _ozonFbsStatusCheckRenderProgress(st);
      if (st.in_progress) {
        _ozonFbsStatusCheckSetBusy(true);
        const stopBtn = document.getElementById("ozonFbsStatusCheckProgressStopBtn");
        if (stopBtn) {
          stopBtn.classList.remove("hidden");
          if (st.cancel_requested) {
            stopBtn.disabled = true;
            stopBtn.textContent = "Остановка…";
          }
        }
        statusCheckState.pollTimer = setTimeout(pollOzonFbsDeliveringStatusCheck, 800);
        return;
      }
      _stopStatusCheckPoll();
      _ozonFbsStatusCheckSetBusy(false);
      const stopBtnDone = document.getElementById("ozonFbsStatusCheckProgressStopBtn");
      if (stopBtnDone) stopBtnDone.classList.add("hidden");
      const closeBtn = document.getElementById("ozonFbsStatusCheckProgressCloseBtn");
      if (closeBtn) closeBtn.classList.remove("hidden");
      const err = document.getElementById("ozonFbsStatusCheckProgressError");
      if (err) {
        const errText = String(st.error || (!st.ok && !st.stopped && st.message) || "").trim();
        err.textContent = errText;
        err.classList.toggle("hidden", !errText || st.ok || st.stopped);
      }
      const infoKind = st.stopped ? "" : (st.ok ? "ok" : "error");
      _ozonFbsSyncSettingsSetInfo(String(st.message || "Готово"), infoKind);
      pollOzonFbsOpsLog(true).catch(() => {});
      if (state.tab === "delivering") {
        loadPostings(true).catch(() => {});
      }
    } catch (e) {
      statusCheckState.pollTimer = setTimeout(pollOzonFbsDeliveringStatusCheck, 1500);
    }
  }

  async function startOzonFbsDeliveringStatusCheck() {
    if (typeof isTenantOwner === "function" && !isTenantOwner()) {
      alert("Проверка статусов доступна только главному пользователю");
      return;
    }
    if (statusCheckState.busy) return;
    _ozonFbsStatusCheckSetBusy(true);
    _ozonFbsStatusCheckShowModal();
    _ozonFbsStatusCheckRenderProgress({
      in_progress: true,
      done: 0,
      total: 0,
      message: "Запуск…",
    });
    _ozonFbsSyncSettingsSetInfo("Запуск проверки статусов…");
    try {
      const res = await fetch("/api/ozon-fbs/delivering-status-check", {
        method: "POST",
        headers: jsonHeaders(),
        body: "{}",
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || data.ok === false) {
        throw new Error(detailText(data.detail) || data.message || `Ошибка ${res.status}`);
      }
      statusCheckState.jobId = String(data.job_id || "");
      _ozonFbsSyncSettingsSetInfo(String(data.message || "Проверка запущена…"));
      pollOzonFbsOpsLog(true).catch(() => {});
      pollOzonFbsDeliveringStatusCheck();
    } catch (e) {
      _ozonFbsStatusCheckSetBusy(false);
      const msg = String(e.message || e);
      _ozonFbsSyncSettingsSetInfo(msg, "error");
      const err = document.getElementById("ozonFbsStatusCheckProgressError");
      if (err) {
        err.textContent = msg;
        err.classList.remove("hidden");
      }
      const closeBtn = document.getElementById("ozonFbsStatusCheckProgressCloseBtn");
      if (closeBtn) closeBtn.classList.remove("hidden");
    }
  }

  function setTab(tab) {
    const next = String(tab || "awaiting_packaging");
    state.tab = OZON_FBS_HIDDEN_TABS.has(next) ? "awaiting_packaging" : next;
    state.selected.clear();
    document.querySelectorAll("#ozonFbsTabs .wb-fbs-tab").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.tab === state.tab);
    });
    updateBottomBar();
    loadPostings(true);
  }

  function onSourceChange() {
    const sel = document.getElementById("ozonFbsSourceSelect");
    state.sourceId = sel?.value ? Number(sel.value) : null;
    if (typeof syncFbsSourcePickerLabel === "function") syncFbsSourcePickerLabel("ozonFbsSource");
    state.selected.clear();
    loadPostings(true);
  }

  function onSearchInput() {
    const el = document.getElementById("ozonFbsSearchFilter");
    state.search = (el?.value || "").trim();
    clearTimeout(state.searchTimer);
    state.searchTimer = setTimeout(() => loadPostings(true), 300);
  }

  function changePage(delta) {
    state.page = Math.max(1, state.page + Number(delta || 0));
    loadPostings(false);
  }

  function changePageSize(val) {
    state.pageSize = Number(val) || 50;
    loadPostings(true);
  }

  function closeSyncInfo() {
    const box = document.getElementById("ozonFbsSyncInfo");
    if (!box) return;
    box.hidden = true;
    box.classList.remove("is-ok", "is-error");
    const textEl = document.getElementById("ozonFbsSyncInfoText");
    const palletsEl = document.getElementById("ozonFbsSyncInfoPallets");
    const multiEl = document.getElementById("ozonFbsSyncInfoMulti");
    if (textEl) textEl.textContent = "";
    if (palletsEl) {
      palletsEl.innerHTML = "";
      palletsEl.hidden = true;
    }
    if (multiEl) {
      multiEl.innerHTML = "";
      multiEl.hidden = true;
    }
  }

  /** Mirror WB FBS sync banner: green/red + per-source rows + pallet/box lines. */
  function syncSourceRows(st, msg) {
    const sources = Array.isArray(st?.sources) ? st.sources : [];
    if (!sources.length) return null;
    if (st?.in_progress) return sources;
    const hasIssues = (st?.errors || []).length || /ошибк/i.test(String(msg || ""));
    if (!hasIssues) return null;
    const bad = sources.filter((row) => {
      const status = String(row?.status || "");
      return status === "error" || status === "stopped";
    });
    return bad.length ? bad : null;
  }

  function showSyncInfo(
    text,
    kind = "",
    palletSummary = null,
    sourceRows = null,
    palletSummaryError = "",
    multiSummary = null,
  ) {
    const info = document.getElementById("ozonFbsSyncInfo");
    if (!info) return;
    const msg = String(text || "").trim();
    const textEl = document.getElementById("ozonFbsSyncInfoText");
    const palletsEl = document.getElementById("ozonFbsSyncInfoPallets");
    const multiEl = document.getElementById("ozonFbsSyncInfoMulti");
    const rowsSrc = Array.isArray(sourceRows) ? sourceRows : [];

    if (textEl) {
      if (rowsSrc.length) {
        const rowsHtml = rowsSrc.map((row) => {
          const name = esc(row?.name || `Источник ${row?.source_id || ""}`);
          const line = esc(row?.message || "");
          const st = String(row?.status || "");
          let cls = "wb-fbs-sync-info-source-row";
          if (st === "error") cls += " is-error";
          else if (st === "done") cls += " is-ok";
          else if (st === "stopped") cls += " is-stopped";
          return `<div class="${cls}"><span class="wb-fbs-sync-info-source-name">${name}</span>: ${line}</div>`;
        }).join("");
        const showSummary = msg && /готово|остановлено/i.test(msg);
        if (showSummary) {
          textEl.innerHTML = `<div class="wb-fbs-sync-info-summary">${esc(msg)}</div>${rowsHtml}`;
        } else {
          textEl.innerHTML = rowsHtml;
        }
      } else {
        textEl.textContent = msg;
      }
    }

    const rows = Array.isArray(palletSummary) ? palletSummary : [];
    const palletErr = String(palletSummaryError || "").trim();
    const canShowPallets = kind === "ok" || /готово/i.test(msg) || /остановлено/i.test(msg);
    if (palletsEl) {
      const parts = [];
      if (palletErr && canShowPallets) {
        parts.push(
          `<div class="wb-fbs-sync-info-pallet-error" role="alert">${esc(palletErr)}</div>`
        );
      }
      if (rows.length && canShowPallets) {
        parts.push(
          ...rows.map((row) => {
            const name = esc(row?.name || `Источник ${row?.source_id || ""}`);
            const label = esc(
              row?.pallets_label
              || `${Number(row?.pallets || 0).toFixed(2).replace(".", ",")} паллета`
            );
            return `<div class="wb-fbs-sync-info-pallet-row">${name} — ${label}</div>`;
          })
        );
      }
      if (parts.length) {
        palletsEl.innerHTML = parts.join("");
        palletsEl.hidden = false;
      } else {
        palletsEl.innerHTML = "";
        palletsEl.hidden = true;
      }
    }

    if (multiEl) {
      const multiRows = Array.isArray(multiSummary) ? multiSummary : [];
      const canShowMulti = kind === "ok" || /готово/i.test(msg);
      const visible = multiRows.filter((row) => Number(row?.multi_count || 0) > 0);
      if (canShowMulti && visible.length) {
        multiEl.innerHTML = visible.map((row) => {
          const name = esc(row?.name || `Источник ${row?.source_id || ""}`);
          const n = Number(row.multi_count || 0);
          return `<div class="wb-fbs-sync-info-multi-row">${name} — мультизаказов: ${esc(String(n))}</div>`;
        }).join("");
        multiEl.hidden = false;
      } else if (canShowMulti && state.sourceId && multiAwaitingCount() > 0) {
        multiEl.innerHTML =
          `<div class="wb-fbs-sync-info-multi-row">Мультизаказов: ${esc(String(multiAwaitingCount()))}</div>`;
        multiEl.hidden = false;
      } else {
        multiEl.innerHTML = "";
        multiEl.hidden = true;
      }
    }

    info.hidden = !(
      msg ||
      rowsSrc.length ||
      (palletErr && canShowPallets) ||
      (multiEl && !multiEl.hidden)
    );
    info.classList.toggle("is-error", kind === "error");
    info.classList.toggle("is-ok", kind === "ok");
    info.style.color = "";
  }

  function setSyncUi(running) {
    const stopBtn = document.getElementById("ozonFbsStopBtn");
    const syncBtn = document.getElementById("ozonFbsSyncBtn");
    if (stopBtn) stopBtn.classList.toggle("hidden", !running);
    state.syncBusy = Boolean(running);
    if (syncBtn) {
      if (running) {
        syncBtn.disabled = true;
      } else {
        _ozonFbsApplyManualSyncGate(manualSyncGateState.blocked
          ? { manual_sync_blocked: true, manual_sync_block_message: manualSyncGateState.message }
          : { manual_sync_blocked: false });
      }
    }
    syncPackagingActionButtons();
  }

  async function pollSyncStatus() {
    try {
      const res = await fetch("/api/ozon-fbs/sync/status");
      const st = await res.json();
      _ozonFbsApplyManualSyncGate(st);
      const running = Boolean(st.in_progress);
      setSyncUi(running);
      const msg = String(st.message || "");
      const errs = (st.errors || [])
        .map((e) => String(e || "").trim())
        .filter((e) => e)
        .slice(0, 2)
        .join("; ");
      const text = `${msg}${errs ? " · " + errs : ""}`.trim();
      let kind = "";
      if (!running) {
        if ((st.errors || []).length || /ошибк/i.test(msg)) kind = "error";
        else if (/готово/i.test(msg) || /остановлено/i.test(msg)) kind = "ok";
      }
      const pallets = (!running && Array.isArray(st.pallet_summary))
        ? st.pallet_summary
        : null;
      const palletErr = !running ? String(st.pallet_summary_error || "").trim() : "";
      const multiSummary = (!running && Array.isArray(st.multi_summary))
        ? st.multi_summary
        : null;
      const sourceRows = syncSourceRows(st, msg);
      if (running && sourceRows) showSyncInfo(text, kind, null, sourceRows);
      else showSyncInfo(text, kind, pallets, sourceRows, palletErr, multiSummary);
      if (running) {
        state.syncPollTimer = setTimeout(pollSyncStatus, 1500);
      } else {
        clearTimeout(state.syncPollTimer);
        state.syncPollTimer = null;
        await loadPostings(false);
      }
    } catch (e) {
      setSyncUi(false);
    }
  }

  async function syncOzonFbs() {
    if (manualSyncGateState.blocked) {
      showSyncInfo(
        manualSyncGateState.message || "Кнопка заблокирована",
        "error"
      );
      _ozonFbsApplyManualSyncGate({
        manual_sync_blocked: true,
        manual_sync_block_message: manualSyncGateState.message,
      });
      return;
    }
    setSyncUi(true);
    showSyncInfo("Запуск синхронизации…");
    try {
      const res = await fetch("/api/ozon-fbs/sync", {
        method: "POST",
        headers: jsonHeaders(),
        body: "{}",
      });
      const data = await res.json();
      _ozonFbsApplyManualSyncGate(data);
      if (!res.ok || !data.ok) {
        showSyncInfo(data.message || data.detail || "Ошибка синхронизации", "error");
        setSyncUi(false);
        return;
      }
      showSyncInfo(data.message || "Синхронизация запущена");
      pollSyncStatus();
    } catch (e) {
      showSyncInfo("Ошибка сети", "error");
      setSyncUi(false);
    }
  }

  async function stopOzonFbsSync() {
    try {
      await fetch("/api/ozon-fbs/sync/stop", { method: "POST", headers: jsonHeaders() });
      showSyncInfo("Остановка…");
    } catch (e) {
      /* noop */
    }
  }

  async function openDetail(postingNumber) {
    if (!state.sourceId || !postingNumber) return;
    state.detailPosting = String(postingNumber);
    const modal = document.getElementById("ozonFbsDetailModal");
    const title = document.getElementById("ozonFbsDetailTitle");
    const meta = document.getElementById("ozonFbsDetailMeta");
    const body = document.getElementById("ozonFbsDetailBody");
    if (title) title.innerHTML = `Отправление ${formatOzonPostingNumberHtml(postingNumber)}`;
    if (meta) meta.textContent = "Загрузка…";
    if (body) body.textContent = "";
    if (modal) modal.classList.remove("hidden");
    try {
      const res = await fetch(
        `/api/ozon-fbs/postings/${encodeURIComponent(postingNumber)}/detail?source_id=${state.sourceId}`
      );
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || "Не найдено");
      state.detailPayload = data;
      if (meta) {
        meta.textContent = `${data.tab_label || data.tab || ""} · ${data.status || ""} · ${data.warehouse_label || ""}`;
      }
      const products = Array.isArray(data.products) ? data.products : [];
      const lines = products.map((p) => {
        const name = esc(p.name || p.offer_id || "Товар");
        const qty = esc(p.quantity || 1);
        return `<div style="margin-bottom:8px"><strong>${name}</strong> — ${qty} шт.</div>`;
      });
      if (body) {
        body.innerHTML = lines.join("") || "<div>Нет данных о товарах</div>";
      }
      const shipBtn = document.getElementById("ozonFbsDetailShipBtn");
      const stickerBtn = document.getElementById("ozonFbsDetailStickerBtn");
      if (shipBtn) shipBtn.hidden = !data.can_ship;
      if (stickerBtn) stickerBtn.hidden = !data.can_print_label;
    } catch (e) {
      if (meta) meta.textContent = e.message || "Ошибка";
    }
  }

  function closeDetailModal() {
    const modal = document.getElementById("ozonFbsDetailModal");
    if (modal) modal.classList.add("hidden");
    state.detailPosting = null;
    state.detailPayload = null;
  }

  async function shipCurrent() {
    if (!state.sourceId || !state.detailPosting) return;
    const btn = document.getElementById("ozonFbsDetailShipBtn");
    if (btn) btn.disabled = true;
    try {
      const res = await fetch(
        `/api/ozon-fbs/postings/${encodeURIComponent(state.detailPosting)}/ship?source_id=${state.sourceId}`,
        { method: "POST", headers: jsonHeaders() }
      );
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || "Ошибка сборки");
      const resultPns = Array.isArray(data.posting_numbers) ? data.posting_numbers : [];
      if (resultPns.length > 1) {
        alert(`Собрано с разбиением: ${resultPns.length} отправлений`);
      }
      closeDetailModal();
      await loadPostings(false);
    } catch (e) {
      alert(e.message || "Ошибка");
    } finally {
      if (btn) btn.disabled = false;
    }
  }

  function printCurrentSticker() {
    if (!state.sourceId || !state.detailPosting) return;
    // Detail card «Этикетка» → same v3 PDF as lookup ⋮ without local supply.
    const url =
      `/api/ozon-fbs/postings/stickers-print?source_id=${state.sourceId}` +
      `&posting_numbers=${encodeURIComponent(state.detailPosting)}`;
    openPrintPdf(url, "Разрешите всплывающие окна для стикера")
      .catch((e) => alert(String(e.message || e)));
  }

  /* ── Selection → new / existing local supply ── */

  const selectionState = {
    mode: "", // create | add
    preview: null,
    postingNumbers: [],
    sourceId: null,
    busy: false,
  };

  function closeSelectionSupplyModal() {
    if (selectionState.busy) return;
    document.getElementById("ozonFbsSelectionSupplyModal")?.classList.add("hidden");
    selectionState.mode = "";
    selectionState.preview = null;
    selectionState.postingNumbers = [];
    selectionState.sourceId = null;
    const err = document.getElementById("ozonFbsSelectionSupplyErr");
    if (err) {
      err.hidden = true;
      err.textContent = "";
    }
  }

  function selectedPostingNumbers() {
    if (isSuppliesTab() || state.tab !== "awaiting_packaging") return [];
    return [...state.selected].map((x) => String(x || "").trim()).filter(Boolean);
  }

  async function selectionPreview(sourceId, postingNumbers) {
    const res = await fetch("/api/ozon-fbs/selection/preview", {
      method: "POST",
      headers: jsonHeaders(),
      body: JSON.stringify({ source_id: sourceId, posting_numbers: postingNumbers }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(detailText(data.detail) || "Не удалось проверить выбор");
    return data;
  }

  function selectionTraitsHtml(traits) {
    const t = traits || {};
    const chips = [];
    if (t.warehouse_name) chips.push(t.warehouse_name);
    else if (t.warehouse_id != null) chips.push(`Склад ${t.warehouse_id}`);
    if (!chips.length) return "";
    return `<div class="wb-fbs-selection-traits">${chips.map((c) =>
      `<span class="wb-fbs-selection-trait">${esc(c)}</span>`
    ).join("")}</div>`;
  }

  function renderSelectionCreateModal(preview) {
    const title = document.getElementById("ozonFbsSelectionSupplyTitle");
    const lead = document.getElementById("ozonFbsSelectionSupplyLead");
    const body = document.getElementById("ozonFbsSelectionSupplyBody");
    const confirmBtn = document.getElementById("ozonFbsSelectionSupplyConfirmBtn");
    if (title) title.textContent = "Новая поставка";
    if (confirmBtn) {
      confirmBtn.textContent = "Создать";
      confirmBtn.disabled = false;
    }
    const count = Number(preview.order_count || 0);
    const splitNote = shipSplitPreviewNote(preview);
    if (lead) {
      lead.textContent =
        `Отправления будут собраны на Ozon и попадут в новую локальную поставку на «Ожидают отгрузки» (${count} шт.).`
        + (splitNote ? ` ${splitNote}` : "");
    }
    const name = String(preview.suggested_name || "");
    const existing = new Set(
      (Array.isArray(preview.existing_names) ? preview.existing_names : [])
        .map((x) => String(x || "").trim()).filter(Boolean)
    );
    const conflict = existing.has(name.trim());
    if (body) {
      body.innerHTML = `
        ${selectionTraitsHtml(preview.traits)}
        <div class="wb-fbs-collect-mgt-field">
          <label for="ozonFbsSelectionSupplyName">Название поставки</label>
          <input type="text" id="ozonFbsSelectionSupplyName" value="${esc(name)}"
                 autocomplete="off" oninput="ozonFbsSelectionSupplyNameInput(this)" />
          <p class="wb-fbs-collect-mgt-warn" id="ozonFbsSelectionSupplyNameWarn" ${conflict ? "" : "hidden"}>
            Поставка с таким названием уже есть — измените название.
          </p>
        </div>`;
    }
  }

  function renderSelectionAddModal(preview) {
    const title = document.getElementById("ozonFbsSelectionSupplyTitle");
    const lead = document.getElementById("ozonFbsSelectionSupplyLead");
    const body = document.getElementById("ozonFbsSelectionSupplyBody");
    const confirmBtn = document.getElementById("ozonFbsSelectionSupplyConfirmBtn");
    if (title) title.textContent = "Добавить к существующей";
    if (confirmBtn) confirmBtn.textContent = "Добавить";
    const count = Number(preview.order_count || 0);
    const supplies = Array.isArray(preview.compatible_supplies) ? preview.compatible_supplies : [];
    const splitNote = shipSplitPreviewNote(preview);
    if (lead) {
      const base = supplies.length
        ? `Выберите открытую поставку для ${count} отпр. Показаны совместимые по складу.`
        : `Для ${count} отпр. нет совместимых открытых поставок.`;
      lead.textContent = splitNote ? `${base} ${splitNote}` : base;
    }
    if (!body) return;
    if (!supplies.length) {
      body.innerHTML = `
        <div class="wb-fbs-collect-mgt-auto">
          Нет открытых поставок с тем же складом. Создайте новую поставку или выберите другой набор.
        </div>`;
      if (confirmBtn) confirmBtn.disabled = true;
      return;
    }
    if (confirmBtn) confirmBtn.disabled = false;
    // No warehouse trait chips — list already filtered by warehouse.
    body.innerHTML = `
      <div class="wb-fbs-collect-mgt-field">
        <label>Поставка</label>
        <div class="wb-fbs-collect-mgt-supplies">
          ${supplies.map((s, si) => {
            const sid = String(s.supply_id || "");
            const sname = String(s.name || sid);
            const meta = [
              s.is_empty ? "пустая" : null,
              `${Number(s.orders_count || 0)} отпр.`,
            ].filter(Boolean).join(" · ");
            return `
              <label class="wb-fbs-collect-mgt-supply">
                <span class="wb-fbs-collect-mgt-supply-main">
                  <input type="radio" name="ozonFbsSelectionSupplyPick" value="${esc(sid)}" ${si === 0 ? "checked" : ""} />
                  <span class="wb-fbs-collect-mgt-supply-name">${esc(sname)}</span>
                </span>
                <span class="wb-fbs-collect-mgt-supply-meta">${esc(meta)}</span>
              </label>`;
          }).join("")}
        </div>
      </div>`;
  }

  function selectionSupplyNameInput(input) {
    const preview = selectionState.preview;
    const existing = new Set(
      (Array.isArray(preview?.existing_names) ? preview.existing_names : [])
        .map((x) => String(x || "").trim()).filter(Boolean)
    );
    const warn = document.getElementById("ozonFbsSelectionSupplyNameWarn");
    if (!warn) return;
    const name = String(input?.value || "").trim();
    warn.hidden = !(name && existing.has(name));
  }

  function showSelectionErrors(errors, mode) {
    const list = Array.isArray(errors) ? errors.filter(Boolean) : [];
    showCollectResult({
      ok: false,
      message: mode === "create"
        ? "Нельзя создать поставку из выбранных отправлений."
        : "Нельзя добавить выбранные отправления в одну поставку.",
      errors: list,
    });
  }

  async function openNewSupplyFromSelection() {
    if (selectionState.busy) return;
    if (state.tab !== "awaiting_packaging") return;
    const nums = selectedPostingNumbers();
    if (!nums.length) {
      alert("Выберите отправления во вкладке «Ожидают сборки»");
      return;
    }
    const sourceId = state.sourceId;
    if (!sourceId) {
      alert("Выберите источник OZON ФБС");
      return;
    }
    selectionState.busy = true;
    selectionState.sourceId = sourceId;
    const errEl = document.getElementById("ozonFbsSelectionSupplyErr");
    if (errEl) { errEl.hidden = true; errEl.textContent = ""; }
    try {
      const preview = await selectionPreview(sourceId, nums);
      if (state.sourceId !== sourceId) return;
      if (!preview.ok) {
        showSelectionErrors(preview.errors, "create");
        return;
      }
      selectionState.mode = "create";
      selectionState.preview = preview;
      selectionState.postingNumbers = Array.isArray(preview.posting_numbers)
        ? preview.posting_numbers
        : nums;
      renderSelectionCreateModal(preview);
      document.getElementById("ozonFbsSelectionSupplyModal")?.classList.remove("hidden");
    } catch (e) {
      selectionState.sourceId = null;
      alert(e.message || String(e));
    } finally {
      selectionState.busy = false;
    }
  }

  async function openAddToExistingSupply() {
    if (selectionState.busy) return;
    if (state.tab !== "awaiting_packaging") return;
    const nums = selectedPostingNumbers();
    if (!nums.length) {
      alert("Выберите отправления во вкладке «Ожидают сборки»");
      return;
    }
    const sourceId = state.sourceId;
    if (!sourceId) {
      alert("Выберите источник OZON ФБС");
      return;
    }
    selectionState.busy = true;
    selectionState.sourceId = sourceId;
    const errEl = document.getElementById("ozonFbsSelectionSupplyErr");
    if (errEl) { errEl.hidden = true; errEl.textContent = ""; }
    try {
      const preview = await selectionPreview(sourceId, nums);
      if (state.sourceId !== sourceId) return;
      if (!preview.ok) {
        showSelectionErrors(preview.errors, "add");
        return;
      }
      if (!preview.has_open_supplies) {
        alert("Нет открытых поставок. Создайте новую поставку.");
        return;
      }
      selectionState.mode = "add";
      selectionState.preview = preview;
      selectionState.postingNumbers = Array.isArray(preview.posting_numbers)
        ? preview.posting_numbers
        : nums;
      renderSelectionAddModal(preview);
      document.getElementById("ozonFbsSelectionSupplyModal")?.classList.remove("hidden");
    } catch (e) {
      selectionState.sourceId = null;
      alert(e.message || String(e));
    } finally {
      selectionState.busy = false;
    }
  }

  async function confirmSelectionSupply() {
    if (selectionState.busy) return;
    if (!selectionState.preview) return;
    if (state.tab !== "awaiting_packaging") {
      alert("Действие доступно только на вкладке «Ожидают сборки»");
      return;
    }
    const mode = selectionState.mode;
    const errEl = document.getElementById("ozonFbsSelectionSupplyErr");
    const confirmBtn = document.getElementById("ozonFbsSelectionSupplyConfirmBtn");
    const sourceId = selectionState.sourceId;
    const postingNumbers = selectionState.postingNumbers || [];
    if (!sourceId || !postingNumbers.length) return;

    let payload = { source_id: sourceId, posting_numbers: postingNumbers };
    let url = "";
    if (mode === "create") {
      const name = String(document.getElementById("ozonFbsSelectionSupplyName")?.value || "").trim();
      const existing = new Set(
        (selectionState.preview.existing_names || [])
          .map((x) => String(x || "").trim()).filter(Boolean)
      );
      if (!name) {
        if (errEl) { errEl.hidden = false; errEl.textContent = "Укажите название поставки"; }
        return;
      }
      if (existing.has(name)) {
        if (errEl) {
          errEl.hidden = false;
          errEl.textContent = `Поставка «${name}» уже есть — измените название`;
        }
        return;
      }
      payload.name = name;
      url = "/api/ozon-fbs/selection/create-supply";
    } else if (mode === "add") {
      const checked = document.querySelector('input[name="ozonFbsSelectionSupplyPick"]:checked');
      const supplyId = String(checked?.value || "").trim();
      if (!supplyId) {
        if (errEl) { errEl.hidden = false; errEl.textContent = "Выберите поставку"; }
        return;
      }
      payload.supply_id = supplyId;
      url = "/api/ozon-fbs/selection/add-to-supply";
    } else {
      return;
    }

    selectionState.busy = true;
    if (confirmBtn) confirmBtn.disabled = true;
    if (errEl) { errEl.hidden = true; errEl.textContent = ""; }
    showSyncInfo("Сборка выбранных отправлений…");
    try {
      const res = await fetch(url, {
        method: "POST",
        headers: jsonHeaders(),
        body: JSON.stringify(payload),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || "Ошибка операции");
      if (!data.ok && !(Number(data.added || 0) > 0)) {
        const errs = Array.isArray(data.errors) ? data.errors : [];
        if (errEl) {
          errEl.hidden = false;
          errEl.textContent = errs.length ? errs.join("\n") : (data.message || "Операция не выполнена");
        }
        return;
      }
      selectionState.busy = false;
      closeSelectionSupplyModal();
      clearSelection();
      showCollectResult(data);
      showSyncInfo(data.message || "Готово");
      if (data.goto_awaiting_deliver) setTab("awaiting_deliver");
      else await loadPostings(true);
    } catch (e) {
      const msg = e.message || String(e);
      if (errEl) {
        errEl.hidden = false;
        errEl.textContent = msg;
      } else {
        alert(msg);
      }
    } finally {
      selectionState.busy = false;
      if (confirmBtn) confirmBtn.disabled = false;
    }
  }

  function todayIsoDate() {
    const d = new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }

  function closeShipmentsModal() {
    document.getElementById("ozonFbsShipmentsModal")?.classList.add("hidden");
    shipmentsState.forming = false;
  }

  const driverModalState = {
    supplyId: null,
    sourceId: null,
    drivers: [],
    loading: false,
    saving: false,
  };

  function _ozonFbsDriverHasAssignment(supply) {
    const row = supply || {};
    const did = Number(row.driver_id || 0);
    const name = String(row.driver_name || "").trim();
    return Boolean(row.has_driver) || (did > 0 && !!name);
  }

  function _ozonFbsSupplyDriverLabel(supply) {
    if (!_ozonFbsDriverHasAssignment(supply)) return "не назначен";
    const name = String(supply?.driver_name || "").trim();
    return name || "не назначен";
  }

  function _ozonFbsSyncDriverBtn() {
    const btn = document.getElementById("ozonFbsSupplyDetailDriverBtn");
    if (!btn) return;
    btn.classList.toggle("is-ok", _ozonFbsDriverHasAssignment(supplyDetailState.supply));
    // Re-apply delivering lock so managers keep a green indicator but cannot open.
    _ozonFbsSyncSupplyDetailToneOnlySplits(_ozonFbsKizPickLockedAsToneOnly());
  }

  function _ozonFbsDriverSetVisible(show) {
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsDriverModal", !!show);
      return;
    }
    const modal = document.getElementById("ozonFbsDriverModal");
    if (modal) modal.classList.toggle("hidden", !show);
  }

  function _ozonFbsDriverSetInfo(text, kind) {
    const el = document.getElementById("ozonFbsDriverInfo");
    if (!el) return;
    const msg = String(text || "").trim();
    el.hidden = !msg;
    el.textContent = msg;
    el.classList.toggle("is-ok", !!msg && kind === "ok");
    el.classList.toggle("is-error", !!msg && kind === "error");
  }

  function _ozonFbsDriverById(driverId) {
    const id = Number(driverId || 0);
    return (driverModalState.drivers || []).find((d) => Number(d.id || 0) === id) || null;
  }

  function _ozonFbsFillDriverSelect(selectedId) {
    const sel = document.getElementById("ozonFbsDriverSelect");
    if (!sel) return;
    const current = String(selectedId || sel.value || "");
    const opts = ['<option value="">— Выберите водителя —</option>'];
    (driverModalState.drivers || []).forEach((d) => {
      const id = String(d.id || "");
      const name = String(d.full_name || "").trim() || `Водитель ${id}`;
      opts.push(`<option value="${esc(id)}">${esc(name)}</option>`);
    });
    sel.innerHTML = opts.join("");
    if (current && [...sel.options].some((o) => o.value === current)) {
      sel.value = current;
    } else {
      sel.value = "";
    }
  }

  function _ozonFbsFillDriverVehicles(selectedPlate) {
    const field = document.getElementById("ozonFbsDriverVehicleField");
    const sel = document.getElementById("ozonFbsDriverVehicleSelect");
    const driver = _ozonFbsDriverById(document.getElementById("ozonFbsDriverSelect")?.value);
    if (!field || !sel) return;
    if (!driver) {
      field.hidden = true;
      sel.innerHTML = '<option value="">— Выберите водителя —</option>';
      sel.disabled = true;
      return;
    }
    const vehicles = Array.isArray(driver.vehicles) ? driver.vehicles : [];
    const plates = vehicles
      .map((v) => String(v?.number || "").trim())
      .filter(Boolean);
    field.hidden = false;
    if (!plates.length) {
      sel.innerHTML = '<option value="">— Нет гос. номеров у водителя —</option>';
      sel.disabled = true;
      sel.value = "";
      return;
    }
    const want = String(selectedPlate || "").trim();
    const opts = plates.length > 1
      ? ['<option value="">— Выберите гос. номер —</option>']
      : [];
    plates.forEach((num) => {
      opts.push(`<option value="${esc(num)}">${esc(num)}</option>`);
    });
    sel.innerHTML = opts.join("");
    sel.disabled = false;
    if (want && plates.some((n) => n.toLowerCase() === want.toLowerCase())) {
      const match = plates.find((n) => n.toLowerCase() === want.toLowerCase());
      sel.value = match;
    } else if (plates.length === 1) {
      sel.value = plates[0];
    } else {
      sel.value = "";
    }
  }

  function onOzonFbsDriverChange() {
    _ozonFbsFillDriverVehicles("");
    _ozonFbsDriverSetInfo("");
  }

  async function openOzonFbsDriverModal() {
    const sid = String(supplyDetailState.supplyId || "").trim();
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    if (!sid || !sourceId) {
      alert("Откройте поставку");
      return;
    }
    if (!supplyDetailState.ordersReady) return;
    driverModalState.supplyId = sid;
    driverModalState.sourceId = sourceId;
    driverModalState.loading = true;
    driverModalState.saving = false;
    const saveBtn = document.getElementById("ozonFbsDriverSaveBtn");
    const driverSel = document.getElementById("ozonFbsDriverSelect");
    if (saveBtn) saveBtn.disabled = true;
    if (driverSel) {
      driverSel.innerHTML = '<option value="">Загрузка…</option>';
      driverSel.disabled = true;
    }
    _ozonFbsFillDriverVehicles("");
    _ozonFbsDriverSetInfo("Загрузка справочника водителей…");
    _ozonFbsDriverSetVisible(true);
    try {
      const res = await fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/driver?source_id=${sourceId}`,
        { headers: jsonHeaders() }
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || "Не удалось загрузить водителя");
      driverModalState.drivers = Array.isArray(data.drivers) ? data.drivers : [];
      const assignedId = Number(data.driver_id || 0) || Number(supplyDetailState.supply?.driver_id || 0);
      const assignedPlate = String(data.vehicle_number || supplyDetailState.supply?.vehicle_number || "").trim();
      if (driverSel) driverSel.disabled = false;
      _ozonFbsFillDriverSelect(assignedId > 0 ? assignedId : "");
      _ozonFbsFillDriverVehicles(assignedPlate);
      if (!driverModalState.drivers.length) {
        _ozonFbsDriverSetInfo("В справочнике нет водителей. Добавьте их в Поставки → Настройки → Водители.", "error");
      } else {
        _ozonFbsDriverSetInfo("");
      }
    } catch (e) {
      if (driverSel) driverSel.disabled = false;
      _ozonFbsDriverSetInfo(e.message || String(e), "error");
    } finally {
      driverModalState.loading = false;
      if (saveBtn) saveBtn.disabled = false;
    }
  }

  function closeOzonFbsDriverModal() {
    _ozonFbsDriverSetVisible(false);
    driverModalState.supplyId = null;
    driverModalState.sourceId = null;
    driverModalState.saving = false;
    _ozonFbsDriverSetInfo("");
  }

  async function saveOzonFbsDriver() {
    const sid = String(driverModalState.supplyId || supplyDetailState.supplyId || "").trim();
    const sourceId = driverModalState.sourceId || supplyDetailState.sourceId || state.sourceId;
    const driverSel = document.getElementById("ozonFbsDriverSelect");
    const vehSel = document.getElementById("ozonFbsDriverVehicleSelect");
    const saveBtn = document.getElementById("ozonFbsDriverSaveBtn");
    const driverId = Number(driverSel?.value || 0);
    const plate = String(vehSel?.disabled ? "" : (vehSel?.value || "")).trim();
    if (!sid || !sourceId) return;
    if (!driverId) {
      _ozonFbsDriverSetInfo("Выберите водителя", "error");
      driverSel?.focus();
      return;
    }
    const driver = _ozonFbsDriverById(driverId);
    const plates = (driver?.vehicles || []).map((v) => String(v?.number || "").trim()).filter(Boolean);
    if (plates.length > 1 && !plate) {
      _ozonFbsDriverSetInfo("Выберите гос. номер", "error");
      vehSel?.focus();
      return;
    }
    if (saveBtn) saveBtn.disabled = true;
    driverModalState.saving = true;
    _ozonFbsDriverSetInfo("Сохраняем…");
    try {
      const res = await fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/driver`,
        {
          method: "PUT",
          headers: jsonHeaders(),
          body: JSON.stringify({
            source_id: sourceId,
            driver_id: driverId,
            vehicle_number: plate,
            posting_tab: String(supplyDetailState.postingTab || state.tab || "").trim(),
          }),
        }
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || "Не удалось сохранить");
      if (supplyDetailState.supply && String(supplyDetailState.supply.supply_id || "") === sid) {
        supplyDetailState.supply.driver_id = Number(data.driver_id || driverId);
        supplyDetailState.supply.driver_name = String(data.driver_name || "").trim();
        supplyDetailState.supply.vehicle_number = String(data.vehicle_number || plate).trim();
        supplyDetailState.supply.has_driver = true;
      }
      const listRow = (state.items || []).find((it) => String(it?.supply_id || "").trim() === sid);
      if (listRow && isDeliveringSuppliesTab()) {
        listRow.driver_id = Number(data.driver_id || driverId);
        listRow.driver_name = String(data.driver_name || "").trim();
        listRow.vehicle_number = String(data.vehicle_number || plate).trim();
        listRow.has_driver = _ozonFbsDriverHasAssignment(listRow);
        renderSuppliesTable(state.items);
      }
      _ozonFbsSyncDriverBtn();
      _ozonFbsSyncMoveDeliveringEnabled();
      _ozonFbsDriverSetInfo("Сохранено", "ok");
      setTimeout(() => {
        if (driverModalState.supplyId === sid) closeOzonFbsDriverModal();
      }, 350);
    } catch (e) {
      _ozonFbsDriverSetInfo(e.message || String(e), "error");
    } finally {
      driverModalState.saving = false;
      if (saveBtn) saveBtn.disabled = false;
    }
  }

  function _ozonFbsContainersModalOpen() {
    const modal = document.getElementById("ozonFbsContainersModal");
    return Boolean(modal && !modal.classList.contains("hidden"));
  }

  function _ozonFbsContainersSetVisible(show) {
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsContainersModal", !!show);
      return;
    }
    const modal = document.getElementById("ozonFbsContainersModal");
    if (modal) modal.classList.toggle("hidden", !show);
  }

  function _ozonFbsContainersSetInfo(text, kind) {
    const el = document.getElementById("ozonFbsContainersInfo");
    if (!el) return;
    const msg = String(text || "").trim();
    if (!msg) {
      el.hidden = true;
      el.textContent = "";
      el.classList.remove("is-ok", "is-error");
      return;
    }
    el.hidden = false;
    el.textContent = msg;
    el.classList.toggle("is-ok", kind === "ok");
    el.classList.toggle("is-error", kind === "error");
  }

  function _ozonFbsContainersAmountValue() {
    const input = document.getElementById("ozonFbsContainersAmount");
    let n = Number(input?.value || 1);
    if (!Number.isFinite(n)) n = 1;
    n = Math.max(1, Math.min(100, Math.round(n)));
    if (input) input.value = String(n);
    return n;
  }

  function ozonFbsContainersStep(delta) {
    if (containersState.busy) return;
    const input = document.getElementById("ozonFbsContainersAmount");
    if (!input) return;
    const next = _ozonFbsContainersAmountValue() + Number(delta || 0);
    input.value = String(Math.max(1, Math.min(100, next)));
  }

  function _ozonFbsContainersListParams(sourceId) {
    const params = new URLSearchParams({ source_id: String(sourceId) });
    if (containersState.showScAccepted) {
      params.set("include_sc_accepted", "1");
    }
    if (containersState.onlyThisSupply) {
      params.set("only_this_supply", "1");
    }
    return params;
  }

  function _ozonFbsContainersSyncShowScUi() {
    const busy = !!containersState.busy || !!containersState.loading;
    const scCb = document.getElementById("ozonFbsContainersShowScAccepted");
    if (scCb) {
      scCb.checked = !!containersState.showScAccepted;
      scCb.disabled = busy;
      const scLabel = scCb.closest(".ozon-fbs-containers-show-sc");
      if (scLabel) scLabel.classList.toggle("is-wait-rows", busy);
    }
    const supplyCb = document.getElementById("ozonFbsContainersOnlyThisSupply");
    if (supplyCb) {
      supplyCb.checked = !!containersState.onlyThisSupply;
      supplyCb.disabled = busy;
      const supplyLabel = supplyCb.closest(".ozon-fbs-containers-show-sc");
      if (supplyLabel) supplyLabel.classList.toggle("is-wait-rows", busy);
    }
  }

  function onOzonFbsContainersShowScChange() {
    if (containersState.busy || containersState.loading) return;
    const cb = document.getElementById("ozonFbsContainersShowScAccepted");
    containersState.showScAccepted = !!cb?.checked;
    loadOzonFbsContainers();
  }

  function onOzonFbsContainersOnlyThisSupplyChange() {
    if (containersState.busy || containersState.loading) return;
    const cb = document.getElementById("ozonFbsContainersOnlyThisSupply");
    containersState.onlyThisSupply = !!cb?.checked;
    loadOzonFbsContainers();
  }

  function _ozonFbsContainersSyncBusyUi() {
    const busy = !!containersState.busy || !!containersState.loading;
    const createBtn = document.getElementById("ozonFbsContainersCreateBtn");
    const refreshBtn = document.getElementById("ozonFbsContainersRefreshBtn");
    const amount = document.getElementById("ozonFbsContainersAmount");
    const sortSel = document.getElementById("ozonFbsContainersSortType");
    if (createBtn) {
      createBtn.disabled = busy;
      createBtn.textContent = containersState.busy ? "Создание…" : "Создать";
    }
    if (refreshBtn) {
      refreshBtn.disabled = busy;
      refreshBtn.textContent = containersState.loading ? "Обновление…" : "Обновить";
    }
    if (amount) amount.disabled = busy;
    if (sortSel) sortSel.disabled = busy;
    document.querySelectorAll("#ozonFbsContainersModal .wb-fbs-trbx-stepper-btn").forEach((btn) => {
      btn.disabled = busy;
    });
    _ozonFbsContainersSyncShowScUi();
  }

  function renderOzonFbsContainersTable(items) {
    const tbody = document.getElementById("ozonFbsContainersTbody");
    if (!tbody) return;
    const rows = Array.isArray(items) ? items : [];
    containersState.items = rows;
    if (!rows.length) {
      tbody.innerHTML = `<tr><td colspan="4" class="wb-fbs-trbx-boxes-empty">Нет активных грузомест</td></tr>`;
      return;
    }
    const busy = containersState.busy ? "disabled" : "";
    const expandedId = String(containersState.expandedId || "");
    tbody.innerHTML = rows.map((c) => {
      const cid = String(c.container_id || "").trim();
      const num = Number(c.container_number || 0);
      const ordersOzon = Number(
        c.order_count_ozon != null ? c.order_count_ozon : c.order_count || 0
      );
      const cancelledN = Number(c.cancelled_removed_count || 0);
      const ordersLabel = cancelledN > 0
        ? `${ordersOzon} (отмененные: ${cancelledN})`
        : String(ordersOzon);
      const status = esc(c.status_label || c.status || "—");
      const sortLabel = esc(c.sort_type_label || "");
      const cargoLabel = esc(c.cargo_type_label || "");
      const meta = [sortLabel, cargoLabel].filter(Boolean).join(" · ");
      const canDelete = c.can_delete === true;
      const canPrint = c.can_print !== false;
      const canApprove = c.can_approve === true;
      const locallyArchived = c.locally_archived === true;
      const isScAccepted = c.is_sc_accepted === true
        || /^(acceptance_in_progress|finished)$/i.test(String(c.status || "").trim());
      const isOwner = typeof isTenantOwner === "function" && isTenantOwner();
      // Local archive/restore — owner only; never touches Ozon.
      const canLocalArchive = isOwner && !locallyArchived && !isScAccepted;
      const canLocalRestore = isOwner && locallyArchived;
      const safeJs = JSON.stringify(cid);
      const isOpen = expandedId && expandedId === cid;
      const caret = isOpen ? "▾" : "▸";
      const detailHtml = isOpen ? _ozonFbsContainersDetailHtml(cid) : "";
      const statusHtml = locallyArchived
        ? `${status} <span class="ozon-fbs-containers-local-arch">Скрыто локально</span>`
        : status;
      const localArchiveBtn = canLocalArchive
        ? `<button type="button" class="wb-fbs-trbx-box-archive" title="В завершённые (локально, без Ozon)"
                    aria-label="В завершённые ${esc(cid)}" ${busy ? "disabled" : ""}
                    onclick='archiveOzonFbsContainerLocally(${safeJs})'>⤵</button>`
        : "";
      const localRestoreBtn = canLocalRestore
        ? `<button type="button" class="wb-fbs-trbx-box-restore" title="Вернуть в активные"
                    aria-label="Вернуть ${esc(cid)}" ${busy ? "disabled" : ""}
                    onclick='restoreOzonFbsContainerLocally(${safeJs})'>⤴</button>`
        : "";
      return `<tr class="ozon-fbs-containers-row${isOpen ? " is-expanded" : ""}${locallyArchived ? " is-local-archived" : ""}" data-cid="${esc(cid)}">
        <td>
          <div class="ozon-fbs-containers-main">
            <button type="button" class="ozon-fbs-containers-expand"
                    aria-expanded="${isOpen ? "true" : "false"}"
                    aria-label="${isOpen ? "Свернуть" : "Состав и даты"} ${esc(cid)}"
                    title="Состав и даты"
                    onclick='toggleOzonFbsContainerDetails(${safeJs})'>${caret}</button>
            <div class="ozon-fbs-containers-main-text">
              <div class="ozon-fbs-containers-id">${esc(cid)}</div>
              <div class="ozon-fbs-containers-sub">№ ${esc(String(num || "—"))}${meta ? ` · ${meta}` : ""}</div>
            </div>
          </div>
        </td>
        <td class="ozon-fbs-containers-col-orders">${esc(ordersLabel)}</td>
        <td class="ozon-fbs-containers-col-meta">${statusHtml}</td>
        <td class="wb-fbs-trbx-boxes-col-act">
          <div class="wb-fbs-trbx-box-actions">
            <button type="button" class="wb-fbs-trbx-box-approve" title="Подтвердить состав грузоместа"
                    aria-label="Подтвердить ${esc(cid)}" ${(busy || !canApprove) ? "disabled" : ""}
                    onclick='approveOzonFbsContainer(${safeJs})'>✓</button>
            <button type="button" class="wb-fbs-trbx-box-print" title="Печать этикетки"
                    aria-label="Печать ${esc(cid)}" ${(busy || !canPrint) ? "disabled" : ""}
                    onclick='printOzonFbsContainerLabel(${safeJs})'>⎙</button>
            <button type="button" class="wb-fbs-trbx-box-delete" title="Удалить грузоместо"
                    aria-label="Удалить ${esc(cid)}" ${(busy || !canDelete) ? "disabled" : ""}
                    onclick='deleteOzonFbsContainer(${safeJs})'>✕</button>
            ${localArchiveBtn}${localRestoreBtn}
          </div>
        </td>
      </tr>
      <tr class="ozon-fbs-containers-detail-row${isOpen ? "" : " is-collapsed"}" data-detail-for="${esc(cid)}" ${isOpen ? "" : "hidden"}>
        <td colspan="4">${detailHtml || (isOpen ? `<div class="ozon-fbs-containers-detail-loading">Загрузка…</div>` : "")}</td>
      </tr>`;
    }).join("");
  }

  function _ozonFbsContainersDetailHtml(cid) {
    const key = String(cid || "").trim();
    if (!key) return "";
    if (String(containersState.detailsLoadingId || "") === key && !containersState.detailsCache[key]) {
      return `<div class="ozon-fbs-containers-detail-loading">Загрузка…</div>`;
    }
    const data = containersState.detailsCache[key];
    if (!data) {
      return `<div class="ozon-fbs-containers-detail-loading">Загрузка…</div>`;
    }
    if (data.error) {
      return `<div class="ozon-fbs-containers-detail-error">${esc(data.error)}</div>`;
    }
    const timeline = Array.isArray(data.timeline) ? data.timeline : [];
    const postings = Array.isArray(data.postings) ? data.postings : [];
    const timelineHtml = timeline.length
      ? `<ul class="ozon-fbs-containers-timeline">${timeline.map((ev) => {
          const label = esc(ev.label || ev.key || "—");
          const when = esc(ev.at_display || "—");
          const hint = ev.hint ? `<div class="ozon-fbs-containers-timeline-hint">${esc(ev.hint)}</div>` : "";
          return `<li><span class="ozon-fbs-containers-timeline-label">${label}</span><span class="ozon-fbs-containers-timeline-at">${when}</span>${hint}</li>`;
        }).join("")}</ul>`
      : `<div class="ozon-fbs-containers-detail-empty">Нет дат</div>`;
    const count = postings.length;
    const cancelledN = Number(data.cancelled_removed_count || 0);
    const compositionTitle = cancelledN > 0
      ? `Состав (${count}) (отмененные: ${cancelledN})`
      : `Состав (${count})`;
    let compositionNote = "";
    if (!count) {
      const rowMeta = (containersState.items || []).find(
        (x) => String(x.container_id || "").trim() === key
      ) || {};
      const ozonOrders = Number(
        rowMeta.order_count_ozon != null ? rowMeta.order_count_ozon : rowMeta.order_count || 0
      );
      if (ozonOrders > 0 && data.ozon_fetch_ok === false) {
        compositionNote = `<div class="ozon-fbs-containers-detail-empty">В Ozon указано заказов: ${esc(String(ozonOrders))}, но состав сейчас не удалось загрузить. Откройте снова.</div>`;
      } else if (ozonOrders > 0) {
        compositionNote = `<div class="ozon-fbs-containers-detail-empty">В Ozon указано заказов: ${esc(String(ozonOrders))}, список отправлений в ответе пуст.</div>`;
      } else {
        compositionNote = `<div class="ozon-fbs-containers-detail-empty">В ГМ пока нет заказов</div>`;
      }
    }
    const safeJs = JSON.stringify(key);
    const xlsLink = count
      ? `<a href="#" class="ozon-fbs-containers-composition-xls"
            title="Скачать состав в Excel"
            aria-label="Скачать состав ГМ ${esc(key)} в Excel"
            onclick='event.preventDefault(); downloadOzonFbsContainerComposition(${safeJs}); return false;'>↓</a>`
      : "";
    return `<div class="ozon-fbs-containers-detail">
      <div class="ozon-fbs-containers-detail-block">
        <div class="ozon-fbs-containers-detail-title">Даты и статус</div>
        ${timelineHtml}
      </div>
      <div class="ozon-fbs-containers-detail-block">
        <div class="ozon-fbs-containers-detail-title ozon-fbs-containers-composition-head">
          <span>${esc(compositionTitle)}</span>${xlsLink}
        </div>
        ${compositionNote}
      </div>
    </div>`;
  }

  async function downloadOzonFbsContainerComposition(containerId) {
    const cid = String(containerId || "").trim();
    const sid = String(containersState.supplyId || "").trim();
    const sourceId = containersState.sourceId;
    if (!cid || !sid || !sourceId) return;
    const row = (containersState.items || []).find(
      (x) => String(x.container_id || "").trim() === cid
    ) || {};
    const params = new URLSearchParams({
      source_id: String(sourceId),
      status: String(row.status || ""),
      status_label: String(row.status_label || ""),
      warehouse_date: String(row.warehouse_date || ""),
      created_at: String(row.created_at || ""),
      container_number: String(row.container_number || 0),
    });
    const cached = containersState.detailsCache[cid];
    if (cached && !cached.error) {
      if (cached.warehouse_date) params.set("warehouse_date", String(cached.warehouse_date));
      if (cached.created_at) params.set("created_at", String(cached.created_at));
      if (cached.status) params.set("status", String(cached.status));
      if (cached.status_label) params.set("status_label", String(cached.status_label));
      if (cached.container_number != null) {
        params.set("container_number", String(cached.container_number || 0));
      }
    }
    _ozonFbsContainersSetInfo("Скачиваем состав ГМ…");
    try {
      const res = await fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/containers/${encodeURIComponent(cid)}/composition.xlsx?${params}`,
        { headers: jsonHeaders() }
      );
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(detailText(data.detail) || data.message || `Ошибка ${res.status}`);
      }
      const blob = await res.blob();
      let fname = `GM-${cid}-sostav.xlsx`;
      const cd = res.headers.get("Content-Disposition") || "";
      const m = /filename\*?=(?:UTF-8''|")?([^\";]+)/i.exec(cd);
      if (m && m[1]) {
        try {
          fname = decodeURIComponent(m[1].replace(/"/g, "").trim());
        } catch (_) {
          fname = m[1].replace(/"/g, "").trim() || fname;
        }
      }
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = fname;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1500);
      _ozonFbsContainersSetInfo(`Скачан файл ${fname}`);
    } catch (e) {
      _ozonFbsContainersSetInfo(e.message || String(e), false);
    }
  }

  async function toggleOzonFbsContainerDetails(containerId) {
    const cid = String(containerId || "").trim();
    if (!cid) return;
    if (String(containersState.expandedId || "") === cid) {
      containersState.expandedId = null;
      renderOzonFbsContainersTable(containersState.items);
      return;
    }
    containersState.expandedId = cid;
    renderOzonFbsContainersTable(containersState.items);
    if (containersState.detailsCache[cid] && !containersState.detailsCache[cid].error) {
      return;
    }
    await loadOzonFbsContainerDetails(cid);
  }

  async function loadOzonFbsContainerDetails(containerId) {
    const cid = String(containerId || "").trim();
    const sid = String(containersState.supplyId || "").trim();
    const sourceId = containersState.sourceId;
    if (!cid || !sid || !sourceId) return null;
    const row = (containersState.items || []).find(
      (x) => String(x.container_id || "").trim() === cid
    ) || {};
    containersState.detailsLoadingId = cid;
    renderOzonFbsContainersTable(containersState.items);
    try {
      const params = new URLSearchParams({
        source_id: String(sourceId),
        status: String(row.status || ""),
        status_label: String(row.status_label || ""),
        warehouse_date: String(row.warehouse_date || ""),
        created_at: String(row.created_at || ""),
        container_number: String(row.container_number || 0),
      });
      const res = await fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/containers/${encodeURIComponent(cid)}/details?${params}`,
        { headers: jsonHeaders() }
      );
      const data = await res.json().catch(() => ({}));
      if (!_ozonFbsContainersModalOpen() || String(containersState.supplyId || "") !== sid) {
        return null;
      }
      if (!res.ok || data.ok === false) {
        throw new Error(detailText(data.detail) || data.message || `Ошибка ${res.status}`);
      }
      containersState.detailsCache[cid] = data;
      return data;
    } catch (e) {
      containersState.detailsCache[cid] = { error: e.message || String(e) };
      return null;
    } finally {
      if (String(containersState.detailsLoadingId || "") === cid) {
        containersState.detailsLoadingId = null;
      }
      if (String(containersState.expandedId || "") === cid) {
        renderOzonFbsContainersTable(containersState.items);
      }
    }
  }

  async function loadOzonFbsContainers({ keepInfo = false } = {}) {
    const sid = String(containersState.supplyId || supplyDetailState.supplyId || "").trim();
    const sourceId = containersState.sourceId || supplyDetailState.sourceId || state.sourceId;
    if (!sid || !sourceId) return null;
    containersState.loading = true;
    _ozonFbsContainersSyncBusyUi();
    if (!keepInfo) _ozonFbsContainersSetInfo("Загружаем грузоместа из Ozon…");
    try {
      const params = _ozonFbsContainersListParams(sourceId);
      const res = await fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/containers?${params}`,
        { headers: jsonHeaders() }
      );
      const data = await res.json().catch(() => ({}));
      if (!_ozonFbsContainersModalOpen() || String(containersState.supplyId || "") !== sid) {
        return null;
      }
      if (!res.ok || data.ok === false) {
        throw new Error(detailText(data.detail) || data.message || `Ошибка ${res.status}`);
      }
      containersState.warehouseId = data.warehouse_id || null;
      // Keep expand only if same id still present; refresh details on next open.
      containersState.detailsCache = {};
      if (containersState.expandedId) {
        const still = (data.items || []).some(
          (x) => String(x.container_id || "").trim() === String(containersState.expandedId)
        );
        if (!still) containersState.expandedId = null;
      }
      renderOzonFbsContainersTable(data.items || []);
      if (containersState.expandedId) {
        loadOzonFbsContainerDetails(containersState.expandedId);
      }
      _ozonFbsSyncContainersBtn();
      _ozonFbsSyncMoveDeliveringEnabled();
      const total = Number(data.total || (data.items || []).length || 0);
      const wh = String(data.warehouse_name || "").trim();
      if (!keepInfo) {
        const scHint = containersState.showScAccepted ? " · включая принятые на СЦ" : "";
        const supplyHint = containersState.onlyThisSupply ? " · только ГМ этой поставки" : "";
        _ozonFbsContainersSetInfo(
          total
            ? `Активных грузомест: ${total}${scHint}${supplyHint}${wh ? ` · ${wh}` : ""}`
            : `Нет активных грузомест${scHint}${supplyHint}${wh ? ` · ${wh}` : ""}`,
          "ok"
        );
      }
      return data;
    } catch (e) {
      if (_ozonFbsContainersModalOpen()) {
        _ozonFbsContainersSetInfo(e.message || String(e), "error");
        if (!containersState.items.length) {
          renderOzonFbsContainersTable([]);
        }
      }
      return null;
    } finally {
      containersState.loading = false;
      _ozonFbsContainersSyncBusyUi();
    }
  }

  function openOzonFbsContainersModal() {
    const sid = String(supplyDetailState.supplyId || "").trim();
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    if (!sid || !sourceId) {
      alert("Откройте поставку");
      return;
    }
    containersState.supplyId = sid;
    containersState.sourceId = sourceId;
    containersState.items = [];
    containersState.busy = false;
    containersState.showScAccepted = false;
    containersState.onlyThisSupply = false;
    containersState.expandedId = null;
    containersState.detailsCache = {};
    containersState.detailsLoadingId = null;
    const amount = document.getElementById("ozonFbsContainersAmount");
    if (amount) amount.value = "1";
    const sortSel = document.getElementById("ozonFbsContainersSortType");
    if (sortSel) sortSel.value = "sort";
    _ozonFbsContainersSyncShowScUi();
    renderOzonFbsContainersTable([]);
    _ozonFbsContainersSetInfo("");
    _ozonFbsContainersSetVisible(true);
    _ozonFbsContainersSyncBusyUi();
    _ozonFbsRenderCargoSummary(
      "ozonFbsContainersCargo",
      (supplyDetailState.supply || {}).cargo_summary,
    );
    loadOzonFbsContainers();
  }

  function closeOzonFbsContainersModal() {
    if (containersState.busy) return;
    if (_ozonFbsContainerApproveResolver) {
      closeOzonFbsContainerApproveModal(false);
    } else {
      _ozonFbsContainerApproveSetVisible(false);
    }
    _ozonFbsContainersSetVisible(false);
    containersState.supplyId = null;
    containersState.items = [];
    containersState.expandedId = null;
    containersState.detailsCache = {};
    containersState.detailsLoadingId = null;
    _ozonFbsContainersSetInfo("");
    _ozonFbsRenderCargoSummary("ozonFbsContainersCargo", null);
    _ozonFbsSyncContainersBtn();
    _ozonFbsSyncMoveDeliveringEnabled();
  }

  function refreshOzonFbsContainers() {
    if (containersState.busy || containersState.loading) return;
    loadOzonFbsContainers();
  }

  async function createOzonFbsContainers() {
    const sid = String(containersState.supplyId || "").trim();
    const sourceId = containersState.sourceId;
    if (!sid || !sourceId || containersState.busy) return;
    const amount = _ozonFbsContainersAmountValue();
    const sortType = String(document.getElementById("ozonFbsContainersSortType")?.value || "sort");
    containersState.busy = true;
    _ozonFbsContainersSyncBusyUi();
    _ozonFbsContainersSetInfo("Создаём грузоместа в Ozon…");
    try {
      const res = await fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/containers`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json", ...jsonHeaders() },
          body: JSON.stringify({
            source_id: sourceId,
            containers_count: amount,
            sort_type: sortType,
            cargo_type: "pallet",
          }),
        }
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok || data.ok === false) {
        throw new Error(detailText(data.detail) || data.message || `Ошибка ${res.status}`);
      }
      _ozonFbsContainersSetInfo(
        String(data.message || `Создано: ${data.created || amount}`),
        "ok"
      );
      await loadOzonFbsContainers({ keepInfo: true });
    } catch (e) {
      _ozonFbsContainersSetInfo(e.message || String(e), "error");
    } finally {
      containersState.busy = false;
      _ozonFbsContainersSyncBusyUi();
    }
  }

  async function _ozonFbsContainerLocalArchiveToggle(containerId, restore) {
    const sid = String(containersState.supplyId || "").trim();
    const sourceId = containersState.sourceId;
    const cid = String(containerId || "").trim();
    if (!sid || !sourceId || !cid || containersState.busy) return;
    if (typeof isTenantOwner === "function" && !isTenantOwner()) return;
    const doRestore = !!restore;
    const path = doRestore ? "local-restore" : "local-archive";
    const waitMsg = doRestore
      ? "Возвращаем грузоместо в активные…"
      : "Переносим грузоместо в завершённые…";
    containersState.busy = true;
    _ozonFbsContainersSyncBusyUi();
    renderOzonFbsContainersTable(containersState.items);
    _ozonFbsContainersSetInfo(waitMsg);
    try {
      const res = await fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/containers/${path}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json", ...jsonHeaders() },
          body: JSON.stringify({
            source_id: sourceId,
            container_id: Number(cid) || cid,
          }),
        }
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok || data.ok === false) {
        throw new Error(
          detailText(data.detail) || data.message || `Ошибка ${res.status}`
        );
      }
      _ozonFbsContainersSetInfo(
        String(
          data.message
          || (doRestore ? "Возвращено в активные" : "Перенесено в завершённые")
        ),
        "ok"
      );
      await loadOzonFbsContainers({ keepInfo: true });
    } catch (e) {
      _ozonFbsContainersSetInfo(e.message || String(e), "error");
      await loadOzonFbsContainers({ keepInfo: true });
    } finally {
      containersState.busy = false;
      _ozonFbsContainersSyncBusyUi();
      renderOzonFbsContainersTable(containersState.items);
    }
  }

  function archiveOzonFbsContainerLocally(containerId) {
    return _ozonFbsContainerLocalArchiveToggle(containerId, false);
  }

  function restoreOzonFbsContainerLocally(containerId) {
    return _ozonFbsContainerLocalArchiveToggle(containerId, true);
  }

  async function deleteOzonFbsContainer(containerId) {
    const sid = String(containersState.supplyId || "").trim();
    const sourceId = containersState.sourceId;
    const cid = String(containerId || "").trim();
    if (!sid || !sourceId || !cid || containersState.busy) return;
    if (!window.confirm(`Удалить грузоместо ${cid}?`)) return;
    containersState.busy = true;
    _ozonFbsContainersSyncBusyUi();
    renderOzonFbsContainersTable(containersState.items);
    _ozonFbsContainersSetInfo("Удаляем грузоместо…");
    try {
      const res = await fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/containers/delete`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json", ...jsonHeaders() },
          body: JSON.stringify({
            source_id: sourceId,
            container_ids: [Number(cid) || cid],
          }),
        }
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok || data.ok === false) {
        const errs = Array.isArray(data.errors) ? data.errors : [];
        const errLine = errs.map((e) => e.error || e).filter(Boolean).join("; ");
        throw new Error(detailText(data.detail) || errLine || data.message || `Ошибка ${res.status}`);
      }
      _ozonFbsContainersSetInfo(String(data.message || "Удалено"), "ok");
      await loadOzonFbsContainers({ keepInfo: true });
      if (typeof window._ozonFbsContainerInvalidate === "function") {
        void window._ozonFbsContainerInvalidate();
      }
    } catch (e) {
      _ozonFbsContainersSetInfo(e.message || String(e), "error");
      await loadOzonFbsContainers({ keepInfo: true });
    } finally {
      containersState.busy = false;
      _ozonFbsContainersSyncBusyUi();
      renderOzonFbsContainersTable(containersState.items);
    }
  }

  let _ozonFbsContainerApproveResolver = null;

  function _ozonFbsContainerApproveSetVisible(show) {
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsContainerApproveModal", !!show);
      return;
    }
    const modal = document.getElementById("ozonFbsContainerApproveModal");
    if (modal) modal.classList.toggle("hidden", !show);
  }

  function closeOzonFbsContainerApproveModal(ok) {
    _ozonFbsContainerApproveSetVisible(false);
    const resolve = _ozonFbsContainerApproveResolver;
    _ozonFbsContainerApproveResolver = null;
    if (typeof resolve === "function") resolve(!!ok);
  }

  function _ozonFbsContainerApproveBuildBody({
    cid,
    total,
    unbound,
    hasUnbound,
    hasSyncErrors,
    syncCount,
    syncErrors,
    forceOnly,
    forceMessage,
  }) {
    const parts = [];
    if (forceOnly) {
      parts.push(
        `<div class="ozon-fbs-container-approve-sync">`
        + `<div>${esc(String(forceMessage || "Есть ошибки синхронизации с Ozon."))}</div>`
        + `<div>Подтвердить всё равно?</div>`
        + `</div>`
      );
      return parts.join("");
    }

    if (hasUnbound) {
      parts.push(
        `<div class="ozon-fbs-container-approve-warn" role="alert">`
        + `<p><strong>Внимание:</strong> `
        + `${esc(String(unbound))} из ${esc(String(total || "?"))} заказов поставки `
        + `ещё не привязаны ни к одному грузоместу.</p>`
        + `<p>Кнопка «Да» станет доступна, когда все заказы поставки будут привязаны к грузоместам.</p>`
        + `</div>`
      );
    } else {
      parts.push(
        `<p class="ozon-fbs-container-approve-text">`
        + `Вы собираетесь подтвердить грузоместо. `
        + `После подтверждения изменить грузоместо будет нельзя. `
        + `Вы уверены?`
        + `</p>`
      );
    }

    if (hasSyncErrors) {
      const samples = Array.isArray(syncErrors) ? syncErrors : [];
      const sampleItems = samples
        .slice(0, 3)
        .map((e) => {
          const pn = esc(String(e.posting_number || "?"));
          const err = esc(String(e.error || "ошибка"));
          return `<li><code>${pn}</code>: ${err}</li>`;
        })
        .join("");
      parts.push(
        `<div class="ozon-fbs-container-approve-sync">`
        + `<div>Есть ошибки синхронизации с Ozon `
        + `(${esc(String(syncCount))}). Состав на портале может отличаться.</div>`
        + (sampleItems
          ? `<ul class="ozon-fbs-container-approve-sync-list">${sampleItems}</ul>`
          : "")
        + (hasUnbound ? "" : `<div>Подтвердить всё равно?</div>`)
        + `</div>`
      );
    }

    return parts.join("");
  }

  function openOzonFbsContainerApproveModal(opts) {
    const options = opts && typeof opts === "object" ? opts : {};
    const body = document.getElementById("ozonFbsContainerApproveBody");
    const yesBtn = document.getElementById("ozonFbsContainerApproveYesBtn");
    const title = document.getElementById("ozonFbsContainerApproveTitle");
    if (body) body.innerHTML = _ozonFbsContainerApproveBuildBody(options);
    if (title) {
      title.textContent = options.forceOnly
        ? "Подтверждение с ошибками синхронизации"
        : "Подтверждение грузоместа";
    }
    const allowYes = !options.hasUnbound;
    if (yesBtn) {
      yesBtn.disabled = !allowYes;
      yesBtn.title = allowYes
        ? ""
        : "Сначала привяжите все заказы поставки к грузоместам";
    }
    if (_ozonFbsContainerApproveResolver) {
      const prev = _ozonFbsContainerApproveResolver;
      _ozonFbsContainerApproveResolver = null;
      prev(false);
    }
    return new Promise((resolve) => {
      _ozonFbsContainerApproveResolver = resolve;
      _ozonFbsContainerApproveSetVisible(true);
      const focusBtn = allowYes
        ? yesBtn
        : document.querySelector("#ozonFbsContainerApproveModal .icon-btn");
      try {
        focusBtn?.focus();
      } catch (_e) {
        /* ignore */
      }
    });
  }

  async function approveOzonFbsContainer(containerId) {
    const sid = String(containersState.supplyId || "").trim();
    const sourceId = containersState.sourceId;
    const cid = String(containerId || "").trim();
    if (!sid || !sourceId || !cid || containersState.busy) return;

    let precheck = null;
    try {
      const params = new URLSearchParams({
        source_id: String(sourceId),
        container_id: String(cid),
      });
      const postingTab = String(supplyDetailState.postingTab || "").trim();
      if (postingTab) params.set("posting_tab", postingTab);
      const preRes = await fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/containers/approve-precheck?${params}`,
        { headers: jsonHeaders() }
      );
      const preData = await preRes.json().catch(() => ({}));
      if (preRes.ok && preData && preData.ok !== false) {
        precheck = preData;
      }
    } catch (_e) {
      // Soft-fail: still allow confirm if precheck unavailable.
      precheck = null;
    }

    const syncCount = Number(precheck?.sync_error_count || 0) || 0;
    const unbound = Number(precheck?.unbound || 0) || 0;
    const total = Number(precheck?.total_orders || 0) || 0;
    const hasSyncErrors = !!precheck?.has_sync_errors || syncCount > 0;
    const hasUnbound = !!precheck?.has_unbound || unbound > 0;

    const confirmed = await openOzonFbsContainerApproveModal({
      cid,
      total,
      unbound,
      hasUnbound,
      hasSyncErrors,
      syncCount,
      syncErrors: Array.isArray(precheck?.sync_errors) ? precheck.sync_errors : [],
    });
    if (!confirmed || hasUnbound) return;

    containersState.busy = true;
    _ozonFbsContainersSyncBusyUi();
    renderOzonFbsContainersTable(containersState.items);
    _ozonFbsContainersSetInfo("Подтверждаем грузоместо…");
    try {
      const res = await fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/containers/approve`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json", ...jsonHeaders() },
          body: JSON.stringify({
            source_id: sourceId,
            container_ids: [Number(cid) || cid],
            force: !!hasSyncErrors,
          }),
        }
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok || data.ok === false) {
        // Backend may still require force if precheck was stale/unavailable.
        const detail = data.detail;
        const needsForce =
          res.status === 409
          && detail
          && typeof detail === "object"
          && (detail.code === "container_sync_errors" || detail.precheck?.requires_force);
        if (needsForce && !hasSyncErrors) {
          const forceOk = await openOzonFbsContainerApproveModal({
            cid,
            forceOnly: true,
            forceMessage: String(detail.message || "Есть ошибки синхронизации с Ozon."),
            hasUnbound: false,
          });
          if (!forceOk) {
            throw new Error(String(detail.message || "Подтверждение отменено"));
          }
          const res2 = await fetch(
            `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/containers/approve`,
            {
              method: "POST",
              headers: { "Content-Type": "application/json", ...jsonHeaders() },
              body: JSON.stringify({
                source_id: sourceId,
                container_ids: [Number(cid) || cid],
                force: true,
              }),
            }
          );
          const data2 = await res2.json().catch(() => ({}));
          if (!res2.ok || data2.ok === false) {
            const errs2 = Array.isArray(data2.errors) ? data2.errors : [];
            const errLine2 = errs2.map((e) => e.error || e).filter(Boolean).join("; ");
            throw new Error(
              detailText(data2.detail) || errLine2 || data2.message || `Ошибка ${res2.status}`
            );
          }
          _ozonFbsContainersSetInfo(String(data2.message || "Подтверждено"), "ok");
          await loadOzonFbsContainers({ keepInfo: true });
          if (typeof window._ozonFbsContainerInvalidate === "function") {
            void window._ozonFbsContainerInvalidate();
          }
          return;
        }
        const errs = Array.isArray(data.errors) ? data.errors : [];
        const errLine = errs.map((e) => e.error || e).filter(Boolean).join("; ");
        throw new Error(detailText(data.detail) || errLine || data.message || `Ошибка ${res.status}`);
      }
      _ozonFbsContainersSetInfo(String(data.message || "Подтверждено"), "ok");
      await loadOzonFbsContainers({ keepInfo: true });
      if (typeof window._ozonFbsContainerInvalidate === "function") {
        void window._ozonFbsContainerInvalidate();
      }
    } catch (e) {
      _ozonFbsContainersSetInfo(e.message || String(e), "error");
      await loadOzonFbsContainers({ keepInfo: true });
    } finally {
      containersState.busy = false;
      _ozonFbsContainersSyncBusyUi();
      renderOzonFbsContainersTable(containersState.items);
    }
  }

  async function printOzonFbsContainerLabel(containerId) {
    const sid = String(containersState.supplyId || "").trim();
    const sourceId = containersState.sourceId;
    const cid = String(containerId || "").trim();
    if (!sid || !sourceId || !cid || containersState.busy) return;
    containersState.busy = true;
    _ozonFbsContainersSyncBusyUi();
    renderOzonFbsContainersTable(containersState.items);
    try {
      const res = await fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/containers/labels`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json", ...jsonHeaders() },
          body: JSON.stringify({
            source_id: sourceId,
            container_ids: [Number(cid) || cid],
          }),
        }
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok || data.ok === false) {
        throw new Error(detailText(data.detail) || data.message || `Ошибка ${res.status}`);
      }
      const b64 = String(data.file_content || "").trim();
      if (!b64) throw new Error("Ozon не вернул PDF этикетки");
      const byteChars = atob(b64);
      const bytes = new Uint8Array(byteChars.length);
      for (let i = 0; i < byteChars.length; i += 1) bytes[i] = byteChars.charCodeAt(i);
      const blob = new Blob([bytes], { type: String(data.content_type || "application/pdf") });
      const url = URL.createObjectURL(blob);
      const win = window.open(url, "_blank");
      if (!win) {
        const a = document.createElement("a");
        a.href = url;
        a.download = `ozon-container-${cid}.pdf`;
        a.click();
      }
      setTimeout(() => URL.revokeObjectURL(url), 60_000);
      _ozonFbsContainersSetInfo(`Этикетка ${cid} готова`, "ok");
    } catch (e) {
      _ozonFbsContainersSetInfo(e.message || String(e), "error");
    } finally {
      containersState.busy = false;
      _ozonFbsContainersSyncBusyUi();
      renderOzonFbsContainersTable(containersState.items);
    }
  }

  function fillShipmentsMethods(methods, selectedId, selectedName) {
    const sel = document.getElementById("ozonFbsShipmentsMethod");
    if (!sel) return;
    let list = Array.isArray(methods) ? methods.slice() : [];
    if (!list.length && selectedId) {
      list = [{
        id: selectedId,
        name: String(selectedName || `Метод ${selectedId}`),
      }];
    }
    if (!list.length) {
      sel.value = "";
      return;
    }
    const selectedKey = String(selectedId ?? "");
    const picked = list.find((m) => String(m.id ?? "") === selectedKey) || list[0];
    sel.value = String(picked?.id ?? "");
  }

  function listShipmentsFormedCarriages(data) {
    const out = [];
    const blocks = Array.isArray(data?.blocks) ? data.blocks : [];
    for (const block of blocks) {
      const carriages = Array.isArray(block?.carriages) ? block.carriages : [];
      for (const c of carriages) {
        if (!c?.is_formed || !c?.carriage_id) continue;
        const barcode = c.barcode && typeof c.barcode === "object" ? c.barcode : null;
        out.push({ carriage: c, barcode, block });
      }
    }
    return out;
  }

  function resolveShipmentsBarcode(data, _carriageId) {
    const wh = data?.warehouse_barcode;
    if (wh && typeof wh === "object") {
      const text = String(wh.barcode_text || "").trim();
      const labelB64 = String(wh.barcode_label_base64 || "").trim();
      const b64 = String(wh.barcode_image_base64 || "").trim();
      if (text || labelB64 || b64) return wh;
    }
    const formed = listShipmentsFormedCarriages(data);
    const withBc = formed.find((x) => x.barcode);
    if (withBc?.barcode) return withBc.barcode;
    return data?.barcode || null;
  }

  function shipmentsWarehouseCaption(data) {
    const name = String(data?.warehouse_name || "").trim();
    if (name) return `Штрихкод для склада ${name}`;
    const wid = Number(data?.warehouse_id || 0);
    if (wid > 0) return `Штрихкод для склада ${wid}`;
    return "Штрихкод для склада";
  }

  function composeOzonFbsShipmentBarcodeLabelDataUrl(text, options) {
    const value = String(text || "").trim();
    if (!value || typeof JsBarcode === "undefined") return "";
    const forPrint = !!(options && options.forPrint);
    const bcCanvas = document.createElement("canvas");
    try {
      JsBarcode(bcCanvas, value, {
        format: "CODE128",
        width: 2,
        height: forPrint ? 120 : 80,
        displayValue: false,
        margin: forPrint ? 2 : 8,
        background: "#ffffff",
        lineColor: "#000000",
      });
    } catch (_e) {
      return "";
    }
    const targetW = Math.max(bcCanvas.width, 420);
    const padX = 12;
    let padTop = 10;
    let padBottom = 10;
    let gap = 8;
    let textH = 28;
    let barH = Math.max(72, Math.min(140, Math.round(targetW * 0.22)));
    if (forPrint) {
      padTop = 2;
      padBottom = 2;
      gap = 4;
      textH = 22;
      const outWTarget = targetW + padX * 2;
      const outHTarget = Math.max(1, Math.round(outWTarget * (40 / 58)));
      barH = Math.max(120, outHTarget - padTop - padBottom - gap - textH);
    }
    const outW = targetW + padX * 2;
    const outH = padTop + barH + gap + textH + padBottom;
    const out = document.createElement("canvas");
    out.width = outW;
    out.height = outH;
    const ctx = out.getContext("2d");
    if (!ctx) return "";
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, outW, outH);
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(bcCanvas, 0, 0, bcCanvas.width, bcCanvas.height, padX, padTop, targetW, barH);
    ctx.imageSmoothingEnabled = true;
    ctx.fillStyle = "#0f172a";
    ctx.font = '600 22px "Courier New", Courier, monospace';
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(value, outW / 2, padTop + barH + gap + textH / 2);
    return out.toDataURL("image/png");
  }

  function getOzonFbsShipmentBarcodeLabelDataUrl(barcode) {
    const labelB64 = String(barcode?.barcode_label_base64 || "").trim();
    if (labelB64) return `data:image/png;base64,${labelB64}`;
    const text = String(barcode?.barcode_text || "").trim();
    if (!text) return "";
    shipmentsState.barcodeLabelCache = shipmentsState.barcodeLabelCache || {};
    if (shipmentsState.barcodeLabelCache[text]) return shipmentsState.barcodeLabelCache[text];
    const url = composeOzonFbsShipmentBarcodeLabelDataUrl(text);
    if (url) shipmentsState.barcodeLabelCache[text] = url;
    return url;
  }

  function paintShipmentsBarcodeLabel() {
    const img = document.getElementById("ozonFbsShipmentsBarcodeImg");
    if (!img || img.dataset.ready === "1" || img.getAttribute("src")) return;
    const text = String(img.dataset.barcodeText || "").trim();
    const pending = document.getElementById("ozonFbsShipmentsBarcodePending");
    if (!text) return;
    const dataUrl = getOzonFbsShipmentBarcodeLabelDataUrl({ barcode_text: text });
    if (!dataUrl) {
      if (pending) pending.textContent = `Не удалось сформировать штрихкод ${text}`;
      return;
    }
    img.src = dataUrl;
    img.hidden = false;
    img.dataset.ready = "1";
    if (pending) pending.remove();
  }

  function openOzonFbsShipmentBarcodePrintWindow(text, warehouseName) {
    const dataUrl = composeOzonFbsShipmentBarcodeLabelDataUrl(text, { forPrint: true })
      || getOzonFbsShipmentBarcodeLabelDataUrl({ barcode_text: text });
    if (!dataUrl) throw new Error("Не удалось сформировать штрихкод для печати");
    const wh = esc(warehouseName || "");
    const html = `<!doctype html>
<html lang="ru"><head><meta charset="utf-8"/>
<title>ШК поставки</title>
<style>
  @page { size: 58mm 40mm; margin: 0; }
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; }
  body { font-family: Arial, sans-serif; color: #0f172a; }
  .label {
    width: 58mm; height: 40mm; page-break-after: always;
    overflow: hidden; display: flex; align-items: center; justify-content: center;
    padding: 1mm 2mm;
  }
  .label img {
    width: 56mm; height: 38mm; max-height: none;
    object-fit: fill; object-position: center;
  }
  .toolbar { padding: 8px 12px; }
  @media print { .toolbar { display: none !important; } }
</style></head><body>
  <div class="toolbar"><button type="button" onclick="window.print()">Печать</button>
    <span style="margin-left:8px;color:#64748b;font-size:13px">58×40 · ШК поставки Ozon${wh ? ` · ${wh}` : ""}</span>
  </div>
  <section class="label"><img src="${dataUrl}" alt="ШК поставки ${esc(text)}" /></section>
  <script>window.addEventListener("load",function(){setTimeout(function(){window.print();},300);});</script>
</body></html>`;
    const blob = new Blob([html], { type: "text/html;charset=utf-8" });
    const blobUrl = URL.createObjectURL(blob);
    const win = window.open(blobUrl, "_blank");
    if (!win) {
      URL.revokeObjectURL(blobUrl);
      throw new Error("Разрешите всплывающие окна для печати штрихкода");
    }
    setTimeout(() => URL.revokeObjectURL(blobUrl), 120000);
    try { win.focus(); } catch (_e) { /* ignore */ }
  }

  function renderShipmentsBarcodePanel(data) {
    const barcode = resolveShipmentsBarcode(data);
    const text = String(barcode?.barcode_text || "").trim();
    const labelB64 = String(barcode?.barcode_label_base64 || "").trim();
    const b64 = String(barcode?.barcode_image_base64 || "").trim();
    const canPrint = Boolean(labelB64 || b64 || text);
    let visual = `<div class="ozon-fbs-shipments-barcode-empty">Не удалось загрузить штрихкод склада</div>`;
    if (labelB64) {
      visual = `<img id="ozonFbsShipmentsBarcodeImg" class="ozon-fbs-shipments-barcode-label" src="data:image/png;base64,${labelB64}" alt="Штрихкод поставки ${esc(text)}" data-ready="1" />`;
    } else if (text) {
      visual = `
        <img id="ozonFbsShipmentsBarcodeImg" class="ozon-fbs-shipments-barcode-label"
             data-barcode-text="${esc(text)}" alt="Штрихкод поставки ${esc(text)}" hidden />
        <div id="ozonFbsShipmentsBarcodePending" class="ozon-fbs-shipments-barcode-loading">Формирование штрихкода…</div>`;
    } else if (b64) {
      visual = `<img id="ozonFbsShipmentsBarcodeImg" class="ozon-fbs-shipments-barcode-label" src="data:image/png;base64,${b64}" alt="Штрихкод поставки" data-ready="1" />`;
    }
    return `
      <div class="ozon-fbs-shipments-barcode-main">
        <div class="ozon-fbs-shipments-barcode-visual">
          ${visual}
        </div>
        <div class="ozon-fbs-shipments-barcode-actions">
          <button type="button" class="ozon-fbs-shipments-icon-btn" ${canPrint ? "" : "disabled"}
                  onclick="ozonFbsShipmentsPrintBarcode()" title="Печать" aria-label="Печать штрихкода">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M7 9V4h10v5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M7 17H5a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <rect x="7" y="13" width="10" height="7" rx="1" stroke="currentColor" stroke-width="2"/>
            </svg>
          </button>
          <button type="button" class="ozon-fbs-shipments-icon-btn" ${canPrint ? "" : "disabled"}
                  onclick="ozonFbsShipmentsDownloadBarcode()" title="Скачать PNG" aria-label="Скачать штрихкод PNG">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M12 4v10M8 10l4 4 4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M5 19h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            </svg>
          </button>
        </div>
      </div>`;
  }

  function renderShipmentsMetaColumn(block, data) {
    const address = String(block?.dropoff_address || "").trim() || "—";
    return `
      <div class="ozon-fbs-shipments-meta-col">
        <div class="ozon-fbs-shipments-meta-item">
          <span class="ozon-fbs-shipments-meta-label">Адрес</span>
          <span class="ozon-fbs-shipments-meta-value">${esc(address)}</span>
        </div>
      </div>`;
  }

  function renderShipmentsView(data) {
    const body = document.getElementById("ozonFbsShipmentsBody");
    if (!body) return;
    if (!data) {
      body.innerHTML = `<div class="ozon-fbs-shipments-loading">Нет данных</div>`;
      return;
    }
    if (data.ok === false && data.message && !(Array.isArray(data.blocks) && data.blocks.length)) {
      body.innerHTML = `<div class="ozon-fbs-shipments-error">${esc(data.message)}</div>`;
      return;
    }
    const blocks = Array.isArray(data.blocks) ? data.blocks : [];
    const primary = blocks[0] || null;
    body.innerHTML = `
      <div class="ozon-fbs-shipments-compact">
        ${renderShipmentsBarcodePanel(data)}
        ${renderShipmentsMetaColumn(primary, data)}
      </div>`;
    paintShipmentsBarcodeLabel();
  }

  async function loadShipments() {
    const sid = shipmentsState.supplyId;
    const sourceId = shipmentsState.sourceId;
    const body = document.getElementById("ozonFbsShipmentsBody");
    if (!sid || !sourceId) return;
    const dateEl = document.getElementById("ozonFbsShipmentsDate");
    const methodEl = document.getElementById("ozonFbsShipmentsMethod");
    const day = String(dateEl?.value || todayIsoDate());
    const methodId = String(methodEl?.value || "").trim();
    shipmentsState.loading = true;
    if (body) body.innerHTML = `<div class="ozon-fbs-shipments-loading">Загрузка…</div>`;
    try {
      const qs = new URLSearchParams({
        source_id: String(sourceId),
        departure_date: day,
      });
      if (methodId) qs.set("delivery_method_id", methodId);
      const res = await fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/shipments?${qs.toString()}`
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || "Не удалось загрузить отгрузки");
      shipmentsState.data = data;
      fillShipmentsMethods(
        data.delivery_methods,
        data.selected_delivery_method_id,
        data.selected_delivery_method_name
      );
      if (dateEl && data.departure_date) dateEl.value = String(data.departure_date).slice(0, 10);
      renderShipmentsView(data);
    } catch (e) {
      if (body) {
        body.innerHTML = `<div class="ozon-fbs-shipments-error">${esc(e.message || e)}</div>`;
      }
    } finally {
      shipmentsState.loading = false;
    }
  }

  async function openShipmentsModal() {
    const sid = String(supplyDetailState.supplyId || "").trim();
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    if (!sid || !sourceId || !_ozonFbsSupplyActionsReady()) {
      alert("Откройте поставку");
      return;
    }
    shipmentsState.supplyId = sid;
    shipmentsState.sourceId = sourceId;
    shipmentsState.data = null;
    const modal = document.getElementById("ozonFbsShipmentsModal");
    const dateEl = document.getElementById("ozonFbsShipmentsDate");
    const methodEl = document.getElementById("ozonFbsShipmentsMethod");
    if (dateEl && !dateEl.value) dateEl.value = todayIsoDate();
    if (methodEl) methodEl.value = "";
    if (modal) modal.classList.remove("hidden");
    await loadShipments();
  }

  /**
   * Local only: move supply awaiting_deliver → delivering and deduct Остатки.
   * Does not call Ozon. Uses in-app confirm/notice modals (not browser dialogs).
   */
  const moveDeliveringModalState = { mode: "confirm", busy: false };

  function _ozonFbsMoveDeliveringSetVisible(show) {
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsMoveDeliveringModal", !!show);
      return;
    }
    const modal = document.getElementById("ozonFbsMoveDeliveringModal");
    if (!modal) return;
    modal.classList.toggle("hidden", !show);
  }

  function closeOzonFbsMoveDeliveringModal() {
    if (moveDeliveringModalState.busy) return;
    moveDeliveringModalState.mode = "confirm";
    _ozonFbsMoveDeliveringSetVisible(false);
  }

  function _ozonFbsMoveDeliveringRender(mode, { title, html, kind } = {}) {
    moveDeliveringModalState.mode = mode;
    const titleEl = document.getElementById("ozonFbsMoveDeliveringTitle");
    const body = document.getElementById("ozonFbsMoveDeliveringBody");
    const cancelBtn = document.getElementById("ozonFbsMoveDeliveringCancelBtn");
    const confirmBtn = document.getElementById("ozonFbsMoveDeliveringConfirmBtn");
    const okBtn = document.getElementById("ozonFbsMoveDeliveringOkBtn");
    const card = document.querySelector("#ozonFbsMoveDeliveringModal .ozon-fbs-move-delivering-modal");
    if (titleEl) titleEl.textContent = title || "Перенести в доставку";
    if (body) body.innerHTML = html || "";
    if (card) {
      card.classList.toggle("is-error", kind === "error");
      card.classList.toggle("is-ok", kind === "ok");
    }
    const isConfirm = mode === "confirm";
    if (cancelBtn) cancelBtn.hidden = !isConfirm;
    if (confirmBtn) {
      confirmBtn.hidden = !isConfirm;
      confirmBtn.disabled = false;
      confirmBtn.textContent = "Перенести";
    }
    if (okBtn) okBtn.hidden = isConfirm;
    _ozonFbsMoveDeliveringSetVisible(true);
  }

  function _ozonFbsMoveDeliveringNotice(message, { title, kind } = {}) {
    const msg = String(message || "").trim() || "Готово";
    const lines = msg.split("\n").map((l) => l.trim()).filter(Boolean);
    const html = lines.map((l) => `<p class="ozon-fbs-move-delivering-text">${esc(l)}</p>`).join("");
    _ozonFbsMoveDeliveringRender("notice", {
      title: title || (kind === "error" ? "Не удалось перенести" : "Поставка перенесена"),
      html,
      kind: kind || "ok",
    });
  }

  function moveOzonFbsSupplyToDelivering() {
    const sid = String(supplyDetailState.supplyId || "").trim();
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    if (!sid || !sourceId || !_ozonFbsSupplyActionsReady()) {
      _ozonFbsMoveDeliveringNotice(
        "Откройте поставку и дождитесь загрузки заказов",
        { title: "Перенести в доставку", kind: "error" }
      );
      return;
    }
    if (isDeliveringSuppliesTab() || isSupplyDetailReadOnly()) {
      _ozonFbsMoveDeliveringNotice(
        "Поставка уже в «Доставляются»",
        { title: "Перенести в доставку", kind: "error" }
      );
      return;
    }
    if (!_ozonFbsCanMoveToDelivering()) {
      _ozonFbsSyncMoveDeliveringEnabled();
      _ozonFbsMoveDeliveringNotice(
        "Сначала выполните все условия: подтверждение грузомест (если есть), зелёные «Товары с КИЗ» / «Товары без КИЗ» и выбранный водитель",
        { title: "Перенести в доставку", kind: "error" }
      );
      return;
    }
    const name = String(supplyDetailState.supply?.name || sid).trim();
    const orderN = Number(supplyDetailState.supply?.order_count || 0);
    const orderLabel = orderN > 0 ? String(orderN) : "Все";
    _ozonFbsMoveDeliveringRender("confirm", {
      title: "Перенести в доставку",
      html: `
        <p class="ozon-fbs-move-delivering-lead">
          Перенести поставку «${esc(name)}» в «Доставляются»?
        </p>
        <ul class="ozon-fbs-move-delivering-list">
          <li>На Ozon ничего не отправится</li>
          <li>${esc(orderLabel)} отправлений уйдут из «Ожидают отгрузки»</li>
          <li>Продукция спишется с Остатки прямо сейчас</li>
          <li>При следующей сборке заказов создастся новая поставка</li>
        </ul>
      `,
    });
  }

  async function confirmOzonFbsMoveDelivering() {
    if (moveDeliveringModalState.mode !== "confirm" || moveDeliveringModalState.busy) return;
    const sid = String(supplyDetailState.supplyId || "").trim();
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    const btn = document.getElementById("ozonFbsSupplyDetailMoveDeliveringBtn");
    const confirmBtn = document.getElementById("ozonFbsMoveDeliveringConfirmBtn");
    if (!sid || !sourceId) {
      _ozonFbsMoveDeliveringNotice(
        "Откройте поставку и дождитесь загрузки заказов",
        { title: "Перенести в доставку", kind: "error" }
      );
      return;
    }
    if (!_ozonFbsCanMoveToDelivering()) {
      _ozonFbsSyncMoveDeliveringEnabled();
      _ozonFbsMoveDeliveringNotice(
        "Сначала выполните все условия: подтверждение грузомест (если есть), зелёные «Товары с КИЗ» / «Товары без КИЗ» и выбранный водитель",
        { title: "Перенести в доставку", kind: "error" }
      );
      return;
    }
    moveDeliveringModalState.busy = true;
    if (confirmBtn) {
      confirmBtn.disabled = true;
      confirmBtn.textContent = "Перенос…";
    }
    if (btn) {
      btn.setAttribute("aria-disabled", "true");
      btn.classList.add("is-wait-orders");
    }
    try {
      const res = await fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/move-to-delivering`
          + `?source_id=${encodeURIComponent(sourceId)}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json", ...jsonHeaders() },
        }
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      closeSupplyDetailModal();
      setTab("delivering");
      const moved = Number(data.moved || 0);
      const shipped = Number(data.stock?.shipped || 0);
      const base = String(data.message || "Поставка перенесена в «Доставляются»");
      const stockNote = moved > 0
        ? (shipped > 0
          ? `Списание с Остатки: записей ${shipped}`
          : "Списание с Остатки: будет при следующей синхронизации / нет производства")
        : "";
      moveDeliveringModalState.busy = false;
      _ozonFbsMoveDeliveringNotice(
        stockNote ? `${base}\n${stockNote}` : base,
        { title: "Поставка перенесена", kind: "ok" }
      );
      showSyncInfo(base, "ok");
    } catch (e) {
      moveDeliveringModalState.busy = false;
      _ozonFbsMoveDeliveringNotice(e.message || String(e), {
        title: "Не удалось перенести",
        kind: "error",
      });
    } finally {
      moveDeliveringModalState.busy = false;
      if (confirmBtn) {
        confirmBtn.disabled = false;
        confirmBtn.textContent = "Перенести";
      }
      if (btn) {
        btn.classList.remove("is-wait-orders");
        _ozonFbsSyncMoveDeliveringEnabled();
      }
    }
  }

  /**
   * Local only: move selected delivering supplies → awaiting_deliver and restore Остатки.
   * Does not call Ozon. Selection bottom bar on «Доставляются».
   */
  const moveAwaitingModalState = { mode: "confirm", busy: false, supplyIds: [] };

  function _ozonFbsMoveAwaitingSetVisible(show) {
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsMoveAwaitingModal", !!show);
      return;
    }
    const modal = document.getElementById("ozonFbsMoveAwaitingModal");
    if (!modal) return;
    modal.classList.toggle("hidden", !show);
  }

  function closeOzonFbsMoveAwaitingModal() {
    if (moveAwaitingModalState.busy) return;
    moveAwaitingModalState.mode = "confirm";
    moveAwaitingModalState.supplyIds = [];
    _ozonFbsMoveAwaitingSetVisible(false);
  }

  function _ozonFbsMoveAwaitingRender(mode, { title, html, kind } = {}) {
    moveAwaitingModalState.mode = mode;
    const titleEl = document.getElementById("ozonFbsMoveAwaitingTitle");
    const body = document.getElementById("ozonFbsMoveAwaitingBody");
    const cancelBtn = document.getElementById("ozonFbsMoveAwaitingCancelBtn");
    const confirmBtn = document.getElementById("ozonFbsMoveAwaitingConfirmBtn");
    const okBtn = document.getElementById("ozonFbsMoveAwaitingOkBtn");
    const card = document.querySelector("#ozonFbsMoveAwaitingModal .ozon-fbs-move-delivering-modal");
    if (titleEl) titleEl.textContent = title || "В «Ожидают отгрузки»";
    if (body) body.innerHTML = html || "";
    if (card) {
      card.classList.toggle("is-error", kind === "error");
      card.classList.toggle("is-ok", kind === "ok");
    }
    const isConfirm = mode === "confirm";
    if (cancelBtn) cancelBtn.hidden = !isConfirm;
    if (confirmBtn) {
      confirmBtn.hidden = !isConfirm;
      confirmBtn.disabled = false;
      confirmBtn.textContent = "Перенести";
    }
    if (okBtn) okBtn.hidden = isConfirm;
    _ozonFbsMoveAwaitingSetVisible(true);
  }

  function _ozonFbsMoveAwaitingNotice(message, { title, kind } = {}) {
    const text = String(message || "").trim() || "Готово";
    const lines = text.split("\n").map((l) => l.trim()).filter(Boolean);
    const html = lines.map((l) => `<p class="ozon-fbs-move-delivering-text">${esc(l)}</p>`).join("");
    _ozonFbsMoveAwaitingRender("notice", {
      title: title || "Готово",
      html,
      kind: kind || "ok",
    });
  }

  function _ozonFbsSelectedSupplyLabel(n) {
    const abs = Math.abs(Number(n) || 0) % 100;
    const last = abs % 10;
    let word = "поставок";
    if (!(abs > 10 && abs < 20)) {
      if (last === 1) word = "поставку";
      else if (last >= 2 && last <= 4) word = "поставки";
    }
    return `${n} ${word}`;
  }

  function openOzonFbsMoveSelectedToAwaitingDeliver() {
    if (!isDeliveringSuppliesTab()) {
      _ozonFbsMoveAwaitingNotice(
        "Выберите поставки на вкладке «Доставляются»",
        { title: "В «Ожидают отгрузки»", kind: "error" }
      );
      return;
    }
    const sourceId = state.sourceId;
    if (!sourceId) {
      _ozonFbsMoveAwaitingNotice(
        "Сначала выберите источник Ozon FBS",
        { title: "В «Ожидают отгрузки»", kind: "error" }
      );
      return;
    }
    const ids = [...state.selected]
      .map((x) => String(x || "").trim())
      .filter(Boolean);
    if (!ids.length) {
      _ozonFbsMoveAwaitingNotice(
        "Отметьте одну или несколько поставок",
        { title: "В «Ожидают отгрузки»", kind: "error" }
      );
      return;
    }
    moveAwaitingModalState.supplyIds = ids;
    const orderTotal = ids.reduce((sum, sid) => {
      const row = (state.items || []).find(
        (s) => String(s.supply_id || "").trim() === sid
      );
      return sum + Number(row?.order_count || 0);
    }, 0);
    const names = ids.slice(0, 3).map((sid) => {
      const row = (state.items || []).find(
        (s) => String(s.supply_id || "").trim() === sid
      );
      return String(row?.name || sid).trim() || sid;
    });
    const namesNote = names.length
      ? `<li>${esc(names.join(", "))}${ids.length > 3 ? "…" : ""}</li>`
      : "";
    const orderLine = orderTotal > 0
      ? `<li>${esc(String(orderTotal))} отправлений вернутся в «Ожидают отгрузки»</li>`
      : "<li>Отправления поставки вернутся в «Ожидают отгрузки»</li>";
    _ozonFbsMoveAwaitingRender("confirm", {
      title: "В «Ожидают отгрузки»",
      html: `
        <p class="ozon-fbs-move-delivering-lead">
          Вернуть ${_ozonFbsSelectedSupplyLabel(ids.length)} в «Ожидают отгрузки»?
        </p>
        <ul class="ozon-fbs-move-delivering-list">
          ${namesNote}
          <li>На Ozon ничего не отправится</li>
          ${orderLine}
          <li>Количество вернётся на Остатки</li>
          <li>Можно снова добавлять заказы через «Собрать все» или «Добавить к существующей»</li>
          <li>Если в Ozon уже «Доставляются», синхронизация может снова перенести поставку</li>
        </ul>
      `,
    });
  }

  async function confirmOzonFbsMoveAwaiting() {
    if (moveAwaitingModalState.mode !== "confirm" || moveAwaitingModalState.busy) return;
    const sourceId = state.sourceId;
    const ids = (moveAwaitingModalState.supplyIds || [])
      .map((x) => String(x || "").trim())
      .filter(Boolean);
    const confirmBtn = document.getElementById("ozonFbsMoveAwaitingConfirmBtn");
    if (!sourceId || !ids.length) {
      _ozonFbsMoveAwaitingNotice(
        "Выберите поставки на вкладке «Доставляются»",
        { title: "В «Ожидают отгрузки»", kind: "error" }
      );
      return;
    }
    moveAwaitingModalState.busy = true;
    if (confirmBtn) {
      confirmBtn.disabled = true;
      confirmBtn.textContent = "Перенос…";
    }
    let movedTotal = 0;
    let reversedTotal = 0;
    const errors = [];
    try {
      for (const sid of ids) {
        try {
          const res = await fetch(
            `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/move-to-awaiting-deliver`
              + `?source_id=${encodeURIComponent(sourceId)}`,
            {
              method: "POST",
              headers: { "Content-Type": "application/json", ...jsonHeaders() },
            }
          );
          const data = await res.json().catch(() => ({}));
          if (!res.ok) {
            throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
          }
          movedTotal += Number(data.moved || 0);
          reversedTotal += Number(data.stock?.reversed || 0);
        } catch (e) {
          errors.push(`${sid}: ${e.message || e}`);
        }
      }
      const okN = ids.length - errors.length;
      // Only leave «Доставляются» when at least one supply actually moved.
      if (okN > 0) {
        clearSelection();
        setTab("awaiting_deliver");
      }
      const base = errors.length
        ? `Перенесено поставок: ${okN} из ${ids.length}`
        : `Перенесено в «Ожидают отгрузки»: ${_ozonFbsSelectedSupplyLabel(okN)}`;
      const detailParts = [];
      if (movedTotal > 0) detailParts.push(`отправлений ${movedTotal}`);
      if (reversedTotal > 0) detailParts.push(`возврат на Остатки: записей ${reversedTotal}`);
      else if (movedTotal > 0) {
        detailParts.push("возврат на Остатки: будет при следующей синхронизации / нет производства");
      }
      const stockNote = detailParts.join("; ");
      const errNote = errors.length
        ? `\nОшибки:\n${errors.slice(0, 5).join("\n")}${errors.length > 5 ? "\n…" : ""}`
        : "";
      moveAwaitingModalState.busy = false;
      _ozonFbsMoveAwaitingNotice(
        (stockNote ? `${base}\n${stockNote}` : base) + errNote,
        {
          title: okN === 0
            ? "Не удалось перенести"
            : (errors.length ? "Перенос с ошибками" : "Поставки перенесены"),
          kind: okN === 0 ? "error" : (errors.length ? "error" : "ok"),
        }
      );
      showSyncInfo(base, okN === 0 ? "error" : (errors.length ? "warn" : "ok"));
    } catch (e) {
      moveAwaitingModalState.busy = false;
      _ozonFbsMoveAwaitingNotice(e.message || String(e), {
        title: "Не удалось перенести",
        kind: "error",
      });
    } finally {
      moveAwaitingModalState.busy = false;
      if (confirmBtn) {
        confirmBtn.disabled = false;
        confirmBtn.textContent = "Перенести";
      }
    }
  }

  const movePostingState = {
    postingNumber: "",
    postingNumbers: [],
    excludeSupplyId: "",
    selectedSupplyId: "",
    selectedTab: "",
    items: [],
    busy: false,
  };

  function closeOzonFbsMovePostingModal() {
    if (movePostingState.busy) return;
    movePostingState.postingNumber = "";
    movePostingState.postingNumbers = [];
    movePostingState.excludeSupplyId = "";
    movePostingState.selectedSupplyId = "";
    movePostingState.selectedTab = "";
    movePostingState.items = [];
    const err = document.getElementById("ozonFbsMovePostingErr");
    if (err) {
      err.hidden = true;
      err.textContent = "";
    }
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsMovePostingModal", false);
    } else {
      document.getElementById("ozonFbsMovePostingModal")?.classList.add("hidden");
    }
  }

  function _ozonFbsMovePostingSetErr(text) {
    const err = document.getElementById("ozonFbsMovePostingErr");
    if (!err) return;
    const msg = String(text || "").trim();
    err.hidden = !msg;
    err.textContent = msg;
  }

  function _ozonFbsMovePostingSelect(supplyId, tab) {
    movePostingState.selectedSupplyId = String(supplyId || "").trim();
    movePostingState.selectedTab = String(tab || "").trim();
    const body = document.getElementById("ozonFbsMovePostingBody");
    if (body) {
      body.querySelectorAll(".ozon-fbs-move-supply-row").forEach((row) => {
        const sid = String(row.getAttribute("data-supply-id") || "");
        const t = String(row.getAttribute("data-tab") || "");
        const on =
          sid === movePostingState.selectedSupplyId &&
          t === movePostingState.selectedTab;
        row.classList.toggle("is-selected", on);
        const inp = row.querySelector('input[type="radio"]');
        if (inp) inp.checked = on;
      });
    }
    const btn = document.getElementById("ozonFbsMovePostingConfirmBtn");
    if (btn) btn.disabled = !movePostingState.selectedSupplyId;
    _ozonFbsMovePostingSetErr("");
  }

  function _ozonFbsMovePostingRenderList(groups) {
    const body = document.getElementById("ozonFbsMovePostingBody");
    if (!body) return;
    const exclude = String(movePostingState.excludeSupplyId || "").trim();
    // Only «Ожидают отгрузки» — delivering supplies are not valid local move targets.
    const items = (groups.awaiting_deliver || groups.items || []).filter((s) => {
      const sid = String(s.supply_id || "").trim();
      return sid && sid !== exclude;
    });
    const flat = [];
    let html = "";
    if (items.length) {
      html += `<div class="ozon-fbs-move-section">`;
      html += `<h4 class="ozon-fbs-move-section-title">Ожидают отгрузки</h4>`;
      html += items.map((s) => {
        flat.push(s);
        const sid = String(s.supply_id || "").trim();
        const tab = String(s.tab || "awaiting_deliver").trim() || "awaiting_deliver";
        const name = String(s.name || sid).trim() || sid;
        const count = Number(s.order_count || 0) || 0;
        const wh = String(s.warehouse_name || "").trim();
        const id = `ozonFbsMoveSupply_${esc(tab)}_${esc(sid)}`;
        return `<label class="ozon-fbs-move-supply-row" data-supply-id="${esc(sid)}" data-tab="${esc(tab)}" for="${id}">
          <input type="radio" name="ozonFbsMoveSupply" id="${id}"
                 onchange="selectOzonFbsMovePostingTarget('${esc(sid)}', '${esc(tab)}')" />
          <span class="ozon-fbs-move-supply-main">
            <span class="ozon-fbs-move-supply-name">${esc(name)}</span>
            <span class="ozon-fbs-move-supply-meta">${esc(sid)} · ${esc(count)} отпр.${wh ? " · " + esc(wh) : ""}</span>
          </span>
        </label>`;
      }).join("");
      html += `</div>`;
    }
    movePostingState.items = flat;
    if (!html) {
      body.innerHTML = `<div class="wb-fbs-empty">Нет других локальных поставок в «Ожидают отгрузки»</div>`;
    } else {
      body.innerHTML = html;
    }
    const btn = document.getElementById("ozonFbsMovePostingConfirmBtn");
    if (btn) btn.disabled = true;
  }

  async function _ozonFbsOpenMovePostingModal(postingNumbers, opts) {
    closeOzonFbsRowMenus();
    const nums = (Array.isArray(postingNumbers) ? postingNumbers : [])
      .map((x) => String(x || "").trim())
      .filter(Boolean);
    const sourceId = Number(supplyDetailState.sourceId || state.sourceId || 0) || 0;
    if (!nums.length || !sourceId) {
      alert("Не удалось определить отправление или источник");
      return;
    }
    const excludeSupplyId = String(opts?.excludeSupplyId || "").trim();
    movePostingState.postingNumbers = nums;
    movePostingState.postingNumber = nums.length === 1 ? nums[0] : "";
    movePostingState.excludeSupplyId = excludeSupplyId;
    movePostingState.selectedSupplyId = "";
    movePostingState.selectedTab = "";
    _ozonFbsMovePostingSetErr("");
    const lead = document.getElementById("ozonFbsMovePostingLead");
    if (lead) {
      lead.textContent = nums.length === 1
        ? `Отправление ${nums[0]}: выберите локальную поставку. В Ozon ничего не отправляется.`
        : `Выбрано ${nums.length} отпр.: выберите локальную поставку. В Ozon ничего не отправляется.`;
    }
    const body = document.getElementById("ozonFbsMovePostingBody");
    if (body) body.innerHTML = `<div class="wb-fbs-empty">Загрузка поставок…</div>`;
    const confirmBtn = document.getElementById("ozonFbsMovePostingConfirmBtn");
    if (confirmBtn) {
      confirmBtn.disabled = true;
      confirmBtn.textContent = "Переместить";
    }
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsMovePostingModal", true);
    } else {
      document.getElementById("ozonFbsMovePostingModal")?.classList.remove("hidden");
    }
    try {
      const res = await fetch(
        `/api/ozon-fbs/postings/move-targets?source_id=${encodeURIComponent(sourceId)}`
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      _ozonFbsMovePostingRenderList(data);
    } catch (e) {
      if (body) {
        body.innerHTML = `<div class="wb-fbs-empty" style="color:#b91c1c">${esc(String(e.message || e))}</div>`;
      }
    }
  }

  async function openOzonFbsMovePostingModal(postingNumber) {
    await _ozonFbsOpenMovePostingModal([postingNumber], { excludeSupplyId: "" });
  }

  function openOzonFbsSupplyDetailMoveExisting() {
    const nums = supplyDetailSelectedPostingNumbers();
    if (!nums.length) {
      alert("Выберите отправления");
      return;
    }
    const currentSid = String(supplyDetailState.supplyId || "").trim();
    void _ozonFbsOpenMovePostingModal(nums, { excludeSupplyId: currentSid });
  }

  function selectOzonFbsMovePostingTarget(supplyId, tab) {
    _ozonFbsMovePostingSelect(supplyId, tab);
  }

  async function _ozonFbsAfterLocalMoveSuccess(msg, movedNumbers) {
    showSyncInfo(msg);
    clearSupplyDetailSelection();
    if (supplyDetailState.supplyId) {
      await _ozonFbsRefreshOpenSupplyDetail();
    }
    const nums = (Array.isArray(movedNumbers) ? movedNumbers : [])
      .map((x) => String(x || "").trim())
      .filter(Boolean);
    if (state.lookupMode && nums.length === 1) {
      const pn = nums[0];
      if (parsePostingNumberQuery(state.search) === pn) {
        try {
          const lookup = await lookupPostingByNumber(pn, { refresh: false });
          if (lookup) applyLookupResult(lookup, pn);
          return;
        } catch (_e) {
          /* fall through */
        }
      }
    }
    await loadPostings(false);
  }

  async function confirmOzonFbsMovePosting() {
    const nums = (movePostingState.postingNumbers || [])
      .map((x) => String(x || "").trim())
      .filter(Boolean);
    const single = String(movePostingState.postingNumber || "").trim();
    if (!nums.length && single) nums.push(single);
    const sid = String(movePostingState.selectedSupplyId || "").trim();
    const tab = String(movePostingState.selectedTab || "").trim();
    const sourceId = Number(supplyDetailState.sourceId || state.sourceId || 0) || 0;
    if (!nums.length || !sid || !sourceId) {
      _ozonFbsMovePostingSetErr("Выберите поставку");
      return;
    }
    const btn = document.getElementById("ozonFbsMovePostingConfirmBtn");
    if (btn) {
      btn.disabled = true;
      btn.textContent = "Перенос…";
    }
    movePostingState.busy = true;
    _ozonFbsMovePostingSetErr("");
    try {
      let data;
      if (nums.length === 1) {
        const res = await fetch(
          `/api/ozon-fbs/postings/${encodeURIComponent(nums[0])}/move-to-supply`,
          {
            method: "POST",
            headers: jsonHeaders(),
            body: JSON.stringify({
              source_id: sourceId,
              supply_id: sid,
              target_tab: tab || undefined,
            }),
          }
        );
        data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      } else {
        const res = await fetch("/api/ozon-fbs/postings/bulk-move-to-supply", {
          method: "POST",
          headers: jsonHeaders(),
          body: JSON.stringify({
            source_id: sourceId,
            supply_id: sid,
            target_tab: tab || undefined,
            posting_numbers: nums,
          }),
        });
        data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      }
      const msg = String(data.message || "Перенесено локально");
      movePostingState.busy = false;
      closeOzonFbsMovePostingModal();
      await _ozonFbsAfterLocalMoveSuccess(msg, nums);
      alert(msg);
    } catch (e) {
      _ozonFbsMovePostingSetErr(String(e.message || e));
      if (btn) {
        btn.disabled = false;
        btn.textContent = "Переместить";
      }
    } finally {
      movePostingState.busy = false;
    }
  }

  const sdNewSupplyState = { busy: false };

  function _ozonFbsSuggestedLocalSupplyName() {
    const src = (state.sources || []).find(
      (s) => Number(s.id) === Number(supplyDetailState.sourceId || state.sourceId)
    );
    const sourceName = String(src?.name || "").trim() || "—";
    const d = new Date();
    const dd = String(d.getDate()).padStart(2, "0");
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const yyyy = d.getFullYear();
    return `Поставка ${sourceName} от ${dd}.${mm}.${yyyy}`;
  }

  function closeOzonFbsSupplyDetailNewSupplyModal() {
    if (sdNewSupplyState.busy) return;
    const err = document.getElementById("ozonFbsSupplyDetailNewSupplyErr");
    if (err) {
      err.hidden = true;
      err.textContent = "";
    }
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsSupplyDetailNewSupplyModal", false);
    } else {
      document.getElementById("ozonFbsSupplyDetailNewSupplyModal")?.classList.add("hidden");
    }
  }

  function openOzonFbsSupplyDetailNewSupply() {
    const nums = supplyDetailSelectedPostingNumbers();
    if (!nums.length) {
      alert("Выберите отправления");
      return;
    }
    const err = document.getElementById("ozonFbsSupplyDetailNewSupplyErr");
    if (err) {
      err.hidden = true;
      err.textContent = "";
    }
    const lead = document.getElementById("ozonFbsSupplyDetailNewSupplyLead");
    if (lead) {
      lead.textContent =
        `Локальный перенос ${nums.length} отпр. в новую поставку. В Ozon ничего не отправляется.`;
    }
    const input = document.getElementById("ozonFbsSupplyDetailNewSupplyName");
    if (input) input.value = _ozonFbsSuggestedLocalSupplyName();
    const btn = document.getElementById("ozonFbsSupplyDetailNewSupplyConfirmBtn");
    if (btn) {
      btn.disabled = false;
      btn.textContent = "Создать";
    }
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsSupplyDetailNewSupplyModal", true);
    } else {
      document.getElementById("ozonFbsSupplyDetailNewSupplyModal")?.classList.remove("hidden");
    }
  }

  async function confirmOzonFbsSupplyDetailNewSupply() {
    const nums = supplyDetailSelectedPostingNumbers();
    const sourceId = Number(supplyDetailState.sourceId || state.sourceId || 0) || 0;
    const name = String(
      document.getElementById("ozonFbsSupplyDetailNewSupplyName")?.value || ""
    ).trim();
    if (!nums.length || !sourceId) {
      alert("Выберите отправления");
      return;
    }
    const err = document.getElementById("ozonFbsSupplyDetailNewSupplyErr");
    const btn = document.getElementById("ozonFbsSupplyDetailNewSupplyConfirmBtn");
    if (err) {
      err.hidden = true;
      err.textContent = "";
    }
    if (btn) {
      btn.disabled = true;
      btn.textContent = "Создание…";
    }
    sdNewSupplyState.busy = true;
    try {
      const res = await fetch("/api/ozon-fbs/postings/bulk-move-to-new-supply", {
        method: "POST",
        headers: jsonHeaders(),
        body: JSON.stringify({
          source_id: sourceId,
          posting_numbers: nums,
          name,
          target_tab: String(supplyDetailState.postingTab || "awaiting_deliver"),
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      const msg = String(data.message || "Поставка создана");
      sdNewSupplyState.busy = false;
      closeOzonFbsSupplyDetailNewSupplyModal();
      await _ozonFbsAfterLocalMoveSuccess(msg, nums);
      alert(msg);
    } catch (e) {
      if (err) {
        err.hidden = false;
        err.textContent = String(e.message || e);
      }
      if (btn) {
        btn.disabled = false;
        btn.textContent = "Создать";
      }
    } finally {
      sdNewSupplyState.busy = false;
    }
  }

  async function formShipmentsCarriage() {
    const sid = shipmentsState.supplyId;
    const sourceId = shipmentsState.sourceId;
    if (!sid || !sourceId || shipmentsState.forming) return;
    const dateEl = document.getElementById("ozonFbsShipmentsDate");
    const methodEl = document.getElementById("ozonFbsShipmentsMethod");
    const day = String(dateEl?.value || todayIsoDate());
    const methodId = String(methodEl?.value || "").trim();
    if (!methodId) {
      alert("Выберите метод доставки");
      return;
    }
    shipmentsState.forming = true;
    renderShipmentsView(shipmentsState.data);
    try {
      const res = await fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/shipments/form`,
        {
          method: "POST",
          headers: jsonHeaders(),
          body: JSON.stringify({
            source_id: Number(sourceId),
            departure_date: day,
            delivery_method_id: Number(methodId),
          }),
        }
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || "Ошибка формирования");
      shipmentsState.data = data;
      fillShipmentsMethods(
        data.delivery_methods,
        data.selected_delivery_method_id,
        data.selected_delivery_method_name
      );
      renderShipmentsView(data);
      if (data.message) showSyncInfo(String(data.message));
    } catch (e) {
      alert(e.message || String(e));
      renderShipmentsView(shipmentsState.data);
    } finally {
      shipmentsState.forming = false;
      renderShipmentsView(shipmentsState.data);
    }
  }

  function shipmentsPrintBarcode() {
    const sid = shipmentsState.supplyId;
    const sourceId = shipmentsState.sourceId;
    if (!sid || !sourceId) return;
    const dateEl = document.getElementById("ozonFbsShipmentsDate");
    const methodEl = document.getElementById("ozonFbsShipmentsMethod");
    const day = String(dateEl?.value || todayIsoDate());
    const methodId = String(methodEl?.value || shipmentsState.data?.selected_delivery_method_id || "").trim();
    const barcode = resolveShipmentsBarcode(shipmentsState.data);
    const text = String(barcode?.barcode_text || "").trim();
    const labelB64 = String(barcode?.barcode_label_base64 || "").trim();
    if (!text && !barcode?.barcode_image_base64 && !labelB64) {
      alert("Штрихкод склада недоступен");
      return;
    }
    if (text && typeof JsBarcode !== "undefined") {
      try {
        openOzonFbsShipmentBarcodePrintWindow(text, shipmentsState.data?.warehouse_name || "");
        return;
      } catch (e) {
        if (!labelB64 && !barcode?.barcode_image_base64) {
          alert(String(e.message || e));
          return;
        }
      }
    }
    const qs = new URLSearchParams({
      source_id: String(sourceId),
      departure_date: day,
    });
    if (methodId) qs.set("delivery_method_id", methodId);
    const url =
      `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/shipments/barcode-print?${qs.toString()}`;
    openPrintHtml(url, "Разрешите всплывающие окна для печати штрихкода")
      .catch((e) => alert(String(e.message || e)));
  }

  async function shipmentsDownloadBarcode() {
    const sid = shipmentsState.supplyId;
    const sourceId = shipmentsState.sourceId;
    if (!sid || !sourceId) return;
    const dateEl = document.getElementById("ozonFbsShipmentsDate");
    const methodEl = document.getElementById("ozonFbsShipmentsMethod");
    const day = String(dateEl?.value || todayIsoDate());
    const methodId = String(methodEl?.value || shipmentsState.data?.selected_delivery_method_id || "").trim();
    const barcode = resolveShipmentsBarcode(shipmentsState.data) || {};
    const labelB64 = String(barcode.barcode_label_base64 || "").trim();
    const text = String(barcode.barcode_text || "").trim();
    const suffix = text || "warehouse";
    const triggerDownload = (href, filename) => {
      const a = document.createElement("a");
      a.href = href;
      a.download = filename;
      a.click();
    };
    const clientDataUrl = text ? getOzonFbsShipmentBarcodeLabelDataUrl(barcode) : "";
    if (clientDataUrl) {
      triggerDownload(clientDataUrl, `ozon-warehouse-barcode-${suffix}.png`);
      return;
    }
    if (labelB64) {
      triggerDownload(`data:image/png;base64,${labelB64}`, `ozon-warehouse-barcode-${suffix}.png`);
      return;
    }
    try {
      const qs = new URLSearchParams({
        source_id: String(sourceId),
        departure_date: day,
      });
      if (methodId) qs.set("delivery_method_id", methodId);
      const res = await fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/shipments/barcode-label?${qs.toString()}`
      );
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      triggerDownload(url, `ozon-warehouse-barcode-${suffix}.png`);
      setTimeout(() => URL.revokeObjectURL(url), 60_000);
    } catch (e) {
      alert(e.message || String(e));
    }
  }

  const ozonFbsKizState = {
    rows: [],
    errors: {},
    pendingPosting: null,
    saving: false,
    rowsReady: false,
    baselineByPosting: {},
    forceSaveByPosting: {},
    localAutosaveChain: Promise.resolve(),
    localAutosaveSeqByPosting: {},
    localAutosaveInflight: 0,
    /** @type {Set<string>} postings waiting for coalesced silent save */
    localAutosaveDirty: new Set(),
    localAutosaveClearByPosting: {},
    localAutosaveFlushQueued: false,
    /** @type {Map<string, object>} posting_number → row */
    rowsByPosting: new Map(),
    /** @type {Map<string, string>} normalized mark → posting_number */
    markIndex: new Map(),
    /** @type {Map<string, string[]>} sticker scan key → posting_number[] */
    stickerIndex: new Map(),
    statusRefreshing: false,
    statusRefreshGen: 0,
    /** Re-run status once current refresh finishes (open+save race). */
    statusRefreshQueued: false,
    /** While modal open: soft-poll marking/status so peer scans update fill counters. */
    modalStatusPollTimer: null,
    modalStatusFirstTimer: null,
    modalStatusBurstRetry: null,
    lastModalStatusPollAt: 0,
    /** Defer table rebuild when operator is typing in a KIZ cell. */
    peerDomRefreshPending: false,
    /** Bumped to abort in-flight marking resolve when modal closes / reopens. */
    loadGen: 0,
    /** @type {Array<object>} conflicts from last import (sticker has other KIZ) */
    importConflicts: [],
    /** Rate-limit bucket for anomaly-only scan diagnostics (not on happy path). */
    diagWindowMs: 0,
    diagWindowCount: 0,
  };

  const ozonFbsPickState = {
    rows: [],
    errors: {},
    pendingPosting: null,
    saving: false,
    rowsReady: false,
    baselineByPosting: {},
    forceSaveByPosting: {},
    localAutosaveChain: Promise.resolve(),
    localAutosaveSeqByPosting: {},
    localAutosaveInflight: 0,
    statusRefreshing: false,
    statusRefreshGen: 0,
    /** Re-run status once current refresh finishes (open+save race). */
    statusRefreshQueued: false,
    /** While modal open: soft-poll pick-verify/status for peer fill counters. */
    modalStatusPollTimer: null,
    modalStatusFirstTimer: null,
    modalStatusBurstRetry: null,
    lastModalStatusPollAt: 0,
    peerDomRefreshPending: false,
    /** Bumped to abort in-flight pick-verify resolve when modal closes / reopens. */
    loadGen: 0,
  };

  /**
   * Anomaly-only scan diagnostics → journal via tiny POST.
   * Never called on successful sticker/КИЗ scan. Rate-limited; fire-and-forget.
   */
  function _ozonFbsKizScanDiag(reason, detail) {
    const now = Date.now();
    if (!ozonFbsKizState.diagWindowMs || now - ozonFbsKizState.diagWindowMs > 60000) {
      ozonFbsKizState.diagWindowMs = now;
      ozonFbsKizState.diagWindowCount = 0;
    }
    if (ozonFbsKizState.diagWindowCount >= 12) return;
    ozonFbsKizState.diagWindowCount += 1;
    const reasonKey = String(reason || "unknown").slice(0, 64);
    const detailText = String(detail || "").slice(0, 360);
    try {
      console.warn("[ozon-fbs-scan]", reasonKey, detailText);
    } catch (_e) {
      /* ignore */
    }
    try {
      const body = JSON.stringify({
        area: "ozon_fbs_marking_scan",
        reason: reasonKey,
        detail: detailText,
        supply_id: String(supplyDetailState.supplyId || ""),
        source_id: Number(supplyDetailState.sourceId || state.sourceId || 0) || 0,
      });
      // keepalive + no await: must not slow or block the scan path.
      void fetch("/api/ozon-fbs/client-diag", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body,
        credentials: "same-origin",
        keepalive: true,
      }).catch(() => {});
    } catch (_e) {
      /* ignore */
    }
  }
  window._ozonFbsKizScanDiag = _ozonFbsKizScanDiag;

  function _ozonFbsKizScanDiagSnapshot(input) {
    const ruOpen =
      typeof _wbFbsKizRuLayoutModalOpen === "function" && _wbFbsKizRuLayoutModalOpen();
    const prompt = document.getElementById("ozonFbsKizScanPrompt");
    const promptOpen = !!(prompt && !prompt.classList.contains("hidden"));
    const activeId = document.activeElement?.id || "";
    return [
      `ru=${ruOpen ? 1 : 0}`,
      `ready=${ozonFbsKizState.rowsReady ? 1 : 0}`,
      `ro=${input?.readOnly ? 1 : 0}`,
      `dis=${input?.disabled ? 1 : 0}`,
      `prompt=${promptOpen ? 1 : 0}`,
      `pending=${String(ozonFbsKizState.pendingPosting || "")}`,
      `focus=${activeId}`,
      `valLen=${String(input?.value || "").length}`,
      `rows=${(ozonFbsKizState.rows || []).length}`,
    ].join(" ");
  }

  function _ozonFbsNormalizeScan(value) {
    if (typeof _wbFbsKizNormalizeScan === "function") {
      return _wbFbsKizNormalizeScan(value);
    }
    return String(value || "").replace(/\s+/g, "").trim();
  }

  function _ozonFbsStickerScanKey(value) {
    if (typeof _wbFbsKizScanKey === "function") {
      return _wbFbsKizScanKey(value);
    }
    return _ozonFbsNormalizeScan(value).toLocaleLowerCase("en-US");
  }

  function _ozonFbsStickerPartsFromPostingNumber(postingNumber) {
    const pn = String(postingNumber || "").trim();
    if (!pn) return { part_a: "", part_b: "" };
    const idx = pn.indexOf("-");
    if (idx < 0) return { part_a: pn, part_b: "" };
    return {
      part_a: pn.slice(0, idx).trim(),
      part_b: pn.slice(idx + 1).trim(),
    };
  }

  function _ozonFbsStickerNumberFromRow(row) {
    const partA = _ozonFbsNormalizeScan(row?.sticker_part_a);
    const partB = _ozonFbsNormalizeScan(row?.sticker_part_b);
    if (partA && partB) return `${partA}${partB}`;
    if (partA || partB) return partA || partB;
    return _ozonFbsNormalizeScan(row?.posting_number);
  }

  function _ozonFbsLooksLikeScanit(value) {
    const raw = String(value || "").replace(/\s+/g, "").trim();
    return /^ii[A-Za-z0-9._-]{2,}$/i.test(raw);
  }

  /** Last-4 posting/supply digits for SEARCH boxes only — never for sticker scan. */
  function _ozonFbsSearchPostingDigitTail(raw) {
    const q = String(raw || "").replace(/\s+/g, "").trim();
    if (!q || _ozonFbsLooksLikeScanit(q)) return "";
    const d = q.replace(/\D+/g, "");
    if (d.length >= 12 && d === q) return "";
    if (d.length >= 4 && d.length <= 8) return d.slice(-4);
    return "";
  }

  function _ozonFbsSearchMatchesPostingOrSupply(row, q) {
    if (!q) return true;
    const needle = String(q).trim().toLowerCase();
    if (!needle) return true;
    const pn = String(row?.posting_number || "").trim();
    const sid = String(row?.supply_id || "").trim();
    if (pn.toLowerCase().includes(needle) || sid.toLowerCase().includes(needle)) return true;
    const tail = _ozonFbsSearchPostingDigitTail(needle);
    if (!tail) return false;
    const pnDigits = pn.replace(/\D+/g, "");
    const sidDigits = sid.replace(/\D+/g, "");
    return (!!pnDigits && pnDigits.endsWith(tail)) || (!!sidDigits && sidDigits.endsWith(tail));
  }

  /** Supply-detail search: posting/SKU/name + package QR + ii… scanit (same idea as KIZ/Pick). */
  function _ozonFbsSupplyDetailRowMatchesSearch(row, q) {
    if (!q) return true;
    const needle = String(q).trim().toLowerCase();
    if (!needle) return true;
    const fields = _ozonFbsResolvedStickerFields(row);
    const hay = [
      row?.posting_number, row?.offer_id, row?.sku, row?.product_name, row?.warehouse_label,
      fields.upper, fields.lower, fields.scanit, fields.partA, fields.partB,
      ...(Array.isArray(row?.barcodes) ? row.barcodes : []),
      ...(Array.isArray(row?.products_brief)
        ? row.products_brief.flatMap((p) => [p?.offer_id, p?.sku, p?.name])
        : []),
    ].map((x) => String(x || "").toLowerCase()).join(" ");
    if (hay.includes(needle)) return true;
    return _ozonFbsSearchMatchesPostingOrSupply(row, needle);
  }

  function _ozonFbsResolvedStickerFields(row) {
    let upper = _ozonFbsNormalizeScan(row?.sticker_barcode);
    let lower = _ozonFbsNormalizeScan(row?.sticker_lower_barcode);
    let scanit = _ozonFbsNormalizeScan(row?.sticker_scanit);
    let partA = _ozonFbsNormalizeScan(row?.sticker_part_a);
    let partB = _ozonFbsNormalizeScan(row?.sticker_part_b);
    const pn = String(row?.posting_number || "").trim();
    if ((!partA || !partB) && pn) {
      const parts = _ozonFbsStickerPartsFromPostingNumber(pn);
      if (!partA) partA = _ozonFbsNormalizeScan(parts.part_a);
      if (!partB) partB = _ozonFbsNormalizeScan(parts.part_b);
    }
    return { upper, lower, scanit, partA, partB, pn };
  }

  /**
   * Ozon FBS sticker scan — exact QR / ``ii…`` / full posting_number only.
   * Partial posting tail lives in search boxes, not in the scan field.
   */
  function _ozonFbsFindByStickerInRows(scan, rows, opts) {
    const raw = _ozonFbsNormalizeScan(scan);
    if (!raw) return { row: null, ambiguous: false };
    const rawKey = _ozonFbsStickerScanKey(raw);
    const rawLower = raw.toLowerCase();
    const includeCancelled = !!(opts && opts.includeCancelled);
    const list = includeCancelled
      ? (Array.isArray(rows) ? rows : [])
      : _ozonFbsActiveModalRows(Array.isArray(rows) ? rows : []);

    const rowKey = (row) => String(row?.posting_number || row?.order_id || "").trim();

    const byBarcode = [];
    const seenBc = new Set();
    for (const row of list) {
      const fields = _ozonFbsResolvedStickerFields(row);
      let hit = false;
      if (fields.upper && _ozonFbsStickerScanKey(fields.upper) === rawKey) hit = true;
      else if (fields.lower && _ozonFbsStickerScanKey(fields.lower) === rawKey) hit = true;
      else if (fields.scanit && _ozonFbsStickerScanKey(fields.scanit) === rawKey) hit = true;
      if (!hit) continue;
      const id = rowKey(row);
      if (id && seenBc.has(id)) continue;
      if (id) seenBc.add(id);
      byBarcode.push(row);
    }
    if (byBarcode.length === 1) return { row: byBarcode[0], ambiguous: false };
    if (byBarcode.length > 1) return { row: null, ambiguous: true, matches: byBarcode };

    const byPnExact = [];
    const seenPn = new Set();
    for (const row of list) {
      const pn = String(row?.posting_number || "").trim();
      if (!(pn && pn.toLowerCase() === rawLower)) continue;
      if (pn && seenPn.has(pn)) continue;
      if (pn) seenPn.add(pn);
      byPnExact.push(row);
    }
    if (byPnExact.length === 1) return { row: byPnExact[0], ambiguous: false };
    if (byPnExact.length > 1) return { row: null, ambiguous: true, matches: byPnExact };
    return { row: null, ambiguous: false };
  }

  function _ozonFbsApplyStickerScanToRow(row, scanRaw) {
    if (!row) return;
    const raw = _ozonFbsNormalizeScan(scanRaw);
    if (!raw) return;
    const pn = String(row.posting_number || "").trim();
    const rawKey = _ozonFbsStickerScanKey(raw);
    const rawLower = raw.toLowerCase();
    const pnLower = pn.toLowerCase();
    let partA = String(row.sticker_part_a || "").trim();
    let partB = String(row.sticker_part_b || "").trim();
    if (!partA && !partB && pn) {
      const parts = _ozonFbsStickerPartsFromPostingNumber(pn);
      partA = parts.part_a;
      partB = parts.part_b;
    }
    const knownUpper = _ozonFbsNormalizeScan(row.sticker_barcode);
    const knownLower = _ozonFbsNormalizeScan(row.sticker_lower_barcode);
    const knownScanit = _ozonFbsNormalizeScan(row.sticker_scanit);
    if (knownScanit && _ozonFbsStickerScanKey(knownScanit) === rawKey) {
      row.sticker_scanit = raw;
    } else if (_ozonFbsLooksLikeScanit(raw)) {
      row.sticker_scanit = raw;
    } else if (knownLower && _ozonFbsStickerScanKey(knownLower) === rawKey) {
      row.sticker_lower_barcode = raw;
    } else if (knownUpper && _ozonFbsStickerScanKey(knownUpper) === rawKey) {
      row.sticker_barcode = raw;
    } else if (rawLower === pnLower || (pnLower && rawLower.includes(pnLower))) {
      if (!row.sticker_barcode) row.sticker_barcode = raw;
    } else {
      // Новый скан с этикетки — по умолчанию upper; Ozon API разделяет upper/lower.
      row.sticker_barcode = raw;
    }
    if (partA) row.sticker_part_a = partA;
    if (partB) row.sticker_part_b = partB;
  }

  async function _ozonFbsPersistStickerForRow(row, scanRaw) {
    const pn = String(row?.posting_number || "").trim();
    const raw = _ozonFbsNormalizeScan(scanRaw);
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    if (!pn || !raw || !sourceId) return;
    _ozonFbsApplyStickerScanToRow(row, raw);
    if (ozonFbsKizState.rowsByPosting?.has(pn)) {
      _ozonFbsKizRebuildIndexes();
    }
    try {
      await fetch("/api/ozon-fbs/postings/persist-sticker", {
        method: "POST",
        headers: { "Content-Type": "application/json", ...jsonHeaders() },
        body: JSON.stringify({
          source_id: sourceId,
          posting_number: pn,
          scan_raw: raw,
          sticker_barcode: String(row.sticker_barcode || "").trim(),
          sticker_lower_barcode: String(row.sticker_lower_barcode || "").trim(),
          sticker_scanit: String(row.sticker_scanit || "").trim(),
          sticker_part_a: String(row.sticker_part_a || "").trim(),
          sticker_part_b: String(row.sticker_part_b || "").trim(),
          supply_id: String(supplyDetailState.supplyId || "").trim() || undefined,
        }),
      });
    } catch (_) {
      /* local bind is best-effort */
    }
  }

  async function _ozonFbsPersistStickerScan(postingNumber, scanRaw) {
    const pn = String(postingNumber || "").trim();
    const row =
      ozonFbsKizState.rows.find((r) => String(r.posting_number) === pn)
      || ozonFbsPickState.rows.find((r) => String(r.posting_number) === pn)
      || { posting_number: pn };
    await _ozonFbsPersistStickerForRow(row, scanRaw);
  }

  function _ozonFbsNormalizeMark(value) {
    let text;
    if (typeof _wbFbsKizNormalizeMark === "function") {
      text = _wbFbsKizNormalizeMark(value);
    } else {
      text = String(value || "")
        .replace(/\u2194/g, "\u001D")
        .replace(/\r?\n/g, "")
        .replace(/^[ \t\r\n]+|[ \t\r\n]+$/g, "");
    }
    // Ozon-only: scanners/pastes sometimes use ☻/☺ instead of GS; also
    // accept visible "<GS>" / "\\u001D" from normalized copy-paste lists.
    text = String(text || "")
      .replace(/\u263b/g, "\u001D") // ☻
      .replace(/\u263a/g, "\u001D") // ☺
      .replace(/\\u001[dD]/g, "\u001D")
      .replace(/<GS>/gi, "\u001D")
      .replace(/\r?\n/g, "");
    // ЧЗ: GS before AI 91 (4-char key) and before AI 92 crypto.
    text = text.replace(/(91[0-9A-Za-z+/]{4})(?!\u001D)(92)/, "$1\u001D$2");
    text = text.replace(/(?<!\u001D)(91[0-9A-Za-z+/]{4}\u001D92)/, "\u001D$1");
    return text;
  }

  function _ozonFbsKizMarkLooksComplete(mark) {
    const raw = _ozonFbsNormalizeMark(mark);
    if (!raw || !/^01\d{14}21/.test(raw)) return false;
    return /\u001D91.{4}\u001D92.{20,}/.test(raw) || /91.{4}\u001D92.{20,}/.test(raw);
  }

  function _ozonFbsKizCanImport() {
    // Available to all roles while Marking modal is open and rows are loaded.
    return _ozonFbsKizModalIsOpen() && !!ozonFbsKizState.rowsReady;
  }

  function _ozonFbsKizSyncImportBtn() {
    const btn = document.getElementById("ozonFbsKizImportBtn");
    if (!btn) return;
    const can = !!ozonFbsKizState.rowsReady && _ozonFbsKizModalIsOpen();
    btn.hidden = !can;
    btn.style.display = can ? "" : "none";
    if (!can) closeOzonFbsKizImportModal();
  }

  function _ozonFbsKizImportModalIsOpen() {
    const modal = document.getElementById("ozonFbsKizImportModal");
    return !!(modal && !modal.classList.contains("hidden"));
  }

  function openOzonFbsKizImportModal() {
    if (!_ozonFbsKizModalIsOpen() || !ozonFbsKizState.rowsReady) {
      alert("Сначала откройте модалку «Маркировка» и дождитесь загрузки");
      return;
    }
    _ozonFbsKizSyncImportBtn();
    if (typeof setModalVisibility === "function") setModalVisibility("ozonFbsKizImportModal", true);
    else document.getElementById("ozonFbsKizImportModal")?.classList.remove("hidden");
    const ta = document.getElementById("ozonFbsKizImportText");
    if (ta) {
      // Scanner-first: keep focus in the paste/scan field; wedge ends with Enter → newline.
      setTimeout(() => {
        ta.focus();
        try {
          const len = String(ta.value || "").length;
          ta.setSelectionRange(len, len);
        } catch (_e) {
          /* ignore */
        }
      }, 40);
    }
  }

  function closeOzonFbsKizImportModal() {
    // Unlock keyboard if RU warning was open for this textarea (do not wipe text).
    try {
      if (
        typeof _wbFbsKizRuLayoutModalOpen === "function"
        && _wbFbsKizRuLayoutModalOpen()
        && typeof wbFbsKizState !== "undefined"
        && wbFbsKizState.ruLayoutFocusId === "ozonFbsKizImportText"
      ) {
        document.removeEventListener("keydown", _wbFbsKizRuLayoutSwallowKeys, true);
        if (typeof setModalVisibility === "function") {
          setModalVisibility("wbFbsKizRuLayoutModal", false);
        }
        wbFbsKizState.ruLayoutFocusId = null;
        wbFbsKizState.ruLayoutPreserveValue = false;
        wbFbsKizState.ruLayoutOpenedAt = 0;
      }
    } catch (_e) {
      /* ignore */
    }
    if (typeof setModalVisibility === "function") setModalVisibility("ozonFbsKizImportModal", false);
    else document.getElementById("ozonFbsKizImportModal")?.classList.add("hidden");
  }

  /** Open the shared «Русская раскладка» modal; never wipe the import textarea. */
  function _ozonFbsKizImportWarnRuLayout(inputEl) {
    if (typeof _wbFbsKizBlockRuLayout !== "function") return;
    if (typeof _wbFbsKizRuLayoutModalOpen === "function" && _wbFbsKizRuLayoutModalOpen()) {
      return;
    }
    _wbFbsKizBlockRuLayout(inputEl, { preserveValue: true });
  }

  /**
   * Pre-input RU check (beforeinput): block Cyrillic before it lands in the field,
   * show the same modal as Marking, keep existing text intact.
   */
  function onOzonFbsKizImportTextBeforeInput(event) {
    if (!event) return;
    const input = event.target;
    if (!input) return;
    const inputType = String(event.inputType || "");
    if (typeof _wbFbsKizRuLayoutModalOpen === "function" && _wbFbsKizRuLayoutModalOpen()) {
      // While warning is open: block new inserts, allow Backspace/Delete to fix leftovers.
      if (inputType.startsWith("insert")) {
        event.preventDefault();
      }
      return;
    }
    // Paste is handled in onpaste (clipboardData is reliable there).
    if (inputType === "insertFromPaste" || inputType === "insertFromDrop") return;
    const data = String(event.data || "");
    if (!data) return;
    if (typeof _wbFbsKizHasCyrillic === "function" && _wbFbsKizHasCyrillic(data)) {
      event.preventDefault();
      _ozonFbsKizImportWarnRuLayout(input);
    }
  }

  /** Paste path: reject clipboard with Cyrillic before it enters the textarea. */
  function onOzonFbsKizImportTextPaste(event) {
    if (!event) return;
    const input = event.target;
    if (!input) return;
    if (typeof _wbFbsKizRuLayoutModalOpen === "function" && _wbFbsKizRuLayoutModalOpen()) {
      event.preventDefault();
      return;
    }
    const text = String(event.clipboardData?.getData("text") || "");
    if (typeof _wbFbsKizHasCyrillic === "function" && _wbFbsKizHasCyrillic(text)) {
      event.preventDefault();
      _ozonFbsKizImportWarnRuLayout(input);
    }
  }

  /**
   * Safety net if Cyrillic somehow got into the field (e.g. old buffer).
   * Same modal as Marking; never wipe the textarea; no sticky bottom error.
   */
  function onOzonFbsKizImportTextInput(event) {
    const input = event?.target;
    if (!input) return;
    if (typeof _wbFbsKizRuLayoutModalOpen === "function" && _wbFbsKizRuLayoutModalOpen()) {
      return;
    }
    if (typeof _wbFbsKizHasCyrillic === "function" && _wbFbsKizHasCyrillic(input.value)) {
      _ozonFbsKizImportWarnRuLayout(input);
    }
  }

  /**
   * Scanner-friendly Enter: after sticker+КИЗ pair lands (wedge sends Enter),
   * apply the latest complete pair immediately. Ctrl/Cmd+Enter runs full import.
   */
  function onOzonFbsKizImportTextKey(event) {
    if (!event) return;
    if (typeof _wbFbsKizRuLayoutModalOpen === "function" && _wbFbsKizRuLayoutModalOpen()) {
      // Swallow scanner tail while warning is open; do not wipe the field.
      // Allow Backspace/Delete so leftover Cyrillic can be removed.
      const key = String(event.key || "");
      if (key === "Enter" || key === "Tab" || key.length === 1) {
        event.preventDefault();
      }
      return;
    }
    if ((event.ctrlKey || event.metaKey) && event.key === "Enter") {
      event.preventDefault();
      void runOzonFbsKizImport();
      return;
    }
    if (event.key !== "Enter" || event.ctrlKey || event.metaKey || event.altKey) return;
    // Allow newline for sticker / KIZ separation, then try live apply.
    window.setTimeout(() => {
      void _ozonFbsKizImportApplyLatestScanPair();
    }, 0);
  }

  async function _ozonFbsKizImportApplyLatestScanPair() {
    if (!_ozonFbsKizImportModalIsOpen() || !_ozonFbsKizCanImport()) return;
    const ta = document.getElementById("ozonFbsKizImportText");
    if (!ta) return;
    if (typeof _wbFbsKizHasCyrillic === "function" && _wbFbsKizHasCyrillic(ta.value)) {
      return;
    }
    const snapshot = String(ta.value || "");
    const pairs = _ozonFbsKizParseImportText(snapshot);
    if (!pairs.length) return;
    // Batch paste: operator uses «Импортировать». Live wedge usually has 1 pair in flight.
    if (pairs.length > 2) return;
    const last = pairs[pairs.length - 1];
    const mark = _ozonFbsNormalizeMark(last.kiz);
    // Wait until the wedge finished a Data Matrix (not only the sticker line).
    if (!/^01\d{14}21/.test(mark)) return;
    // Do not accept truncated scans (typical cut right at GS before AI 91, ~31 chars).
    if (!_ozonFbsKizMarkLooksComplete(mark)) {
      _ozonFbsKizImportSetInfo(
        `КИЗ обрезан / неполный (${mark.length} симв.) — пересканируйте маркировку целиком`
      );
      const info = document.getElementById("ozonFbsKizImportInfo");
      if (info) {
        info.classList.remove("is-ok");
        info.classList.add("is-warn");
      }
      return;
    }
    const remaining = pairs.slice(0, -1);
    ta.value = `${last.sticker}\t${last.kiz}`;
    let result = null;
    try {
      result = await runOzonFbsKizImport({ liveScan: true });
    } finally {
      // Only drop the applied pair on success; keep buffer on skip/error for rescan.
      if (result && Number(result.okN || 0) > 0) {
        ta.value = remaining.map((p) => `${p.sticker}\t${p.kiz}`).join("\n");
      } else {
        ta.value = snapshot;
      }
      ta.focus();
      try {
        const len = String(ta.value || "").length;
        ta.setSelectionRange(len, len);
      } catch (_e) {
        /* ignore */
      }
    }
  }

  /** @deprecated use openOzonFbsKizImportModal / closeOzonFbsKizImportModal */
  function toggleOzonFbsKizImportPanel(forceOpen) {
    if (forceOpen === false) {
      closeOzonFbsKizImportModal();
      return;
    }
    if (forceOpen === true || !_ozonFbsKizImportModalIsOpen()) openOzonFbsKizImportModal();
    else closeOzonFbsKizImportModal();
  }

  function _ozonFbsKizImportSetInfo(text, ok) {
    const el = document.getElementById("ozonFbsKizImportInfo");
    if (!el) {
      _ozonFbsKizSetInfo(text, ok);
      return;
    }
    const msg = String(text || "").trim();
    el.hidden = !msg;
    el.textContent = msg;
    el.classList.remove("is-warn");
    el.classList.toggle("is-ok", !!msg && !!ok);
  }

  function _ozonFbsKizParseImportText(text) {
    // Notepad-like: blank lines between pairs are fine; same-line "sticker KIZ" too.
    const rawLines = String(text || "")
      .replace(/\u00a0/g, " ")
      .split(/\r?\n/);
    const lines = [];
    for (const line of rawLines) {
      const trimmed = line.trim();
      if (!trimmed) continue; // 1–N empty lines between pairs
      if (/^стикер\b/i.test(trimmed) && /\bкиз\b/i.test(trimmed)) continue;
      lines.push(trimmed);
    }

    const pairs = [];
    let pendingSticker = "";

    const pushPair = (sticker, kiz) => {
      const s = String(sticker || "").trim();
      const k = String(kiz || "").trim();
      if (s && k) pairs.push({ sticker: s, kiz: k });
    };

    const isStickerToken = (s) => /^\d{10,20}$/.test(String(s || "").trim());
    const isKizStart = (s) => /^01\d{14}21/.test(String(s || "").trim());

    for (let i = 0; i < lines.length; i += 1) {
      const trimmed = lines[i];

      // Same-line: sticker \t KIZ
      if (trimmed.includes("\t")) {
        pendingSticker = "";
        const parts = trimmed.split("\t");
        pushPair(parts[0], parts.slice(1).join("\t"));
        continue;
      }
      // Same-line: sticker | KIZ
      if (trimmed.includes("|") && /^\d{10,20}\s*\|/.test(trimmed)) {
        pendingSticker = "";
        const idx = trimmed.indexOf("|");
        pushPair(trimmed.slice(0, idx), trimmed.slice(idx + 1));
        continue;
      }
      // Same-line: sticker + spaces + 01…KIZ (Notepad / paste from Excel)
      const inline = trimmed.match(/^(\d{10,20})[ \t]+(01\d{14}21[\s\S]+)$/);
      if (inline) {
        pendingSticker = "";
        pushPair(inline[1], inline[2]);
        continue;
      }

      // Alternating lines: sticker, then KIZ (optionally wrapped after GS → newline).
      if (isStickerToken(trimmed)) {
        pendingSticker = trimmed;
        continue;
      }
      if (pendingSticker && isKizStart(trimmed)) {
        let kiz = trimmed;
        while (i + 1 < lines.length) {
          const nxt = lines[i + 1];
          if (isStickerToken(nxt)) break;
          if (isKizStart(nxt)) break;
          if (nxt.includes("\t") || /^\d{10,20}\s*\|/.test(nxt)) break;
          if (/^\d{10,20}[ \t]+01\d{14}21/.test(nxt)) break;
          // Continuation of crypto / AI91 after GS was turned into a line break.
          kiz += nxt;
          i += 1;
        }
        pushPair(pendingSticker, kiz);
        pendingSticker = "";
        continue;
      }
      // Lone KIZ / junk without sticker — ignore, reset pending.
      pendingSticker = "";
    }
    return pairs;
  }

  function _ozonFbsKizImportSetLog(lines) {
    const el = document.getElementById("ozonFbsKizImportLog");
    if (!el) return;
    const text = (Array.isArray(lines) ? lines : []).join("\n");
    el.hidden = !text;
    el.textContent = text;
  }

  function _ozonFbsKizMarkPreview(mark) {
    const raw = _ozonFbsNormalizeMark(mark);
    if (!raw) return "—";
    if (raw.length <= 28) return raw;
    return `${raw.slice(0, 14)}…${raw.slice(-10)}`;
  }

  function _ozonFbsKizRowExistingCodes(row) {
    return _ozonFbsKizNormalizeCodesList(row?.kiz_codes);
  }

  function _ozonFbsKizClearImportConflicts() {
    ozonFbsKizState.importConflicts = [];
    const wrap = document.getElementById("ozonFbsKizImportConflicts");
    const list = document.getElementById("ozonFbsKizImportConflictsList");
    if (wrap) wrap.hidden = true;
    if (list) list.innerHTML = "";
  }

  function _ozonFbsKizRenderImportConflicts() {
    const wrap = document.getElementById("ozonFbsKizImportConflicts");
    const list = document.getElementById("ozonFbsKizImportConflictsList");
    if (!wrap || !list) return;
    const items = Array.isArray(ozonFbsKizState.importConflicts)
      ? ozonFbsKizState.importConflicts
      : [];
    if (!items.length) {
      wrap.hidden = true;
      list.innerHTML = "";
      return;
    }
    wrap.hidden = false;
    list.innerHTML = items.map((c, idx) => {
      const id = `ozonFbsKizImportConflict_${idx}`;
      const had = (c.existing || []).map(_ozonFbsKizMarkPreview).join("; ");
      const incoming = _ozonFbsKizMarkPreview(c.mark);
      const incompleteNote = c.incomplete ? " · неполный КИЗ" : "";
      return (
        `<label class="ozon-fbs-kiz-import-conflict" for="${id}">` +
          `<input type="checkbox" id="${id}" data-conflict-idx="${idx}" checked />` +
          `<span class="ozon-fbs-kiz-import-conflict-meta">` +
            `<strong>${esc(c.sticker)} → ${esc(c.posting_number)}</strong>` +
            `<span class="ozon-fbs-kiz-import-conflict-codes">сейчас: ${esc(had)}</span>` +
            `<span class="ozon-fbs-kiz-import-conflict-codes">импорт: ${esc(incoming)}${esc(incompleteNote)}</span>` +
          `</span>` +
        `</label>`
      );
    }).join("");
  }

  function selectAllOzonFbsKizImportConflicts(selected) {
    const list = document.getElementById("ozonFbsKizImportConflictsList");
    if (!list) return;
    list.querySelectorAll('input[type="checkbox"][data-conflict-idx]').forEach((el) => {
      el.checked = !!selected;
    });
  }

  function dismissOzonFbsKizImportConflicts() {
    _ozonFbsKizClearImportConflicts();
    _ozonFbsKizImportSetInfo("Конфликты оставлены без замены", true);
  }

  async function applyOzonFbsKizImportConflicts() {
    if (!_ozonFbsKizCanImport()) return;
    if (!ozonFbsKizState.rowsReady || !_ozonFbsKizModalIsOpen()) return;
    const items = Array.isArray(ozonFbsKizState.importConflicts)
      ? ozonFbsKizState.importConflicts
      : [];
    if (!items.length) return;

    const list = document.getElementById("ozonFbsKizImportConflictsList");
    const replaceBtn = document.getElementById("ozonFbsKizImportReplaceBtn");
    const selectedIdx = new Set();
    list?.querySelectorAll('input[type="checkbox"][data-conflict-idx]:checked').forEach((el) => {
      const idx = Number(el.getAttribute("data-conflict-idx"));
      if (Number.isFinite(idx)) selectedIdx.add(idx);
    });
    if (!selectedIdx.size) {
      _ozonFbsKizImportSetInfo("Не выбрано ни одной строки для замены");
      return;
    }

    if (replaceBtn) replaceBtn.disabled = true;
    const log = [];
    let okN = 0;
    let skipN = 0;
    const touched = new Set();
    const remaining = [];

    try {
      for (let idx = 0; idx < items.length; idx += 1) {
        const c = items[idx];
        if (!selectedIdx.has(idx)) {
          remaining.push(c);
          continue;
        }
        const pn = String(c.posting_number || "").trim();
        const mark = _ozonFbsNormalizeMark(c.mark);
        const stickerKey = _ozonFbsNormalizeScan(c.sticker);
        const row = _ozonFbsKizRowByPosting(pn);
        if (!row || !mark || !pn) {
          skipN += 1;
          log.push(`${stickerKey || "—"} → ${pn || "—"} — не удалось заменить`);
          remaining.push(c);
          continue;
        }
        if (_ozonFbsRowIsCancelled(row)) {
          skipN += 1;
          log.push(`${stickerKey} → ${pn} — отправление отменено`);
          remaining.push(c);
          continue;
        }
        const check = _ozonFbsKizValidateMarkForOrder(mark, row);
        if (!check.ok) {
          skipN += 1;
          log.push(`${stickerKey} → ${pn} — ${check.error || "КИЗ не совпадает с ШК"}`);
          remaining.push(c);
          continue;
        }
        const dup = _ozonFbsKizFindExistingMark(mark);
        if (dup && String(dup.posting_number || "").trim() !== pn) {
          skipN += 1;
          log.push(
            `${stickerKey} → ${pn} — КИЗ уже в отправлении ${dup.posting_number}`
          );
          remaining.push(c);
          continue;
        }

        for (const old of _ozonFbsKizRowExistingCodes(row)) {
          if (old && old !== mark) _ozonFbsKizIndexClearMark(old);
        }
        row.kiz_codes = [mark];
        row.kiz_status = "pending";
        delete ozonFbsKizState.errors[pn];
        _ozonFbsKizIndexSetMark(mark, pn);
        touched.add(pn);
        void _ozonFbsPersistStickerForRow(row, stickerKey);
        _ozonFbsKizScheduleLocalAutosave(pn, false);
        if (typeof _ozonFbsContainerMaybeBind === "function") {
          void _ozonFbsContainerMaybeBind("kiz", pn);
        }
        okN += 1;
        log.push(`${stickerKey} → ${pn} — заменён на ${_ozonFbsKizMarkPreview(mark)}`);
      }

      if (touched.size) {
        renderOzonFbsKizTable({ skipCollect: true });
        await _ozonFbsKizAwaitLocalAutosaves();
      }

      ozonFbsKizState.importConflicts = remaining;
      _ozonFbsKizRenderImportConflicts();

      const prevLog = document.getElementById("ozonFbsKizImportLog");
      const prevText = prevLog && !prevLog.hidden ? String(prevLog.textContent || "") : "";
      const extra = ["", "— Замена конфликтов —", ...log, "", `Заменено ${okN}, пропущено ${skipN}`];
      _ozonFbsKizImportSetLog(
        prevText ? prevText.split("\n").concat(extra) : extra
      );
      _ozonFbsKizImportSetInfo(`Замена: ${okN} ок, ${skipN} пропущено`, okN > 0 && skipN === 0);
      if (okN > 0 && skipN > 0) {
        const info = document.getElementById("ozonFbsKizImportInfo");
        if (info) {
          info.classList.remove("is-ok");
          info.classList.add("is-warn");
        }
      }
    } finally {
      if (replaceBtn) replaceBtn.disabled = false;
    }
  }

  async function runOzonFbsKizImport(opts) {
    const liveScan = !!(opts && opts.liveScan);
    const emptyResult = { okN: 0, skipN: 0, conflicts: 0 };
    if (!_ozonFbsKizCanImport()) {
      if (!liveScan) {
        _ozonFbsKizImportSetInfo("Сначала откройте модалку маркировки и дождитесь загрузки");
      }
      return emptyResult;
    }
    if (!ozonFbsKizState.rowsReady || !_ozonFbsKizModalIsOpen()) {
      _ozonFbsKizImportSetInfo("Сначала откройте модалку маркировки и дождитесь загрузки");
      return emptyResult;
    }
    const ta = document.getElementById("ozonFbsKizImportText");
    const runBtn = document.getElementById("ozonFbsKizImportRunBtn");
    const rawText = String(ta?.value || "");
    if (typeof _wbFbsKizHasCyrillic === "function" && _wbFbsKizHasCyrillic(rawText)) {
      if (!liveScan && ta) {
        _ozonFbsKizImportWarnRuLayout(ta);
      }
      return emptyResult;
    }
    const pairs = _ozonFbsKizParseImportText(rawText);
    if (!pairs.length) {
      if (!liveScan) {
        _ozonFbsKizImportSetLog([
          "Нет пар стикер+КИЗ. Допустимо:",
          "• стикер и КИЗ в одной строке через пробел или таб",
          "• стикер, затем КИЗ на следующей строке (пустые строки между ними ок)",
        ]);
        _ozonFbsKizImportSetInfo("Импорт: пустой список");
        _ozonFbsKizClearImportConflicts();
      }
      return emptyResult;
    }

    if (runBtn) runBtn.disabled = true;
    _ozonFbsKizSyncActiveCodeInput();
    _ozonFbsKizClearImportConflicts();
    const log = [];
    let okN = 0;
    let skipN = 0;
    const touched = new Set();
    /** Marks accepted earlier in this same paste — avoid double-add in one run. */
    const importedMarks = new Set();
    /** @type {Map<string, object>} posting_number → conflict (last wins) */
    const conflictsByPn = new Map();

    try {
      for (let i = 0; i < pairs.length; i += 1) {
        const { sticker, kiz } = pairs[i];
        const n = i + 1;
        const stickerKey = _ozonFbsNormalizeScan(sticker);
        const mark = _ozonFbsNormalizeMark(kiz);
        if (!stickerKey || !mark) {
          skipN += 1;
          log.push(`${n}. пропуск — пустой стикер или КИЗ`);
          continue;
        }
        const incomplete = !_ozonFbsKizMarkLooksComplete(mark);

        const found = _ozonFbsKizFindBySticker(stickerKey);
        if (found.ambiguous) {
          skipN += 1;
          const ids = (found.matches || []).map((r) => r.posting_number).slice(0, 4).join(", ");
          log.push(`${n}. ${stickerKey} — стикер неоднозначен (${ids || "несколько отправлений"})`);
          continue;
        }
        if (!found.row) {
          skipN += 1;
          log.push(`${n}. ${stickerKey} — стикер не найден в этой поставке`);
          continue;
        }
        const row = found.row;
        const pn = String(row.posting_number || "").trim();
        if (!pn) {
          skipN += 1;
          log.push(`${n}. ${stickerKey} — нет номера отправления`);
          continue;
        }
        if (_ozonFbsRowIsCancelled(row)) {
          skipN += 1;
          log.push(`${n}. ${stickerKey} → ${pn} — отправление отменено`);
          continue;
        }

        const check = _ozonFbsKizValidateMarkForOrder(mark, row);
        if (!check.ok) {
          skipN += 1;
          log.push(`${n}. ${stickerKey} → ${pn} — ${check.error || "КИЗ не совпадает с ШК"}`);
          ozonFbsKizState.errors[pn] = check.error || "КИЗ не совпадает с ШК";
          continue;
        }

        const existing = _ozonFbsKizRowExistingCodes(row);
        // Same sticker + same KIZ already scanned (or already in this paste).
        if (existing.includes(mark) || importedMarks.has(mark)) {
          skipN += 1;
          log.push(
            `${n}. ${stickerKey} → ${pn} — дубль: стикер и КИЗ уже просканированы ` +
              `(${_ozonFbsKizMarkPreview(mark)})`
          );
          continue;
        }

        const dup = _ozonFbsKizFindExistingMark(mark);
        if (dup) {
          const dupPn = String(dup.posting_number || "").trim();
          skipN += 1;
          log.push(
            dupPn === pn
              ? `${n}. ${stickerKey} → ${pn} — дубль: этот КИЗ уже есть в отправлении (${_ozonFbsKizMarkPreview(mark)})`
              : `${n}. ${stickerKey} → ${pn} — дубль: КИЗ уже в отправлении ${dupPn} (${_ozonFbsKizMarkPreview(mark)})`
          );
          continue;
        }

        if (!Array.isArray(row.kiz_codes) || !row.kiz_codes.length) row.kiz_codes = [""];
        const qty = Math.max(1, Number(row.quantity) || 1);
        const filledN = existing.length;
        if (filledN >= qty) {
          skipN += 1;
          const had = existing.map(_ozonFbsKizMarkPreview).join("; ");
          log.push(
            `${n}. ${stickerKey} → ${pn} — конфликт: у стикера уже другой КИЗ ` +
              `[${had}], импорт [${_ozonFbsKizMarkPreview(mark)}] — см. список ниже`
          );
          conflictsByPn.set(pn, {
            sticker: stickerKey,
            posting_number: pn,
            mark,
            existing: existing.slice(),
            incomplete: !!incomplete,
            line: n,
          });
          continue;
        }

        let placedIdx = -1;
        for (let j = 0; j < row.kiz_codes.length; j += 1) {
          if (!String(row.kiz_codes[j] || "").trim()) {
            row.kiz_codes[j] = mark;
            placedIdx = j;
            break;
          }
        }
        if (placedIdx < 0) {
          row.kiz_codes.push(mark);
          placedIdx = row.kiz_codes.length - 1;
        }
        row.kiz_status = "pending";
        delete ozonFbsKizState.errors[pn];
        _ozonFbsKizIndexSetMark(mark, pn);
        importedMarks.add(mark);
        touched.add(pn);
        void _ozonFbsPersistStickerForRow(row, stickerKey);
        _ozonFbsKizScheduleLocalAutosave(pn, false);
        if (typeof _ozonFbsContainerMaybeBind === "function") {
          void _ozonFbsContainerMaybeBind("kiz", pn);
        }
        okN += 1;
        log.push(
          incomplete
            ? `${n}. ${stickerKey} → ${pn} — добавлен (неполный КИЗ, без 91/92 — можно восстановить позже)`
            : `${n}. ${stickerKey} → ${pn} — добавлен`
        );
      }

      if (touched.size) {
        const emptyFilter = document.getElementById("ozonFbsKizFilterEmpty");
        if (emptyFilter) emptyFilter.checked = false;
        renderOzonFbsKizTable({ skipCollect: true });
        await _ozonFbsKizAwaitLocalAutosaves();
      }

      const conflicts = Array.from(conflictsByPn.values());
      ozonFbsKizState.importConflicts = conflicts;
      _ozonFbsKizRenderImportConflicts();

      log.push("");
      log.push(`Итого: добавлено ${okN}, пропущено ${skipN}, строк ${pairs.length}`);
      if (conflicts.length) {
        log.push(`Конфликтов (другой КИЗ на стикере): ${conflicts.length} — отметьте и замените ниже, если нужно`);
      }
      _ozonFbsKizImportSetLog(log);
      const summary = conflicts.length
        ? `Импорт: добавлено ${okN}, пропущено ${skipN}, конфликтов ${conflicts.length}`
        : `Импорт: добавлено ${okN}, пропущено ${skipN}`;
      _ozonFbsKizImportSetInfo(summary, okN > 0 && skipN === 0 && !conflicts.length);
      if ((okN > 0 && skipN > 0) || conflicts.length) {
        const info = document.getElementById("ozonFbsKizImportInfo");
        if (info) {
          info.classList.remove("is-ok");
          info.classList.add("is-warn");
        }
      }
      // Mirror short status into Marking modal too.
      _ozonFbsKizSetInfo(summary, okN > 0 && skipN === 0 && !conflicts.length);
      if ((okN > 0 && skipN > 0) || conflicts.length) {
        const info = document.getElementById("ozonFbsKizInfo");
        if (info) {
          info.classList.remove("is-ok");
          info.classList.add("is-warn");
        }
      }
      return { okN, skipN, conflicts: conflicts.length };
    } finally {
      if (runBtn) runBtn.disabled = false;
    }
  }

  function _ozonFbsKizNormalizeCodesList(codes) {
    const seen = new Set();
    const out = [];
    for (const c of Array.isArray(codes) ? codes : []) {
      const n = _ozonFbsNormalizeMark(c);
      if (!n || seen.has(n)) continue;
      seen.add(n);
      out.push(n);
    }
    return out;
  }

  function _ozonFbsKizModalIsOpen() {
    const modal = document.getElementById("ozonFbsKizModal");
    return !!(modal && !modal.classList.contains("hidden"));
  }

  function _ozonFbsKizStickerHtml(row) {
    const partA = String(row?.sticker_part_a || "").trim();
    const partB = String(row?.sticker_part_b || "").trim();
    const bc = String(row?.sticker_barcode || "").trim();
    let head = partA;
    let tail = partB;
    if ((!head || !tail) && bc) {
      if (bc.length > 4) {
        head = bc.slice(0, -4);
        tail = bc.slice(-4);
      } else {
        head = "";
        tail = bc;
      }
    }
    if (!head && !tail) {
      return `<div class="wb-fbs-kiz-sticker">—</div>`;
    }
    if (!tail) {
      return `<div class="wb-fbs-kiz-sticker">${esc(head)}</div>`;
    }
    return `<div class="wb-fbs-kiz-sticker">` +
      (head ? `<span class="wb-fbs-kiz-sticker-head">${esc(head)}</span>` : "") +
      `<span class="wb-fbs-kiz-sticker-tail">${esc(tail)}</span>` +
      `</div>`;
  }

  /** Row ⋮ menu for Marking / Pick Verify modals (text-only items, no icons). */
  function _ozonFbsModalRowMenuItemsHtml(row, mode) {
    const pn = String(row?.posting_number || "").trim();
    const safePn = esc(pn);
    const canMove = typeof _ozonFbsContainerRowCanMove === "function"
      && _ozonFbsContainerRowCanMove(row);
    const moveItem = canMove
      ? `<button type="button" class="wb-fbs-row-menu-item" role="menuitem"
                onclick="openOzonFbsMoveContainerPicker('${esc(mode)}', '${safePn}')">
           Переместить в другое ГМ
         </button>`
      : "";
    const removeCancelledItem = _ozonFbsRowIsCancelled(row)
      ? `<button type="button" class="wb-fbs-row-menu-item" role="menuitem"
                onclick="ozonFbsRemoveCancelledPostingFromSupply(event, '${safePn}')">
           Удалить товар из поставки
         </button>`
      : "";
    return (
      moveItem +
      `<button type="button" class="wb-fbs-row-menu-item" role="menuitem"
              onclick="ozonFbsPrintOnePostingStickerFromDetail(event, '${safePn}')">
         Напечатать стикер
       </button>` +
      removeCancelledItem
    );
  }

  function _ozonFbsSyncRowMenuContent(menu) {
    if (!menu) return;
    const mode = String(menu.dataset.mode || "").trim();
    const pn = String(menu.dataset.posting || "").trim();
    if (mode !== "kiz" && mode !== "pick") return;
    if (!pn) return;
    const rows = mode === "pick"
      ? (ozonFbsPickState?.rows || [])
      : (ozonFbsKizState?.rows || []);
    const row = rows.find((r) => String(r?.posting_number || "").trim() === pn);
    if (!row) return;
    menu.innerHTML = _ozonFbsModalRowMenuItemsHtml(row, mode);
  }

  function _ozonFbsModalRowActionsHtml(row, mode) {
    const pn = String(row?.posting_number || "").trim();
    if (!pn) {
      return `<div class="wb-fbs-row-menu-wrap wb-fbs-row-menu-wrap--empty" aria-hidden="true"></div>`;
    }
    // Prefix with mode so supply-detail ⋮ (same posting) does not steal getElementById.
    const menuKey = _ozonFbsPostingMenuKey(`${mode || "kiz"}_${pn}`);
    const safePn = esc(pn);
    return `<div class="wb-fbs-row-menu-wrap" id="ozonFbsRowMenuWrap_${menuKey}">
      <button type="button" class="icon-btn secondary wb-fbs-row-menu-btn" title="Действия"
              onclick="toggleOzonFbsRowMenu(event, '${menuKey}')" aria-haspopup="menu">⋮</button>
      <div id="ozonFbsRowMenu_${menuKey}" class="wb-fbs-row-menu" data-posting="${safePn}" data-mode="${esc(mode)}" role="menu">
        ${_ozonFbsModalRowMenuItemsHtml(row, mode)}
      </div>
    </div>`;
  }

  /** First column like supply detail: posting number, scanit, date. */
  function _ozonFbsModalPostingColHtml(row, { quantity } = {}) {
    const pn = String(row?.posting_number || "").trim();
    const created = row?.created_at_ozon || row?.in_process_at || row?.created_date || "";
    const ago = agoLabel(created);
    const badges = [];
    if (ago) badges.push(`<span class="wb-fbs-badge time">${esc(ago)}</span>`);
    const qty = Number(quantity != null ? quantity : row?.quantity || 0);
    const qtyHtml =
      qty > 1 ? `<div class="wb-fbs-order-meta">${esc(qty)} шт.</div>` : "";
    const safePnAttr = esc(pn).replace(/'/g, "&#39;");
    const actionsHtml = pn
      ? `<span class="ozon-fbs-modal-posting-actions">
          <button type="button" class="ozon-fbs-posting-icon-btn ozon-fbs-posting-copy"
                  title="Скопировать стикер"
                  aria-label="Скопировать стикер ${safePnAttr}"
                  onclick="event.stopPropagation(); copyOzonFbsModalPostingNumber('${safePnAttr}', this)">
            <svg class="ozon-fbs-posting-icon-btn-ico" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
              <path fill="currentColor" d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/>
            </svg>
          </button>
          <button type="button" class="ozon-fbs-posting-icon-btn ozon-fbs-posting-status-refresh"
                  title="Проверить статус на Ozon"
                  aria-label="Проверить статус заказа ${safePnAttr}"
                  onclick="event.stopPropagation(); refreshOzonFbsModalPostingStatus('${safePnAttr}')">
            <svg class="ozon-fbs-posting-icon-btn-ico" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
              <path fill="currentColor" d="M17.65 6.35A7.95 7.95 0 0 0 12 4a8 8 0 1 0 7.73 10h-2.08A6 6 0 1 1 12 6c1.66 0 3.14.69 4.22 1.78L13 11h7V4z"/>
            </svg>
          </button>
        </span>`
      : "";
    return (
      cancelBadgeHtml(row, { lead: true }) +
      `<div class="wb-fbs-sd-order-id ozon-fbs-modal-posting-id">` +
        `<span class="ozon-fbs-modal-posting-num">${esc(pn) || "—"}</span>` +
        `${actionsHtml}` +
      `</div>` +
      _ozonFbsScanitUnderOrderHtml(row) +
      `<div class="wb-fbs-order-meta">от ${esc(fmtDate(created))}</div>` +
      (badges.length ? `<div class="wb-fbs-badges">${badges.join("")}</div>` : "") +
      qtyHtml
    );
  }

  function _ozonFbsKizRowIsEmpty(row) {
    const codes = Array.isArray(row?.kiz_codes) ? row.kiz_codes : [];
    return !codes.some((c) => String(c || "").trim());
  }

  function _ozonFbsKizValidateMarkForOrder(mark, row) {
    if (typeof _wbFbsKizValidateMarkForOrder === "function") {
      return _wbFbsKizValidateMarkForOrder(mark, row);
    }
    const raw = _ozonFbsNormalizeMark(mark);
    if (!raw) return { ok: false, error: "Пустой код маркировки" };
    return { ok: true };
  }

  function _ozonFbsKizMergeOrderFlagsIntoDetail(flags) {
    const supply = supplyDetailState.supply;
    if (!supply || !Array.isArray(supply.orders) || !Array.isArray(flags)) return;
    const byPn = new Map();
    flags.forEach((row) => {
      const pn = String(row?.posting_number || "").trim();
      if (pn) byPn.set(pn, row);
    });
    supply.orders.forEach((o) => {
      const pn = String(o?.posting_number || "").trim();
      const upd = byPn.get(pn);
      if (!upd) return;
      o.kiz_required = !!upd.kiz_required;
      if (upd.kiz_status) o.kiz_status = String(upd.kiz_status);
      if (upd.cancel_reason_label) {
        o.cancel_reason_label = String(upd.cancel_reason_label || "").trim();
      }
      if (upd.cancelled) o.cancelled = true;
    });
  }

  function _ozonFbsKizMergeStatusIntoDetail(orders) {
    const supply = supplyDetailState.supply;
    if (!supply || !Array.isArray(supply.orders) || !Array.isArray(orders)) return;
    const byPn = new Map();
    orders.forEach((row) => {
      const pn = String(row?.posting_number || "").trim();
      if (pn) byPn.set(pn, row);
    });
    supply.orders.forEach((o) => {
      const pn = String(o?.posting_number || "").trim();
      const upd = byPn.get(pn);
      if (!upd) return;
      o.kiz_required = !!upd.kiz_required;
      if (Array.isArray(upd.kiz_codes)) o.kiz_codes = upd.kiz_codes.slice();
      o.kiz_status = String(upd.kiz_status || o.kiz_status || "empty");
      if (upd.cancel_reason_label) {
        o.cancel_reason_label = String(upd.cancel_reason_label || "").trim();
      }
      if (upd.cancelled) o.cancelled = true;
      if ("container_id" in upd) {
        const cid = Number(upd.container_id || 0);
        o.container_id = Number.isFinite(cid) && cid > 0 ? cid : null;
      }
      if ("container_barcode" in upd) {
        o.container_barcode = String(upd.container_barcode || "").trim();
      }
      if ("container_synced" in upd) o.container_synced = !!upd.container_synced;
      if ("container_sync_error" in upd) {
        o.container_sync_error = String(upd.container_sync_error || "").trim();
      }
    });
  }

  function _ozonFbsSupplyActionsReady() {
    return !!supplyDetailState.ordersReady;
  }

  function _ozonFbsKizOrderScanned(order) {
    if (!order) return false;
    if (Array.isArray(order.kiz_codes) && order.kiz_codes.some((c) => String(c || "").trim())) {
      return true;
    }
    const st = String(order.kiz_status || "").trim().toLowerCase();
    return st === "ok" || st === "pending";
  }

  function _ozonFbsPickOrderScanned(order) {
    return !!(order?.pick_verified && String(order?.pick_barcode || "").trim());
  }

  function _ozonFbsComputeKizBtnProgress(orders) {
    let done = 0;
    let total = 0;
    for (const o of Array.isArray(orders) ? orders : []) {
      if (!o || !o.kiz_required || _ozonFbsRowIsCancelled(o)) continue;
      total += 1;
      if (_ozonFbsKizOrderScanned(o)) done += 1;
    }
    return { done, total };
  }

  function _ozonFbsComputePickBtnProgress(orders) {
    let done = 0;
    let total = 0;
    for (const o of Array.isArray(orders) ? orders : []) {
      if (!o || o.kiz_required || _ozonFbsRowIsCancelled(o)) continue;
      total += 1;
      if (_ozonFbsPickOrderScanned(o)) done += 1;
    }
    return { done, total };
  }

  function _ozonFbsSetSupplyActionBtnCount(btnId, baseLabel, done, total) {
    const btn = document.getElementById(btnId);
    if (!btn) return;
    const d = Math.max(0, Math.floor(Number(done) || 0));
    const t = Math.max(0, Math.floor(Number(total) || 0));
    // Keep title untouched (wait-orders / tone-only own it).
    btn.textContent = t > 0 ? `${baseLabel} (${d}/${t})` : baseLabel;
  }

  function _ozonFbsSyncKizPickBtnLabels(opts) {
    const orders = Array.isArray(opts && opts.orders)
      ? opts.orders
      : (Array.isArray(supplyDetailState.supply?.orders) ? supplyDetailState.supply.orders : []);
    const kiz = (opts && opts.kiz) || _ozonFbsComputeKizBtnProgress(orders);
    const pick = (opts && opts.pick) || _ozonFbsComputePickBtnProgress(orders);
    _ozonFbsSetSupplyActionBtnCount(
      "ozonFbsSupplyDetailKizBtn",
      "Товары с КИЗ",
      kiz.done,
      kiz.total
    );
    _ozonFbsSetSupplyActionBtnCount(
      "ozonFbsSupplyDetailPickVerifyBtn",
      "Товары без КИЗ",
      pick.done,
      pick.total
    );
  }

  function _ozonFbsSyncPickVerifyBtn(orders) {
    const btn = document.getElementById("ozonFbsSupplyDetailPickVerifyBtn");
    const split = document.getElementById("ozonFbsPickSplit");
    if (!btn && !split) return;
    const list = Array.isArray(orders) ? orders : [];
    const hasPlain = list.some((o) => o && !o.kiz_required && !_ozonFbsRowIsCancelled(o));
    const can = _ozonFbsSupplyActionsReady() && hasPlain;
    if (split) {
      split.hidden = !can;
      split.style.display = can ? "" : "none";
    }
    if (btn) {
      btn.hidden = !can;
      btn.style.display = can ? "" : "none";
    }
  }

  function _ozonFbsPickSplitSetTone(tone) {
    const split = document.getElementById("ozonFbsPickSplit");
    if (!split) return;
    split.classList.remove("is-ok", "is-error");
    const t = String(tone || "").trim().toLowerCase();
    if (t === "ok") split.classList.add("is-ok");
    else if (t === "error") split.classList.add("is-error");
    const refreshBtn = document.getElementById("ozonFbsSupplyDetailPickRefreshBtn");
    if (refreshBtn) {
      if (t === "error") {
        const tip = split.dataset.containerErrorTip || "Ошибка привязки к грузоместу";
        refreshBtn.title = tip;
        split.title = tip;
      } else {
        refreshBtn.title = "Обновить статусы проверки ШК";
        split.removeAttribute("title");
        delete split.dataset.containerErrorTip;
      }
    }
    _ozonFbsSyncMoveDeliveringEnabled();
  }

  function kizBadgeHtml(order) {
    if (!order?.kiz_required) return "";
    const status = String(order?.kiz_status || "empty");
    let cls = "is-empty";
    let label = "КИЗ";
    let title = "Требуется маркировка — код не указан";
    if (status === "pending") {
      cls = "is-pending";
      label = "Частично";
      title = "Маркировка сохранена локально, не все коды заполнены";
    } else if (status === "ok") {
      cls = "is-ok";
      title = "Маркировка сохранена локально";
    }
    return `<div class="wb-fbs-kiz ${cls}" title="${esc(title)}">${esc(label)}</div>`;
  }

  function _ozonFbsKizSetInfo(text, ok) {
    const el = document.getElementById("ozonFbsKizInfo");
    if (!el) return;
    const msg = String(text || "").trim();
    el.hidden = !msg;
    el.textContent = msg;
    el.classList.remove("is-warn");
    el.classList.toggle("is-ok", !!msg && !!ok);
  }

  function _ozonFbsPickSetInfo(text, ok) {
    const el = document.getElementById("ozonFbsPickInfo");
    if (!el) return;
    const msg = String(text || "").trim();
    el.hidden = !msg;
    el.textContent = msg;
    el.classList.toggle("is-ok", !!msg && !!ok);
  }

  /**
   * Load marking / pick-verify payloads in chunks until catalog КИЗ resolve is done.
   * Prevents nginx 504 on large supplies.
   */
  async function _ozonFbsFetchResolvedChunks(url, { onProgress, onChunk, shouldAbort } = {}) {
    let data = null;
    let remaining = 1;
    let checkedTotal = 0;
    let guard = 0;
    while (remaining > 0 && guard < 200) {
      if (typeof shouldAbort === "function" && shouldAbort()) {
        return data || {};
      }
      guard += 1;
      const res = await fetch(url);
      if (typeof shouldAbort === "function" && shouldAbort()) {
        return data || {};
      }
      data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      }
      const mr =
        data.marking_resolve && typeof data.marking_resolve === "object"
          ? data.marking_resolve
          : {};
      const checked = Number(mr.checked || 0);
      checkedTotal += checked;
      remaining = Number(mr.remaining || 0);
      if (remaining > 0 && checked <= 0) remaining = 0;
      if (typeof onChunk === "function") {
        onChunk(data, {
          checkedTotal,
          remaining,
          round: guard,
          done: remaining <= 0,
        });
      }
      if (typeof onProgress === "function") {
        onProgress({
          checkedTotal,
          remaining: checkedTotal ? remaining : null,
          round: guard,
          done: remaining <= 0,
        });
      }
    }
    return data || {};
  }

  function _ozonFbsResolveProgressText(progress) {
    if (progress?.done) return "";
    const checked = Number(progress?.checkedTotal || 0);
    const remaining = Number(progress?.remaining);
    if (checked && Number.isFinite(remaining) && remaining > 0) {
      const total = checked + remaining;
      return `Определение маркировки… проверено ${checked} из ${total}`;
    }
    if (checked) {
      return `Определение маркировки… проверено ${checked}`;
    }
    // First paint / remaining=0 after sync warm — no long “determining” banner.
    if (progress && Number.isFinite(remaining) && remaining <= 0) return "";
    return "Определение маркировки…";
  }

  function _ozonFbsKizSplitSetTone(tone) {
    const split = document.getElementById("ozonFbsKizSplit");
    if (!split) return;
    split.classList.remove("is-ok", "is-error");
    const t = String(tone || "").trim().toLowerCase();
    if (t === "ok") split.classList.add("is-ok");
    else if (t === "error") split.classList.add("is-error");
    const refreshBtn = document.getElementById("ozonFbsSupplyDetailKizRefreshBtn");
    if (refreshBtn && t === "error") {
      const tip = split.dataset.containerErrorTip || refreshBtn.title || "Ошибка привязки к грузоместу";
      refreshBtn.title = tip;
    }
    _ozonFbsSyncMoveDeliveringEnabled();
  }

  /** Fire-and-forget: reuse marking/pick status endpoints (same tone rules as refresh). */
  function _ozonFbsAutoRefreshSplitTones() {
    const sid = String(supplyDetailState.supplyId || "").trim();
    if (!sid || !_ozonFbsSupplyActionsReady()) return;
    const orders = Array.isArray(supplyDetailState.supply?.orders)
      ? supplyDetailState.supply.orders
      : [];
    const needsKiz = orders.some((o) => o && o.kiz_required && !_ozonFbsRowIsCancelled(o));
    const needsPick = orders.some((o) => o && !o.kiz_required && !_ozonFbsRowIsCancelled(o));
    if (!needsKiz && !needsPick) return;
    // Parallel + silent: no spinner, no full re-render — open stays snappy.
    const tasks = [];
    if (needsKiz) tasks.push(refreshOzonFbsMarkingStatus(null, { silent: true }));
    if (needsPick) tasks.push(refreshOzonFbsPickVerifyStatus(null, { silent: true }));
    void Promise.all(tasks).catch(() => {});
  }

  function _ozonFbsStatusCooldownOk(kind, ms) {
    const key = kind === "pick" ? "_pickStatusAt" : "_kizStatusAt";
    const at = Number(supplyDetailState[key] || 0);
    return !at || (Date.now() - at) >= (ms || 1500);
  }

  function _ozonFbsStatusCooldownTouch(kind) {
    const key = kind === "pick" ? "_pickStatusAt" : "_kizStatusAt";
    supplyDetailState[key] = Date.now();
  }

  function _ozonFbsOrderHasContainer(o) {
    const cid = Number(o?.container_id || 0);
    if (Number.isFinite(cid) && cid > 0) return true;
    return !!String(o?.container_barcode || "").trim();
  }

  /** Local ШК entered — does not mean Ozon accepted the fill. */
  function _ozonFbsOrderHasContainerBind(o) {
    return _ozonFbsOrderHasContainer(o);
  }

  /** Confirmed on Ozon (container_synced), analogous to WB kiz_wb_synced. */
  function _ozonFbsOrderContainerConfirmed(o) {
    if (!_ozonFbsOrderHasContainerBind(o)) return false;
    if (String(o?.container_sync_error || "").trim()) return false;
    return !!o?.container_synced;
  }

  /** Cargo places are in play for this supply (warehouse has GM or any bind exists). */
  function _ozonFbsContainersInPlay(mode) {
    if (window.ozonFbsContainerBindState?.hasContainers) return true;
    if (typeof window._ozonFbsContainerGmUiVisible === "function") {
      try {
        if (window._ozonFbsContainerGmUiVisible(mode)) return true;
      } catch (_e) { /* ignore */ }
    }
    return false;
  }

  /** Prefer bind-module cache; fall back to containers modal list. */
  function _ozonFbsSupplyContainerItems() {
    const bindItems = window.ozonFbsContainerBindState?.containers;
    if (Array.isArray(bindItems) && bindItems.length) return bindItems;
    if (Array.isArray(containersState.items) && containersState.items.length) {
      return containersState.items;
    }
    return Array.isArray(bindItems) ? bindItems : [];
  }

  /** GMs with local KIZ/pick binds to the open supply. */
  function _ozonFbsSupplyBoundContainers() {
    const items = _ozonFbsSupplyContainerItems();
    const orders = Array.isArray(supplyDetailState.supply?.orders)
      ? supplyDetailState.supply.orders
      : [];
    const orderCids = new Set();
    for (const o of orders) {
      if (!o || _ozonFbsRowIsCancelled(o)) continue;
      const cid = Number(o.container_id || 0);
      if (cid > 0) orderCids.add(cid);
    }
    return items.filter((c) => {
      if (!c || typeof c !== "object") return false;
      if (c.bound_to_open_supply === true) return true;
      if (c.bound_to_open_supply === false) return false;
      const cid = Number(c.container_id || 0);
      if (cid > 0 && orderCids.has(cid)) return true;
      return Number(c.order_count || 0) > 0 && orderCids.size > 0 && orderCids.has(cid);
    });
  }

  /** True when operator already bound at least one order to a cargo place. */
  function _ozonFbsSupplyHasGmBinds() {
    if (_ozonFbsSupplyBoundContainers().length > 0) return true;
    const orders = Array.isArray(supplyDetailState.supply?.orders)
      ? supplyDetailState.supply.orders
      : [];
    return orders.some((o) => o && !_ozonFbsRowIsCancelled(o) && _ozonFbsOrderHasContainerBind(o));
  }

  /** Green ✓ pressed / composition locked on Ozon. */
  function _ozonFbsContainerCompositionConfirmed(c) {
    if (!c || typeof c !== "object") return false;
    if (c.can_approve === true) return false;
    const st = String(c.status || "").trim().toLowerCase();
    return [
      "approved",
      "formed",
      "ready",
      "acceptance_in_progress",
      "finished",
      "shipped",
      "closed",
    ].includes(st);
  }

  /** All bound GMs confirmed — drives green «Грузоместа» button. */
  function _ozonFbsContainersAllConfirmed() {
    const bound = _ozonFbsSupplyBoundContainers();
    if (!bound.length) return false;
    return bound.every(_ozonFbsContainerCompositionConfirmed);
  }

  /** Move-to-delivering GM gate: N/A (ok) when no binds; else all confirmed. */
  function _ozonFbsGmConfirmOkForMove() {
    if (!_ozonFbsSupplyHasGmBinds()) return true;
    return _ozonFbsContainersAllConfirmed();
  }

  function _ozonFbsSyncContainersBtn() {
    const btn = document.getElementById("ozonFbsSupplyDetailTrbxBtn");
    if (!btn) return;
    btn.classList.toggle("is-ok", _ozonFbsContainersAllConfirmed());
  }

  /** Called after bind-module container list refresh (open detail / approve / invalidate). */
  function _ozonFbsOnContainersLoaded() {
    _ozonFbsSyncContainersBtn();
    _ozonFbsSyncMoveDeliveringEnabled();
  }

  function _ozonFbsKizToneFromSupply(supply) {
    const orders = Array.isArray(supply?.orders) ? supply.orders : [];
    const required = orders.filter((o) => o && o.kiz_required && !_ozonFbsRowIsCancelled(o));
    if (!required.length) return "";
    if (!required.every((o) => String(o.kiz_status || "") === "ok")) return "";
    const gmInPlay =
      _ozonFbsContainersInPlay("kiz")
      || required.some((o) => _ozonFbsOrderHasContainerBind(o));
    if (gmInPlay && !required.every((o) => _ozonFbsOrderContainerConfirmed(o))) return "";
    return "ok";
  }

  function _ozonFbsPickToneFromSupply(supply) {
    const orders = Array.isArray(supply?.orders) ? supply.orders : [];
    const plain = orders.filter((o) => o && !o.kiz_required && !_ozonFbsRowIsCancelled(o));
    if (!plain.length) return "";
    if (!plain.every(
      (o) => !!o.pick_verified && !!String(o.pick_barcode || "").trim()
    )) return "";
    const gmInPlay =
      _ozonFbsContainersInPlay("pick")
      || plain.some((o) => _ozonFbsOrderHasContainerBind(o));
    if (gmInPlay && !plain.every((o) => _ozonFbsOrderContainerConfirmed(o))) return "";
    return "ok";
  }

  function _ozonFbsMoveDeliveringGateItems() {
    const supply = supplyDetailState.supply;
    const orders = Array.isArray(supply?.orders) ? supply.orders : [];
    const needsKiz = orders.some((o) => o && o.kiz_required && !_ozonFbsRowIsCancelled(o));
    const needsPick = orders.some((o) => o && !o.kiz_required && !_ozonFbsRowIsCancelled(o));
    const items = [];
    if (_ozonFbsSupplyHasGmBinds()) {
      items.push({
        key: "gm",
        label: "Подтверждение грузомест",
        done: _ozonFbsContainersAllConfirmed(),
      });
    }
    if (needsKiz) {
      const kizSplit = document.getElementById("ozonFbsKizSplit");
      const splitOk = !!(kizSplit && !kizSplit.hidden && kizSplit.classList.contains("is-ok"));
      items.push({
        key: "kiz",
        label: "Сканирование товаров с КИЗ",
        done: splitOk && _ozonFbsKizToneFromSupply(supply) === "ok",
      });
    }
    if (needsPick) {
      const pickSplit = document.getElementById("ozonFbsPickSplit");
      const splitOk = !!(pickSplit && !pickSplit.hidden && pickSplit.classList.contains("is-ok"));
      items.push({
        key: "pick",
        label: "Сканирование товаров без КИЗ",
        done: splitOk && _ozonFbsPickToneFromSupply(supply) === "ok",
      });
    }
    items.push({
      key: "driver",
      label: "Водитель выбран",
      done: _ozonFbsDriverHasAssignment(supply),
    });
    return items;
  }

  function _ozonFbsRenderMoveDeliveringGateTip(items) {
    const tip = document.getElementById("ozonFbsMoveDeliveringGateTip");
    if (!tip) return;
    const list = Array.isArray(items) ? items : [];
    if (!list.length) {
      tip.hidden = true;
      tip.innerHTML = "";
      return;
    }
    tip.innerHTML =
      `<p class="ozon-fbs-move-gate-title">Чтобы перенести в доставку</p>`
      + `<ul class="ozon-fbs-move-gate-list">`
      + list.map((it) => {
        const done = !!it.done;
        const mark = done ? "✓" : "○";
        return `<li class="${done ? "is-done" : "is-todo"}">`
          + `<span class="ozon-fbs-move-gate-mark" aria-hidden="true">${mark}</span>`
          + `<span>${esc(it.label)}</span>`
          + `</li>`;
      }).join("")
      + `</ul>`;
  }

  /**
   * «Перенести в доставку» only when every present gate is green:
   * - bound GMs → compositions confirmed (green «Грузоместа»)
   * - KIZ rows → «Товары с КИЗ» is-ok
   * - plain rows → «Товары без КИЗ» is-ok
   * - driver assigned
   * Missing scan group is not required. Cancelled postings are ignored.
   * Tenant owner skips these gates. Already-delivering supplies stay blocked.
   */
  function _ozonFbsCanMoveToDelivering() {
    if (isDeliveringSuppliesTab() || isSupplyDetailReadOnly()) return false;
    if (!_ozonFbsSupplyActionsReady()) return false;
    if (_ozonFbsIsTenantOwner()) return true;
    const supply = supplyDetailState.supply;
    const orders = Array.isArray(supply?.orders) ? supply.orders : [];
    const needsKiz = orders.some((o) => o && o.kiz_required && !_ozonFbsRowIsCancelled(o));
    const needsPick = orders.some((o) => o && !o.kiz_required && !_ozonFbsRowIsCancelled(o));
    if (!needsKiz && !needsPick) return false;
    if (!_ozonFbsGmConfirmOkForMove()) return false;
    if (!_ozonFbsDriverHasAssignment(supply)) return false;
    if (needsKiz) {
      const kizSplit = document.getElementById("ozonFbsKizSplit");
      if (!kizSplit || kizSplit.hidden || !kizSplit.classList.contains("is-ok")) return false;
      if (_ozonFbsKizToneFromSupply(supply) !== "ok") return false;
    }
    if (needsPick) {
      const pickSplit = document.getElementById("ozonFbsPickSplit");
      if (!pickSplit || pickSplit.hidden || !pickSplit.classList.contains("is-ok")) return false;
      if (_ozonFbsPickToneFromSupply(supply) !== "ok") return false;
    }
    return true;
  }

  function _ozonFbsSyncMoveDeliveringEnabled() {
    const btn = document.getElementById("ozonFbsSupplyDetailMoveDeliveringBtn");
    const tip = document.getElementById("ozonFbsMoveDeliveringGateTip");
    if (!btn || btn.hidden) {
      if (tip) tip.hidden = true;
      return;
    }
    // While orders are loading / request in flight, leave wait-orders alone.
    if (!supplyDetailState.ordersReady || btn.classList.contains("is-wait-orders")) {
      btn.classList.remove("is-scan-incomplete");
      if (tip) tip.hidden = true;
      return;
    }
    const tipOk =
      "Локально перенести поставку в «Доставляются» и списать с Остатки (без отправки в Ozon)";
    const gateItems = _ozonFbsMoveDeliveringGateItems();
    const can = _ozonFbsCanMoveToDelivering();
    if (can) {
      btn.removeAttribute("aria-disabled");
      btn.classList.remove("is-scan-incomplete");
      btn.removeAttribute("tabindex");
      btn.setAttribute("title", tipOk);
      if (tip) {
        tip.hidden = true;
        tip.innerHTML = "";
      }
    } else {
      btn.setAttribute("aria-disabled", "true");
      btn.classList.add("is-scan-incomplete");
      btn.tabIndex = -1;
      // Rich hover checklist replaces the plain title while blocked.
      btn.removeAttribute("title");
      _ozonFbsRenderMoveDeliveringGateTip(gateItems);
      if (tip) tip.hidden = false;
    }
  }

  function _ozonFbsPickSyncToneFromRows(rows) {
    const supply = supplyDetailState.supply;
    if (!supply || !Array.isArray(supply.orders)) return;
    const list = Array.isArray(rows) ? rows : [];
    const byPn = new Map();
    for (const row of list) {
      const pn = String(row?.posting_number || "").trim();
      if (!pn) continue;
      byPn.set(pn, row);
    }
    for (const o of supply.orders) {
      if (!o || o.kiz_required || _ozonFbsRowIsCancelled(o)) continue;
      const pn = String(o.posting_number || "").trim();
      const row = byPn.get(pn);
      if (!row) continue;
      const verified = !!row.pick_verified && !!String(row.pick_barcode || "").trim();
      o.pick_verified = verified;
      o.pick_barcode = verified ? String(row.pick_barcode || "").trim() : "";
      if ("container_id" in row) {
        const cid = Number(row.container_id || 0);
        o.container_id = Number.isFinite(cid) && cid > 0 ? cid : null;
      }
      if ("container_barcode" in row) {
        o.container_barcode = String(row.container_barcode || "").trim();
      }
      if ("container_synced" in row) o.container_synced = !!row.container_synced;
      if ("container_sync_error" in row) {
        o.container_sync_error = String(row.container_sync_error || "").trim();
      }
    }
    const needsPick = supply.orders.some(
      (o) => o && !o.kiz_required && !_ozonFbsRowIsCancelled(o)
    );
    if (!needsPick) _ozonFbsPickSplitSetTone("");
    else _ozonFbsPickSplitSetTone(_ozonFbsPickToneFromSupply(supply));
  }

  function _ozonFbsKizStatusFromRow(row) {
    const codes = (Array.isArray(row?.kiz_codes) ? row.kiz_codes : [])
      .map((c) => String(c || "").trim())
      .filter(Boolean);
    const req = Math.max(Number(row?.quantity) || 1, 1);
    if (!codes.length) return "empty";
    if (codes.length >= req) return "ok";
    return "pending";
  }

  function _ozonFbsKizRefreshDetailBadgesFromRows(rows) {
    const supply = supplyDetailState.supply;
    if (!supply || !Array.isArray(supply.orders) || !Array.isArray(rows)) return false;
    const byPn = new Map();
    rows.forEach((row) => {
      const pn = String(row?.posting_number || "").trim();
      if (pn) byPn.set(pn, row);
    });
    let changed = false;
    supply.orders.forEach((o) => {
      const pn = String(o?.posting_number || "").trim();
      const row = byPn.get(pn);
      if (!row || !o.kiz_required) return;
      const st = _ozonFbsKizStatusFromRow(row);
      const codes = (row.kiz_codes || []).map((c) => String(c || "").trim()).filter(Boolean);
      if (String(o.kiz_status || "") !== st) {
        o.kiz_status = st;
        changed = true;
      }
      const prev = JSON.stringify(Array.isArray(o.kiz_codes) ? o.kiz_codes : []);
      const next = JSON.stringify(codes);
      if (prev !== next) {
        o.kiz_codes = codes;
        changed = true;
      }
      if ("container_id" in row || "container_barcode" in row) {
        const cid = Number(row.container_id || 0);
        const nextCid = Number.isFinite(cid) && cid > 0 ? cid : null;
        const nextBc = String(row.container_barcode || "").trim();
        if (o.container_id !== nextCid || String(o.container_barcode || "") !== nextBc) {
          o.container_id = nextCid;
          o.container_barcode = nextBc;
          changed = true;
        }
        if ("container_synced" in row) o.container_synced = !!row.container_synced;
        if ("container_sync_error" in row) {
          o.container_sync_error = String(row.container_sync_error || "").trim();
        }
      }
    });
    return changed;
  }

  function _ozonFbsKizSetFiltersReady(ready) {
    ozonFbsKizState.rowsReady = !!ready;
    const tip = "Дождитесь загрузки заказов";
    const filled = document.getElementById("ozonFbsKizFilterFilled");
    const empty = document.getElementById("ozonFbsKizFilterEmpty");
    const legal = document.getElementById("ozonFbsKizFilterLegal");
    const errors = document.getElementById("ozonFbsKizFilterErrors");
    const cancelled = document.getElementById("ozonFbsKizFilterCancelled");
    const filledLabel = document.getElementById("ozonFbsKizFilterFilledLabel")
      || (filled && filled.closest("label"));
    const emptyLabel = document.getElementById("ozonFbsKizFilterEmptyLabel")
      || (empty && empty.closest("label"));
    const legalLabel = document.getElementById("ozonFbsKizFilterLegalLabel")
      || (legal && legal.closest("label"));
    const errorsLabel = document.getElementById("ozonFbsKizFilterErrorsLabel")
      || (errors && errors.closest("label"));
    const cancelledLabel = document.getElementById("ozonFbsKizFilterCancelledLabel")
      || (cancelled && cancelled.closest("label"));
    const search = document.getElementById("ozonFbsKizSearchFilter");
    const sticker = document.getElementById("ozonFbsKizStickerScan");
    const containerCheck = document.getElementById("ozonFbsKizContainerScanCheck");
    const containerLabel = document.getElementById("ozonFbsKizContainerScanLabel")
      || (containerCheck && containerCheck.closest("label"));

    const setLabelWait = (label, on) => {
      if (!label) return;
      if (on) {
        if (label.dataset.waitTitleSaved === undefined) {
          label.dataset.waitTitleSaved = label.getAttribute("title") || "";
        }
        label.classList.add("is-wait-rows");
        label.setAttribute("title", tip);
      } else {
        label.classList.remove("is-wait-rows");
        const saved = label.dataset.waitTitleSaved;
        if (saved !== undefined) {
          if (saved) label.setAttribute("title", saved);
          else label.removeAttribute("title");
          delete label.dataset.waitTitleSaved;
        }
      }
    };

    const setInputWait = (input, on) => {
      if (!input) return;
      if (on) {
        if (input.dataset.waitTitleSaved === undefined) {
          input.dataset.waitTitleSaved = input.getAttribute("title") || "";
        }
        input.readOnly = true;
        input.setAttribute("aria-disabled", "true");
        input.classList.add("is-wait-rows");
        input.setAttribute("title", tip);
        input.tabIndex = -1;
        if (document.activeElement === input) {
          try { input.blur(); } catch (_) {}
        }
      } else {
        input.readOnly = false;
        input.removeAttribute("aria-disabled");
        input.classList.remove("is-wait-rows");
        input.removeAttribute("tabindex");
        const saved = input.dataset.waitTitleSaved;
        if (saved !== undefined) {
          if (saved) input.setAttribute("title", saved);
          else input.removeAttribute("title");
          delete input.dataset.waitTitleSaved;
        }
      }
    };

    if (filled) filled.disabled = !ready;
    if (empty) empty.disabled = !ready;
    if (legal) legal.disabled = !ready;
    if (errors) errors.disabled = !ready;
    if (cancelled) cancelled.disabled = !ready;
    if (containerCheck) {
      containerCheck.disabled = !ready;
      if (!ready) containerCheck.checked = false;
    }
    setLabelWait(filledLabel, !ready);
    setLabelWait(emptyLabel, !ready);
    setLabelWait(legalLabel, !ready);
    setLabelWait(errorsLabel, !ready);
    setLabelWait(cancelledLabel, !ready);
    setLabelWait(containerLabel, !ready);
    setInputWait(search, !ready);
    setInputWait(sticker, !ready);
    if (typeof window._ozonFbsContainerSyncCheckboxUi === "function") {
      window._ozonFbsContainerSyncCheckboxUi("kiz");
    }
  }

  function _ozonFbsPickSetFiltersReady(ready) {
    ozonFbsPickState.rowsReady = !!ready;
    const tip = "Дождитесь загрузки заказов";
    const filled = document.getElementById("ozonFbsPickFilterFilled");
    const empty = document.getElementById("ozonFbsPickFilterEmpty");
    const errors = document.getElementById("ozonFbsPickFilterErrors");
    const cancelled = document.getElementById("ozonFbsPickFilterCancelled");
    const filledLabel = document.getElementById("ozonFbsPickFilterFilledLabel")
      || (filled && filled.closest("label"));
    const emptyLabel = document.getElementById("ozonFbsPickFilterEmptyLabel")
      || (empty && empty.closest("label"));
    const errorsLabel = document.getElementById("ozonFbsPickFilterErrorsLabel")
      || (errors && errors.closest("label"));
    const cancelledLabel = document.getElementById("ozonFbsPickFilterCancelledLabel")
      || (cancelled && cancelled.closest("label"));
    const search = document.getElementById("ozonFbsPickSearchFilter");
    const sticker = document.getElementById("ozonFbsPickStickerScan");
    const containerCheck = document.getElementById("ozonFbsPickContainerScanCheck");
    const containerLabel = document.getElementById("ozonFbsPickContainerScanLabel")
      || (containerCheck && containerCheck.closest("label"));

    const setLabelWait = (label, on) => {
      if (!label) return;
      if (on) {
        if (label.dataset.waitTitleSaved === undefined) {
          label.dataset.waitTitleSaved = label.getAttribute("title") || "";
        }
        label.classList.add("is-wait-rows");
        label.setAttribute("title", tip);
      } else {
        label.classList.remove("is-wait-rows");
        const saved = label.dataset.waitTitleSaved;
        if (saved !== undefined) {
          if (saved) label.setAttribute("title", saved);
          else label.removeAttribute("title");
          delete label.dataset.waitTitleSaved;
        }
      }
    };

    const setInputWait = (input, on) => {
      if (!input) return;
      if (on) {
        if (input.dataset.waitTitleSaved === undefined) {
          input.dataset.waitTitleSaved = input.getAttribute("title") || "";
        }
        input.readOnly = true;
        input.setAttribute("aria-disabled", "true");
        input.classList.add("is-wait-rows");
        input.setAttribute("title", tip);
        input.tabIndex = -1;
        if (document.activeElement === input) {
          try { input.blur(); } catch (_) {}
        }
      } else {
        input.readOnly = false;
        input.removeAttribute("aria-disabled");
        input.classList.remove("is-wait-rows");
        input.removeAttribute("tabindex");
        const saved = input.dataset.waitTitleSaved;
        if (saved !== undefined) {
          if (saved) input.setAttribute("title", saved);
          else input.removeAttribute("title");
          delete input.dataset.waitTitleSaved;
        }
      }
    };

    if (filled) filled.disabled = !ready;
    if (empty) empty.disabled = !ready;
    if (errors) errors.disabled = !ready;
    if (cancelled) cancelled.disabled = !ready;
    if (containerCheck) {
      containerCheck.disabled = !ready;
      if (!ready) containerCheck.checked = false;
    }
    setLabelWait(filledLabel, !ready);
    setLabelWait(emptyLabel, !ready);
    setLabelWait(errorsLabel, !ready);
    setLabelWait(cancelledLabel, !ready);
    setLabelWait(containerLabel, !ready);
    setInputWait(search, !ready);
    setInputWait(sticker, !ready);
    if (typeof window._ozonFbsContainerSyncCheckboxUi === "function") {
      window._ozonFbsContainerSyncCheckboxUi("pick");
    }
  }

  function _ozonFbsKizRowFilled(row) {
    const codes = Array.isArray(row?.kiz_codes) ? row.kiz_codes : [];
    const req = Math.max(Number(row?.quantity) || 1, 1);
    const filled = codes.filter((c) => String(c || "").trim()).length;
    return filled >= req;
  }

  function _ozonFbsKizRowContainerOk(row) {
    return !!String(row?.container_barcode || "").trim();
  }

  /** GM column shown for either modal → require ШК грузоместа in filled/empty filters. */
  function _ozonFbsGmRequiredInFilters(mode) {
    if (typeof window._ozonFbsContainerGmUiVisibleAny === "function") {
      return !!window._ozonFbsContainerGmUiVisibleAny();
    }
    if (typeof window._ozonFbsContainerGmUiVisible === "function") {
      return !!window._ozonFbsContainerGmUiVisible(mode);
    }
    return false;
  }

  /** Complete = all KIZ codes + ШК грузоместа (when GM column is active). */
  function _ozonFbsKizRowIsComplete(row) {
    if (!_ozonFbsKizRowFilled(row)) return false;
    if (_ozonFbsGmRequiredInFilters("kiz") && !_ozonFbsKizRowContainerOk(row)) return false;
    return true;
  }

  function _ozonFbsKizRowHasError(row) {
    const pn = String(row?.posting_number || "");
    return !!String(ozonFbsKizState.errors[pn] || "").trim();
  }

  function _ozonFbsKizUpdateScanCounter() {
    const el = document.getElementById("ozonFbsKizScanCount");
    if (!el) return;
    let filled = 0;
    let total = 0;
    for (const row of ozonFbsKizState.rows) {
      if (_ozonFbsRowIsCancelled(row)) continue;
      const codes = Array.isArray(row?.kiz_codes) && row.kiz_codes.length ? row.kiz_codes : [""];
      total += codes.length;
      for (const code of codes) {
        if (String(code || "").trim()) filled += 1;
      }
    }
    el.textContent = `Просканировано ${filled} из ${total} КИЗ`;
    el.classList.toggle("is-complete", total > 0 && filled === total);
  }

  /** True when rewriting the KIZ/pick table would fight an active scan. */
  function _ozonFbsPeerIsScanInput(el) {
    if (!el) return false;
    const id = String(el.id || "");
    if (
      id === "ozonFbsKizStickerScan"
      || id === "ozonFbsKizMarkScan"
      || id === "ozonFbsPickStickerScan"
      || id === "ozonFbsPickSkuScan"
      || id === "ozonFbsKizImportText"
    ) {
      return true;
    }
    const tag = String(el.tagName || "").toUpperCase();
    if (tag !== "INPUT" && tag !== "TEXTAREA") return false;
    const cls = el.classList;
    if (!cls) return false;
    return (
      cls.contains("wb-fbs-kiz-code-input")
      || cls.contains("wb-fbs-pick-code-input")
      || cls.contains("ozon-fbs-pick-barcode-input")
      || cls.contains("ozon-fbs-container-input")
    );
  }

  const OZON_FBS_PEER_SCAN_BUSY_MS = 2500;
  /** Soft poll: local-DB status only; keep rare so scanning stays primary. */
  const OZON_FBS_MODAL_STATUS_POLL_MS = 20000;
  const OZON_FBS_MODAL_STATUS_MIN_GAP_MS = 15000;
  /** First silent pull after open — don't wait a full poll interval. */
  const OZON_FBS_MODAL_STATUS_FIRST_MS = 3000;

  let _ozonFbsPeerLastScanAt = 0;
  let _ozonFbsPeerScanWatchBound = false;
  let _ozonFbsPeerDomIdleTimer = null;

  function _ozonFbsPeerNoteScanActivity() {
    _ozonFbsPeerLastScanAt = Date.now();
    // Keep GM-reconcile busy window in sync (COM never hits keydown watchers).
    if (typeof window._ozonFbsContainerNoteScanActivity === "function") {
      try { window._ozonFbsContainerNoteScanActivity(); } catch (_e) { /* ignore */ }
    }
  }

  function _ozonFbsPeerBindScanWatch() {
    if (_ozonFbsPeerScanWatchBound || typeof document === "undefined") return;
    _ozonFbsPeerScanWatchBound = true;
    const mark = (ev) => {
      if (!_ozonFbsPeerIsScanInput(ev && ev.target)) return;
      _ozonFbsPeerNoteScanActivity();
    };
    document.addEventListener("keydown", mark, true);
    document.addEventListener("input", mark, true);
  }

  /** Recent wedge/COM activity — used to skip network poll during a burst. */
  function _ozonFbsPeerScanBurstBusy() {
    if (typeof window._ozonFbsContainerIsScanBusy === "function") {
      try {
        if (window._ozonFbsContainerIsScanBusy()) return true;
      } catch (_e) { /* ignore */ }
    }
    return Date.now() - Number(_ozonFbsPeerLastScanAt || 0) < OZON_FBS_PEER_SCAN_BUSY_MS;
  }

  /**
   * Defer heavy table rebuild while a burst is active OR a row/GM cell is focused.
   * Resting focus on the top sticker/mark scan field must NOT block tbody refresh —
   * those inputs live outside the table.
   */
  function _ozonFbsPeerDomBusy() {
    if (_ozonFbsPeerScanBurstBusy()) return true;
    const el = document.activeElement;
    if (!_ozonFbsPeerIsScanInput(el)) return false;
    const id = String(el.id || "");
    if (
      id === "ozonFbsKizStickerScan"
      || id === "ozonFbsKizMarkScan"
      || id === "ozonFbsPickStickerScan"
      || id === "ozonFbsPickSkuScan"
    ) {
      return false;
    }
    return true;
  }

  /** @deprecated alias — prefer burst (poll) vs dom (rebuild) explicitly. */
  function _ozonFbsPeerScanBusy() {
    return _ozonFbsPeerDomBusy();
  }

  function _ozonFbsPeerSavedAtMs(value) {
    const raw = String(value || "").trim();
    if (!raw) return 0;
    const t = Date.parse(raw);
    return Number.isFinite(t) ? t : 0;
  }

  /** Remote wins only when strictly newer; never let a stale status wipe a fresh local save. */
  function _ozonFbsPeerRemoteIsNewer(localSavedAt, remoteSavedAt) {
    const localMs = _ozonFbsPeerSavedAtMs(localSavedAt);
    const remoteMs = _ozonFbsPeerSavedAtMs(remoteSavedAt);
    if (remoteMs <= 0 && localMs > 0) return false;
    if (localMs <= 0) return true;
    return remoteMs > localMs;
  }

  /** Posting whose row cell is focused — never peer-overwrite that row mid-edit. */
  function _ozonFbsPeerFocusedPosting() {
    const el = document.activeElement;
    if (!_ozonFbsPeerIsScanInput(el)) return "";
    return String(el.dataset?.posting || el.getAttribute?.("data-posting") || "").trim();
  }

  function _ozonFbsPeerClearDomIdleTimer() {
    if (_ozonFbsPeerDomIdleTimer != null) {
      clearTimeout(_ozonFbsPeerDomIdleTimer);
      _ozonFbsPeerDomIdleTimer = null;
    }
  }

  function _ozonFbsPeerScheduleDomFlush() {
    if (_ozonFbsPeerDomIdleTimer != null) clearTimeout(_ozonFbsPeerDomIdleTimer);
    _ozonFbsPeerDomIdleTimer = setTimeout(() => {
      _ozonFbsPeerDomIdleTimer = null;
      if (_ozonFbsPeerDomBusy()) {
        _ozonFbsPeerScheduleDomFlush();
        return;
      }
      if (ozonFbsKizState.peerDomRefreshPending && _ozonFbsKizModalIsOpen()) {
        ozonFbsKizState.peerDomRefreshPending = false;
        renderOzonFbsKizTable({ skipCollect: true });
      }
      if (ozonFbsPickState.peerDomRefreshPending && _ozonFbsPickModalIsOpen()) {
        ozonFbsPickState.peerDomRefreshPending = false;
        renderOzonFbsPickVerifyTable();
      }
    }, OZON_FBS_PEER_SCAN_BUSY_MS + 50);
  }

  /**
   * Pull peer autosaves from marking/status into the open modal.
   * Skips dirty / pending / locally-edited / focused rows so we never overwrite an active scan.
   * Counters/indexes update immediately; full table rebuild waits until scan is idle.
   */
  function _ozonFbsKizMergeRemoteIntoOpenModal(orders) {
    if (!_ozonFbsKizModalIsOpen()) return 0;
    if (!Array.isArray(orders) || !orders.length) return 0;
    if (!Array.isArray(ozonFbsKizState.rows) || !ozonFbsKizState.rows.length) return 0;
    const dirty = ozonFbsKizState.localAutosaveDirty instanceof Set
      ? ozonFbsKizState.localAutosaveDirty
      : new Set();
    const pending = String(ozonFbsKizState.pendingPosting || "").trim();
    const focusedPn = _ozonFbsPeerFocusedPosting();
    const byPn = new Map();
    for (const o of orders) {
      const pn = String(o?.posting_number || "").trim();
      if (pn) byPn.set(pn, o);
    }
    let touched = 0;
    for (const row of ozonFbsKizState.rows) {
      const pn = String(row?.posting_number || "").trim();
      if (!pn || dirty.has(pn) || pending === pn || (focusedPn && pn === focusedPn)) continue;
      const upd = byPn.get(pn);
      if (!upd) continue;
      // Only touch marking-required rows (status payload includes all orders).
      if (upd.kiz_required === false) continue;
      const curCodes = _ozonFbsKizNormalizeCodesList(row.kiz_codes);
      // Unsaved local edits vs baseline — leave alone.
      if (!_ozonFbsKizBaselineEquals(pn, curCodes)) continue;
      const nextCodes = _ozonFbsKizNormalizeCodesList(upd.kiz_codes);
      const sameCodes = curCodes.length === nextCodes.length
        && curCodes.every((c, i) => c === nextCodes[i]);
      const nextSaved = String(upd.kiz_saved_at || "").trim();
      const curSaved = String(row.kiz_saved_at || "").trim();
      if (sameCodes) {
        // Prefer the newer conflict token when codes already match.
        if (_ozonFbsPeerRemoteIsNewer(curSaved, nextSaved)) row.kiz_saved_at = nextSaved;
        continue;
      }
      // Codes differ: adopt only a strictly newer remote snapshot.
      if (!_ozonFbsPeerRemoteIsNewer(curSaved, nextSaved)) continue;
      row.kiz_codes = nextCodes.length ? nextCodes.slice() : [""];
      if (upd.kiz_status) row.kiz_status = String(upd.kiz_status);
      if (nextSaved) row.kiz_saved_at = nextSaved;
      if (!ozonFbsKizState.baselineByPosting) ozonFbsKizState.baselineByPosting = {};
      ozonFbsKizState.baselineByPosting[pn] = nextCodes.slice();
      if (ozonFbsKizState.forceSaveByPosting) delete ozonFbsKizState.forceSaveByPosting[pn];
      touched += 1;
    }
    if (!touched) {
      if (ozonFbsKizState.peerDomRefreshPending && !_ozonFbsPeerDomBusy()) {
        ozonFbsKizState.peerDomRefreshPending = false;
        renderOzonFbsKizTable({ skipCollect: true });
      } else if (ozonFbsKizState.peerDomRefreshPending) {
        _ozonFbsPeerScheduleDomFlush();
      }
      return 0;
    }
    // Indexes + counters are cheap and must stay live for duplicate-mark guards
    // and the header fill line — even mid-wedge. Heavy tbody rebuild waits.
    _ozonFbsKizRebuildIndexes();
    _ozonFbsKizUpdateScanCounter();
    _ozonFbsKizUpdateFilterCounts();
    if (_ozonFbsPeerDomBusy()) {
      ozonFbsKizState.peerDomRefreshPending = true;
      _ozonFbsPeerScheduleDomFlush();
    } else {
      ozonFbsKizState.peerDomRefreshPending = false;
      renderOzonFbsKizTable({ skipCollect: true });
    }
    return touched;
  }

  function _ozonFbsKizStopModalStatusPoll() {
    if (ozonFbsKizState.modalStatusPollTimer != null) {
      clearInterval(ozonFbsKizState.modalStatusPollTimer);
      ozonFbsKizState.modalStatusPollTimer = null;
    }
    if (ozonFbsKizState.modalStatusFirstTimer != null) {
      clearTimeout(ozonFbsKizState.modalStatusFirstTimer);
      ozonFbsKizState.modalStatusFirstTimer = null;
    }
    if (ozonFbsKizState.modalStatusBurstRetry != null) {
      clearTimeout(ozonFbsKizState.modalStatusBurstRetry);
      ozonFbsKizState.modalStatusBurstRetry = null;
    }
    ozonFbsKizState.peerDomRefreshPending = false;
    if (!_ozonFbsPickModalIsOpen()) _ozonFbsPeerClearDomIdleTimer();
  }

  function _ozonFbsKizStartModalStatusPoll() {
    _ozonFbsKizStopModalStatusPoll();
    if (!_ozonFbsKizModalIsOpen()) return;
    _ozonFbsPeerBindScanWatch();
    ozonFbsKizState.lastModalStatusPollAt = 0;
    const tick = () => {
      if (!_ozonFbsKizModalIsOpen()) {
        _ozonFbsKizStopModalStatusPoll();
        return;
      }
      if (typeof document !== "undefined" && document.hidden) return;
      // Burst only — resting focus on sticker must NOT block peer counter sync.
      if (_ozonFbsPeerScanBurstBusy()) {
        if (ozonFbsKizState.modalStatusBurstRetry == null) {
          ozonFbsKizState.modalStatusBurstRetry = setTimeout(() => {
            ozonFbsKizState.modalStatusBurstRetry = null;
            tick();
          }, OZON_FBS_PEER_SCAN_BUSY_MS + 100);
        }
        return;
      }
      const now = Date.now();
      if (now - Number(ozonFbsKizState.lastModalStatusPollAt || 0) < OZON_FBS_MODAL_STATUS_MIN_GAP_MS) {
        return;
      }
      ozonFbsKizState.lastModalStatusPollAt = now;
      void refreshOzonFbsMarkingStatus(null, { silent: true });
    };
    ozonFbsKizState.modalStatusFirstTimer = setTimeout(() => {
      ozonFbsKizState.modalStatusFirstTimer = null;
      tick();
    }, OZON_FBS_MODAL_STATUS_FIRST_MS);
    ozonFbsKizState.modalStatusPollTimer = setInterval(tick, OZON_FBS_MODAL_STATUS_POLL_MS);
  }

  function _ozonFbsKizStickerIndexAdd(map, key, pn) {
    const k = String(key || "").trim();
    const posting = String(pn || "").trim();
    if (!k || !posting) return;
    const list = map.get(k);
    if (!list) {
      map.set(k, [posting]);
      return;
    }
    if (!list.includes(posting)) list.push(posting);
  }

  /** Rebuild O(1) maps used by high-frequency Marking scans (~hundreds of rows). */
  function _ozonFbsKizRebuildIndexes() {
    const rowsByPosting = new Map();
    const markIndex = new Map();
    const stickerIndex = new Map();
    for (const row of ozonFbsKizState.rows || []) {
      const pn = String(row?.posting_number || "").trim();
      if (!pn) continue;
      rowsByPosting.set(pn, row);
      for (const c of row.kiz_codes || []) {
        const mark = _ozonFbsNormalizeMark(c);
        if (mark) markIndex.set(mark, pn);
      }
      const fields = _ozonFbsResolvedStickerFields(row);
      if (fields.upper) _ozonFbsKizStickerIndexAdd(stickerIndex, _ozonFbsStickerScanKey(fields.upper), pn);
      if (fields.lower) _ozonFbsKizStickerIndexAdd(stickerIndex, _ozonFbsStickerScanKey(fields.lower), pn);
      if (fields.scanit) _ozonFbsKizStickerIndexAdd(stickerIndex, _ozonFbsStickerScanKey(fields.scanit), pn);
      if (pn) _ozonFbsKizStickerIndexAdd(stickerIndex, pn.toLowerCase(), pn);
    }
    ozonFbsKizState.rowsByPosting = rowsByPosting;
    ozonFbsKizState.markIndex = markIndex;
    ozonFbsKizState.stickerIndex = stickerIndex;
  }

  function _ozonFbsKizRowByPosting(postingNumber) {
    const pn = String(postingNumber || "").trim();
    if (!pn) return null;
    const cached = ozonFbsKizState.rowsByPosting?.get(pn);
    if (cached) return cached;
    return (ozonFbsKizState.rows || []).find((r) => String(r.posting_number) === pn) || null;
  }

  function _ozonFbsKizIndexSetMark(mark, postingNumber) {
    const key = _ozonFbsNormalizeMark(mark);
    const pn = String(postingNumber || "").trim();
    if (!key || !pn) return;
    if (!ozonFbsKizState.markIndex) ozonFbsKizState.markIndex = new Map();
    ozonFbsKizState.markIndex.set(key, pn);
  }

  function _ozonFbsKizIndexClearMark(mark) {
    const key = _ozonFbsNormalizeMark(mark);
    if (!key || !ozonFbsKizState.markIndex) return;
    ozonFbsKizState.markIndex.delete(key);
  }

  function _ozonFbsKizCollectFromDom() {
    const byPn = ozonFbsKizState.rowsByPosting;
    document.querySelectorAll("#ozonFbsKizTbody .wb-fbs-kiz-code-input").forEach((input) => {
      const pn = String(input.dataset.posting || "");
      const idx = Number(input.dataset.idx);
      const row = (byPn && byPn.get(pn)) || ozonFbsKizState.rows.find((r) => String(r.posting_number) === pn);
      if (!row || !Number.isFinite(idx)) return;
      if (!Array.isArray(row.kiz_codes)) row.kiz_codes = [];
      const prev = _ozonFbsNormalizeMark(row.kiz_codes[idx]);
      const committed = _ozonFbsNormalizeMark(input.dataset.committedMark || "");
      let next = _ozonFbsNormalizeMark(input.value);
      // Illegal replace in progress (wedge typed over filled slot): keep committed
      // in row/index until blur/Enter rejects — do not poison markIndex or Save.
      if (committed && next && committed !== next) next = committed;
      row.kiz_codes[idx] = next;
      if (prev && prev !== next) _ozonFbsKizIndexClearMark(prev);
      if (next) _ozonFbsKizIndexSetMark(next, pn);
    });
  }

  function _ozonFbsKizCaptureBaseline() {
    const map = {};
    const gtdMap = {};
    for (const r of ozonFbsKizState.rows) {
      const pn = String(r.posting_number || "").trim();
      if (!pn) continue;
      map[pn] = _ozonFbsKizNormalizeCodesList(r.kiz_codes);
      gtdMap[pn] = String(r.gtd_number || "").trim();
    }
    ozonFbsKizState.baselineByPosting = map;
    ozonFbsKizState.baselineGtdByPosting = gtdMap;
  }

  function _ozonFbsKizBaselineEquals(postingNumber, codes) {
    const pn = String(postingNumber || "").trim();
    const base = ozonFbsKizState.baselineByPosting?.[pn];
    if (!Array.isArray(base)) return false;
    const cur = _ozonFbsKizNormalizeCodesList(codes);
    if (base.length !== cur.length) return false;
    for (let i = 0; i < base.length; i += 1) {
      if (base[i] !== cur[i]) return false;
    }
    return true;
  }

  function _ozonFbsApplyStickerBindings(rows, bindings) {
    if (!bindings || typeof bindings !== "object" || !Array.isArray(rows)) return;
    for (const row of rows) {
      const pn = String(row?.posting_number || "").trim();
      if (!pn) continue;
      const st = bindings[pn];
      if (!st || typeof st !== "object") continue;
      if (st.sticker_barcode != null) {
        row.sticker_barcode = String(st.sticker_barcode || "").trim();
      }
      if (st.sticker_lower_barcode != null) {
        row.sticker_lower_barcode = String(st.sticker_lower_barcode || "").trim();
      }
      if (st.sticker_part_a != null) {
        row.sticker_part_a = String(st.sticker_part_a || "").trim();
      }
      if (st.sticker_part_b != null) {
        row.sticker_part_b = String(st.sticker_part_b || "").trim();
      }
      if (st.sticker_scanit != null) {
        row.sticker_scanit = String(st.sticker_scanit || "").trim();
      }
    }
  }

  function _ozonFbsLookupRefreshPostings(rows, scan) {
    const out = [];
    const seen = new Set();
    const scanitScan = _ozonFbsLooksLikeScanit(scan);
    for (const row of Array.isArray(rows) ? rows : []) {
      const pn = String(row?.posting_number || "").trim();
      if (!pn || seen.has(pn)) continue;
      const fields = _ozonFbsResolvedStickerFields(row);
      // Prefer unbound rows. For ii… refresh even QR-bound rows missing scanit.
      if (scanitScan) {
        if (fields.scanit) continue;
      } else if (fields.upper || fields.lower) {
        continue;
      }
      seen.add(pn);
      out.push(pn);
      if (out.length >= 80) break;
    }
    return out;
  }

  function _ozonFbsScanLooksLikePackageBarcode(scan) {
    const raw = _ozonFbsNormalizeScan(scan);
    if (!raw) return false;
    const digits = raw.replace(/\D+/g, "");
    return digits.length >= 12 && digits === raw;
  }

  function _ozonFbsScanLooksLikeLabelScan(scan) {
    return _ozonFbsScanLooksLikePackageBarcode(scan) || _ozonFbsLooksLikeScanit(scan);
  }

  async function _ozonFbsLookupPostingByScan(scan, rows) {
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    const raw = _ozonFbsNormalizeScan(scan);
    if (!sourceId || !raw) return { found: false };
    const params = new URLSearchParams({ source_id: String(sourceId), scan: raw });
    if (_ozonFbsScanLooksLikeLabelScan(raw)) {
      const refreshPns = _ozonFbsLookupRefreshPostings(rows, raw);
      if (refreshPns.length) params.set("refresh_postings", refreshPns.join(","));
    }
    const res = await fetch(`/api/ozon-fbs/postings/lookup?${params}`);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return { found: false };
    return data && typeof data === "object" ? data : { found: false };
  }

  function _ozonFbsKizFindBySticker(scan) {
    const raw = _ozonFbsNormalizeScan(scan);
    if (!raw) return { row: null, ambiguous: false };
    const index = ozonFbsKizState.stickerIndex;
    if (index && index.size) {
      const rawKey = _ozonFbsStickerScanKey(raw);
      const rawLower = raw.toLowerCase();
      for (const key of [rawKey, rawLower]) {
        const pns = index.get(key);
        if (!pns || !pns.length) continue;
        const rows = pns.map((pn) => _ozonFbsKizRowByPosting(pn)).filter(Boolean);
        if (rows.length === 1) return { row: rows[0], ambiguous: false };
        if (rows.length > 1) return { row: null, ambiguous: true, matches: rows };
      }
    }
    return _ozonFbsFindByStickerInRows(scan, ozonFbsKizState.rows, { includeCancelled: true });
  }

  async function _ozonFbsKizFindByStickerWithLookup(scan) {
    const local = _ozonFbsKizFindBySticker(scan);
    if (local.row || local.ambiguous) return local;
    const raw = _ozonFbsNormalizeScan(scan);
    if (!raw) return local;
    try {
      const data = await _ozonFbsLookupPostingByScan(raw, ozonFbsKizState.rows);
      if (data.sticker_bindings) {
        _ozonFbsApplyStickerBindings(ozonFbsKizState.rows, data.sticker_bindings);
        _ozonFbsKizRebuildIndexes();
        const afterRefresh = _ozonFbsKizFindBySticker(scan);
        if (afterRefresh.row || afterRefresh.ambiguous) return afterRefresh;
      }
      if (!data.found || !data.posting) return local;
      const pn = String(data.posting.posting_number || "").trim();
      if (!pn) return local;
      const row = _ozonFbsKizRowByPosting(pn);
      if (!row) return local;
      row.sticker_barcode = String(data.posting.sticker_barcode || row.sticker_barcode || "").trim();
      row.sticker_lower_barcode = String(
        data.posting.sticker_lower_barcode || row.sticker_lower_barcode || ""
      ).trim();
      row.sticker_scanit = String(data.posting.sticker_scanit || row.sticker_scanit || "").trim();
      row.sticker_part_a = String(data.posting.sticker_part_a || row.sticker_part_a || "").trim();
      row.sticker_part_b = String(data.posting.sticker_part_b || row.sticker_part_b || "").trim();
      _ozonFbsKizRebuildIndexes();
      return { row, ambiguous: false };
    } catch (_) {
      return local;
    }
  }

  function _ozonFbsKizFindByPosting(scan) {
    return _ozonFbsFindByStickerInRows(scan, ozonFbsKizState.rows);
  }

  function _ozonFbsKizFindExistingMark(mark) {
    const key = _ozonFbsNormalizeMark(mark);
    if (!key) return null;
    const indexedPn = ozonFbsKizState.markIndex?.get(key);
    if (indexedPn) {
      const row = _ozonFbsKizRowByPosting(indexedPn);
      if (row) return row;
    }
    for (const row of ozonFbsKizState.rows) {
      for (const c of row.kiz_codes || []) {
        if (_ozonFbsNormalizeMark(c) === key) {
          _ozonFbsKizIndexSetMark(key, row.posting_number);
          return row;
        }
      }
    }
    return null;
  }


  function _ozonFbsSetFilterCount(elId, count) {
    const el = document.getElementById(elId);
    if (!el) return;
    const n = Math.max(0, Number(count) || 0);
    el.textContent = `(${n})`;
    const label = el.closest("label");
    if (label) {
      const base = String(label.getAttribute("data-filter-base-title") || label.getAttribute("title") || "").trim();
      if (!label.hasAttribute("data-filter-base-title")) {
        label.setAttribute("data-filter-base-title", label.getAttribute("title") || "");
      }
      const tip = `По текущему поиску: ${n}`;
      label.title = base ? `${base} — ${tip}` : tip;
    }
  }

  /** Search-only base for facet counts (independent of other checkboxes). */
  function _ozonFbsKizRowMatchesSearch(row, q) {
    if (!q) return true;
    const hay = [
      row?.posting_number, row?.offer_id, row?.product_name, row?.sku,
      row?.sticker_barcode, row?.sticker_lower_barcode, row?.sticker_scanit,
      row?.sticker_part_a, row?.sticker_part_b,
      row?.container_barcode, row?.container_id, row?.container_number,
      ...(Array.isArray(row?.barcodes) ? row.barcodes : []),
    ].map((x) => String(x || "").toLowerCase()).join(" ");
    return hay.includes(q) || _ozonFbsSearchMatchesPostingOrSupply(row, q);
  }

  function _ozonFbsPickRowMatchesSearch(row, q) {
    if (!q) return true;
    const hay = [
      row?.posting_number, row?.offer_id, row?.product_name, row?.sku, row?.pick_barcode,
      row?.sticker_barcode, row?.sticker_lower_barcode, row?.sticker_scanit,
      row?.sticker_part_a, row?.sticker_part_b,
      row?.container_barcode, row?.container_id, row?.container_number,
      ...(Array.isArray(row?.barcodes) ? row.barcodes : []),
    ].map((x) => String(x || "").toLowerCase()).join(" ");
    return hay.includes(q) || _ozonFbsSearchMatchesPostingOrSupply(row, q);
  }

  /**
   * Facet counts: each filter shows how many rows match THAT criterion
   * within the current search. Other checkboxes do not narrow these numbers,
   * so dual-filter AND in the table stays clear (counts ≠ visible rows).
   */
  function _ozonFbsKizUpdateFilterCounts() {
    const q = String(document.getElementById("ozonFbsKizSearchFilter")?.value || "")
      .trim()
      .toLowerCase();
    let filled = 0;
    let empty = 0;
    let legal = 0;
    let errors = 0;
    let cancelled = 0;
    for (const r of ozonFbsKizState.rows || []) {
      if (!_ozonFbsKizRowMatchesSearch(r, q)) continue;
      if (_ozonFbsRowIsCancelled(r)) {
        cancelled += 1;
        continue;
      }
      if (_ozonFbsKizRowIsComplete(r)) filled += 1;
      else empty += 1;
      if (r?.gtd_required) legal += 1;
      if (_ozonFbsKizRowHasError(r)) errors += 1;
    }
    _ozonFbsSetFilterCount("ozonFbsKizFilterFilledCount", filled);
    _ozonFbsSetFilterCount("ozonFbsKizFilterEmptyCount", empty);
    _ozonFbsSetFilterCount("ozonFbsKizFilterLegalCount", legal);
    _ozonFbsSetFilterCount("ozonFbsKizFilterErrorsCount", errors);
    _ozonFbsSetFilterCount("ozonFbsKizFilterCancelledCount", cancelled);
  }

  function _ozonFbsPickUpdateFilterCounts() {
    const q = String(document.getElementById("ozonFbsPickSearchFilter")?.value || "")
      .trim()
      .toLowerCase();
    let filled = 0;
    let empty = 0;
    let errors = 0;
    let cancelled = 0;
    for (const r of ozonFbsPickState.rows || []) {
      if (!_ozonFbsPickRowMatchesSearch(r, q)) continue;
      if (_ozonFbsRowIsCancelled(r)) {
        cancelled += 1;
        continue;
      }
      if (_ozonFbsPickRowIsComplete(r)) filled += 1;
      else empty += 1;
      if (_ozonFbsPickRowHasError(r)) errors += 1;
    }
    _ozonFbsSetFilterCount("ozonFbsPickFilterFilledCount", filled);
    _ozonFbsSetFilterCount("ozonFbsPickFilterEmptyCount", empty);
    _ozonFbsSetFilterCount("ozonFbsPickFilterErrorsCount", errors);
    _ozonFbsSetFilterCount("ozonFbsPickFilterCancelledCount", cancelled);
  }

  function onOzonFbsKizFilterFilledChange() {
    const filled = document.getElementById("ozonFbsKizFilterFilled");
    const empty = document.getElementById("ozonFbsKizFilterEmpty");
    if (filled?.checked && empty) empty.checked = false;
    renderOzonFbsKizTable();
  }

  function onOzonFbsKizFilterEmptyChange() {
    const filled = document.getElementById("ozonFbsKizFilterFilled");
    const empty = document.getElementById("ozonFbsKizFilterEmpty");
    if (empty?.checked && filled) filled.checked = false;
    renderOzonFbsKizTable();
  }

  function renderOzonFbsKizTable(opts) {
    if (!opts?.skipCollect) _ozonFbsKizCollectFromDom();
    const tbody = document.getElementById("ozonFbsKizTbody");
    if (!tbody) return;
    _ozonFbsPrepareRowMenuRender();
    const q = String(document.getElementById("ozonFbsKizSearchFilter")?.value || "")
      .trim()
      .toLowerCase();
    const showFilled = !!document.getElementById("ozonFbsKizFilterFilled")?.checked;
    const showEmpty = !!document.getElementById("ozonFbsKizFilterEmpty")?.checked;
    const showLegal = !!document.getElementById("ozonFbsKizFilterLegal")?.checked;
    const showErrors = !!document.getElementById("ozonFbsKizFilterErrors")?.checked;
    const showCancelled = !!document.getElementById("ozonFbsKizFilterCancelled")?.checked;
    const pending = String(ozonFbsKizState.pendingPosting || "").trim();
    const rows = (ozonFbsKizState.rows || []).filter((r) => {
      const complete = _ozonFbsKizRowIsComplete(r);
      if (showFilled && !complete) return false;
      if (showEmpty && complete) return false;
      // Ozon юрлицо: requirements.products_requiring_gtd → gtd_required.
      if (showLegal && !r?.gtd_required) return false;
      if (showErrors && !_ozonFbsKizRowHasError(r)) return false;
      if (showCancelled && !_ozonFbsRowIsCancelled(r)) return false;
      return _ozonFbsKizRowMatchesSearch(r, q);
    });
    _ozonFbsKizUpdateFilterCounts();
    if (!rows.length) {
      tbody.innerHTML = `<tr><td colspan="5" class="wb-fbs-empty">${
        ozonFbsKizState.rows?.length ? "Нет строк по выбранным фильтрам" : "Нет отправлений с маркировкой"
      }</td></tr>`;
      _ozonFbsKizRebuildIndexes();
      _ozonFbsKizUpdateScanCounter();
      if (typeof _ozonFbsContainerUpdateCounters === "function") _ozonFbsContainerUpdateCounters();
      return;
    }
    tbody.innerHTML = rows.map((r) => {
      const pn = String(r.posting_number || "");
      const safePn = esc(pn);
      const menuKey = _ozonFbsPostingMenuKey(pn);
      const isCancelled = _ozonFbsRowIsCancelled(r);
      const codes = Array.isArray(r.kiz_codes) && r.kiz_codes.length ? r.kiz_codes : [""];
      const err = String(ozonFbsKizState.errors[pn] || "").trim();
      const photo = r.product_photo
        ? `<img class="wb-fbs-product-photo" src="${esc(r.product_photo)}" alt="" width="56" height="56" loading="lazy">`
        : `<span class="wb-fbs-product-ph" aria-hidden="true"></span>`;
      const barcodes = Array.isArray(r.barcodes) ? r.barcodes : [];
      const barcodeHtml = barcodes.length
        ? `<div class="wb-fbs-kiz-barcodes" title="Штрихкод товара">${barcodes.map((b) =>
            `<div class="wb-fbs-kiz-barcode">${esc(b)}</div>`
          ).join("")}</div>`
        : "";
      const canRemoveRow = !isCancelled && codes.length > 1;
      // Cancelled: same input chrome as active rows (not plain text), but readonly.
      const codeHtml = codes.map((code, idx) => {
        const clearTitle = canRemoveRow ? "Удалить строку КИЗ" : "Очистить маркировку";
        const roAttrs = isCancelled ? " readonly tabindex=\"-1\"" : "";
        const removeDisabled = isCancelled ? " disabled" : "";
        return `
        <div class="wb-fbs-kiz-code-block${isCancelled ? " is-cancelled" : ""}">
          <div class="wb-fbs-kiz-code-row">
            <span class="wb-fbs-kiz-code-idx">${idx + 1}</span>
            <input id="ozonFbsKizCode_${menuKey}_${idx}"
                   class="wb-fbs-kiz-code-input${err && String(code || "").trim() ? " is-error" : ""}" type="text"
                   data-posting="${safePn}" data-idx="${idx}"
                   autocomplete="off"${roAttrs}
                   oninput="onOzonFbsKizCodeInput('${safePn}', event)"
                   onblur="onOzonFbsKizCodeBlur('${safePn}', event)"
                   onkeydown="onOzonFbsKizCodeKey('${safePn}', event)" />
            <button type="button" class="wb-fbs-kiz-remove" title="${clearTitle}"
                    aria-label="${clearTitle}"${removeDisabled}
                    onclick="removeOzonFbsKizCode('${safePn}', ${idx})">×</button>
          </div>
          ${err && String(code || "").trim() ? `<div class="wb-fbs-kiz-code-status is-error">${esc(err)}</div>` : ""}
        </div>`;
      }).join("");
      return `<tr class="wb-fbs-kiz-row${pending === pn ? " is-active" : ""}${isCancelled ? " is-cancelled" : ""}" data-posting="${safePn}">
        <td>
          ${_ozonFbsModalPostingColHtml(r)}
        </td>
        <td>
          <div class="wb-fbs-product">
            ${photo}
            <div class="wb-fbs-product-text">
              <div class="wb-fbs-product-name" title="${esc(r.product_name || r.offer_id || "")}">${esc(r.product_name || r.offer_id || "—")}</div>
              <div class="wb-fbs-product-sub">Арт. ${esc(r.offer_id || "—")}</div>
              ${barcodeHtml}
            </div>
          </div>
        </td>
        <td>
          <div class="wb-fbs-kiz-codes">${codeHtml}</div>
          ${
            isCancelled
              ? ""
              : `<button type="button" class="wb-fbs-kiz-add" onclick="addOzonFbsKizCode('${safePn}')">+ Добавить КИЗ</button>`
          }
          ${
            !isCancelled && r.gtd_required
              ? `<div class="ozon-fbs-packaging-exemplar-field" style="margin-top:12px">
                   <label for="ozonFbsKizGtd_${safePn}">ГТД (юрлицо)</label>
                   <input id="ozonFbsKizGtd_${safePn}" type="text" class="ozon-fbs-kiz-gtd-input"
                          data-posting="${safePn}" autocomplete="off"
                          value="${esc(r.gtd_number || "")}"
                          placeholder="Номер ГТД"
                          oninput="onOzonFbsKizGtdInput('${safePn}', event)" />
                 </div>`
              : (r.gtd_number
                  ? `<div class="wb-fbs-order-meta" style="margin-top:8px">ГТД: ${esc(r.gtd_number)}</div>`
                  : "")
          }
        </td>
        <td class="wb-fbs-kiz-col-container">${
          typeof _ozonFbsContainerCellHtml === "function"
            ? _ozonFbsContainerCellHtml(r, "kiz")
            : "—"
        }</td>
        <td>
          ${_ozonFbsModalRowActionsHtml(r, "kiz")}
        </td>
      </tr>`;
    }).join("");
    tbody.querySelectorAll(".wb-fbs-kiz-code-input").forEach((input) => {
      const pn = String(input.dataset.posting || "");
      const idx = Number(input.dataset.idx);
      const row = _ozonFbsKizRowByPosting(pn);
      if (!row || !Number.isFinite(idx)) return;
      const rowCodes = Array.isArray(row.kiz_codes) ? row.kiz_codes : [];
      const val = String(rowCodes[idx] ?? "");
      input.value = val;
      _ozonFbsKizSyncCommittedMark(input, val);
    });
    _ozonFbsKizRebuildIndexes();
    _ozonFbsKizUpdateScanCounter();
    if (typeof _ozonFbsContainerUpdateCounters === "function") _ozonFbsContainerUpdateCounters();
  }

  /**
   * Patch one existing KIZ input after a wedge scan (no full table rebuild).
   * Returns false when DOM cannot represent the new state → caller should full-render.
   */
  function _ozonFbsKizPatchScannedCode(postingNumber, codeIdx, mark) {
    const pn = String(postingNumber || "").trim();
    const idx = Number(codeIdx);
    if (!pn || !Number.isFinite(idx) || idx < 0) return false;
    const tr = document.querySelector(`#ozonFbsKizTbody tr.wb-fbs-kiz-row[data-posting="${pn}"]`);
    if (!tr) return false;
    const input = tr.querySelector(`.wb-fbs-kiz-code-input[data-posting="${pn}"][data-idx="${idx}"]`);
    if (!input) return false;
    input.value = String(mark || "");
    _ozonFbsKizSyncCommittedMark(input, mark);
    input.classList.remove("is-error");
    const block = input.closest(".wb-fbs-kiz-code-block");
    if (block) block.querySelectorAll(".wb-fbs-kiz-code-status").forEach((node) => node.remove());
    _ozonFbsKizUpdateScanCounter();
    return true;
  }

  /** Append a new KIZ slot into an existing row without rebuilding the whole table. */
  function _ozonFbsKizAppendScannedCodeSlot(postingNumber, codeIdx, mark) {
    const pn = String(postingNumber || "").trim();
    const idx = Number(codeIdx);
    if (!pn || !Number.isFinite(idx) || idx < 0) return false;
    const tr = document.querySelector(`#ozonFbsKizTbody tr.wb-fbs-kiz-row[data-posting="${pn}"]`);
    if (!tr) return false;
    const codesWrap = tr.querySelector(".wb-fbs-kiz-codes");
    if (!codesWrap) return false;
    const safePn = esc(pn);
    const menuKey = _ozonFbsPostingMenuKey(pn);
    const clearTitle = "Удалить строку КИЗ";
    codesWrap.insertAdjacentHTML(
      "beforeend",
      `<div class="wb-fbs-kiz-code-block">
          <div class="wb-fbs-kiz-code-row">
            <span class="wb-fbs-kiz-code-idx">${idx + 1}</span>
            <input id="ozonFbsKizCode_${menuKey}_${idx}"
                   class="wb-fbs-kiz-code-input" type="text"
                   data-posting="${safePn}" data-idx="${idx}"
                   autocomplete="off"
                   oninput="onOzonFbsKizCodeInput('${safePn}', event)"
                   onblur="onOzonFbsKizCodeBlur('${safePn}', event)"
                   onkeydown="onOzonFbsKizCodeKey('${safePn}', event)" />
            <button type="button" class="wb-fbs-kiz-remove" title="${clearTitle}"
                    aria-label="${clearTitle}"
                    onclick="removeOzonFbsKizCode('${safePn}', ${idx})">×</button>
          </div>
        </div>`
    );
    const input = document.getElementById(`ozonFbsKizCode_${menuKey}_${idx}`);
    if (input) input.value = String(mark || "");
    tr.querySelectorAll(".wb-fbs-kiz-remove").forEach((btn) => {
      btn.title = clearTitle;
      btn.setAttribute("aria-label", clearTitle);
    });
    _ozonFbsKizUpdateScanCounter();
    return true;
  }

  function onOzonFbsKizGtdInput(postingNumber, event) {
    const pn = String(postingNumber || "").trim();
    const row = _ozonFbsKizRowByPosting(pn);
    if (!row) return;
    row.gtd_number = String(event?.target?.value || "").trim();
    // Keep GTD in local autosave so it is not lost before «Сохранить».
    _ozonFbsKizScheduleLocalAutosave(pn, false);
  }
  function _ozonFbsKizSyncCommittedMark(input, mark) {
    if (!input) return;
    input.dataset.committedMark = _ozonFbsNormalizeMark(mark) || "";
  }

  /**
   * Block replacing a filled KIZ slot with a different code unless cleared (×).
   * Uses data-committed-mark so keyboard wedge cannot poison row state via oninput
   * before Enter/blur. COM fill into the cell uses the same guard.
   * Returns true when the replace was rejected.
   */
  function _ozonFbsKizRejectReplaceFilledSlot(postingNumber, input, nextRaw) {
    const pn = String(postingNumber || "").trim();
    if (!pn || !input) return false;
    const idx = Number(input.dataset?.idx);
    const row = _ozonFbsKizRowByPosting(pn);
    if (!row || !Number.isFinite(idx) || idx < 0) return false;
    if (!Array.isArray(row.kiz_codes)) return false;
    const committed = _ozonFbsNormalizeMark(input.dataset.committedMark || "");
    const prev = committed || _ozonFbsNormalizeMark(row.kiz_codes[idx]);
    const next = _ozonFbsNormalizeMark(nextRaw ?? input.value);
    if (!prev || !next || prev === next) {
      if (next) _ozonFbsKizSyncCommittedMark(input, next);
      return false;
    }
    input.value = prev;
    _ozonFbsKizSyncCommittedMark(input, prev);
    if (Array.isArray(row.kiz_codes)) row.kiz_codes[idx] = prev;
    // CollectFromDom may have briefly indexed `next` before reject — restore.
    if (next) _ozonFbsKizIndexClearMark(next);
    if (prev) _ozonFbsKizIndexSetMark(prev, pn);
    const msg =
      `У отправления ${pn} уже есть КИЗ. Чтобы заменить — сначала очистите текущий.`;
    _ozonFbsKizSetInfo(msg);
    if (typeof showFbsScanAck === "function") showFbsScanAck(msg, input);
    try { input.focus(); input.select?.(); } catch (_e) { /* ignore */ }
    return true;
  }


  function onOzonFbsKizCodeInput(postingNumber, event) {
    const pn = String(postingNumber || "");
    const input = event?.target;
    if (_ozonFbsRowIsCancelled(_ozonFbsKizRowByPosting(pn))) return;
    if (input?.readOnly) return;
    if (input && typeof _wbFbsKizHasCyrillic === "function") {
      if (typeof _wbFbsKizRuLayoutModalOpen === "function" && _wbFbsKizRuLayoutModalOpen()) {
        input.value = "";
        return;
      }
      if (_wbFbsKizHasCyrillic(input.value)) {
        const idx = Number(input.dataset.idx);
        const row = _ozonFbsKizRowByPosting(pn);
        if (row && Array.isArray(row.kiz_codes) && Number.isFinite(idx) && idx >= 0) {
          const prev = _ozonFbsNormalizeMark(row.kiz_codes[idx]);
          if (prev) _ozonFbsKizIndexClearMark(prev);
          row.kiz_codes[idx] = "";
        }
        if (ozonFbsKizState.errors[pn]) delete ozonFbsKizState.errors[pn];
        if (typeof _wbFbsKizBlockRuLayout === "function") _wbFbsKizBlockRuLayout(input);
        _ozonFbsKizUpdateScanCounter();
        return;
      }
    }
    if (ozonFbsKizState.errors[pn]) delete ozonFbsKizState.errors[pn];
    // Clearing the cell (× or Delete) unlocks replace; keep committed in sync.
    if (input && !String(input.value || "").trim()) {
      _ozonFbsKizSyncCommittedMark(input, "");
    }
    _ozonFbsKizCollectFromDom();
    const row = _ozonFbsKizRowByPosting(pn);
    if (row) {
      const codes = _ozonFbsKizNormalizeCodesList(row.kiz_codes);
      if (!codes.length) {
        delete ozonFbsKizState.errors[pn];
        if (String(row.kiz_status || "") === "error") row.kiz_status = "empty";
      } else {
        row.kiz_status = "pending";
      }
    }
    _ozonFbsKizUpdateScanCounter();
  }

  function onOzonFbsKizCodeBlur(postingNumber, event) {
    const pn = String(postingNumber || "").trim();
    if (!pn || !_ozonFbsKizModalIsOpen()) return;
    if (_ozonFbsRowIsCancelled(_ozonFbsKizRowByPosting(pn))) return;
    const input = event?.target;
    if (input && _ozonFbsKizRejectReplaceFilledSlot(pn, input, input.value)) return;
    _ozonFbsKizCollectFromDom();
    _ozonFbsKizScheduleLocalAutosave(pn, false);
  }

  function onOzonFbsKizCodeKey(postingNumber, event) {
    if (!event || event.key !== "Enter") return;
    event.preventDefault();
    const pn = String(postingNumber || "").trim();
    if (!pn) return;
    if (_ozonFbsRowIsCancelled(_ozonFbsKizRowByPosting(pn))) return;
    const input = event.target;
    if (input && _ozonFbsKizRejectReplaceFilledSlot(pn, input, input.value)) return;
    _ozonFbsKizCollectFromDom();
    _ozonFbsKizScheduleLocalAutosave(pn, false);
    const sticker = document.getElementById("ozonFbsKizStickerScan");
    if (sticker) {
      sticker.focus();
      sticker.select?.();
    }
  }

  function addOzonFbsKizCode(postingNumber) {
    _ozonFbsKizCollectFromDom();
    const pn = String(postingNumber || "");
    const row = _ozonFbsKizRowByPosting(pn);
    if (!row || _ozonFbsRowIsCancelled(row)) return;
    if (!Array.isArray(row.kiz_codes)) row.kiz_codes = [""];
    const qty = Math.max(1, Number(row.quantity) || 1);
    if (row.kiz_codes.length >= qty) {
      _ozonFbsKizSetInfo(
        `У отправления ${pn} уже ${qty} слот(ов) КИЗ — больше добавлять нельзя`
      );
      return;
    }
    row.kiz_codes.push("");
    renderOzonFbsKizTable({ skipCollect: true });
    const inputs = document.querySelectorAll(`.wb-fbs-kiz-code-input[data-posting="${pn}"]`);
    const last = inputs[inputs.length - 1];
    if (last) last.focus();
  }

  function removeOzonFbsKizCode(postingNumber, idx) {
    _ozonFbsKizCollectFromDom();
    const pn = String(postingNumber || "");
    const removeIdx = Number(idx);
    const row = _ozonFbsKizRowByPosting(pn);
    if (!row || _ozonFbsRowIsCancelled(row) || !Number.isFinite(removeIdx)) return;
    if (!Array.isArray(row.kiz_codes)) row.kiz_codes = [""];
    const removedMark = _ozonFbsNormalizeMark(row.kiz_codes[removeIdx]);
    if (row.kiz_codes.length <= 1) {
      row.kiz_codes = [""];
    } else {
      row.kiz_codes.splice(removeIdx, 1);
      if (!row.kiz_codes.length) row.kiz_codes = [""];
    }
    if (removedMark) _ozonFbsKizIndexClearMark(removedMark);
    delete ozonFbsKizState.errors[pn];
    if (!_ozonFbsKizNormalizeCodesList(row.kiz_codes).length) {
      row.kiz_status = "empty";
    }
    renderOzonFbsKizTable({ skipCollect: true });
    _ozonFbsKizScheduleLocalAutosave(pn, !_ozonFbsKizNormalizeCodesList(row.kiz_codes).length);
  }

  function clearOzonFbsKizRow(postingNumber) {
    const pn = String(postingNumber || "");
    const row = _ozonFbsKizRowByPosting(pn);
    if (!row) return;
    for (const c of row.kiz_codes || []) {
      const mark = _ozonFbsNormalizeMark(c);
      if (mark) _ozonFbsKizIndexClearMark(mark);
    }
    row.kiz_codes = [""];
    row.kiz_status = "empty";
    delete ozonFbsKizState.errors[pn];
    // Must skip DOM collect: inputs still hold the old mark until re-render.
    renderOzonFbsKizTable({ skipCollect: true });
    _ozonFbsKizScheduleLocalAutosave(pn, true);
  }

  /**
   * Silent local save after each scan (WB FBS parity).
   * - Persists to FeedPilot only (`local_only`) — never waits on Ozon API.
   * - Per-posting seq coalesces rapid re-scans of the same posting.
   * - Microtask batches different postings touched in the same turn into one PUT.
   * - Scan path never awaits; UI stays responsive under hundreds of marks.
   * - After a successful local write for B2C catalog-KIZ (not юрлицо/GTD),
   *   a fire-and-forget Ozon exemplar push runs in the background — scan UI
   *   does not await it. Юрлица keep their packaging/GTD path elsewhere.
   * - Always adopt server kiz_saved_at on ok (even if a newer scan is pending)
   *   so the next PUT does not false-conflict on stale expected_saved_at.
   */
  function _ozonFbsKizScheduleLocalAutosave(postingNumber, clear) {
    const pn = String(postingNumber || "").trim();
    if (!pn) return;
    if (!ozonFbsKizState.localAutosaveSeqByPosting) ozonFbsKizState.localAutosaveSeqByPosting = {};
    if (!ozonFbsKizState.localAutosaveDirty) ozonFbsKizState.localAutosaveDirty = new Set();
    if (!ozonFbsKizState.localAutosaveClearByPosting) ozonFbsKizState.localAutosaveClearByPosting = {};
    const seq = (Number(ozonFbsKizState.localAutosaveSeqByPosting[pn]) || 0) + 1;
    ozonFbsKizState.localAutosaveSeqByPosting[pn] = seq;
    ozonFbsKizState.localAutosaveDirty.add(pn);
    if (clear) ozonFbsKizState.localAutosaveClearByPosting[pn] = true;
    else delete ozonFbsKizState.localAutosaveClearByPosting[pn];
    if (ozonFbsKizState.localAutosaveFlushQueued) return;
    ozonFbsKizState.localAutosaveFlushQueued = true;
    queueMicrotask(() => {
      ozonFbsKizState.localAutosaveFlushQueued = false;
      _ozonFbsKizQueueDirtyAutosaveFlush();
    });
  }

  function _ozonFbsKizQueueDirtyAutosaveFlush() {
    const dirty = ozonFbsKizState.localAutosaveDirty;
    if (!dirty || !dirty.size) return;
    const postings = Array.from(dirty);
    dirty.clear();
    const clearFlags = { ...(ozonFbsKizState.localAutosaveClearByPosting || {}) };
    for (const pn of postings) {
      delete ozonFbsKizState.localAutosaveClearByPosting?.[pn];
    }
    const seqSnapshot = {};
    for (const pn of postings) {
      seqSnapshot[pn] = Number(ozonFbsKizState.localAutosaveSeqByPosting?.[pn]) || 0;
    }
    const run = () => _ozonFbsKizFlushLocalAutosaveBatch(postings, clearFlags, seqSnapshot);
    ozonFbsKizState.localAutosaveChain = (ozonFbsKizState.localAutosaveChain || Promise.resolve())
      .then(run, run)
      .catch(() => {});
  }

  function _ozonFbsKizAwaitLocalAutosaves() {
    return (async () => {
      if (ozonFbsKizState.localAutosaveFlushQueued) {
        ozonFbsKizState.localAutosaveFlushQueued = false;
        _ozonFbsKizQueueDirtyAutosaveFlush();
      }
      for (let i = 0; i < 40; i += 1) {
        if (ozonFbsKizState.localAutosaveFlushQueued) {
          ozonFbsKizState.localAutosaveFlushQueued = false;
          _ozonFbsKizQueueDirtyAutosaveFlush();
        }
        const tip = ozonFbsKizState.localAutosaveChain || Promise.resolve();
        try {
          await tip;
        } catch (_e) {
          /* ignore — Save still covers drafts */
        }
        const latest = ozonFbsKizState.localAutosaveChain || tip;
        const inflight = Number(ozonFbsKizState.localAutosaveInflight) || 0;
        const dirtyLeft = ozonFbsKizState.localAutosaveDirty?.size || 0;
        if (tip === latest && inflight <= 0 && dirtyLeft <= 0 && !ozonFbsKizState.localAutosaveFlushQueued) {
          return;
        }
      }
    })();
  }

  async function _ozonFbsKizFlushLocalAutosaveBatch(postings, clearFlags, seqSnapshot, attempt = 0) {
    const sid = String(supplyDetailState.supplyId || "").trim();
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    if (!sid || !sourceId || !_ozonFbsKizModalIsOpen()) return;

    const items = [];
    const codesByPosting = {};
    for (const pn of postings || []) {
      const seq = Number(seqSnapshot?.[pn]) || 0;
      // Newer scan already superseded this snapshot — skip obsolete write.
      if ((Number(ozonFbsKizState.localAutosaveSeqByPosting?.[pn]) || 0) !== seq) continue;
      const row = _ozonFbsKizRowByPosting(pn);
      if (!row || _ozonFbsRowIsCancelled(row)) continue;
      const codes = _ozonFbsKizNormalizeCodesList(row.kiz_codes);
      const wantClear = !!(clearFlags && clearFlags[pn]) && !codes.length;
      const gtdNow = String(row.gtd_number || "").trim();
      const gtdBase = String(ozonFbsKizState.baselineGtdByPosting?.[pn] || "").trim();
      const gtdDirty = gtdNow !== gtdBase;
      if (!codes.length && !wantClear && !gtdDirty) continue;
      if (!wantClear && _ozonFbsKizBaselineEquals(pn, codes) && !gtdDirty) continue;
      codesByPosting[pn] = codes.slice();
      items.push({
        posting_number: pn,
        kiz_codes: codes,
        gtd_number: gtdNow,
        expected_saved_at: String(row.kiz_saved_at || ""),
        force: !!(ozonFbsKizState.forceSaveByPosting && ozonFbsKizState.forceSaveByPosting[pn]),
        clear: wantClear,
      });
    }
    if (!items.length) return;

    ozonFbsKizState.localAutosaveInflight = (Number(ozonFbsKizState.localAutosaveInflight) || 0) + 1;
    let retryPostings = null;
    try {
      const res = await fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/marking?source_id=${sourceId}`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json", ...jsonHeaders() },
          body: JSON.stringify({ items, local_only: true }),
          keepalive: true,
        }
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        if (attempt < 1) retryPostings = postings.slice();
        return;
      }
      for (const result of data.results || []) {
        const pn = String(result?.posting_number || "").trim();
        if (!pn) continue;
        const row = _ozonFbsKizRowByPosting(pn);
        if (!row) continue;
        const seq = Number(seqSnapshot?.[pn]) || 0;
        const seqCurrent = (Number(ozonFbsKizState.localAutosaveSeqByPosting?.[pn]) || 0) === seq;
        const stillDirty = !!ozonFbsKizState.localAutosaveDirty?.has(pn);

        if (result.conflict) {
          // Adopt server clock so the next write (often force) is consistent.
          row.kiz_saved_at = String(result.kiz_saved_at || row.kiz_saved_at || "");
          if (!ozonFbsKizState.forceSaveByPosting) ozonFbsKizState.forceSaveByPosting = {};
          ozonFbsKizState.forceSaveByPosting[pn] = true;
          if (seqCurrent && !stillDirty) {
            _ozonFbsKizSetInfo(
              result.error
                || "Коды изменены другим оператором — проверьте КИЗ и сохраните снова"
            );
          }
          continue;
        }
        if (!result.ok) {
          if (attempt < 1 && seqCurrent) {
            if (!retryPostings) retryPostings = [];
            if (!retryPostings.includes(pn)) retryPostings.push(pn);
          }
          continue;
        }

        // Server write succeeded — always refresh optimistic token (even if a
        // newer scan is already queued). Prevents self false-conflicts.
        if (result.kiz_saved_at) {
          row.kiz_saved_at = String(result.kiz_saved_at);
        }
        if (seqCurrent && !stillDirty) {
          if (!ozonFbsKizState.baselineByPosting) ozonFbsKizState.baselineByPosting = {};
          ozonFbsKizState.baselineByPosting[pn] = (codesByPosting[pn] || []).slice();
          if (!ozonFbsKizState.baselineGtdByPosting) ozonFbsKizState.baselineGtdByPosting = {};
          ozonFbsKizState.baselineGtdByPosting[pn] = String(row.gtd_number || "").trim();
          if (typeof result.kiz_ozon_synced === "boolean") {
            row.kiz_ozon_synced = !!result.kiz_ozon_synced;
          }
          delete ozonFbsKizState.forceSaveByPosting?.[pn];
          delete ozonFbsKizState.errors[pn];
          // B2C catalog-KIZ: attach marks to Ozon after local scan save, without
          // blocking the wedge. Юрлица (gtd_required) use packaging exemplar flow.
          if (!(clearFlags && clearFlags[pn])) {
            _ozonFbsKizScheduleBackgroundOzonPush(pn);
          }
        }
      }
    } catch (_e) {
      if (attempt < 1) retryPostings = (postings || []).slice();
    } finally {
      ozonFbsKizState.localAutosaveInflight = Math.max(
        0,
        (Number(ozonFbsKizState.localAutosaveInflight) || 1) - 1
      );
    }
    if (retryPostings && retryPostings.length) {
      await new Promise((r) => setTimeout(r, 120));
      const still = retryPostings.filter((pn) => {
        const seq = Number(seqSnapshot?.[pn]) || 0;
        return (Number(ozonFbsKizState.localAutosaveSeqByPosting?.[pn]) || 0) === seq;
      });
      if (still.length) {
        return _ozonFbsKizFlushLocalAutosaveBatch(still, clearFlags, seqSnapshot, attempt + 1);
      }
    }
  }

  /**
   * Fire-and-forget exemplar push after local autosave (B2C catalog-KIZ only).
   * Never awaited by the scan path — operator latency stays on FeedPilot DB only.
   * Per-posting promise chain + seq: rapid re-scans must not let an older
   * in-flight push overwrite newer codes on Ozon.
   */
  function _ozonFbsKizScheduleBackgroundOzonPush(postingNumber) {
    const pn = String(postingNumber || "").trim();
    if (!pn || !_ozonFbsKizModalIsOpen()) return;
    const row = _ozonFbsKizRowByPosting(pn);
    if (!row || _ozonFbsRowIsCancelled(row) || row.gtd_required) return;
    if (row.kiz_ozon_synced) return;
    const codesNow = _ozonFbsKizNormalizeCodesList(row.kiz_codes);
    const reqQty = Math.max(Number(row.quantity) || 1, 1);
    if (codesNow.length < reqQty) return;
    const sid = String(supplyDetailState.supplyId || "").trim();
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    if (!sid || !sourceId) return;
    if (!ozonFbsKizState.bgOzonPushSeqByPosting) ozonFbsKizState.bgOzonPushSeqByPosting = {};
    if (!ozonFbsKizState.bgOzonPushChainByPosting) ozonFbsKizState.bgOzonPushChainByPosting = {};
    const seq = (Number(ozonFbsKizState.bgOzonPushSeqByPosting[pn]) || 0) + 1;
    ozonFbsKizState.bgOzonPushSeqByPosting[pn] = seq;
    const prev = ozonFbsKizState.bgOzonPushChainByPosting[pn] || Promise.resolve();
    const run = () => {
      // Superseded by a newer schedule for this posting — skip stale work.
      if ((Number(ozonFbsKizState.bgOzonPushSeqByPosting?.[pn]) || 0) !== seq) {
        return Promise.resolve();
      }
      if (!_ozonFbsKizModalIsOpen()) return Promise.resolve();
      const live = _ozonFbsKizRowByPosting(pn);
      if (!live || _ozonFbsRowIsCancelled(live) || live.gtd_required) {
        return Promise.resolve();
      }
      if (live.kiz_ozon_synced) return Promise.resolve();
      const codes = _ozonFbsKizNormalizeCodesList(live.kiz_codes);
      const need = Math.max(Number(live.quantity) || 1, 1);
      if (codes.length < need) return Promise.resolve();
      const payload = {
        items: [
          {
            posting_number: pn,
            kiz_codes: codes,
            gtd_number: "",
            expected_saved_at: String(live.kiz_saved_at || ""),
            force: true,
          },
        ],
        local_only: false,
      };
      // Do not await from the scan path — only chain per posting in background.
      return fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/marking?source_id=${sourceId}`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json", ...jsonHeaders() },
          body: JSON.stringify(payload),
          keepalive: true,
        }
      )
        .then((res) => res.json().catch(() => ({})))
        .then((data) => {
          if ((Number(ozonFbsKizState.bgOzonPushSeqByPosting?.[pn]) || 0) !== seq) return;
          const result = (data.results || []).find(
            (r) => String(r?.posting_number || "").trim() === pn
          );
          if (!result || !result.ok) return;
          const rowLive = _ozonFbsKizRowByPosting(pn);
          if (!rowLive) return;
          if (result.kiz_saved_at) rowLive.kiz_saved_at = String(result.kiz_saved_at);
          if (typeof result.kiz_ozon_synced === "boolean") {
            rowLive.kiz_ozon_synced = !!result.kiz_ozon_synced;
          }
        })
        .catch(() => {});
    };
    ozonFbsKizState.bgOzonPushChainByPosting[pn] = prev.then(run, run).catch(() => {});
  }

  function _ozonFbsKizSyncActiveCodeInput() {
    const active = document.activeElement;
    if (!active || !active.classList?.contains("wb-fbs-kiz-code-input")) return;
    if (!active.closest?.("#ozonFbsKizTbody")) return;
    const pn = String(active.dataset.posting || "").trim();
    const idx = Number(active.dataset.idx);
    const row = _ozonFbsKizRowByPosting(pn);
    if (!row || !Number.isFinite(idx) || idx < 0) return;
    if (!Array.isArray(row.kiz_codes)) row.kiz_codes = [];
    const prev = _ozonFbsNormalizeMark(row.kiz_codes[idx]);
    const next = _ozonFbsNormalizeMark(active.value);
    row.kiz_codes[idx] = next;
    if (prev && prev !== next) _ozonFbsKizIndexClearMark(prev);
    if (next) _ozonFbsKizIndexSetMark(next, pn);
  }

  async function processOzonFbsKizStickerScan(raw, inputEl) {
    const input = inputEl || document.getElementById("ozonFbsKizStickerScan");
    if (typeof _wbFbsKizRuLayoutModalOpen === "function" && _wbFbsKizRuLayoutModalOpen()) {
      _ozonFbsKizScanDiag("sticker_enter_ru_modal", _ozonFbsKizScanDiagSnapshot(input));
      return;
    }
    if (typeof _fbsScanAckModalOpen === "function" && _fbsScanAckModalOpen()) {
      return;
    }
    if (typeof _fbsStickerNotFoundModalOpen === "function" && _fbsStickerNotFoundModalOpen()) {
      return;
    }
    if (input?.disabled || input?.readOnly || !ozonFbsKizState.rowsReady) {
      _ozonFbsKizScanDiag(
        "sticker_enter_blocked",
        _ozonFbsKizScanDiagSnapshot(input)
      );
      return;
    }
    const rawTyped = String(raw ?? input?.value ?? "").replace(/\s+/g, "").trim();
    if (!rawTyped) {
      // Digits never reached the field (swallow/readonly) or scanner sent bare Enter.
      _ozonFbsKizScanDiag("sticker_enter_empty", _ozonFbsKizScanDiagSnapshot(input));
      return;
    }
    if (typeof _wbFbsKizHasCyrillic === "function" && _wbFbsKizHasCyrillic(rawTyped)) {
      _ozonFbsKizScanDiag(
        "sticker_enter_cyrillic",
        `${_ozonFbsKizScanDiagSnapshot(input)} sampleLen=${rawTyped.length}`
      );
      if (typeof _wbFbsKizBlockRuLayout === "function") _wbFbsKizBlockRuLayout(input);
      return;
    }
    if (typeof _ozonFbsContainerIsScanMode === "function" && _ozonFbsContainerIsScanMode("kiz")) {
      await _ozonFbsContainerHandleScan("kiz", rawTyped);
      return;
    }
    if (
      typeof _ozonFbsContainerGuardOrderScanRequiresActiveGm === "function"
      && !_ozonFbsContainerGuardOrderScanRequiresActiveGm("kiz", input)
    ) {
      return;
    }
    // Sync only the focused cell (if any) — avoid walking hundreds of inputs.
    _ozonFbsKizSyncActiveCodeInput();
    const found = await _ozonFbsKizFindByStickerWithLookup(rawTyped);
    if (found.ambiguous) {
      const ids = (found.matches || []).map((r) => r.posting_number).slice(0, 5).join(", ");
      const msg =
        `Код этикетки совпадает у нескольких отправлений (${ids}${
          (found.matches || []).length > 5 ? "…" : ""
        }). Отсканируйте QR ещё раз.`;
      _ozonFbsKizSetInfo(msg);
      if (typeof showFbsScanAck === "function") showFbsScanAck(msg, input);
      if (input) input.select();
      return;
    }
    if (!found.row) {
      const msg = `Отправление «${rawTyped}» не найдено среди товаров с маркировкой.`;
      _ozonFbsKizSetInfo(msg);
      if (typeof showFbsStickerNotFound === "function") showFbsStickerNotFound(msg, input);
      if (input) input.select();
      return;
    }
    // Cancelled stay visible in the modal, but must not accept new KIZ via scan
    // (readonly cell / × disabled; import already skips cancelled).
    if (_ozonFbsRowIsCancelled(found.row)) {
      const pnCancelled = String(found.row.posting_number || "").trim();
      const msg =
        `Отправление ${pnCancelled || rawTyped} отменено — КИЗ менять нельзя`;
      _ozonFbsKizSetInfo(msg);
      if (typeof showFbsScanAck === "function") showFbsScanAck(msg, input);
      if (input) {
        input.value = "";
        input.select?.();
      }
      return;
    }
    ozonFbsKizState.pendingPosting = String(found.row.posting_number || "");
    void _ozonFbsPersistStickerForRow(found.row, rawTyped);
    _ozonFbsKizSetInfo("");
    if (input) input.value = "";
    const meta = document.getElementById("ozonFbsKizScanPromptMeta");
    if (meta) meta.textContent = `Отправление ${ozonFbsKizState.pendingPosting}`;
    if (typeof setModalVisibility === "function") setModalVisibility("ozonFbsKizScanPrompt", true);
    else document.getElementById("ozonFbsKizScanPrompt")?.classList.remove("hidden");
    const mark = document.getElementById("ozonFbsKizMarkScan");
    if (mark) {
      mark.value = "";
      setTimeout(() => mark.focus(), 40);
    }
  }

  async function onOzonFbsKizStickerScanKey(event) {
    if (!event || event.key !== "Enter") return;
    event.preventDefault();
    await processOzonFbsKizStickerScan(event.target?.value || "", event.target);
  }

  function cancelOzonFbsKizMarkScan() {
    if (typeof setModalVisibility === "function") setModalVisibility("ozonFbsKizScanPrompt", false);
    else document.getElementById("ozonFbsKizScanPrompt")?.classList.add("hidden");
    ozonFbsKizState.pendingPosting = null;
    const sticker = document.getElementById("ozonFbsKizStickerScan");
    if (sticker) setTimeout(() => sticker.focus(), 40);
  }

  function processOzonFbsKizMarkScan(raw, inputEl) {
    const input = inputEl || document.getElementById("ozonFbsKizMarkScan");
    if (typeof _wbFbsKizRuLayoutModalOpen === "function" && _wbFbsKizRuLayoutModalOpen()) {
      _ozonFbsKizScanDiag("mark_enter_ru_modal", _ozonFbsKizScanDiagSnapshot(input));
      return;
    }
    if (typeof _fbsScanAckModalOpen === "function" && _fbsScanAckModalOpen()) return;
    if (typeof _fbsStickerNotFoundModalOpen === "function" && _fbsStickerNotFoundModalOpen()) return;
    const pn = String(ozonFbsKizState.pendingPosting || "");
    const rawTyped = String(raw ?? input?.value ?? "");
    if (!pn || !String(rawTyped || "").replace(/\s+/g, "")) {
      _ozonFbsKizScanDiag(
        "mark_enter_empty",
        `${_ozonFbsKizScanDiagSnapshot(input)} pn=${pn || "-"}`
      );
      return;
    }
    if (typeof _wbFbsKizHasCyrillic === "function" && _wbFbsKizHasCyrillic(rawTyped)) {
      _ozonFbsKizScanDiag(
        "mark_enter_cyrillic",
        `${_ozonFbsKizScanDiagSnapshot(input)} pn=${pn}`
      );
      if (typeof _wbFbsKizBlockRuLayout === "function") _wbFbsKizBlockRuLayout(input);
      return;
    }
    const mark = _ozonFbsNormalizeMark(rawTyped);
    if (!mark) return;
    _ozonFbsKizSyncActiveCodeInput();
    const row = _ozonFbsKizRowByPosting(pn);
    if (!row) {
      cancelOzonFbsKizMarkScan();
      return;
    }
    if (_ozonFbsRowIsCancelled(row)) {
      const msg = `Отправление ${pn} отменено — КИЗ менять нельзя`;
      _ozonFbsKizSetInfo(msg);
      // Prompt closes — refocus sticker after «Хорошо», not the hidden mark field.
      const sticker = document.getElementById("ozonFbsKizStickerScan");
      cancelOzonFbsKizMarkScan();
      if (typeof showFbsScanAck === "function") showFbsScanAck(msg, sticker || input);
      return;
    }
    const check = _ozonFbsKizValidateMarkForOrder(mark, row);
    if (!check.ok) {
      const msg = check.error || "Маркировка не подходит к ШК товара в отправлении";
      _ozonFbsKizSetInfo(msg);
      if (typeof showFbsScanAck === "function") showFbsScanAck(msg, input);
      if (input) input.select();
      return;
    }
    const dup = _ozonFbsKizFindExistingMark(mark);
    if (dup) {
      const dupPn = String(dup.posting_number || "");
      const msg =
        dupPn === pn
          ? `Этот КИЗ уже просканирован в отправление ${pn} — повторно не добавляем`
          : `Этот КИЗ уже просканирован в отправление ${dupPn} — в ${pn} не добавляем`;
      _ozonFbsKizSetInfo(msg);
      if (typeof showFbsScanAck === "function") showFbsScanAck(msg, input);
      if (input) input.select();
      return;
    }
    // Cap by quantity: do not grow a second (Nth) slot when all required codes
    // are already filled. Prevents «same sticker + other KIZ» creating 2 codes
    // on qty=1 postings (live scan path; import already had this check).
    const existing = _ozonFbsKizRowExistingCodes(row);
    const qty = Math.max(1, Number(row.quantity) || 1);
    if (existing.length >= qty) {
      const had = existing.map(_ozonFbsKizMarkPreview).join("; ");
      const msg =
        `У отправления ${pn} уже есть КИЗ (${had}). Чтобы заменить — сначала очистите текущий.`;
      _ozonFbsKizSetInfo(msg);
      if (typeof showFbsScanAck === "function") showFbsScanAck(msg, input);
      if (input) input.select();
      return;
    }
    if (!Array.isArray(row.kiz_codes) || !row.kiz_codes.length) row.kiz_codes = [""];
    let placedIdx = -1;
    for (let i = 0; i < row.kiz_codes.length; i += 1) {
      if (!String(row.kiz_codes[i] || "").trim()) {
        row.kiz_codes[i] = mark;
        placedIdx = i;
        break;
      }
    }
    const addedSlot = placedIdx < 0;
    if (addedSlot) {
      row.kiz_codes.push(mark);
      placedIdx = row.kiz_codes.length - 1;
    }
    row.kiz_status = "pending";
    delete ozonFbsKizState.errors[pn];
    _ozonFbsKizIndexSetMark(mark, pn);
    const emptyFilter = document.getElementById("ozonFbsKizFilterEmpty");
    const emptyFilterWasOn = !!emptyFilter?.checked;
    if (emptyFilter) emptyFilter.checked = false;
    cancelOzonFbsKizMarkScan();
    if (
      emptyFilterWasOn
      || (addedSlot
        ? !_ozonFbsKizAppendScannedCodeSlot(pn, placedIdx, mark)
        : !_ozonFbsKizPatchScannedCode(pn, placedIdx, mark))
    ) {
      renderOzonFbsKizTable({ skipCollect: true });
    }
    _ozonFbsKizSetInfo(`КИЗ сохранён локально для ${pn}`, true);
    _ozonFbsKizScheduleLocalAutosave(pn, false);
    if (typeof _ozonFbsContainerMaybeBind === "function") {
      void _ozonFbsContainerMaybeBind("kiz", pn);
    }
    const rowEl = document.querySelector(`#ozonFbsKizTbody tr[data-posting="${pn}"]`);
    if (rowEl) rowEl.scrollIntoView({ block: "nearest" });
  
  }

  function onOzonFbsKizMarkScanKey(event) {
    if (!event || event.key !== "Enter") return;
    event.preventDefault();
    processOzonFbsKizMarkScan(event.target?.value || "", event.target);
  }

  function _ozonFbsKizApplySaveResults(results) {
    (results || []).forEach((r) => {
      if (!r || !r.ok) return;
      const pn = String(r.posting_number || "").trim();
      if (!pn) return;
      const row = _ozonFbsKizRowByPosting(pn);
      if (!row) return;
      if (Array.isArray(r.kiz_codes)) {
        row.kiz_codes = r.kiz_codes.length ? r.kiz_codes.slice() : [""];
      }
      if (r.kiz_saved_at) row.kiz_saved_at = String(r.kiz_saved_at);
      if (typeof r.kiz_ozon_synced === "boolean") {
        row.kiz_ozon_synced = !!r.kiz_ozon_synced;
      }
      if (r.gtd_number != null) row.gtd_number = String(r.gtd_number || "").trim();
      row.kiz_status = _ozonFbsKizStatusFromRow(row);
    });
    _ozonFbsKizCaptureBaseline();
    renderOzonFbsKizTable();
    _ozonFbsKizRefreshDetailBadgesFromRows(ozonFbsKizState.rows);
    if (supplyDetailState.supply) {
      renderSupplyDetail();
      _ozonFbsKizSplitSetTone(_ozonFbsKizToneFromSupply(supplyDetailState.supply));
      void refreshOzonFbsMarkingStatus(null, { silent: true });
    }
  }

  function _ozonFbsKizApplyLoadedPayload(
    data,
    { unlockScan = false, focusScan = false, preserveFocus = false, resolveMsg = "" } = {}
  ) {
    const tbody = document.getElementById("ozonFbsKizTbody");
    const saveBtn = document.getElementById("ozonFbsKizSaveBtn");
    const scan = document.getElementById("ozonFbsKizStickerScan");
    const dirty = ozonFbsKizState.localAutosaveDirty instanceof Set
      ? ozonFbsKizState.localAutosaveDirty
      : new Set();
    const prevByPn = ozonFbsKizState.rowsByPosting instanceof Map
      ? ozonFbsKizState.rowsByPosting
      : new Map();
    const active = preserveFocus ? document.activeElement : null;
    const activeId = active && active.id ? String(active.id) : "";
    const activePosting = active?.dataset?.posting
      ? String(active.dataset.posting)
      : "";
    const activeIdx = active?.dataset?.idx != null ? String(active.dataset.idx) : "";
    const activeWasScan = !!(scan && active === scan);
    const activeScanValue = activeWasScan ? String(scan.value || "") : "";

    const incoming = (Array.isArray(data?.rows) ? data.rows : []).map((r) => {
      const pn = String(r?.posting_number || "").trim();
      const prev = pn ? prevByPn.get(pn) : null;
      // Keep in-progress local scans while background resolve continues.
      if (prev && (dirty.has(pn) || ozonFbsKizState.pendingPosting === pn)) {
        return {
          ...r,
          kiz_codes: Array.isArray(prev.kiz_codes) ? prev.kiz_codes.slice() : [""],
          kiz_status: prev.kiz_status,
          kiz_saved_at: prev.kiz_saved_at,
        };
      }
      const raw = Array.isArray(r.kiz_codes) ? r.kiz_codes : [];
      const filled = raw.map((c) => String(c || "").trim()).filter(Boolean);
      return {
        ...r,
        kiz_codes: filled.length ? filled.slice() : [""],
      };
    });

    ozonFbsKizState.rows = incoming;
    _ozonFbsKizMergeOrderFlagsIntoDetail(data?.order_kiz_flags || []);
    if (!Object.keys(ozonFbsKizState.baselineByPosting || {}).length) {
      _ozonFbsKizCaptureBaseline();
    }
    _ozonFbsKizRebuildIndexes();
    renderOzonFbsKizTable();
    if (supplyDetailState.supply) {
      renderSupplyDetail();
      _ozonFbsKizSplitSetTone(_ozonFbsKizToneFromSupply(supplyDetailState.supply));
    }
    if (saveBtn) saveBtn.disabled = false;
    if (unlockScan) {
      _ozonFbsKizSetFiltersReady(true);
      _ozonFbsKizSyncImportBtn();
    }
    if (preserveFocus && _ozonFbsKizModalIsOpen()) {
      setTimeout(() => {
        if (!_ozonFbsKizModalIsOpen()) return;
        if (activeWasScan) {
          const s = document.getElementById("ozonFbsKizStickerScan");
          if (s) {
            if (activeScanValue && !s.value) s.value = activeScanValue;
            s.focus();
          }
          return;
        }
        if (activeId) {
          const byId = document.getElementById(activeId);
          if (byId) {
            byId.focus();
            return;
          }
        }
        if (activePosting) {
          const sel = activeIdx !== ""
            ? `.wb-fbs-kiz-code-input[data-posting="${activePosting}"][data-idx="${activeIdx}"]`
            : `.wb-fbs-kiz-code-input[data-posting="${activePosting}"]`;
          const el = document.querySelector(sel);
          if (el) el.focus();
        }
      }, 0);
    } else if (focusScan && scan && document.activeElement !== scan) {
      setTimeout(() => {
        if (_ozonFbsKizModalIsOpen()) scan.focus();
      }, 40);
    }
    if (resolveMsg) {
      _ozonFbsKizSetInfo(resolveMsg, true);
    } else if (!ozonFbsKizState.rows.length) {
      _ozonFbsKizSetInfo("В поставке нет отправлений, требующих маркировки");
    } else {
      _ozonFbsKizSetInfo("");
    }
    if (tbody && !ozonFbsKizState.rows.length && resolveMsg) {
      tbody.innerHTML = `<tr><td colspan="4" class="wb-fbs-empty">${esc(resolveMsg)}</td></tr>`;
    }
  }

  async function openOzonFbsKizModal() {
    if (isSupplyDetailReadOnly() && !_ozonFbsCanOpenKizPickWhileReadOnly()) return;
    const sid = String(supplyDetailState.supplyId || "").trim();
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    if (!sid || !sourceId || !_ozonFbsSupplyActionsReady()) return;
    if (typeof setModalVisibility === "function") setModalVisibility("ozonFbsKizModal", true);
    else document.getElementById("ozonFbsKizModal")?.classList.remove("hidden");
    ozonFbsKizColResizer.init();
    const loadGen = (ozonFbsKizState.loadGen = Number(ozonFbsKizState.loadGen || 0) + 1);
    ozonFbsKizState.rows = [];
    ozonFbsKizState.errors = {};
    ozonFbsKizState.pendingPosting = null;
    ozonFbsKizState.baselineByPosting = {};
    ozonFbsKizState.forceSaveByPosting = {};
    ozonFbsKizState.localAutosaveDirty = new Set();
    ozonFbsKizState.localAutosaveClearByPosting = {};
    ozonFbsKizState.localAutosaveFlushQueued = false;
    ozonFbsKizState.localAutosaveSeqByPosting = {};
    ozonFbsKizState.rowsByPosting = new Map();
    ozonFbsKizState.markIndex = new Map();
    ozonFbsKizState.stickerIndex = new Map();
    _ozonFbsKizSetFiltersReady(false);
    _ozonFbsKizSetInfo("");
    _ozonFbsKizSyncImportBtn();
    closeOzonFbsKizImportModal();
    const importText = document.getElementById("ozonFbsKizImportText");
    if (importText) importText.value = "";
    _ozonFbsKizImportSetLog([]);
    _ozonFbsKizImportSetInfo("");
    _ozonFbsKizClearImportConflicts();
    const tbody = document.getElementById("ozonFbsKizTbody");
    if (tbody) {
      tbody.innerHTML = `<tr><td colspan="5" class="wb-fbs-empty">Загрузка…</td></tr>`;
    }
    _ozonFbsKizSetInfo("");
    const saveBtn = document.getElementById("ozonFbsKizSaveBtn");
    if (saveBtn) saveBtn.disabled = true;
    const scan = document.getElementById("ozonFbsKizStickerScan");
    if (scan) scan.value = "";
    let loadOk = false;
    let applied = false;
    const stillThisLoad = () =>
      Number(ozonFbsKizState.loadGen) === loadGen && _ozonFbsKizModalIsOpen();
    try {
      const params = new URLSearchParams({ source_id: String(sourceId) });
      _ozonFbsAppendPostingTab(params);
      await _ozonFbsFetchResolvedChunks(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/marking?${params}`,
        {
          shouldAbort: () => !stillThisLoad(),
          onProgress: (p) => {
            if (!stillThisLoad()) return;
            const msg = _ozonFbsResolveProgressText(p);
            if (!msg) return;
            if (tbody && !applied) {
              tbody.innerHTML = `<tr><td colspan="5" class="wb-fbs-empty">${esc(msg)}</td></tr>`;
            }
            _ozonFbsKizSetInfo(msg, true);
          },
          onChunk: (data, meta) => {
            if (!stillThisLoad()) return;
            const resolving = !meta?.done && Number(meta?.remaining || 0) > 0;
            const resolveMsg = resolving ? _ozonFbsResolveProgressText(meta) : "";
            if (!applied) {
              // Keep filters / scan / cargo-checkbox locked until the whole load finishes.
              _ozonFbsKizApplyLoadedPayload(data, {
                unlockScan: false,
                resolveMsg,
              });
              applied = true;
              loadOk = true;
              return;
            }
            // Later chunks can add newly-resolved kiz_required rows. Merge them,
            // keep controls locked, preserve in-progress local edits.
            const prevKeys = new Set(
              (ozonFbsKizState.rows || [])
                .map((r) => String(r?.posting_number || "").trim())
                .filter(Boolean)
            );
            const nextKeys = new Set(
              (Array.isArray(data?.rows) ? data.rows : [])
                .map((r) => String(r?.posting_number || "").trim())
                .filter(Boolean)
            );
            let rowsChanged = prevKeys.size !== nextKeys.size;
            if (!rowsChanged) {
              for (const k of nextKeys) {
                if (!prevKeys.has(k)) {
                  rowsChanged = true;
                  break;
                }
              }
            }
            if (rowsChanged || meta?.done) {
              _ozonFbsKizApplyLoadedPayload(data, {
                unlockScan: false,
                resolveMsg,
              });
              return;
            }
            _ozonFbsKizMergeOrderFlagsIntoDetail(data?.order_kiz_flags || []);
            if (supplyDetailState.supply) {
              renderSupplyDetail();
              _ozonFbsKizSplitSetTone(_ozonFbsKizToneFromSupply(supplyDetailState.supply));
            }
            if (resolveMsg) _ozonFbsKizSetInfo(resolveMsg, true);
            else if (ozonFbsKizState.rows.length) _ozonFbsKizSetInfo("");
          },
        }
      );
      if (!stillThisLoad()) return;
      if (!applied) {
        _ozonFbsKizApplyLoadedPayload({}, { unlockScan: false });
      } else {
        _ozonFbsKizSetInfo(
          ozonFbsKizState.rows.length
            ? ""
            : "В поставке нет отправлений, требующих маркировки"
        );
      }
    } catch (e) {
      if (!stillThisLoad()) return;
      if (tbody && !applied) {
        tbody.innerHTML = `<tr><td colspan="4" class="wb-fbs-empty" style="color:#b91c1c">${esc(e.message)}</td></tr>`;
      }
      _ozonFbsKizSetInfo(String(e.message || e));
    } finally {
      if (!stillThisLoad()) return;
      if (saveBtn) saveBtn.disabled = false;
      _ozonFbsKizSetFiltersReady(true);
      _ozonFbsKizSyncImportBtn();
      if (typeof _ozonFbsContainerPrepareModal === "function") {
        await _ozonFbsContainerPrepareModal("kiz");
      }
      _ozonFbsKizStartModalStatusPoll();
      void _ozonFbsScanComOnModalOpened();
      if (loadOk && scan) setTimeout(() => {
        if (stillThisLoad()) scan.focus();
      }, 50);
    }
  }

  async function closeOzonFbsKizModal() {
    ozonFbsKizState.loadGen = Number(ozonFbsKizState.loadGen || 0) + 1;
    _ozonFbsKizStopModalStatusPoll();
    try {
      await _ozonFbsKizAwaitLocalAutosaves();
    } catch (_e) {
      /* keep closing */
    }
    if (typeof window._ozonFbsContainerClearOnModalClose === "function") {
      window._ozonFbsContainerClearOnModalClose();
    }
    // Same cleanup as WB marking: drop RU-layout swallow so wedge scan works again.
    _ozonFbsClearRuLayoutGuard();
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsKizScanPrompt", false);
      setModalVisibility("ozonFbsKizModal", false);
    } else {
      document.getElementById("ozonFbsKizScanPrompt")?.classList.add("hidden");
      document.getElementById("ozonFbsKizModal")?.classList.add("hidden");
    }
    cancelOzonFbsKizMarkScan();
    closeOzonFbsKizImportModal();
    void _ozonFbsScanComOnModalClosed();
    ozonFbsKizState.rows = [];
    ozonFbsKizState.rowsByPosting = new Map();
    ozonFbsKizState.markIndex = new Map();
    ozonFbsKizState.stickerIndex = new Map();
    ozonFbsKizState.localAutosaveDirty = new Set();
    _ozonFbsKizSetFiltersReady(false);
    _ozonFbsKizSetInfo("");
    // Skip if save/open just refreshed (avoid double network on close).
    if (_ozonFbsStatusCooldownOk("kiz")) {
      void refreshOzonFbsMarkingStatus(null, { silent: true });
    }
  }

  async function saveOzonFbsKizModal() {
    const sid = String(supplyDetailState.supplyId || "").trim();
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    if (!sid || !sourceId || ozonFbsKizState.saving) return;
    // Commit typed ШК грузоместа before KIZ save (bind is a separate API).
    if (typeof window._ozonFbsContainerFlushPendingCells === "function") {
      await window._ozonFbsContainerFlushPendingCells("kiz");
    }
    _ozonFbsKizCollectFromDom();
    const saveBtn = document.getElementById("ozonFbsKizSaveBtn");
    ozonFbsKizState.saving = true;
    if (saveBtn) saveBtn.disabled = true;
    _ozonFbsKizSetInfo("Сохранение…");
    try {
      await _ozonFbsKizAwaitLocalAutosaves();
      _ozonFbsKizCollectFromDom();
      const items = [];
      for (const r of ozonFbsKizState.rows || []) {
        if (_ozonFbsRowIsCancelled(r)) continue;
        const pn = String(r.posting_number || "").trim();
        if (!pn) continue;
        const codes = (r.kiz_codes || []).map((c) => _ozonFbsNormalizeMark(c)).filter(Boolean);
        const gtdNow = String(r.gtd_number || "").trim();
        const gtdRequired = !!r.gtd_required;
        const gtdBase = String(ozonFbsKizState.baselineGtdByPosting?.[pn] || "").trim();
        const gtdDirty = gtdNow !== gtdBase;
        const force = !!(ozonFbsKizState.forceSaveByPosting && ozonFbsKizState.forceSaveByPosting[pn]);
        const baseCodes = Array.isArray(ozonFbsKizState.baselineByPosting?.[pn])
          ? ozonFbsKizState.baselineByPosting[pn]
          : null;
        const baseHadCodes = Array.isArray(baseCodes) && baseCodes.length > 0;
        // Empty rows are fine — skip. Only clear when codes existed and were removed.
        const wantClear = !codes.length && baseHadCodes;
        const codesDirty = !_ozonFbsKizBaselineEquals(pn, codes);
        // Retry Ozon attach when local codes exist but exemplar push failed/pending.
        // Юрлица still require GTD; B2C catalog-KIZ retries marks-only.
        const needsOzonPush = codes.length > 0
          && !r.kiz_ozon_synced
          && (!gtdRequired || !!gtdNow);
        if (!force && !codesDirty && !gtdDirty && !needsOzonPush && !wantClear) continue;
        if (!codes.length && !wantClear && !gtdDirty && !force) continue;
        if (ozonFbsKizState.errors[pn]) delete ozonFbsKizState.errors[pn];
        items.push({
          posting_number: pn,
          kiz_codes: codes,
          gtd_number: gtdNow,
          expected_saved_at: r.kiz_saved_at || "",
          force,
          clear: wantClear,
        });
      }
      if (!items.length) {
        _ozonFbsKizSetInfo("Готово", true);
        return;
      }
      // Chunk Ozon pushes so nginx 60s default cannot 504 a bulk юрлицо save.
      const CHUNK = 15;
      const allResults = [];
      let savedTotal = 0;
      for (let i = 0; i < items.length; i += CHUNK) {
        const chunk = items.slice(i, i + CHUNK);
        if (items.length > CHUNK) {
          _ozonFbsKizSetInfo(
            `Сохранение… ${Math.min(i + CHUNK, items.length)}/${items.length}`
          );
        }
        const res = await fetch(
          `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/marking?source_id=${sourceId}`,
          {
            method: "PUT",
            headers: { "Content-Type": "application/json", ...jsonHeaders() },
            body: JSON.stringify({ items: chunk }),
          }
        );
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
        allResults.push(...(data.results || []));
        savedTotal += Number(data.saved) || 0;
      }
      const errs = allResults.filter((r) => r && !r.ok);
      if (errs.length) {
        errs.forEach((e) => {
          if (e.posting_number) ozonFbsKizState.errors[e.posting_number] = e.error || "ошибка";
        });
        renderOzonFbsKizTable();
        const parts = [];
        if (savedTotal) parts.push(`сохранено ${savedTotal}`);
        parts.push(`ошибок ${errs.length}`);
        _ozonFbsKizSetInfo(`Сохранено частично (${parts.join(", ")}).`);
      } else {
        _ozonFbsKizSetInfo(
          savedTotal ? `Сохранено: ${savedTotal}` : "Готово",
          true
        );
      }
      _ozonFbsKizApplySaveResults(allResults);
    } catch (e) {
      _ozonFbsKizSetInfo(String(e.message || e));
    } finally {
      ozonFbsKizState.saving = false;
      if (saveBtn) saveBtn.disabled = false;
    }
  }

  async function refreshOzonFbsMarkingStatus(event, opts) {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    const silent = !!(opts && opts.silent);
    const sid = String(supplyDetailState.supplyId || "").trim();
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    if (!sid || !sourceId || !_ozonFbsSupplyActionsReady()) return;
    if (ozonFbsKizState.statusRefreshing) {
      ozonFbsKizState.statusRefreshQueued = true;
      return;
    }
    const refreshBtn = document.getElementById("ozonFbsSupplyDetailKizRefreshBtn");
    const refreshGen = Number(ozonFbsKizState.statusRefreshGen || 0) + 1;
    ozonFbsKizState.statusRefreshGen = refreshGen;
    ozonFbsKizState.statusRefreshing = true;
    ozonFbsKizState.statusRefreshQueued = false;
    if (!silent && refreshBtn) {
      refreshBtn.disabled = true;
      refreshBtn.classList.add("is-spinning");
    }
    try {
      const params = new URLSearchParams({ source_id: String(sourceId) });
      _ozonFbsAppendPostingTab(params);
      const res = await fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/marking/status?${params}`
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok || data.ok === false) {
        throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      }
      if (supplyDetailState.supplyId !== sid) return;
      if (ozonFbsKizState.statusRefreshGen !== refreshGen) return;
      _ozonFbsKizMergeStatusIntoDetail(data.orders || []);
      // Multi-op: adopt peer KIZ fills into the open modal (scan counter line 1).
      _ozonFbsKizMergeRemoteIntoOpenModal(data.orders || []);
      // Manual refresh: full re-render. Silent/auto: tone only (detail already painted).
      if (!silent && supplyDetailState.supply) renderSupplyDetail();
      _ozonFbsStatusCooldownTouch("kiz");
      const st = String(data.status || "");
      const split = document.getElementById("ozonFbsKizSplit");
      const refreshBtn = document.getElementById("ozonFbsSupplyDetailKizRefreshBtn");
      if (st === "error") {
        const tip = typeof _ozonFbsContainerErrorsTooltip === "function"
          ? _ozonFbsContainerErrorsTooltip(data.container_errors || [])
          : "Ошибка привязки к грузоместу";
        if (split) {
          split.dataset.containerErrorTip = tip || "Ошибка привязки к грузоместу";
          split.title = tip || "Ошибка привязки к грузоместу";
        }
        if (refreshBtn) refreshBtn.title = tip || "Ошибка привязки к грузоместу";
        _ozonFbsKizSplitSetTone("error");
      } else {
        if (split) {
          split.removeAttribute("title");
          delete split.dataset.containerErrorTip;
        }
        if (refreshBtn) refreshBtn.title = "Обновить статусы маркировки";
        // Recompute locally so incomplete GM cannot stay green when API only checked КИЗ.
        _ozonFbsKizSplitSetTone(_ozonFbsKizToneFromSupply(supplyDetailState.supply));
      }
      _ozonFbsSyncKizPickBtnLabels();
    } catch (e) {
      if (
        !silent
        && supplyDetailState.supplyId === sid
        && ozonFbsKizState.statusRefreshGen === refreshGen
      ) {
        const info = document.getElementById("ozonFbsSupplyDetailInfo");
        if (info) {
          info.hidden = false;
          info.textContent = String(e.message || e);
        }
      }
    } finally {
      if (ozonFbsKizState.statusRefreshGen === refreshGen) {
        ozonFbsKizState.statusRefreshing = false;
        if (refreshBtn) {
          refreshBtn.disabled = false;
          refreshBtn.classList.remove("is-spinning");
        }
        if (ozonFbsKizState.statusRefreshQueued) {
          ozonFbsKizState.statusRefreshQueued = false;
          void refreshOzonFbsMarkingStatus(null, { silent: true });
        }
      }
    }
  }

  function _ozonFbsPickBarcodeKeys(value) {
    const raw = _ozonFbsNormalizeScan(value);
    const digits = raw.replace(/\D/g, "");
    const set = new Set();
    if (raw) set.add(raw);
    if (digits) {
      set.add(digits);
      if (digits.length === 14 && digits.startsWith("0")) set.add(digits.slice(1));
      if (digits.length === 13) set.add(`0${digits}`);
    }
    return set;
  }

  function _ozonFbsPickOrderSkuSet(row) {
    const set = new Set();
    for (const b of row?.barcodes || []) {
      for (const k of _ozonFbsPickBarcodeKeys(b)) set.add(k);
    }
    return set;
  }

  function _ozonFbsPickValidateEanForOrder(scan, row) {
    const raw = _ozonFbsNormalizeScan(scan);
    const digits = raw.replace(/\D/g, "");
    if (!digits) return { ok: false, error: "Отсканируйте штрихкод товара (EAN-13)" };
    if (![8, 12, 13, 14].includes(digits.length)) {
      return { ok: false, error: `Ожидается EAN/GTIN (8–14 цифр), получено ${digits.length}` };
    }
    const orderSkus = _ozonFbsPickOrderSkuSet(row);
    if (!orderSkus.size) {
      return { ok: false, error: "У отправления нет штрихкодов товара — нельзя сверить ШК" };
    }
    const candidates = _ozonFbsPickBarcodeKeys(scan);
    let matched = false;
    for (const c of candidates) {
      if (orderSkus.has(c)) {
        matched = true;
        break;
      }
    }
    if (!matched) {
      return { ok: false, error: "ШК не совпадает ни с одним ШК товара в отправлении" };
    }
    const normalized = digits.length === 14 && digits.startsWith("0") ? digits.slice(1) : digits;
    return { ok: true, barcode: normalized };
  }

  function _ozonFbsPickFindBySticker(scan) {
    return _ozonFbsFindByStickerInRows(scan, ozonFbsPickState.rows);
  }

  async function _ozonFbsPickFindByStickerWithLookup(scan) {
    const local = _ozonFbsPickFindBySticker(scan);
    if (local.row || local.ambiguous) return local;
    const raw = _ozonFbsNormalizeScan(scan);
    if (!raw) return local;
    try {
      const data = await _ozonFbsLookupPostingByScan(raw, ozonFbsPickState.rows);
      if (data.sticker_bindings) {
        _ozonFbsApplyStickerBindings(ozonFbsPickState.rows, data.sticker_bindings);
        const afterRefresh = _ozonFbsPickFindBySticker(scan);
        if (afterRefresh.row || afterRefresh.ambiguous) return afterRefresh;
      }
      if (!data.found || !data.posting) return local;
      const pn = String(data.posting.posting_number || "").trim();
      if (!pn) return local;
      const row = (ozonFbsPickState.rows || []).find((r) => String(r.posting_number || "").trim() === pn);
      if (!row) return local;
      row.sticker_barcode = String(data.posting.sticker_barcode || row.sticker_barcode || "").trim();
      row.sticker_lower_barcode = String(
        data.posting.sticker_lower_barcode || row.sticker_lower_barcode || ""
      ).trim();
      row.sticker_scanit = String(data.posting.sticker_scanit || row.sticker_scanit || "").trim();
      row.sticker_part_a = String(data.posting.sticker_part_a || row.sticker_part_a || "").trim();
      row.sticker_part_b = String(data.posting.sticker_part_b || row.sticker_part_b || "").trim();
      return { row, ambiguous: false };
    } catch (_) {
      return local;
    }
  }

  function _ozonFbsPickFindByPosting(scan) {
    return _ozonFbsPickFindBySticker(scan);
  }

  function _ozonFbsPickUpdateScanCounter() {
    const el = document.getElementById("ozonFbsPickScanCount");
    if (!el) return;
    let filled = 0;
    const active = _ozonFbsActiveModalRows(ozonFbsPickState.rows);
    const total = active.length;
    for (const row of active) {
      if (row.pick_verified && String(row.pick_barcode || "").trim()) filled += 1;
    }
    el.textContent = `Проверено ${filled} из ${total}`;
    el.classList.toggle("is-complete", total > 0 && filled === total);
  }

  /** Pull peer pick-verify autosaves into the open «Товары без КИЗ» modal. */
  function _ozonFbsPickMergeRemoteIntoOpenModal(orders) {
    if (!_ozonFbsPickModalIsOpen()) return 0;
    if (!Array.isArray(orders) || !orders.length) return 0;
    if (!Array.isArray(ozonFbsPickState.rows) || !ozonFbsPickState.rows.length) return 0;
    const pending = String(ozonFbsPickState.pendingPosting || "").trim();
    const focusedPn = _ozonFbsPeerFocusedPosting();
    const byPn = new Map();
    for (const o of orders) {
      const pn = String(o?.posting_number || "").trim();
      if (pn) byPn.set(pn, o);
    }
    let touched = 0;
    for (const row of ozonFbsPickState.rows) {
      const pn = String(row?.posting_number || "").trim();
      if (!pn || pending === pn || (focusedPn && pn === focusedPn)) continue;
      const upd = byPn.get(pn);
      if (!upd) continue;
      const curVerified = !!row.pick_verified && !!String(row.pick_barcode || "").trim();
      const curBarcode = String(row.pick_barcode || "").trim();
      if (!_ozonFbsPickBaselineEquals(pn, curVerified, curBarcode)) continue;
      const nextVerified = !!upd.pick_verified && !!String(upd.pick_barcode || "").trim();
      const nextBarcode = nextVerified ? String(upd.pick_barcode || "").trim() : "";
      const nextAt = String(upd.pick_verified_at || "").trim();
      const curAt = String(row.pick_verified_at || "").trim();
      if (curVerified === nextVerified && curBarcode === nextBarcode) {
        if (_ozonFbsPeerRemoteIsNewer(curAt, nextAt)) row.pick_verified_at = nextAt;
        continue;
      }
      if (!_ozonFbsPeerRemoteIsNewer(curAt, nextAt)) continue;
      row.pick_verified = nextVerified;
      row.pick_barcode = nextBarcode;
      // Keep clear/fill token for the next conflict / peer compare.
      row.pick_verified_at = nextAt;
      _ozonFbsPickSetBaseline(pn, nextVerified, nextBarcode);
      if (ozonFbsPickState.forceSaveByPosting) delete ozonFbsPickState.forceSaveByPosting[pn];
      touched += 1;
    }
    if (!touched) {
      if (ozonFbsPickState.peerDomRefreshPending && !_ozonFbsPeerDomBusy()) {
        ozonFbsPickState.peerDomRefreshPending = false;
        renderOzonFbsPickVerifyTable();
      } else if (ozonFbsPickState.peerDomRefreshPending) {
        _ozonFbsPeerScheduleDomFlush();
      }
      return 0;
    }
    _ozonFbsPickUpdateScanCounter();
    _ozonFbsPickUpdateFilterCounts();
    if (_ozonFbsPeerDomBusy()) {
      ozonFbsPickState.peerDomRefreshPending = true;
      _ozonFbsPeerScheduleDomFlush();
    } else {
      ozonFbsPickState.peerDomRefreshPending = false;
      renderOzonFbsPickVerifyTable();
    }
    return touched;
  }

  function _ozonFbsPickStopModalStatusPoll() {
    if (ozonFbsPickState.modalStatusPollTimer != null) {
      clearInterval(ozonFbsPickState.modalStatusPollTimer);
      ozonFbsPickState.modalStatusPollTimer = null;
    }
    if (ozonFbsPickState.modalStatusFirstTimer != null) {
      clearTimeout(ozonFbsPickState.modalStatusFirstTimer);
      ozonFbsPickState.modalStatusFirstTimer = null;
    }
    if (ozonFbsPickState.modalStatusBurstRetry != null) {
      clearTimeout(ozonFbsPickState.modalStatusBurstRetry);
      ozonFbsPickState.modalStatusBurstRetry = null;
    }
    ozonFbsPickState.peerDomRefreshPending = false;
    if (!_ozonFbsKizModalIsOpen()) _ozonFbsPeerClearDomIdleTimer();
  }

  function _ozonFbsPickStartModalStatusPoll() {
    _ozonFbsPickStopModalStatusPoll();
    if (!_ozonFbsPickModalIsOpen()) return;
    _ozonFbsPeerBindScanWatch();
    ozonFbsPickState.lastModalStatusPollAt = 0;
    const tick = () => {
      if (!_ozonFbsPickModalIsOpen()) {
        _ozonFbsPickStopModalStatusPoll();
        return;
      }
      if (typeof document !== "undefined" && document.hidden) return;
      if (_ozonFbsPeerScanBurstBusy()) {
        if (ozonFbsPickState.modalStatusBurstRetry == null) {
          ozonFbsPickState.modalStatusBurstRetry = setTimeout(() => {
            ozonFbsPickState.modalStatusBurstRetry = null;
            tick();
          }, OZON_FBS_PEER_SCAN_BUSY_MS + 100);
        }
        return;
      }
      const now = Date.now();
      if (now - Number(ozonFbsPickState.lastModalStatusPollAt || 0) < OZON_FBS_MODAL_STATUS_MIN_GAP_MS) {
        return;
      }
      ozonFbsPickState.lastModalStatusPollAt = now;
      void refreshOzonFbsPickVerifyStatus(null, { silent: true });
    };
    ozonFbsPickState.modalStatusFirstTimer = setTimeout(() => {
      ozonFbsPickState.modalStatusFirstTimer = null;
      tick();
    }, OZON_FBS_MODAL_STATUS_FIRST_MS);
    ozonFbsPickState.modalStatusPollTimer = setInterval(tick, OZON_FBS_MODAL_STATUS_POLL_MS);
  }

  function _ozonFbsPickCaptureBaseline() {
    const map = {};
    for (const r of ozonFbsPickState.rows || []) {
      const pn = String(r.posting_number || "").trim();
      if (!pn) continue;
      map[pn] = {
        pick_verified: !!r.pick_verified && !!String(r.pick_barcode || "").trim(),
        pick_barcode: String(r.pick_barcode || "").trim(),
      };
    }
    ozonFbsPickState.baselineByPosting = map;
  }

  function _ozonFbsPickApplyLoadedPayload(
    data,
    { unlockScan = false, resolveMsg = "" } = {}
  ) {
    const saveBtn = document.getElementById("ozonFbsPickVerifySaveBtn");
    try {
      _ozonFbsPickCollectFromDom();
    } catch (_e) {
      /* first paint — tbody may be empty */
    }
    const prevByPn = new Map();
    for (const r of ozonFbsPickState.rows || []) {
      const pn = String(r?.posting_number || "").trim();
      if (pn) prevByPn.set(pn, r);
    }
    const pending = String(ozonFbsPickState.pendingPosting || "").trim();
    const hasBaseline = !!Object.keys(ozonFbsPickState.baselineByPosting || {}).length;
    const incoming = (Array.isArray(data?.rows) ? data.rows : []).map((r) => {
      const pn = String(r?.posting_number || "").trim();
      const prev = pn ? prevByPn.get(pn) : null;
      if (
        prev
        && hasBaseline
        && (
          pending === pn
          || !_ozonFbsPickBaselineEquals(
            pn,
            !!prev.pick_verified,
            String(prev.pick_barcode || "").trim()
          )
        )
      ) {
        return {
          ...r,
          pick_barcode: String(prev.pick_barcode || "").trim(),
          pick_verified: !!prev.pick_verified,
          pick_verified_at: prev.pick_verified_at,
        };
      }
      return { ...r };
    });
    ozonFbsPickState.rows = incoming;
    if (!hasBaseline) {
      _ozonFbsPickCaptureBaseline();
    }
    _ozonFbsKizMergeOrderFlagsIntoDetail(data?.order_kiz_flags || []);
    renderOzonFbsPickVerifyTable();
    if (supplyDetailState.supply) {
      renderSupplyDetail();
      _ozonFbsKizSplitSetTone(_ozonFbsKizToneFromSupply(supplyDetailState.supply));
    }
    if (saveBtn) saveBtn.disabled = false;
    if (unlockScan) _ozonFbsPickSetFiltersReady(true);
    if (resolveMsg) {
      _ozonFbsPickSetInfo(resolveMsg, true);
    } else if (!ozonFbsPickState.rows.length) {
      _ozonFbsPickSetInfo("В поставке нет отправлений без маркировки", true);
    } else {
      _ozonFbsPickSetInfo("");
    }
  }

  function _ozonFbsPickBaselineEquals(postingNumber, verified, barcode) {
    const pn = String(postingNumber || "").trim();
    const base = ozonFbsPickState.baselineByPosting?.[pn] || {};
    const baseVerified = !!base.pick_verified && !!String(base.pick_barcode || "").trim();
    const baseBarcode = String(base.pick_barcode || "").trim();
    const v = !!verified && !!String(barcode || "").trim();
    const b = String(barcode || "").trim();
    return v === baseVerified && b === baseBarcode;
  }

  function _ozonFbsPickSetBaseline(postingNumber, verified, barcode) {
    const pn = String(postingNumber || "").trim();
    if (!pn) return;
    if (!ozonFbsPickState.baselineByPosting) ozonFbsPickState.baselineByPosting = {};
    ozonFbsPickState.baselineByPosting[pn] = {
      pick_verified: !!verified && !!String(barcode || "").trim(),
      pick_barcode: String(barcode || "").trim(),
    };
  }

  function _ozonFbsPickCollectFromDom() {
    document.querySelectorAll("#ozonFbsPickTbody .ozon-fbs-pick-barcode-input").forEach((input) => {
      const pn = String(input.dataset.posting || "").trim();
      if (!pn) return;
      const row = (ozonFbsPickState.rows || []).find((r) => String(r.posting_number) === pn);
      if (!row || _ozonFbsRowIsCancelled(row)) return;
      const val = String(input.value || "").trim();
      const prev = String(row.pick_barcode || "").trim();
      const wasVerified = !!row.pick_verified;
      row.pick_barcode = val;
      if (!val) row.pick_verified = false;
      else if (wasVerified && val !== prev) row.pick_verified = false;
    });
  }

  function _ozonFbsPickStatusHtml(row) {
    const pn = String(row.posting_number || "");
    const safePn = esc(pn);
    if (_ozonFbsRowIsCancelled(row)) {
      const label = String(row.cancel_reason_label || "Отменено").trim();
      return `<div class="wb-fbs-pick-status is-muted">${esc(label)}</div>`;
    }
    const err = String(ozonFbsPickState.errors[pn] || "").trim();
    const barcode = String(row.pick_barcode || "").trim();
    const verified = !!row.pick_verified && !!barcode;
    const clearTitle = barcode || err ? "Сбросить" : "Очистить поле";
    return `<div class="ozon-fbs-pick-barcode-cell${err ? " is-error" : ""}${verified ? " is-ok" : ""}">
      <div class="ozon-fbs-pick-barcode-input-row">
        <input type="text" class="ozon-fbs-pick-barcode-input${err ? " is-error" : ""}"
               data-posting="${safePn}"
               value="${esc(barcode)}"
               placeholder="ШК товара"
               title="${err ? esc(err) : (verified ? "ШК проверен" : "Введите или отсканируйте ШК товара")}"
               autocomplete="off"
               oninput="onOzonFbsPickBarcodeInput('${safePn}', event)"
               onblur="onOzonFbsPickBarcodeBlur('${safePn}', event)"
               onkeydown="onOzonFbsPickBarcodeKey('${safePn}', event)" />
        <button type="button" class="wb-fbs-kiz-remove" title="${clearTitle}"
                aria-label="${clearTitle}"
                onclick="clearOzonFbsPickVerify('${safePn}')">×</button>
      </div>
      ${err ? `<div class="ozon-fbs-pick-barcode-err">${esc(err)}</div>` : ""}
    </div>`;
  }

  function onOzonFbsPickBarcodeInput(postingNumber, event) {
    const pn = String(postingNumber || "").trim();
    const row = (ozonFbsPickState.rows || []).find((r) => String(r.posting_number) === pn);
    if (!row || _ozonFbsRowIsCancelled(row)) return;
    const val = String(event?.target?.value || "").trim();
    const prevVerifiedBarcode = row.pick_verified
      ? String(row.pick_barcode || "").trim()
      : "";
    row.pick_barcode = val;
    if (!val) {
      // Draft empty in the input; keep previous verified until blur/×/Save decides.
      // Mark unverified only so counters don't stay green on a blank field.
      row.pick_verified = false;
      if (ozonFbsPickState.errors[pn]) delete ozonFbsPickState.errors[pn];
      return;
    }
    // Typing invalidates previous green state until Enter validates.
    if (prevVerifiedBarcode && val !== prevVerifiedBarcode) {
      row.pick_verified = false;
    }
    if (ozonFbsPickState.errors[pn]) delete ozonFbsPickState.errors[pn];
  }

  function _ozonFbsPickCommitBarcode(postingNumber, rawValue, { fromBlur = false } = {}) {
    const pn = String(postingNumber || "").trim();
    const row = (ozonFbsPickState.rows || []).find((r) => String(r.posting_number) === pn);
    if (!row || _ozonFbsRowIsCancelled(row)) return false;
    const rawTyped = String(rawValue || "").replace(/\s+/g, "").trim();
    if (!rawTyped) {
      // Empty on blur: restore last saved baseline (× clears explicitly).
      if (fromBlur) {
        const base = ozonFbsPickState.baselineByPosting?.[pn] || {};
        const baseBarcode = String(base.pick_barcode || "").trim();
        if (base.pick_verified && baseBarcode) {
          row.pick_verified = true;
          row.pick_barcode = baseBarcode;
          const input = document.querySelector(
            `#ozonFbsPickTbody .ozon-fbs-pick-barcode-input[data-posting="${pn}"]`
          );
          if (input) input.value = baseBarcode;
          if (ozonFbsPickState.errors[pn]) delete ozonFbsPickState.errors[pn];
          return false;
        }
      }
      row.pick_barcode = "";
      row.pick_verified = false;
      if (ozonFbsPickState.errors[pn]) delete ozonFbsPickState.errors[pn];
      return false;
    }
    if (typeof _wbFbsKizHasCyrillic === "function" && _wbFbsKizHasCyrillic(rawTyped)) {
      if (typeof _wbFbsKizBlockRuLayout === "function") {
        const input = document.querySelector(
          `#ozonFbsPickTbody .ozon-fbs-pick-barcode-input[data-posting="${pn}"]`
        );
        _wbFbsKizBlockRuLayout(input);
      }
      return false;
    }
    const check = _ozonFbsPickValidateEanForOrder(_ozonFbsNormalizeScan(rawTyped), row);
    if (!check.ok) {
      ozonFbsPickState.errors[pn] = check.error || "Ошибка проверки ШК";
      row.pick_verified = false;
      row.pick_barcode = rawTyped;
      renderOzonFbsPickVerifyTable();
      _ozonFbsPickSetInfo(check.error || "Ошибка проверки ШК");
      return false;
    }
    row.pick_verified = true;
    row.pick_barcode = check.barcode;
    delete ozonFbsPickState.errors[pn];
    const emptyFilter = document.getElementById("ozonFbsPickFilterEmpty");
    if (emptyFilter) emptyFilter.checked = false;
    renderOzonFbsPickVerifyTable();
    _ozonFbsPickScheduleLocalAutosave(pn, false);
    _ozonFbsPickSyncToneFromRows(ozonFbsPickState.rows);
    _ozonFbsPickSetInfo(`ШК проверен локально для ${pn}`, true);
    if (typeof _ozonFbsContainerMaybeBind === "function") {
      void _ozonFbsContainerMaybeBind("pick", pn);
    }
    return true;
  }

  function onOzonFbsPickBarcodeBlur(postingNumber, event) {
    const pn = String(postingNumber || "").trim();
    const row = (ozonFbsPickState.rows || []).find((r) => String(r.posting_number) === pn);
    if (!row || _ozonFbsRowIsCancelled(row)) return;
    const val = String(event?.target?.value || "").trim();
    if (!val) {
      _ozonFbsPickCommitBarcode(pn, "", { fromBlur: true });
      return;
    }
    if (row.pick_verified && val === String(row.pick_barcode || "").trim()) return;
    _ozonFbsPickCommitBarcode(pn, val, { fromBlur: true });
  }

  function onOzonFbsPickBarcodeKey(postingNumber, event) {
    if (!event || event.key !== "Enter") return;
    event.preventDefault();
    if (typeof _wbFbsKizRuLayoutModalOpen === "function" && _wbFbsKizRuLayoutModalOpen()) return;
    const input = event.target;
    if (input?.disabled || input?.readOnly || !ozonFbsPickState.rowsReady) return;
    _ozonFbsPickCommitBarcode(postingNumber, input?.value || "");
  }

  function _ozonFbsPickRowPickOk(row) {
    return !!row?.pick_verified && !!String(row?.pick_barcode || "").trim();
  }

  function _ozonFbsPickRowContainerOk(row) {
    return !!String(row?.container_barcode || "").trim();
  }

  /** When GM column is active: row is complete only with both pick ШК and GM. */
  function _ozonFbsPickRowIsComplete(row) {
    if (!_ozonFbsPickRowPickOk(row)) return false;
    if (_ozonFbsGmRequiredInFilters("pick") && !_ozonFbsPickRowContainerOk(row)) return false;
    return true;
  }

  function _ozonFbsPickRowHasError(row) {
    const pn = String(row?.posting_number || "");
    if (String(ozonFbsPickState.errors[pn] || "").trim()) return true;
    return !!String(row?.container_sync_error || "").trim();
  }

  function onOzonFbsPickFilterFilledChange() {
    const filled = document.getElementById("ozonFbsPickFilterFilled");
    const empty = document.getElementById("ozonFbsPickFilterEmpty");
    if (filled?.checked && empty) empty.checked = false;
    renderOzonFbsPickVerifyTable();
  }

  function onOzonFbsPickFilterEmptyChange() {
    const filled = document.getElementById("ozonFbsPickFilterFilled");
    const empty = document.getElementById("ozonFbsPickFilterEmpty");
    if (empty?.checked && filled) filled.checked = false;
    renderOzonFbsPickVerifyTable();
  }

  function renderOzonFbsPickVerifyTable() {
    const tbody = document.getElementById("ozonFbsPickTbody");
    if (!tbody) return;
    _ozonFbsPrepareRowMenuRender();
    const q = String(document.getElementById("ozonFbsPickSearchFilter")?.value || "")
      .trim()
      .toLowerCase();
    const showFilled = !!document.getElementById("ozonFbsPickFilterFilled")?.checked;
    const showEmpty = !!document.getElementById("ozonFbsPickFilterEmpty")?.checked;
    const showErrors = !!document.getElementById("ozonFbsPickFilterErrors")?.checked;
    const showCancelled = !!document.getElementById("ozonFbsPickFilterCancelled")?.checked;
    const pending = String(ozonFbsPickState.pendingPosting || "").trim();
    const rows = (ozonFbsPickState.rows || []).filter((r) => {
      const complete = _ozonFbsPickRowIsComplete(r);
      const pn = String(r.posting_number || "");
      const hasErr = _ozonFbsPickRowHasError(r);
      if (showFilled && !complete) return false;
      if (showEmpty && complete) return false;
      if (showErrors && !hasErr) return false;
      if (showCancelled && !_ozonFbsRowIsCancelled(r)) return false;
      return _ozonFbsPickRowMatchesSearch(r, q);
    });
    _ozonFbsPickUpdateFilterCounts();
    if (!rows.length) {
      tbody.innerHTML = `<tr><td colspan="5" class="wb-fbs-empty">${
        ozonFbsPickState.rows?.length ? "Нет строк по фильтру" : "Нет отправлений без маркировки"
      }</td></tr>`;
      _ozonFbsPickUpdateScanCounter();
      if (typeof _ozonFbsContainerUpdateCounters === "function") _ozonFbsContainerUpdateCounters();
      return;
    }
    tbody.innerHTML = rows.map((r) => {
      const pn = String(r.posting_number || "");
      const safePn = esc(pn);
      const photo = r.product_photo
        ? `<img class="wb-fbs-product-photo" src="${esc(r.product_photo)}" alt="" width="56" height="56" loading="lazy">`
        : `<span class="wb-fbs-product-ph" aria-hidden="true"></span>`;
      const barcodes = Array.isArray(r.barcodes) ? r.barcodes : [];
      const barcodeHtml = barcodes.length
        ? `<div class="wb-fbs-kiz-barcodes" title="Штрихкод товара">${barcodes.map((b) =>
            `<div class="wb-fbs-kiz-barcode">${esc(b)}</div>`
          ).join("")}</div>`
        : "";
      return `<tr class="wb-fbs-kiz-row${pending === pn ? " is-active" : ""}${_ozonFbsRowIsCancelled(r) ? " is-cancelled" : ""}" data-posting="${safePn}">
        <td>
          ${_ozonFbsModalPostingColHtml(r)}
        </td>
        <td>
          <div class="wb-fbs-product">
            ${photo}
            <div class="wb-fbs-product-text">
              <div class="wb-fbs-product-name" title="${esc(r.product_name || r.offer_id || "")}">${esc(r.product_name || r.offer_id || "—")}</div>
              <div class="wb-fbs-product-sub">Арт. ${esc(r.offer_id || "—")}</div>
              ${barcodeHtml}
            </div>
          </div>
        </td>
        <td class="wb-fbs-kiz-col-kiz">${_ozonFbsPickStatusHtml(r)}</td>
        <td class="wb-fbs-kiz-col-container">${
          typeof _ozonFbsContainerCellHtml === "function"
            ? _ozonFbsContainerCellHtml(r, "pick")
            : "—"
        }</td>
        <td>
          ${_ozonFbsModalRowActionsHtml(r, "pick")}
        </td>
      </tr>`;
    }).join("");
    tbody.querySelectorAll(".ozon-fbs-pick-barcode-input").forEach((input) => {
      const pn = String(input.dataset.posting || "").trim();
      const row = (ozonFbsPickState.rows || []).find((r) => String(r.posting_number) === pn);
      if (!row) return;
      input.value = String(row.pick_barcode || "");
    });
    _ozonFbsPickUpdateScanCounter();
    if (typeof _ozonFbsContainerUpdateCounters === "function") _ozonFbsContainerUpdateCounters();
  }

  function clearOzonFbsPickVerify(postingNumber) {
    const pn = String(postingNumber || "");
    const row = ozonFbsPickState.rows.find((r) => String(r.posting_number) === pn);
    if (!row || _ozonFbsRowIsCancelled(row)) return;
    row.pick_verified = false;
    row.pick_barcode = "";
    delete ozonFbsPickState.errors[pn];
    renderOzonFbsPickVerifyTable();
    _ozonFbsPickScheduleLocalAutosave(pn, true);
    _ozonFbsPickSyncToneFromRows(ozonFbsPickState.rows);
  }

  function _ozonFbsPickScheduleLocalAutosave(postingNumber, clear) {
    const pn = String(postingNumber || "").trim();
    if (!pn) return;
    if (!ozonFbsPickState.localAutosaveSeqByPosting) ozonFbsPickState.localAutosaveSeqByPosting = {};
    const seq = (Number(ozonFbsPickState.localAutosaveSeqByPosting[pn]) || 0) + 1;
    ozonFbsPickState.localAutosaveSeqByPosting[pn] = seq;
    const run = () => _ozonFbsPickFlushLocalAutosave(pn, seq, !!clear);
    ozonFbsPickState.localAutosaveChain = (ozonFbsPickState.localAutosaveChain || Promise.resolve())
      .then(run, run)
      .catch(() => {});
  }

  async function _ozonFbsPickFlushLocalAutosave(postingNumber, seq, clear) {
    const pn = String(postingNumber || "").trim();
    if ((Number(ozonFbsPickState.localAutosaveSeqByPosting?.[pn]) || 0) !== seq) return;
    const sid = String(supplyDetailState.supplyId || "").trim();
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    if (!sid || !sourceId) return;
    const row = ozonFbsPickState.rows.find((r) => String(r.posting_number) === pn);
    if (!row || _ozonFbsRowIsCancelled(row)) return;
    const verified = !!row.pick_verified && !!String(row.pick_barcode || "").trim();
    let item;
    if (verified) {
      item = {
        posting_number: pn,
        pick_verified: true,
        pick_barcode: row.pick_barcode,
        expected_verified_at: row.pick_verified_at || "",
        force: !!(ozonFbsPickState.forceSaveByPosting && ozonFbsPickState.forceSaveByPosting[pn]),
      };
    } else {
      item = {
        posting_number: pn,
        pick_verified: false,
        pick_barcode: "",
        clear: !!clear,
        expected_verified_at: row.pick_verified_at || "",
        force: !!(ozonFbsPickState.forceSaveByPosting && ozonFbsPickState.forceSaveByPosting[pn]),
      };
    }
    ozonFbsPickState.localAutosaveInflight = (Number(ozonFbsPickState.localAutosaveInflight) || 0) + 1;
    try {
      const res = await fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/pick-verify?source_id=${sourceId}`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json", ...jsonHeaders() },
          body: JSON.stringify({ items: [item] }),
          keepalive: true,
        }
      );
      if ((Number(ozonFbsPickState.localAutosaveSeqByPosting?.[pn]) || 0) !== seq) return;
      const data = await res.json().catch(() => ({}));
      if (!res.ok) return;
      const result = (data.results || []).find((r) => String(r.posting_number) === pn);
      if (!result?.ok) {
        if (result?.conflict) {
          row.pick_verified_at = String(result.pick_verified_at || row.pick_verified_at || "");
          if (!ozonFbsPickState.forceSaveByPosting) ozonFbsPickState.forceSaveByPosting = {};
          ozonFbsPickState.forceSaveByPosting[pn] = true;
        }
        return;
      }
      row.pick_verified = !!result.pick_verified;
      row.pick_barcode = String(result.pick_barcode || "").trim();
      // Always adopt token (incl. clear) for peer/conflict compares.
      if (result.pick_verified_at != null) {
        row.pick_verified_at = String(result.pick_verified_at || "");
      }
      _ozonFbsPickSetBaseline(pn, row.pick_verified, row.pick_barcode);
      if (ozonFbsPickState.forceSaveByPosting) delete ozonFbsPickState.forceSaveByPosting[pn];
      delete ozonFbsPickState.errors[pn];
    } finally {
      ozonFbsPickState.localAutosaveInflight = Math.max(
        0,
        (Number(ozonFbsPickState.localAutosaveInflight) || 1) - 1
      );
    }
  }

  async function processOzonFbsPickStickerScan(raw, inputEl) {
    const input = inputEl || document.getElementById("ozonFbsPickStickerScan");
    if (typeof _wbFbsKizRuLayoutModalOpen === "function" && _wbFbsKizRuLayoutModalOpen()) return;
    if (typeof _fbsScanAckModalOpen === "function" && _fbsScanAckModalOpen()) return;
    if (typeof _fbsStickerNotFoundModalOpen === "function" && _fbsStickerNotFoundModalOpen()) return;

    if (input?.disabled || input?.readOnly || !ozonFbsPickState.rowsReady) return;
    const rawTyped = String(raw ?? input?.value ?? "").replace(/\s+/g, "").trim();
    if (!rawTyped) return;
    if (typeof _wbFbsKizHasCyrillic === "function" && _wbFbsKizHasCyrillic(rawTyped)) {
      if (typeof _wbFbsKizBlockRuLayout === "function") _wbFbsKizBlockRuLayout(input);
      return;
    }
    if (typeof _ozonFbsContainerIsScanMode === "function" && _ozonFbsContainerIsScanMode("pick")) {
      await _ozonFbsContainerHandleScan("pick", rawTyped);
      return;
    }
    if (
      typeof _ozonFbsContainerGuardOrderScanRequiresActiveGm === "function"
      && !_ozonFbsContainerGuardOrderScanRequiresActiveGm("pick", input)
    ) {
      return;
    }
    const scan = _ozonFbsNormalizeScan(rawTyped);
    if (!scan) return;
    const found = await _ozonFbsPickFindByStickerWithLookup(scan);
    if (found.ambiguous) {
      const ids = (found.matches || []).map((r) => r.posting_number).slice(0, 5).join(", ");
      const msg =
        `Код стикера совпадает у нескольких отправлений (${ids}${
          (found.matches || []).length > 5 ? "…" : ""
        }). Отсканируйте QR ещё раз.`;
      _ozonFbsPickSetInfo(msg);
      if (typeof showFbsScanAck === "function") showFbsScanAck(msg, input);
      if (input) input.select();
      return;
    }
    if (!found.row) {
      const msg =
        `Отправление «${scan}» не найдено среди товаров без маркировки. Возможно, это товар с КИЗ.`;
      _ozonFbsPickSetInfo(msg);
      if (typeof showFbsStickerNotFound === "function") showFbsStickerNotFound(msg, input);
      if (input) input.select();
      return;
    }
    ozonFbsPickState.pendingPosting = String(found.row.posting_number || "");
    _ozonFbsPersistStickerForRow(found.row, scan);
    _ozonFbsPickSetInfo("");
    if (input) input.value = "";
    const meta = document.getElementById("ozonFbsPickScanPromptMeta");
    if (meta) meta.textContent = `Отправление ${ozonFbsPickState.pendingPosting}`;
    if (typeof setModalVisibility === "function") setModalVisibility("ozonFbsPickScanPrompt", true);
    else document.getElementById("ozonFbsPickScanPrompt")?.classList.remove("hidden");
    const sku = document.getElementById("ozonFbsPickSkuScan");
    if (sku) {
      sku.value = "";
      setTimeout(() => sku.focus(), 40);
    }
  
  }

  async function onOzonFbsPickStickerScanKey(event) {
    if (!event || event.key !== "Enter") return;
    event.preventDefault();
    await processOzonFbsPickStickerScan(event.target?.value || "", event.target);
  }

  function cancelOzonFbsPickSkuScan() {
    if (typeof setModalVisibility === "function") setModalVisibility("ozonFbsPickScanPrompt", false);
    else document.getElementById("ozonFbsPickScanPrompt")?.classList.add("hidden");
    ozonFbsPickState.pendingPosting = null;
    const sticker = document.getElementById("ozonFbsPickStickerScan");
    if (sticker) setTimeout(() => sticker.focus(), 40);
  }

  function processOzonFbsPickSkuScan(raw, inputEl) {
    if (typeof _wbFbsKizRuLayoutModalOpen === "function" && _wbFbsKizRuLayoutModalOpen()) return;
    if (typeof _fbsScanAckModalOpen === "function" && _fbsScanAckModalOpen()) return;
    if (typeof _fbsStickerNotFoundModalOpen === "function" && _fbsStickerNotFoundModalOpen()) return;
    const pn = String(ozonFbsPickState.pendingPosting || "");
    const input = inputEl || document.getElementById("ozonFbsPickSkuScan");
    const rawTyped = String(raw ?? input?.value ?? "");
    if (!pn || !String(rawTyped || "").replace(/\s+/g, "")) return;
    if (typeof _wbFbsKizHasCyrillic === "function" && _wbFbsKizHasCyrillic(rawTyped)) {
      if (typeof _wbFbsKizBlockRuLayout === "function") _wbFbsKizBlockRuLayout(input);
      return;
    }
    const scan = _ozonFbsNormalizeScan(rawTyped);
    if (!scan) return;
    const row = ozonFbsPickState.rows.find((r) => String(r.posting_number) === pn);
    if (!row) {
      cancelOzonFbsPickSkuScan();
      return;
    }
    const check = _ozonFbsPickValidateEanForOrder(scan, row);
    if (!check.ok) {
      const msg = check.error || "Ошибка проверки ШК";
      ozonFbsPickState.errors[pn] = msg;
      // Prompt closes — refocus sticker after «Хорошо», not the hidden SKU field.
      const sticker = document.getElementById("ozonFbsPickStickerScan");
      cancelOzonFbsPickSkuScan();
      renderOzonFbsPickVerifyTable();
      _ozonFbsPickSetInfo(msg);
      if (typeof showFbsScanAck === "function") showFbsScanAck(msg, sticker || input);
      return;
    }
    row.pick_verified = true;
    row.pick_barcode = check.barcode;
    delete ozonFbsPickState.errors[pn];
    const emptyFilter = document.getElementById("ozonFbsPickFilterEmpty");
    if (emptyFilter) emptyFilter.checked = false;
    cancelOzonFbsPickSkuScan();
    renderOzonFbsPickVerifyTable();
    _ozonFbsPickScheduleLocalAutosave(pn, false);
    _ozonFbsPickSyncToneFromRows(ozonFbsPickState.rows);
    _ozonFbsPickSetInfo(`ШК проверен локально для ${pn}`, true);
    if (typeof _ozonFbsContainerMaybeBind === "function") {
      void _ozonFbsContainerMaybeBind("pick", pn);
    }
    const rowEl = document.querySelector(`#ozonFbsPickTbody tr[data-posting="${pn}"]`);
    // Instant jump — same as Ozon/WB KIZ and WB pick after scan.
    if (rowEl) rowEl.scrollIntoView({ block: "nearest" });
  
  }

  function onOzonFbsPickSkuScanKey(event) {
    if (!event || event.key !== "Enter") return;
    event.preventDefault();
    processOzonFbsPickSkuScan(event.target?.value || "", event.target);
  }

  async function refreshOzonFbsPickVerifyStatus(event, opts) {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    const silent = !!(opts && opts.silent);
    const sid = String(supplyDetailState.supplyId || "").trim();
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    if (!sid || !sourceId || !_ozonFbsSupplyActionsReady()) return;
    if (ozonFbsPickState.statusRefreshing) {
      ozonFbsPickState.statusRefreshQueued = true;
      return;
    }
    const refreshBtn = document.getElementById("ozonFbsSupplyDetailPickRefreshBtn");
    const refreshGen = (Number(ozonFbsPickState.statusRefreshGen) || 0) + 1;
    ozonFbsPickState.statusRefreshGen = refreshGen;
    ozonFbsPickState.statusRefreshing = true;
    ozonFbsPickState.statusRefreshQueued = false;
    if (!silent && refreshBtn) {
      refreshBtn.disabled = true;
      refreshBtn.classList.add("is-spinning");
    }
    try {
      const params = new URLSearchParams({ source_id: String(sourceId) });
      _ozonFbsAppendPostingTab(params);
      const res = await fetch(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/pick-verify/status?${params}`
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok || data.ok === false) {
        throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      }
      if (supplyDetailState.supplyId !== sid) return;
      if (ozonFbsPickState.statusRefreshGen !== refreshGen) return;
      _ozonFbsStatusCooldownTouch("pick");
      const st = String(data.status || "");
      if (Array.isArray(data.orders)) {
        _ozonFbsPickSyncToneFromRows(data.orders);
        // Multi-op: adopt peer ШК checks into the open pick modal (scan counter).
        _ozonFbsPickMergeRemoteIntoOpenModal(data.orders);
      }
      if (st === "error") {
        const tip = typeof _ozonFbsContainerErrorsTooltip === "function"
          ? _ozonFbsContainerErrorsTooltip(data.container_errors || [])
          : "Ошибка привязки к грузоместу";
        const split = document.getElementById("ozonFbsPickSplit");
        if (split) split.dataset.containerErrorTip = tip || "Ошибка привязки к грузоместу";
        _ozonFbsPickSplitSetTone("error");
      } else if (Array.isArray(data.orders)) {
        // _ozonFbsPickSyncToneFromRows already applied GM-aware tone.
      } else {
        _ozonFbsPickSplitSetTone(_ozonFbsPickToneFromSupply(supplyDetailState.supply));
      }
      if (Number.isFinite(Number(data.done)) || Number.isFinite(Number(data.required))) {
        _ozonFbsSyncKizPickBtnLabels({
          pick: {
            done: Math.max(0, Number(data.done) || 0),
            total: Math.max(0, Number(data.required) || 0),
          },
        });
      } else {
        _ozonFbsSyncKizPickBtnLabels();
      }
    } catch (e) {
      if (
        !silent
        && supplyDetailState.supplyId === sid
        && ozonFbsPickState.statusRefreshGen === refreshGen
      ) {
        const info = document.getElementById("ozonFbsSupplyDetailInfo");
        if (info) {
          info.hidden = false;
          info.textContent = String(e.message || e);
        }
      }
    } finally {
      if (ozonFbsPickState.statusRefreshGen === refreshGen) {
        ozonFbsPickState.statusRefreshing = false;
        if (refreshBtn) {
          refreshBtn.disabled = false;
          refreshBtn.classList.remove("is-spinning");
        }
        if (ozonFbsPickState.statusRefreshQueued) {
          ozonFbsPickState.statusRefreshQueued = false;
          void refreshOzonFbsPickVerifyStatus(null, { silent: true });
        }
      }
    }
  }

  async function openOzonFbsPickVerifyModal() {
    if (isSupplyDetailReadOnly() && !_ozonFbsCanOpenKizPickWhileReadOnly()) return;
    const sid = String(supplyDetailState.supplyId || "").trim();
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    if (!sid || !sourceId || !_ozonFbsSupplyActionsReady()) return;
    if (typeof setModalVisibility === "function") setModalVisibility("ozonFbsPickVerifyModal", true);
    else document.getElementById("ozonFbsPickVerifyModal")?.classList.remove("hidden");
    ozonFbsPickColResizer.init();
    const loadGen = (ozonFbsPickState.loadGen = Number(ozonFbsPickState.loadGen || 0) + 1);
    ozonFbsPickState.rows = [];
    ozonFbsPickState.errors = {};
    ozonFbsPickState.pendingPosting = null;
    ozonFbsPickState.baselineByPosting = {};
    ozonFbsPickState.forceSaveByPosting = {};
    _ozonFbsPickSetFiltersReady(false);
    _ozonFbsPickSetInfo("");
    const tbody = document.getElementById("ozonFbsPickTbody");
    if (tbody) tbody.innerHTML = `<tr><td colspan="5" class="wb-fbs-empty">Загрузка…</td></tr>`;
    const saveBtn = document.getElementById("ozonFbsPickVerifySaveBtn");
    if (saveBtn) saveBtn.disabled = true;
    const scan = document.getElementById("ozonFbsPickStickerScan");
    if (scan) scan.value = "";
    let loadOk = false;
    let applied = false;
    const stillThisLoad = () =>
      Number(ozonFbsPickState.loadGen) === loadGen && _ozonFbsPickModalIsOpen();
    try {
      const params = new URLSearchParams({ source_id: String(sourceId) });
      _ozonFbsAppendPostingTab(params);
      await _ozonFbsFetchResolvedChunks(
        `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/pick-verify?${params}`,
        {
          shouldAbort: () => !stillThisLoad(),
          onProgress: (p) => {
            if (!stillThisLoad()) return;
            const msg = _ozonFbsResolveProgressText(p);
            if (!msg) return;
            if (tbody && !applied) {
              tbody.innerHTML = `<tr><td colspan="5" class="wb-fbs-empty">${esc(msg)}</td></tr>`;
            }
            _ozonFbsPickSetInfo(msg, true);
          },
          onChunk: (data, meta) => {
            if (!stillThisLoad()) return;
            const resolving = !meta?.done && Number(meta?.remaining || 0) > 0;
            const resolveMsg = resolving ? _ozonFbsResolveProgressText(meta) : "";
            if (!applied) {
              _ozonFbsPickApplyLoadedPayload(data, {
                unlockScan: false,
                resolveMsg,
              });
              applied = true;
              loadOk = true;
              return;
            }
            const prevKeys = new Set(
              (ozonFbsPickState.rows || [])
                .map((r) => String(r?.posting_number || "").trim())
                .filter(Boolean)
            );
            const nextKeys = new Set(
              (Array.isArray(data?.rows) ? data.rows : [])
                .map((r) => String(r?.posting_number || "").trim())
                .filter(Boolean)
            );
            let rowsChanged = prevKeys.size !== nextKeys.size;
            if (!rowsChanged) {
              for (const k of nextKeys) {
                if (!prevKeys.has(k)) {
                  rowsChanged = true;
                  break;
                }
              }
            }
            if (rowsChanged || meta?.done) {
              _ozonFbsPickApplyLoadedPayload(data, {
                unlockScan: false,
                resolveMsg,
              });
              return;
            }
            _ozonFbsKizMergeOrderFlagsIntoDetail(data?.order_kiz_flags || []);
            if (supplyDetailState.supply) {
              renderSupplyDetail();
              _ozonFbsKizSplitSetTone(_ozonFbsKizToneFromSupply(supplyDetailState.supply));
            }
            if (resolveMsg) _ozonFbsPickSetInfo(resolveMsg, true);
            else if (ozonFbsPickState.rows.length) _ozonFbsPickSetInfo("");
          },
        }
      );
      if (!stillThisLoad()) return;
      if (!applied) {
        _ozonFbsPickApplyLoadedPayload({}, { unlockScan: false });
      } else if (!ozonFbsPickState.rows.length) {
        _ozonFbsPickSetInfo("В поставке нет отправлений без маркировки", true);
      } else {
        _ozonFbsPickSetInfo("");
      }
    } catch (e) {
      if (!stillThisLoad()) return;
      if (tbody && !applied) {
        tbody.innerHTML = `<tr><td colspan="3" class="wb-fbs-empty" style="color:#b91c1c">${esc(e.message)}</td></tr>`;
      }
      _ozonFbsPickSetInfo(String(e.message || e));
    } finally {
      if (!stillThisLoad()) return;
      if (saveBtn) saveBtn.disabled = false;
      _ozonFbsPickSetFiltersReady(true);
      if (typeof _ozonFbsContainerPrepareModal === "function") {
        await _ozonFbsContainerPrepareModal("pick");
      }
      _ozonFbsPickStartModalStatusPoll();
      void _ozonFbsScanComOnModalOpened();
      if (loadOk && scan) setTimeout(() => {
        if (stillThisLoad()) scan.focus();
      }, 50);
    }
  }

  function closeOzonFbsPickVerifyModal() {
    _ozonFbsPickStopModalStatusPoll();
    _ozonFbsPickSyncToneFromRows(ozonFbsPickState.rows);
    ozonFbsPickState.loadGen = Number(ozonFbsPickState.loadGen || 0) + 1;
    if (typeof window._ozonFbsContainerClearOnModalClose === "function") {
      window._ozonFbsContainerClearOnModalClose();
    }
    _ozonFbsClearRuLayoutGuard();
    if (typeof setModalVisibility === "function") setModalVisibility("ozonFbsPickVerifyModal", false);
    else document.getElementById("ozonFbsPickVerifyModal")?.classList.add("hidden");
    cancelOzonFbsPickSkuScan();
    void _ozonFbsScanComOnModalClosed();
    ozonFbsPickState.rows = [];
    _ozonFbsPickSetInfo("");
    // Skip if save/open just refreshed (avoid double network on close).
    if (_ozonFbsStatusCooldownOk("pick")) {
      void refreshOzonFbsPickVerifyStatus(null, { silent: true });
    }
  }

  async function saveOzonFbsPickVerifyModal() {
    const sid = String(supplyDetailState.supplyId || "").trim();
    const sourceId = supplyDetailState.sourceId || state.sourceId;
    if (!sid || !sourceId || ozonFbsPickState.saving) return;
    const saveBtn = document.getElementById("ozonFbsPickVerifySaveBtn");
    ozonFbsPickState.saving = true;
    if (saveBtn) saveBtn.disabled = true;
    _ozonFbsPickSetInfo("Сохранение…");
    try {
      await ozonFbsPickState.localAutosaveChain;
      // Commit typed ШК грузоместа before pick save (bind is a separate API).
      if (typeof window._ozonFbsContainerFlushPendingCells === "function") {
        await window._ozonFbsContainerFlushPendingCells("pick");
      }
      _ozonFbsPickCollectFromDom();
      const items = [];
      for (const r of ozonFbsPickState.rows || []) {
        if (_ozonFbsRowIsCancelled(r)) continue;
        const pn = String(r.posting_number || "").trim();
        if (!pn) continue;
        const barcode = String(r.pick_barcode || "").trim();
        const verified = !!r.pick_verified && !!barcode;
        const base = ozonFbsPickState.baselineByPosting?.[pn] || {};
        const baseVerified = !!base.pick_verified && !!String(base.pick_barcode || "").trim();
        const force = !!(ozonFbsPickState.forceSaveByPosting && ozonFbsPickState.forceSaveByPosting[pn]);
        if (!force && _ozonFbsPickBaselineEquals(pn, verified, barcode)) continue;
        if (verified) {
          const check = _ozonFbsPickValidateEanForOrder(barcode, r);
          if (!check.ok) {
            ozonFbsPickState.errors[pn] = check.error || "ШК не прошёл сверку";
            continue;
          }
          items.push({
            posting_number: pn,
            pick_verified: true,
            pick_barcode: check.barcode,
            expected_verified_at: r.pick_verified_at || "",
            force,
          });
        } else if (baseVerified || force) {
          items.push({
            posting_number: pn,
            pick_verified: false,
            pick_barcode: "",
            clear: true,
            expected_verified_at: r.pick_verified_at || "",
            force,
          });
        } else if (barcode) {
          // Typed but not validated — do not send as verified.
          ozonFbsPickState.errors[pn] = "Нажмите Enter, чтобы проверить ШК";
        }
      }
      if (Object.keys(ozonFbsPickState.errors || {}).length) {
        renderOzonFbsPickVerifyTable();
      }
      if (!items.length) {
        const hasErr = Object.keys(ozonFbsPickState.errors || {}).length > 0;
        _ozonFbsPickSetInfo(
          hasErr ? "Исправьте ошибки сверки ШК перед сохранением" : "Нет изменений для сохранения",
          !hasErr
        );
        return;
      }
      // Chunk like Marking save — one huge PUT can hit nginx/proxy 504.
      const CHUNK = 40;
      const allResults = [];
      let savedTotal = 0;
      for (let i = 0; i < items.length; i += CHUNK) {
        const chunk = items.slice(i, i + CHUNK);
        if (items.length > CHUNK) {
          _ozonFbsPickSetInfo(
            `Сохранение… ${Math.min(i + CHUNK, items.length)}/${items.length}`
          );
        }
        const res = await fetch(
          `/api/ozon-fbs/supplies/${encodeURIComponent(sid)}/pick-verify?source_id=${sourceId}`,
          {
            method: "PUT",
            headers: { "Content-Type": "application/json", ...jsonHeaders() },
            body: JSON.stringify({ items: chunk }),
          }
        );
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
        allResults.push(...(data.results || []));
        savedTotal += Number(data.saved) || 0;
      }
      let errN = 0;
      for (const result of allResults) {
        const pn = String(result?.posting_number || "").trim();
        if (!pn) continue;
        const row = (ozonFbsPickState.rows || []).find((r) => String(r.posting_number) === pn);
        if (result.conflict) {
          errN += 1;
          if (row) {
            row.pick_verified_at = String(result.pick_verified_at || row.pick_verified_at || "");
          }
          if (!ozonFbsPickState.forceSaveByPosting) ozonFbsPickState.forceSaveByPosting = {};
          ozonFbsPickState.forceSaveByPosting[pn] = true;
          ozonFbsPickState.errors[pn] = result.error
            || "Отправление уже сохранено другим оператором — проверьте ШК и сохраните снова";
          continue;
        }
        if (!result.ok) {
          errN += 1;
          ozonFbsPickState.errors[pn] = result.error || "ошибка";
          continue;
        }
        if (row) {
          row.pick_verified = !!result.pick_verified;
          row.pick_barcode = String(result.pick_barcode || "").trim();
          // Always adopt token (incl. clear) for peer/conflict compares.
          if (result.pick_verified_at != null) {
            row.pick_verified_at = String(result.pick_verified_at || "");
          }
        }
        _ozonFbsPickSetBaseline(
          pn,
          !!result.pick_verified,
          String(result.pick_barcode || "")
        );
        if (ozonFbsPickState.forceSaveByPosting) delete ozonFbsPickState.forceSaveByPosting[pn];
        delete ozonFbsPickState.errors[pn];
      }
      renderOzonFbsPickVerifyTable();
      _ozonFbsPickSyncToneFromRows(ozonFbsPickState.rows);
      // Same status rules as «Обновить» (incl. container errors) — not only local rows.
      void refreshOzonFbsPickVerifyStatus(null, { silent: true });
      if (errN) {
        const parts = [];
        if (savedTotal) parts.push(`сохранено ${savedTotal}`);
        parts.push(`ошибок ${errN}`);
        _ozonFbsPickSetInfo(`Сохранено частично (${parts.join(", ")}).`);
      } else {
        _ozonFbsPickSetInfo(
          savedTotal ? `Сохранено локально: ${savedTotal} отправлений` : "Готово",
          true
        );
      }
    } catch (e) {
      _ozonFbsPickSetInfo(String(e.message || e));
    } finally {
      ozonFbsPickState.saving = false;
      if (saveBtn) saveBtn.disabled = false;
    }
  }

  window.initOzonFbsSection = initSection;
  window.setOzonFbsTab = setTab;
  window.onOzonFbsSourceChange = onSourceChange;
  window.onOzonFbsSearchInput = onSearchInput;
  window.ozonFbsChangePage = changePage;
  window.changeOzonFbsPageSize = changePageSize;
  window.syncOzonFbs = syncOzonFbs;
  window.stopOzonFbsSync = stopOzonFbsSync;
  window.openOzonFbsSyncSettings = openOzonFbsSyncSettings;
  window.closeOzonFbsSyncSettings = closeOzonFbsSyncSettings;
  window.saveOzonFbsSyncSettings = saveOzonFbsSyncSettings;
  window.startOzonFbsDeliveringStatusCheck = startOzonFbsDeliveringStatusCheck;
  window.stopOzonFbsDeliveringStatusCheck = stopOzonFbsDeliveringStatusCheck;
  window.closeOzonFbsStatusCheckProgress = closeOzonFbsStatusCheckProgress;
  window.closeOzonFbsSyncInfo = closeSyncInfo;
  window.openOzonFbsDetail = openDetail;
  window.closeOzonFbsDetailModal = closeDetailModal;
  window.ozonFbsShipCurrent = shipCurrent;
  window.ozonFbsShipAll = shipAll;
  window.ozonFbsSplitMulti = splitMulti;
  window.ozonFbsCloseSplitResultModal = closeSplitResultModal;
  window.ozonFbsPrintCurrentSticker = printCurrentSticker;
  window.onOzonFbsCheckboxChange = onCheckboxChange;
  window.toggleSelectAllOzonFbs = toggleSelectAll;
  window.clearOzonFbsSelection = clearSelection;
  window.openOzonFbsNewSupplyFromSelection = openNewSupplyFromSelection;
  window.openOzonFbsAddToExistingSupply = openAddToExistingSupply;
  window.confirmOzonFbsSelectionSupply = confirmSelectionSupply;
  window.closeOzonFbsSelectionSupplyModal = closeSelectionSupplyModal;
  window.ozonFbsSelectionSupplyNameInput = selectionSupplyNameInput;

  function _ozonFbsStickerLookupSetInfo(text, ok) {
    const el = document.getElementById("ozonFbsStickerLookupInfo");
    if (!el) return;
    el.textContent = String(text || "");
    el.classList.remove("is-ok", "is-error");
    if (text && ok) el.classList.add("is-ok");
    if (text && !ok) el.classList.add("is-error");
  }

  function _ozonFbsRenderStickerLookupResult(posting) {
    const box = document.getElementById("ozonFbsStickerLookupResult");
    if (!box) return;
    if (!posting) {
      box.hidden = true;
      box.innerHTML = "";
      return;
    }
    const pn = String(posting.posting_number || "");
    const details = {
      posting_number: pn,
      product_name: posting.product_name || posting.offer_id || "—",
      offer_id: posting.offer_id || "",
      order_number: posting.order_number || posting.order_id || "",
      tab_label: OZON_FBS_TAB_LABELS[String(posting.tab || "").trim()]
        || posting.tab
        || "",
      status_label: posting.status_label || posting.status || "",
      supply_id: posting.supply_id || "",
      sticker_barcode: posting.sticker_barcode || "",
      sticker_scanit: posting.sticker_scanit || "",
      kiz_codes: Array.isArray(posting.kiz_codes) ? posting.kiz_codes : [],
      pick_verified: !!posting.pick_verified,
      pick_barcode: posting.pick_barcode || "",
      container_label: posting.container_label || "",
      container_status_label: posting.container_status_label || "",
      container_warehouse_date: posting.container_warehouse_date || "",
      container_sc_accepted: !!posting.container_sc_accepted,
      in_process_at: posting.in_process_at || "",
      shipment_date: posting.shipment_date || "",
      delivering_date: posting.delivering_date || "",
    };
    const rows = _ozonFbsLookupDetailRows(details)
      .map(
        ([k, v]) =>
          `<div class="ozon-fbs-lookup-k">${esc(k)}</div><div class="ozon-fbs-lookup-v">${esc(v)}</div>`
      )
      .join("");
    box.hidden = false;
    box.innerHTML = `
      <div class="wb-fbs-product" style="margin-bottom:12px">
        <div class="wb-fbs-product-text">
          <div class="wb-fbs-kiz-order-id">${formatOzonPostingNumberHtml(pn)}</div>
          <div class="wb-fbs-product-name">${esc(details.product_name)}</div>
          <div class="wb-fbs-product-sub">Арт. ${esc(details.offer_id || "—")} · заказ ${esc(details.order_number || "—")}</div>
        </div>
      </div>
      <div class="ozon-fbs-lookup-detail-grid">${rows}</div>
    `;
  }

  async function runOzonFbsStickerLookup(scanRaw) {
    const sourceId = state.sourceId;
    const raw = _ozonFbsNormalizeScan(scanRaw);
    if (!sourceId || !raw) return;
    _ozonFbsStickerLookupSetInfo("Поиск…");
    _ozonFbsRenderStickerLookupResult(null);
    try {
      const params = new URLSearchParams({ source_id: String(sourceId), scan: raw });
      const res = await fetch(`/api/ozon-fbs/postings/lookup?${params}`);
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      if (data.ambiguous) {
        const cnt = Array.isArray(data.matches) ? data.matches.length : 0;
        _ozonFbsStickerLookupSetInfo(
          `Найдено несколько отправлений (${cnt}). Уточните скан.`,
          false
        );
        return;
      }
      if (!data.found || !data.posting) {
        _ozonFbsStickerLookupSetInfo(`Отправление не найдено: «${raw}»`, false);
        return;
      }
      _ozonFbsRenderStickerLookupResult(data.posting);
      _ozonFbsStickerLookupSetInfo("Найдено", true);
    } catch (e) {
      _ozonFbsStickerLookupSetInfo(String(e.message || e), false);
    }
  }

  function onOzonFbsStickerLookupScanKey(event) {
    if (!event || event.key !== "Enter") return;
    event.preventDefault();
    const raw = String(event.target?.value || "").trim();
    if (!raw) return;
    runOzonFbsStickerLookup(raw);
    if (event.target) event.target.select();
  }

  function openOzonFbsStickerLookupModal() {
    openOzonFbsFinesModal();
  }

  function closeOzonFbsStickerLookupModal() {
    closeOzonFbsFinesModal();
  }

  const finesState = {
    status: "open",
    loading: false,
    syncing: false,
    importing: false,
    units: [],
    summary: null,
    _pollTimer: null,
  };

  function _ozonFbsFinesIso(daysAgo) {
    const d = new Date();
    d.setHours(12, 0, 0, 0);
    d.setDate(d.getDate() - (daysAgo || 0));
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }

  function _ozonFbsFinesEsc(s) {
    return String(s || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function _ozonFbsFinesMoney(v) {
    const n = Number(v);
    if (!Number.isFinite(n)) return String(v || "—");
    return n.toLocaleString("ru-RU", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  function _ozonFbsFinesStatusLabel(st) {
    if (st === "closed") return "Сторно";
    if (st === "over") return "Перекос";
    return "Открыт";
  }

  function renderOzonFbsFinesList() {
    const list = document.getElementById("ozonFbsFinesList");
    const summaryEl = document.getElementById("ozonFbsFinesSummary");
    if (summaryEl) {
      const s = finesState.summary || {};
      summaryEl.textContent =
        `Открытых: ${s.open_count || 0} · остаток ${ _ozonFbsFinesMoney(s.open_remainder || 0) } ₽` +
        ` · сторно: ${s.closed_count || 0}`;
    }
    if (!list) return;
    const units = Array.isArray(finesState.units) ? finesState.units : [];
    if (finesState.loading) {
      list.innerHTML = `<div class="ozon-fbs-fines-empty">Загрузка…</div>`;
      return;
    }
    if (!units.length) {
      list.innerHTML = `<div class="ozon-fbs-fines-empty">Нет списаний по выбранному фильтру. Синхронизируйте период.</div>`;
      return;
    }
    list.innerHTML = units.map((u) => {
      const st = String(u.status || "open");
      const cls = st === "closed" ? " is-closed" : st === "over" ? " is-over" : " is-open";
      const unitRaw = String(u.unit_number || "");
      const unit = _ozonFbsFinesEsc(unitRaw);
      return (
        `<button type="button" class="ozon-fbs-fines-row${cls}" role="listitem" ` +
        `data-unit="${unit}">` +
        `<div class="ozon-fbs-fines-row-main">` +
        `<span class="ozon-fbs-fines-unit">${unit}</span>` +
        `<span class="ozon-fbs-fines-badge">${_ozonFbsFinesEsc(_ozonFbsFinesStatusLabel(st))}</span>` +
        `</div>` +
        `<div class="ozon-fbs-fines-row-meta">` +
        `<span>Штраф ${_ozonFbsFinesMoney(u.fine_sum)} ₽</span>` +
        `<span>Сторно ${_ozonFbsFinesMoney(u.storno_sum)} ₽</span>` +
        `<span>Остаток ${_ozonFbsFinesMoney(u.net_sum)} ₽</span>` +
        `<span>${_ozonFbsFinesEsc(u.first_fine_date || "—")}` +
        `${u.last_storno_date ? " → " + _ozonFbsFinesEsc(u.last_storno_date) : ""}</span>` +
        `</div>` +
        `</button>`
      );
    }).join("");
    list.querySelectorAll(".ozon-fbs-fines-row[data-unit]").forEach((btn) => {
      btn.addEventListener("click", () => {
        openOzonFbsFinesUnitEvents(btn.getAttribute("data-unit") || "");
      });
    });
  }

  function renderOzonFbsFinesSyncLog(items) {
    const el = document.getElementById("ozonFbsFinesSyncLog");
    if (!el) return;
    const rows = Array.isArray(items) ? items : [];
    if (!rows.length) {
      el.innerHTML = `<div class="ozon-fbs-fines-empty">Лог пуст</div>`;
      return;
    }
    el.innerHTML = rows.map((item) => {
      const level = String(item.level || "info");
      const dlId = item.attachment_id || 0;
      const dlUrl = String(item.download_url || "").trim();
      const dl = (dlId && dlUrl)
        ? `<a class="ozon-fbs-fines-log-dl" href="${_ozonFbsFinesEsc(dlUrl)}" download>Excel</a>`
        : "";
      return (
        `<div class="ozon-fbs-fines-log-row is-${_ozonFbsFinesEsc(level)}">` +
        `<span class="ozon-fbs-fines-log-time">${_ozonFbsFinesEsc(String(item.created_at || "").slice(11, 19))}</span>` +
        `<span class="ozon-fbs-fines-log-msg">${_ozonFbsFinesEsc(item.message)}</span>` +
        dl +
        `</div>`
      );
    }).join("");
    el.scrollTop = el.scrollHeight;
  }

  async function loadOzonFbsFinesSyncLog() {
    try {
      const res = await fetch("/api/ozon-fbs/fines/sync-log?limit=120", { headers: jsonHeaders() });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      renderOzonFbsFinesSyncLog(data.items || []);
    } catch (_) {
      /* keep previous log */
    }
  }

  async function loadOzonFbsFinesUnits() {
    finesState.loading = true;
    renderOzonFbsFinesList();
    try {
      const params = new URLSearchParams({
        status: finesState.status || "open",
        limit: "500",
      });
      const res = await fetch(`/api/ozon-fbs/fines/units?${params}`, { headers: jsonHeaders() });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      finesState.units = Array.isArray(data.units) ? data.units : [];
      finesState.summary = data.summary || null;
    } catch (e) {
      finesState.units = [];
      finesState.summary = null;
      const list = document.getElementById("ozonFbsFinesList");
      if (list) {
        list.innerHTML = `<div class="ozon-fbs-fines-empty is-error">${_ozonFbsFinesEsc(e.message || e)}</div>`;
      }
      finesState.loading = false;
      return;
    }
    finesState.loading = false;
    renderOzonFbsFinesList();
  }

  function setOzonFbsFinesStatusFilter(status) {
    const next = String(status || "open");
    finesState.status = next;
    document.querySelectorAll(".ozon-fbs-fines-filter").forEach((btn) => {
      btn.classList.toggle("is-active", btn.getAttribute("data-fines-status") === next);
    });
    closeOzonFbsFinesFilterMenu();
    loadOzonFbsFinesUnits().catch(() => {});
  }

  function closeOzonFbsFinesFilterMenu() {
    const menu = document.getElementById("ozonFbsFinesFilterMenu");
    const btn = document.getElementById("ozonFbsFinesFilterBtn");
    if (menu) menu.classList.add("hidden");
    if (btn) {
      btn.classList.remove("is-open");
      btn.setAttribute("aria-expanded", "false");
    }
  }

  function toggleOzonFbsFinesFilterMenu(ev) {
    if (ev && typeof ev.stopPropagation === "function") ev.stopPropagation();
    const menu = document.getElementById("ozonFbsFinesFilterMenu");
    const btn = document.getElementById("ozonFbsFinesFilterBtn");
    if (!menu || !btn) return;
    const open = menu.classList.contains("hidden");
    if (open) {
      menu.classList.remove("hidden");
      btn.classList.add("is-open");
      btn.setAttribute("aria-expanded", "true");
    } else {
      closeOzonFbsFinesFilterMenu();
    }
  }

  function triggerOzonFbsFinesImport() {
    if (typeof isTenantOwner === "function" && !isTenantOwner()) {
      alert("Штрафы доступны только главному пользователю");
      return;
    }
    if (finesState.syncing || finesState.importing) return;
    document.getElementById("ozonFbsFinesImportFile")?.click();
  }

  function _ozonFbsFinesSetImportBusy(busy) {
    const syncBtn = document.getElementById("ozonFbsFinesSyncBtn");
    const importBtn = document.getElementById("ozonFbsFinesImportBtn");
    const stornoBtn = document.getElementById("ozonFbsFinesStornoImportBtn");
    if (syncBtn) syncBtn.disabled = !!busy;
    if (importBtn) importBtn.disabled = !!busy;
    if (stornoBtn) stornoBtn.disabled = !!busy;
  }

  async function onOzonFbsFinesImportFileChange(ev) {
    const input = ev?.target || document.getElementById("ozonFbsFinesImportFile");
    const file = input?.files && input.files[0];
    if (!file) return;
    finesState.importing = true;
    _ozonFbsFinesSetImportBusy(true);
    try {
      const fd = new FormData();
      fd.append("file", file, file.name);
      const headers = typeof withCsrfHeaders === "function" ? withCsrfHeaders() : {};
      const res = await fetch("/api/ozon-fbs/fines/import", {
        method: "POST",
        headers,
        body: fd,
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      await loadOzonFbsFinesSyncLog();
      await loadOzonFbsFinesUnits();
      if (data.summary) {
        /* keep quiet if only skipped; still refresh list */
      }
    } catch (e) {
      await loadOzonFbsFinesSyncLog();
      alert(String(e.message || e));
    } finally {
      finesState.importing = false;
      _ozonFbsFinesSetImportBusy(false);
      if (input) input.value = "";
    }
  }

  function triggerOzonFbsFinesStornoImport() {
    if (typeof isTenantOwner === "function" && !isTenantOwner()) {
      alert("Штрафы доступны только главному пользователю");
      return;
    }
    if (finesState.syncing || finesState.importing) return;
    document.getElementById("ozonFbsFinesStornoImportFile")?.click();
  }

  async function onOzonFbsFinesStornoImportFileChange(ev) {
    const input = ev?.target || document.getElementById("ozonFbsFinesStornoImportFile");
    const file = input?.files && input.files[0];
    if (!file) return;
    const fromEl = document.getElementById("ozonFbsFinesDateFrom");
    const toEl = document.getElementById("ozonFbsFinesDateTo");
    const dateFrom = String(fromEl?.value || "").trim();
    const dateTo = String(toEl?.value || "").trim();
    finesState.importing = true;
    finesState.syncing = true;
    _ozonFbsFinesSetImportBusy(true);
    try {
      const fd = new FormData();
      fd.append("file", file, file.name);
      if (dateFrom) fd.append("date_from", dateFrom);
      if (dateTo) fd.append("date_to", dateTo);
      const headers = typeof withCsrfHeaders === "function" ? withCsrfHeaders() : {};
      const q = new URLSearchParams();
      if (dateFrom) q.set("date_from", dateFrom);
      if (dateTo) q.set("date_to", dateTo);
      const qs = q.toString() ? `?${q}` : "";
      const res = await fetch(`/api/ozon-fbs/fines/import-storno${qs}`, {
        method: "POST",
        headers,
        body: fd,
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      if (data.already_running || data.ok === false) {
        throw new Error(data.message || "Синхронизация или импорт сторно уже запущены");
      }
      await loadOzonFbsFinesSyncLog();
      await _ozonFbsFinesPollUntilIdle({ showAlertOnError: true });
      await loadOzonFbsFinesUnits();
    } catch (e) {
      await loadOzonFbsFinesSyncLog();
      alert(String(e.message || e));
    } finally {
      finesState.importing = false;
      finesState.syncing = false;
      _ozonFbsFinesSetImportBusy(false);
      if (input) input.value = "";
    }
  }

  async function syncOzonFbsFines() {
    if (finesState.syncing) return;
    if (typeof isTenantOwner === "function" && !isTenantOwner()) {
      alert("Штрафы доступны только главному пользователю");
      return;
    }
    const fromEl = document.getElementById("ozonFbsFinesDateFrom");
    const toEl = document.getElementById("ozonFbsFinesDateTo");
    const dateFrom = String(fromEl?.value || "").trim();
    const dateTo = String(toEl?.value || "").trim();
    if (!dateFrom || !dateTo) {
      alert("Укажите интервал дат");
      return;
    }
    finesState.syncing = true;
    _ozonFbsFinesSetImportBusy(true);
    try {
      const res = await fetch("/api/ozon-fbs/fines/sync", {
        method: "POST",
        headers: jsonHeaders(),
        body: JSON.stringify({ date_from: dateFrom, date_to: dateTo }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      if (data.already_running || data.ok === false) {
        throw new Error(data.message || "Синхронизация или импорт сторно уже запущены");
      }
      await loadOzonFbsFinesSyncLog();
      // Background job — poll status + log until done (avoids nginx 504).
      await _ozonFbsFinesPollUntilIdle({ showAlertOnError: true });
      await loadOzonFbsFinesUnits();
    } catch (e) {
      await loadOzonFbsFinesSyncLog();
      alert(String(e.message || e));
    } finally {
      finesState.syncing = false;
      _ozonFbsFinesSetImportBusy(false);
    }
  }

  async function _ozonFbsFinesFetchStatus() {
    const res = await fetch("/api/ozon-fbs/fines/sync/status", { headers: jsonHeaders() });
    if (!res.ok) return { in_progress: false };
    return res.json().catch(() => ({ in_progress: false }));
  }

  async function _ozonFbsFinesPollUntilIdle(opts) {
    const showAlertOnError = Boolean(opts && opts.showAlertOnError);
    const maxRounds = 600; // ~15 min at 1.5s
    for (let i = 0; i < maxRounds; i += 1) {
      const st = await _ozonFbsFinesFetchStatus();
      if (!st || !st.in_progress) {
        await loadOzonFbsFinesSyncLog();
        if (showAlertOnError && st && st.error) {
          alert(String(st.error));
        }
        return st || { in_progress: false };
      }
      await loadOzonFbsFinesSyncLog();
      await new Promise((r) => setTimeout(r, 1500));
    }
    await loadOzonFbsFinesSyncLog();
    return { in_progress: false, error: "Таймаут ожидания синхронизации" };
  }

  async function openOzonFbsFinesModal() {
    if (typeof isTenantOwner === "function" && !isTenantOwner()) {
      alert("Штрафы доступны только главному пользователю");
      return;
    }
    const fromEl = document.getElementById("ozonFbsFinesDateFrom");
    const toEl = document.getElementById("ozonFbsFinesDateTo");
    if (fromEl && !fromEl.value) fromEl.value = _ozonFbsFinesIso(14);
    if (toEl && !toEl.value) toEl.value = _ozonFbsFinesIso(0);
    setOzonFbsFinesStatusFilter(finesState.status || "open");
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsFinesModal", true);
    } else {
      document.getElementById("ozonFbsFinesModal")?.classList.remove("hidden");
    }
    await loadOzonFbsFinesSyncLog();
    await loadOzonFbsFinesUnits();
    // Resume UI lock if a background sync / storno import is still running.
    try {
      const st = await _ozonFbsFinesFetchStatus();
      if (st && st.in_progress && !finesState.syncing) {
        finesState.syncing = true;
        _ozonFbsFinesSetImportBusy(true);
        _ozonFbsFinesPollUntilIdle({ showAlertOnError: false })
          .then(async () => {
            await loadOzonFbsFinesUnits();
          })
          .catch(() => {})
          .finally(() => {
            finesState.syncing = false;
            _ozonFbsFinesSetImportBusy(false);
          });
      }
    } catch (_e) { /* ignore */ }
  }

  function closeOzonFbsFinesModal() {
    closeOzonFbsFinesSettingsModal();
    closeOzonFbsFinesEventsModal();
    closeOzonFbsFinesFilterMenu();
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsFinesModal", false);
    } else {
      document.getElementById("ozonFbsFinesModal")?.classList.add("hidden");
    }
  }

  async function openOzonFbsFinesSettingsModal() {
    if (typeof isTenantOwner === "function" && !isTenantOwner()) return;
    const info = document.getElementById("ozonFbsFinesSettingsInfo");
    if (info) { info.hidden = true; info.textContent = ""; }
    try {
      const res = await fetch("/api/ozon-fbs/fines/settings", { headers: jsonHeaders() });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      const cid = document.getElementById("ozonFbsFinesClientId");
      const key = document.getElementById("ozonFbsFinesApiKey");
      const hint = document.getElementById("ozonFbsFinesSettingsKeyHint");
      if (cid) cid.value = String(data.client_id || "");
      if (key) key.value = "";
      if (hint) {
        hint.textContent = data.has_api_key
          ? `Текущий ключ: ${data.api_key_masked || "сохранён"}`
          : "Ключ ещё не сохранён";
      }
    } catch (e) {
      if (info) {
        info.hidden = false;
        info.textContent = String(e.message || e);
      }
    }
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsFinesSettingsModal", true);
    } else {
      document.getElementById("ozonFbsFinesSettingsModal")?.classList.remove("hidden");
    }
  }

  function closeOzonFbsFinesSettingsModal() {
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsFinesSettingsModal", false);
    } else {
      document.getElementById("ozonFbsFinesSettingsModal")?.classList.add("hidden");
    }
  }

  async function saveOzonFbsFinesSettings() {
    const cid = document.getElementById("ozonFbsFinesClientId");
    const key = document.getElementById("ozonFbsFinesApiKey");
    const info = document.getElementById("ozonFbsFinesSettingsInfo");
    const body = { client_id: String(cid?.value || "").trim() };
    const apiKey = String(key?.value || "").trim();
    if (apiKey) body.api_key = apiKey;
    try {
      const res = await fetch("/api/ozon-fbs/fines/settings", {
        method: "PUT",
        headers: jsonHeaders(),
        body: JSON.stringify(body),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      if (key) key.value = "";
      const hint = document.getElementById("ozonFbsFinesSettingsKeyHint");
      if (hint) {
        hint.textContent = data.has_api_key
          ? `Текущий ключ: ${data.api_key_masked || "сохранён"}`
          : "Ключ ещё не сохранён";
      }
      if (info) {
        info.hidden = false;
        info.textContent = "Сохранено";
        info.classList.add("is-ok");
      }
      setTimeout(() => closeOzonFbsFinesSettingsModal(), 400);
    } catch (e) {
      if (info) {
        info.hidden = false;
        info.textContent = String(e.message || e);
        info.classList.remove("is-ok");
      }
    }
  }

  async function openOzonFbsFinesUnitEvents(unitNumber) {
    const unit = String(unitNumber || "").trim();
    if (!unit) return;
    const lead = document.getElementById("ozonFbsFinesEventsLead");
    const list = document.getElementById("ozonFbsFinesEventsList");
    if (lead) lead.textContent = unit;
    if (list) list.innerHTML = `<div class="ozon-fbs-fines-empty">Загрузка…</div>`;
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsFinesEventsModal", true);
    } else {
      document.getElementById("ozonFbsFinesEventsModal")?.classList.remove("hidden");
    }
    try {
      const res = await fetch(
        `/api/ozon-fbs/fines/units/${encodeURIComponent(unit)}/events`,
        { headers: jsonHeaders() }
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      const events = Array.isArray(data.events) ? data.events : [];
      if (!list) return;
      if (!events.length) {
        list.innerHTML = `<div class="ozon-fbs-fines-empty">Нет событий</div>`;
        return;
      }
      list.innerHTML = events.map((ev) => {
        const kind = String(ev.kind || "");
        const cls = kind === "storno" ? " is-storno" : " is-fine";
        return (
          `<div class="ozon-fbs-fines-event${cls}">` +
          `<span>${_ozonFbsFinesEsc(ev.event_date)}</span>` +
          `<span>${kind === "storno" ? "Сторно" : "Штраф"}</span>` +
          `<span>${_ozonFbsFinesMoney(ev.amount)} ₽</span>` +
          `<span class="ozon-fbs-fines-event-id">#${_ozonFbsFinesEsc(ev.accrual_id)}</span>` +
          `</div>`
        );
      }).join("");
    } catch (e) {
      if (list) {
        list.innerHTML = `<div class="ozon-fbs-fines-empty is-error">${_ozonFbsFinesEsc(e.message || e)}</div>`;
      }
    }
  }

  function closeOzonFbsFinesEventsModal() {
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsFinesEventsModal", false);
    } else {
      document.getElementById("ozonFbsFinesEventsModal")?.classList.add("hidden");
    }
  }

  const allCancellationsState = {
    loading: false,
    supplies: [],
    search: "",
    expanded: new Set(),
    lastError: "",
  };

  function _ozonFbsAllCancellationsSetInfo(text, kind) {
    const el = document.getElementById("ozonFbsAllCancellationsInfo");
    if (!el) return;
    const msg = String(text || "").trim();
    el.hidden = !msg;
    el.textContent = msg;
    el.classList.toggle("is-error", !!msg && kind === "error");
    el.classList.toggle("is-ok", !!msg && kind === "ok");
  }

  function _ozonFbsAllCancellationsFilteredSupplies() {
    const q = String(allCancellationsState.search || "").trim().toLowerCase();
    const list = Array.isArray(allCancellationsState.supplies)
      ? allCancellationsState.supplies
      : [];
    if (!q) return list.slice();
    return list.filter((s) => {
      const sid = String(s?.supply_id || "").toLowerCase();
      const name = String(s?.name || "").toLowerCase();
      const wh = String(s?.warehouse_label || "").toLowerCase();
      if (sid.includes(q) || name.includes(q) || wh.includes(q)) return true;
      const orders = Array.isArray(s?.cancelled_orders) ? s.cancelled_orders : [];
      return orders.some((o) => {
        const pn = String(o?.posting_number || "").toLowerCase();
        const offer = String(o?.offer_id || "").toLowerCase();
        const pname = String(o?.product_name || "").toLowerCase();
        return pn.includes(q) || offer.includes(q) || pname.includes(q);
      });
    });
  }

  function _ozonFbsAllCancellationsOrdersHtml(orders) {
    const rows = Array.isArray(orders) ? orders : [];
    if (!rows.length) {
      return `<div class="ozon-fbs-all-cancels-empty">В этой поставке отменённых заказов нет</div>`;
    }
    const body = rows.map((r) => {
      const pn = String(r.posting_number || "").trim();
      const photo = r.product_photo
        ? `<img class="wb-fbs-product-photo" src="${esc(r.product_photo)}" alt="" width="56" height="56" loading="lazy">`
        : `<span class="wb-fbs-product-ph" aria-hidden="true"></span>`;
      const offerArt = [r.offer_id ? `Арт. ${r.offer_id}` : "", r.sku ? `SKU ${r.sku}` : ""]
        .filter(Boolean)
        .join(" · ");
      const barcodes = Array.isArray(r.barcodes) ? r.barcodes : [];
      const barcodeHtml = barcodes.length
        ? `<div class="wb-fbs-kiz-barcodes" title="Штрихкод товара">${barcodes.map((b) =>
            `<div class="wb-fbs-kiz-barcode">${esc(b)}</div>`
          ).join("")}</div>`
        : "";
      return `<tr class="wb-fbs-kiz-row" data-posting="${esc(pn)}">
        <td>
          <div class="wb-fbs-kiz-order-id">${formatOzonPostingNumberHtml(pn)}</div>
          <div class="wb-fbs-kiz-order-date">от ${esc(r.created_date || "—")}</div>
        </td>
        <td>
          <div class="wb-fbs-product">
            ${photo}
            <div class="wb-fbs-product-text">
              <div class="wb-fbs-product-name" title="${esc(r.product_name || r.offer_id || "")}">${esc(r.product_name || r.offer_id || "—")}</div>
              <div class="wb-fbs-product-sub">${esc(offerArt || "—")}</div>
              ${typeof productCompositionHtml === "function" ? productCompositionHtml(r) : ""}
              ${barcodeHtml}
              ${cancelBadgeHtml(r)}
            </div>
          </div>
        </td>
      </tr>`;
    }).join("");
    return `<div class="wb-fbs-kiz-table-wrap">
      <table class="wb-fbs-kiz-table">
        <thead>
          <tr>
            <th class="wb-fbs-kiz-col-order">Отправление</th>
            <th class="wb-fbs-kiz-col-product">Товар</th>
          </tr>
        </thead>
        <tbody>${body}</tbody>
      </table>
    </div>`;
  }

  function renderOzonFbsAllCancellationsList() {
    const root = document.getElementById("ozonFbsAllCancellationsList");
    const summary = document.getElementById("ozonFbsAllCancellationsSummary");
    if (!root) return;
    if (allCancellationsState.loading && !allCancellationsState.supplies.length) {
      root.innerHTML = `<div class="ozon-fbs-all-cancels-empty">Загрузка…</div>`;
      if (summary) summary.textContent = "";
      return;
    }
    if (allCancellationsState.lastError && !allCancellationsState.supplies.length) {
      root.innerHTML = `<div class="ozon-fbs-all-cancels-empty">${esc(allCancellationsState.lastError)}</div>`;
      if (summary) summary.textContent = "";
      return;
    }
    const filtered = _ozonFbsAllCancellationsFilteredSupplies();
    const cancelledShown = filtered.reduce(
      (n, s) => n + (Array.isArray(s.cancelled_orders) ? s.cancelled_orders.length : 0),
      0
    );
    if (summary) {
      summary.textContent = filtered.length
        ? `Поставок: ${filtered.length} · отмен: ${cancelledShown}`
        : "";
    }
    if (!filtered.length) {
      const emptyMsg = String(allCancellationsState.search || "").trim()
        ? "Ничего не найдено"
        : "На вкладке «Доставляются» поставок нет";
      root.innerHTML = `<div class="ozon-fbs-all-cancels-empty">${esc(emptyMsg)}</div>`;
      return;
    }
    root.innerHTML = filtered.map((s) => {
      const sid = String(s.supply_id || "").trim();
      const open = allCancellationsState.expanded.has(sid);
      const count = Number(s.cancelled_count || 0);
      const countCls = count > 0
        ? "ozon-fbs-all-cancels-supply-count"
        : "ozon-fbs-all-cancels-supply-count is-zero";
      const countLabel = count > 0 ? `${count} отм.` : "0 отм.";
      const meta = [
        s.warehouse_label ? String(s.warehouse_label) : "",
        `в доставке: ${Number(s.order_count || 0)}`,
      ].filter(Boolean).join(" · ");
      return `<div class="ozon-fbs-all-cancels-supply${open ? " is-open" : ""}" data-supply="${esc(sid)}" role="listitem">
        <button type="button" class="ozon-fbs-all-cancels-supply-head"
                aria-expanded="${open ? "true" : "false"}"
                onclick='toggleOzonFbsAllCancellationsSupply(${JSON.stringify(sid)})'>
          <span class="ozon-fbs-all-cancels-caret" aria-hidden="true">${open ? "▾" : "▸"}</span>
          <span class="ozon-fbs-all-cancels-supply-main">
            <span class="ozon-fbs-all-cancels-supply-name">${esc(s.name || sid)}</span>
            <span class="ozon-fbs-all-cancels-supply-meta">${esc(meta)}</span>
          </span>
          <span class="${countCls}">${esc(countLabel)}</span>
        </button>
        <div class="ozon-fbs-all-cancels-supply-body" ${open ? "" : "hidden"}>
          ${_ozonFbsAllCancellationsOrdersHtml(s.cancelled_orders)}
        </div>
      </div>`;
    }).join("");
  }

  function toggleOzonFbsAllCancellationsSupply(supplyId) {
    const sid = String(supplyId || "").trim();
    if (!sid) return;
    if (allCancellationsState.expanded.has(sid)) {
      allCancellationsState.expanded.delete(sid);
    } else {
      allCancellationsState.expanded.add(sid);
    }
    renderOzonFbsAllCancellationsList();
  }

  function onOzonFbsAllCancellationsSearchInput() {
    const input = document.getElementById("ozonFbsAllCancellationsSearch");
    allCancellationsState.search = String(input?.value || "");
    renderOzonFbsAllCancellationsList();
  }

  async function loadOzonFbsAllCancellations() {
    const sourceId = state.sourceId;
    if (!sourceId || allCancellationsState.loading) return;
    allCancellationsState.loading = true;
    allCancellationsState.lastError = "";
    _ozonFbsAllCancellationsSetInfo("");
    renderOzonFbsAllCancellationsList();
    try {
      const res = await fetch(
        `/api/ozon-fbs/cancellations/delivering?source_id=${encodeURIComponent(sourceId)}`
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok || data.ok === false) {
        throw new Error(detailText(data.detail) || `Ошибка ${res.status}`);
      }
      allCancellationsState.supplies = Array.isArray(data.supplies) ? data.supplies : [];
      allCancellationsState.lastError = "";
      renderOzonFbsAllCancellationsList();
    } catch (e) {
      allCancellationsState.lastError = String(e.message || e);
      _ozonFbsAllCancellationsSetInfo(allCancellationsState.lastError, "error");
      renderOzonFbsAllCancellationsList();
    } finally {
      allCancellationsState.loading = false;
      renderOzonFbsAllCancellationsList();
    }
  }

  function openOzonFbsAllCancellationsModal() {
    if (typeof isTenantOwner === "function" && !isTenantOwner()) {
      alert("Все отмены доступны только главному пользователю");
      return;
    }
    if (!state.sourceId) {
      alert("Выберите источник Ozon");
      return;
    }
    allCancellationsState.search = "";
    allCancellationsState.expanded = new Set();
    allCancellationsState.supplies = [];
    allCancellationsState.lastError = "";
    const search = document.getElementById("ozonFbsAllCancellationsSearch");
    if (search) search.value = "";
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsAllCancellationsModal", true);
    } else {
      document.getElementById("ozonFbsAllCancellationsModal")?.classList.remove("hidden");
    }
    loadOzonFbsAllCancellations().catch(() => {});
  }

  function closeOzonFbsAllCancellationsModal() {
    allCancellationsState.loading = false;
    if (typeof setModalVisibility === "function") {
      setModalVisibility("ozonFbsAllCancellationsModal", false);
    } else {
      document.getElementById("ozonFbsAllCancellationsModal")?.classList.add("hidden");
    }
  }

  window.openOzonFbsAllCancellationsModal = openOzonFbsAllCancellationsModal;
  window.closeOzonFbsAllCancellationsModal = closeOzonFbsAllCancellationsModal;
  window.toggleOzonFbsAllCancellationsSupply = toggleOzonFbsAllCancellationsSupply;
  window.onOzonFbsAllCancellationsSearchInput = onOzonFbsAllCancellationsSearchInput;
  window.openOzonFbsFinesModal = openOzonFbsFinesModal;
  window.closeOzonFbsFinesModal = closeOzonFbsFinesModal;
  window.syncOzonFbsFines = syncOzonFbsFines;
  window.setOzonFbsFinesStatusFilter = setOzonFbsFinesStatusFilter;
  window.toggleOzonFbsFinesFilterMenu = toggleOzonFbsFinesFilterMenu;
  window.triggerOzonFbsFinesImport = triggerOzonFbsFinesImport;
  window.onOzonFbsFinesImportFileChange = onOzonFbsFinesImportFileChange;
  window.triggerOzonFbsFinesStornoImport = triggerOzonFbsFinesStornoImport;
  window.onOzonFbsFinesStornoImportFileChange = onOzonFbsFinesStornoImportFileChange;

  document.addEventListener("click", (e) => {
    const wrap = document.querySelector("#ozonFbsFinesModal .ozon-fbs-fines-filter-wrap");
    if (!wrap || wrap.contains(e.target)) return;
    closeOzonFbsFinesFilterMenu();
  });
  window.openOzonFbsFinesSettingsModal = openOzonFbsFinesSettingsModal;
  window.closeOzonFbsFinesSettingsModal = closeOzonFbsFinesSettingsModal;
  window.saveOzonFbsFinesSettings = saveOzonFbsFinesSettings;
  window.openOzonFbsFinesUnitEvents = openOzonFbsFinesUnitEvents;
  window.closeOzonFbsFinesEventsModal = closeOzonFbsFinesEventsModal;
  window.openOzonFbsStickerLookupModal = openOzonFbsStickerLookupModal;
  window.closeOzonFbsStickerLookupModal = closeOzonFbsStickerLookupModal;
  window.onOzonFbsStickerLookupScanKey = onOzonFbsStickerLookupScanKey;

  window.closeOzonFbsCollectModal = closeCollectModal;
  window.closeOzonFbsCollectResultModal = closeCollectResultModal;
  window.openOzonFbsPackagingExemplarModal = openOzonFbsPackagingExemplarModal;
  window.closeOzonFbsPackagingExemplarModal = closeOzonFbsPackagingExemplarModal;
  window.saveOzonFbsPackagingExemplar = saveOzonFbsPackagingExemplar;
  window.onOzonFbsPackagingExemplarKizInput = onOzonFbsPackagingExemplarKizInput;
  window.onOzonFbsPackagingExemplarKizKey = onOzonFbsPackagingExemplarKizKey;
  window.processOzonFbsPackagingExemplarKizScan = processOzonFbsPackagingExemplarKizScan;
  window.onOzonFbsPackagingExemplarManualGtd = onOzonFbsPackagingExemplarManualGtd;
  window.confirmOzonFbsCollect = confirmCollect;
  window.ozonFbsCollectNameInput = collectNameInput;
  window.ozonFbsCollectTargetChanged = collectTargetChanged;

  window.openOzonFbsRenameSupplyModal = openOzonFbsRenameSupplyModal;
  window.closeOzonFbsRenameSupplyModal = closeOzonFbsRenameSupplyModal;
  window.submitOzonFbsRenameSupply = submitOzonFbsRenameSupply;
  window.ozonFbsSupplyDetailId = () => String(supplyDetailState.supplyId || "");
  window.openOzonFbsSupplyDetailModal = openSupplyDetailModal;
  window.closeOzonFbsSupplyDetailModal = closeSupplyDetailModal;
  window.renderOzonFbsSupplyDetail = () => renderSupplyDetail();
  window.onOzonFbsSupplyDetailCheckboxChange = onSupplyDetailCheckboxChange;
  window.toggleSelectAllOzonFbsSupplyDetail = toggleSelectAllSupplyDetail;
  window.clearOzonFbsSupplyDetailSelection = clearSupplyDetailSelection;
  window.openOzonFbsSupplyDetailMoveExisting = openOzonFbsSupplyDetailMoveExisting;
  window.openOzonFbsSupplyDetailNewSupply = openOzonFbsSupplyDetailNewSupply;
  window.closeOzonFbsSupplyDetailNewSupplyModal = closeOzonFbsSupplyDetailNewSupplyModal;
  window.confirmOzonFbsSupplyDetailNewSupply = confirmOzonFbsSupplyDetailNewSupply;
  window.ozonFbsOpenPickingList = openPickingList;
  window.ozonFbsOpenStickersPrint = () => openStickersPrint();
  window.ozonFbsOpenNewStickersPrint = () => {
    openStickersPrint(undefined, { newLabels: true });
  };
  window.toggleOzonFbsStickersMenu = toggleStickersMenu;
  window.toggleOzonFbsNewStickersMenu = toggleNewStickersMenu;
  window.openOzonFbsStickersByCategoryModal = openStickersByCategoryModal;
  window.closeOzonFbsStickersByCategoryModal = closeStickersByCategoryModal;
  window.ozonFbsPrintStickersByCategory = ozonFbsPrintStickersByCategory;
  window.onOzonFbsStickersCategoryToggleAt = onOzonFbsStickersCategoryToggleAt;
  window.ozonFbsStickersCategorySelectAll = ozonFbsStickersCategorySelectAll;
  window.ozonFbsStickersCategoryClearAll = ozonFbsStickersCategoryClearAll;
  window.ozonFbsStickersCategoryFillDownAt = ozonFbsStickersCategoryFillDownAt;
  window.openOzonFbsShipmentsModal = openShipmentsModal;
  window.closeOzonFbsShipmentsModal = closeShipmentsModal;
  window.openOzonFbsDriverModal = openOzonFbsDriverModal;
  window.closeOzonFbsDriverModal = closeOzonFbsDriverModal;
  window.onOzonFbsDriverChange = onOzonFbsDriverChange;
  window.saveOzonFbsDriver = saveOzonFbsDriver;
  window._ozonFbsOnContainersLoaded = _ozonFbsOnContainersLoaded;
  window.reloadOzonFbsShipments = loadShipments;
  window.ozonFbsShipmentsForm = formShipmentsCarriage;
  window.ozonFbsShipmentsPrintBarcode = shipmentsPrintBarcode;
  window.ozonFbsShipmentsDownloadBarcode = shipmentsDownloadBarcode;
  window.openOzonFbsContainersModal = openOzonFbsContainersModal;
  window.toggleOzonFbsContainerDetails = toggleOzonFbsContainerDetails;
  window.downloadOzonFbsContainerComposition = downloadOzonFbsContainerComposition;
  window.closeOzonFbsContainersModal = closeOzonFbsContainersModal;
  window.refreshOzonFbsContainers = refreshOzonFbsContainers;
  window.createOzonFbsContainers = createOzonFbsContainers;
  window.deleteOzonFbsContainer = deleteOzonFbsContainer;
  window.archiveOzonFbsContainerLocally = archiveOzonFbsContainerLocally;
  window.restoreOzonFbsContainerLocally = restoreOzonFbsContainerLocally;
  window.approveOzonFbsContainer = approveOzonFbsContainer;
  window.closeOzonFbsContainerApproveModal = closeOzonFbsContainerApproveModal;
  window.printOzonFbsContainerLabel = printOzonFbsContainerLabel;
  window.ozonFbsContainersStep = ozonFbsContainersStep;
  window.onOzonFbsContainersShowScChange = onOzonFbsContainersShowScChange;
  window.onOzonFbsContainersOnlyThisSupplyChange = onOzonFbsContainersOnlyThisSupplyChange;
  window.moveOzonFbsSupplyToDelivering = moveOzonFbsSupplyToDelivering;
  window.closeOzonFbsMoveDeliveringModal = closeOzonFbsMoveDeliveringModal;
  window.confirmOzonFbsMoveDelivering = confirmOzonFbsMoveDelivering;
  window.openOzonFbsMoveSelectedToAwaitingDeliver = openOzonFbsMoveSelectedToAwaitingDeliver;
  window.closeOzonFbsMoveAwaitingModal = closeOzonFbsMoveAwaitingModal;
  window.confirmOzonFbsMoveAwaiting = confirmOzonFbsMoveAwaiting;
  window.toggleOzonFbsRowMenu = toggleOzonFbsRowMenu;
  window.closeOzonFbsRowMenus = closeOzonFbsRowMenus;
  window.ozonFbsFormTtn = ozonFbsFormTtn;
  window.reloadOzonFbsPostings = loadPostings;
  window.ozonFbsPrintOnePostingStickerFromDetail = printOnePostingStickerFromDetail;
  window.ozonFbsRemoveCancelledPostingFromSupply = ozonFbsRemoveCancelledPostingFromSupply;
  window.openOzonFbsMovePostingModal = openOzonFbsMovePostingModal;
  window.closeOzonFbsMovePostingModal = closeOzonFbsMovePostingModal;
  window.selectOzonFbsMovePostingTarget = selectOzonFbsMovePostingTarget;
  window.confirmOzonFbsMovePosting = confirmOzonFbsMovePosting;
  window.openOzonFbsCancelledOrdersModal = openOzonFbsCancelledOrdersModal;
  window.closeOzonFbsCancelledOrdersModal = closeOzonFbsCancelledOrdersModal;
  window.refreshOzonFbsModalPostingStatus = refreshOzonFbsModalPostingStatus;
  window._ozonFbsSilentRefreshPostingStatus = (pn) => refreshOzonFbsModalPostingStatus(pn, { silent: true });
  window._ozonFbsApplyCancelledQuiet = _ozonFbsApplyCancelledQuiet;
  window.copyOzonFbsModalPostingNumber = copyOzonFbsModalPostingNumber;
  window.closeOzonFbsPostingStatusModal = closeOzonFbsPostingStatusModal;
  window.refreshOzonFbsCancelledOrders = refreshOzonFbsCancelledOrders;

  /* ── Ozon FBS scan input mode: keyboard (default) / COM (Web Serial) ─────
   * Keyboard path is unchanged (Enter → process*). COM only feeds the same process* helpers.
   * Ozon specifics (cargo places, local-only marking, posting_number) stay inside process*.
   */
  const OZON_FBS_SCAN_MODE_KEY = "ozon_fbs_scan_input_mode_v1";
  const OZON_FBS_COM_BAUD = 9600;
  const OZON_FBS_COM_INTER_BYTE_MS = 50;
  const OZON_FBS_COM_DEDUP_MS = 500;
  /** USB-UART сканеры часто кратко рвут порт после кадра — переподключаемся сами. */
  const OZON_FBS_COM_RECONNECT_MS = 600;

  const ozonFbsScanComState = {
    preferredCom: false,
    port: null,
    reader: null,
    reading: false,
    buffer: "",
    interByteTimer: null,
    lastRaw: "",
    lastAt: 0,
    connectInFlight: false,
    /** True while we intentionally close (toggle off / modal close) — skip error UX. */
    closing: false,
    disconnectBound: false,
  };

  function _ozonFbsScanComSleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, Math.max(0, Number(ms) || 0)));
  }

  function _ozonFbsScanComSupported() {
    return typeof navigator !== "undefined" && !!(navigator.serial && navigator.serial.requestPort);
  }

  function _ozonFbsScanComIsYandexBrowser() {
    try {
      const ua = String(navigator.userAgent || "");
      return /YaBrowser|Yowser/i.test(ua);
    } catch (_e) {
      return false;
    }
  }

  /** Подсказка, когда диалог браузера пустой («Совместимые устройства не найдены»). */
  function _ozonFbsScanComEmptyPortsHint() {
    if (_ozonFbsScanComIsYandexBrowser()) {
      return (
        "COM: в Яндексе список портов пуст. Закройте Chrome полностью " +
        "(он держит порт), выньте/вставьте сканер и повторите. Надёжнее — Chrome/Edge."
      );
    }
    return (
      "COM: порт не найден. Закройте другие браузеры/программы с этим COM, " +
      "переподключите сканер и выберите порт снова."
    );
  }

  function _ozonFbsScanComPrefEnabled() {
    try {
      return localStorage.getItem(OZON_FBS_SCAN_MODE_KEY) === "com";
    } catch (_e) {
      return false;
    }
  }

  function _ozonFbsScanComSetPref(enabled) {
    ozonFbsScanComState.preferredCom = !!enabled;
    try {
      localStorage.setItem(OZON_FBS_SCAN_MODE_KEY, enabled ? "com" : "keyboard");
    } catch (_e) {
      /* ignore */
    }
  }

  function _ozonFbsScanModeStatusEls() {
    return [
      document.getElementById("ozonFbsKizScanModeStatus"),
      document.getElementById("ozonFbsPickScanModeStatus"),
      document.getElementById("ozonFbsPackagingExemplarScanModeStatus"),
    ].filter(Boolean);
  }

  function _ozonFbsScanModeToggleEls() {
    return [
      document.getElementById("ozonFbsKizScanModeToggle"),
      document.getElementById("ozonFbsPickScanModeToggle"),
      document.getElementById("ozonFbsPackagingExemplarScanModeToggle"),
    ].filter(Boolean);
  }

  function _ozonFbsScanComSetStatus(text, tone) {
    const msg = String(text || "").trim();
    for (const el of _ozonFbsScanModeStatusEls()) {
      if (!msg) {
        el.hidden = true;
        el.textContent = "";
        el.classList.remove("is-error", "is-ok");
        continue;
      }
      el.hidden = false;
      el.textContent = msg;
      el.classList.remove("is-error", "is-ok");
      if (tone === "error") el.classList.add("is-error");
      else if (tone === "ok") el.classList.add("is-ok");
    }
  }

  function _ozonFbsScanComSyncToggleUi() {
    const on = !!ozonFbsScanComState.preferredCom;
    for (const btn of _ozonFbsScanModeToggleEls()) {
      btn.setAttribute("aria-checked", on ? "true" : "false");
      btn.classList.toggle("is-com", on);
    }
  }

  function _ozonFbsScanComModalOpen() {
    try {
      if (typeof _ozonFbsPackagingExemplarModalIsOpen === "function"
          && _ozonFbsPackagingExemplarModalIsOpen()) {
        return true;
      }
    } catch (_e) { /* ignore */ }
    try {
      if (typeof _ozonFbsKizModalIsOpen === "function" && _ozonFbsKizModalIsOpen()) return true;
    } catch (_e) { /* ignore */ }
    try {
      if (typeof _ozonFbsPickModalIsOpen === "function" && _ozonFbsPickModalIsOpen()) return true;
    } catch (_e) { /* ignore */ }
    return false;
  }

  function _ozonFbsScanComPromptOpen(id) {
    const el = document.getElementById(id);
    return !!(el && !el.classList.contains("hidden"));
  }

  /**
   * COM → focused row field in KIZ / Pick tables.
   * KIZ modal: КИЗ + грузоместо. Pick modal: ШК + грузоместо.
   * Returns true when the scan was applied to the focused cell.
   */
  function _ozonFbsComTryFillFocusedRowInput(value) {
    const el = document.activeElement;
    if (!el || el.disabled || el.readOnly) return false;

    // Товары с КИЗ — поле КИЗ в строке заказа.
    if (
      el.classList?.contains("wb-fbs-kiz-code-input")
      && typeof _ozonFbsKizModalIsOpen === "function"
      && _ozonFbsKizModalIsOpen()
      && el.closest?.("#ozonFbsKizModal")
    ) {
      const pn = String(el.dataset.posting || el.getAttribute("data-posting") || "").trim();
      if (pn && _ozonFbsKizRejectReplaceFilledSlot(pn, el, value)) return true;
      el.value = value;
      if (pn) {
        onOzonFbsKizCodeInput(pn, { target: el });
        _ozonFbsKizSyncCommittedMark(el, value);
        _ozonFbsKizScheduleLocalAutosave(pn, false);
      } else {
        try { el.dispatchEvent(new Event("input", { bubbles: true })); } catch (_e) { /* ignore */ }
      }
      try { el.focus(); el.select?.(); } catch (_e) { /* ignore */ }
      return true;
    }

    // Товары без КИЗ — поле ШК в строке заказа.
    if (
      el.classList?.contains("ozon-fbs-pick-barcode-input")
      && typeof _ozonFbsPickModalIsOpen === "function"
      && _ozonFbsPickModalIsOpen()
      && el.closest?.("#ozonFbsPickVerifyModal")
    ) {
      el.value = value;
      const pn = String(el.dataset.posting || el.getAttribute("data-posting") || "").trim();
      if (pn) {
        // Same as Enter in the cell: validate + local autosave.
        _ozonFbsPickCommitBarcode(pn, value);
      } else {
        try { el.dispatchEvent(new Event("input", { bubbles: true })); } catch (_e) { /* ignore */ }
      }
      return true;
    }

    // Грузоместо (КИЗ и Pick) — commit via existing blur/Enter path.
    if (el.classList?.contains("ozon-fbs-container-input")) {
      const pn = String(el.dataset.posting || el.getAttribute("data-posting") || "").trim();
      const mode = String(el.dataset.mode || el.getAttribute("data-mode") || "").trim();
      if (!pn || (mode !== "kiz" && mode !== "pick")) return false;
      if (mode === "kiz") {
        if (typeof _ozonFbsKizModalIsOpen !== "function" || !_ozonFbsKizModalIsOpen()) return false;
      } else if (typeof _ozonFbsPickModalIsOpen !== "function" || !_ozonFbsPickModalIsOpen()) {
        return false;
      }
      el.value = value;
      if (typeof window.onOzonFbsContainerCellBlur === "function") {
        void window.onOzonFbsContainerCellBlur({ target: el }, pn, mode);
      }
      return true;
    }

    return false;
  }

  function deliverOzonFbsComScan(raw) {
    const value = String(raw || "").replace(/[\r\n]+$/g, "");
    if (!value.replace(/\s+/g, "")) return false;
    // Block COM while scan-ack is open — operator must press «Хорошо».
    if (typeof _fbsScanAckModalOpen === "function" && _fbsScanAckModalOpen()) {
      return false;
    }
    if (typeof _fbsStickerNotFoundModalOpen === "function" && _fbsStickerNotFoundModalOpen()) {
      return false;
    }
    const now = Date.now();
    if (value === ozonFbsScanComState.lastRaw && now - ozonFbsScanComState.lastAt < OZON_FBS_COM_DEDUP_MS) {
      return false;
    }
    ozonFbsScanComState.lastRaw = value;
    ozonFbsScanComState.lastAt = now;
    // COM bypasses keyboard watchers — still mark scan-busy for peer sync deferral.
    if (_ozonFbsScanComModalOpen()) _ozonFbsPeerNoteScanActivity();

    // Packaging exemplar (юрлица КИЗ+ГТД) — dedicated overlay, highest when open.
    if (_ozonFbsPackagingExemplarModalIsOpen()) {
      return !!processOzonFbsPackagingExemplarKizScan(value);
    }

    // Same priority as keyboard focus flow: open prompt first, then parent modal.
    if (_ozonFbsScanComPromptOpen("ozonFbsKizScanPrompt")) {
      const input = document.getElementById("ozonFbsKizMarkScan");
      if (input) input.value = value;
      return !!processOzonFbsKizMarkScan(value, input);
    }
    if (typeof _ozonFbsKizModalIsOpen === "function" && _ozonFbsKizModalIsOpen()) {
      // Focused row КИЗ / грузоместо → that cell; otherwise top sticker scan.
      if (_ozonFbsComTryFillFocusedRowInput(value)) return true;
      const input = document.getElementById("ozonFbsKizStickerScan");
      if (input) input.value = value;
      void processOzonFbsKizStickerScan(value, input);
      return true;
    }
    if (_ozonFbsScanComPromptOpen("ozonFbsPickScanPrompt")) {
      const input = document.getElementById("ozonFbsPickSkuScan");
      if (input) input.value = value;
      return !!processOzonFbsPickSkuScan(value, input);
    }
    if (typeof _ozonFbsPickModalIsOpen === "function" && _ozonFbsPickModalIsOpen()) {
      // Focused row ШК / грузоместо → that cell; otherwise top sticker scan.
      if (_ozonFbsComTryFillFocusedRowInput(value)) return true;
      const input = document.getElementById("ozonFbsPickStickerScan");
      if (input) input.value = value;
      void processOzonFbsPickStickerScan(value, input);
      return true;
    }
    return false;
  }

  function _ozonFbsScanComFlushBuffer() {
    if (ozonFbsScanComState.interByteTimer) {
      clearTimeout(ozonFbsScanComState.interByteTimer);
      ozonFbsScanComState.interByteTimer = null;
    }
    const raw = ozonFbsScanComState.buffer;
    ozonFbsScanComState.buffer = "";
    if (!raw) return;
    deliverOzonFbsComScan(raw);
  }

  function _ozonFbsScanComOnChunk(text) {
    if (!text) return;
    ozonFbsScanComState.buffer += text;
    const parts = ozonFbsScanComState.buffer.split(/\r\n|\n|\r/);
    ozonFbsScanComState.buffer = parts.pop() || "";
    for (const part of parts) {
      if (String(part || "").replace(/\s+/g, "")) deliverOzonFbsComScan(part);
    }
    if (ozonFbsScanComState.interByteTimer) clearTimeout(ozonFbsScanComState.interByteTimer);
    if (ozonFbsScanComState.buffer) {
      ozonFbsScanComState.interByteTimer = setTimeout(() => {
        ozonFbsScanComState.interByteTimer = null;
        _ozonFbsScanComFlushBuffer();
      }, OZON_FBS_COM_INTER_BYTE_MS);
    }
  }

  function _ozonFbsScanComBindDisconnect(port) {
    if (!port || ozonFbsScanComState.disconnectBound) return;
    ozonFbsScanComState.disconnectBound = true;
    try {
      port.addEventListener("disconnect", () => {
        if (ozonFbsScanComState.port === port) {
          ozonFbsScanComState.port = null;
          ozonFbsScanComState.reader = null;
        }
      });
    } catch (_e) {
      /* older Chromium — ignore */
    }
  }

  /** Close reader/port without clearing preferredCom (used before auto-reconnect). */
  async function _ozonFbsScanComReleasePort() {
    if (ozonFbsScanComState.interByteTimer) {
      clearTimeout(ozonFbsScanComState.interByteTimer);
      ozonFbsScanComState.interByteTimer = null;
    }
    ozonFbsScanComState.buffer = "";
    const reader = ozonFbsScanComState.reader;
    ozonFbsScanComState.reader = null;
    if (reader) {
      try { await reader.cancel(); } catch (_e) { /* ignore */ }
      try { reader.releaseLock(); } catch (_e) { /* ignore */ }
    }
    const port = ozonFbsScanComState.port;
    ozonFbsScanComState.port = null;
    ozonFbsScanComState.disconnectBound = false;
    if (port) {
      try { await port.close(); } catch (_e) { /* ignore */ }
    }
  }

  function _ozonFbsScanComShouldStayConnected() {
    return (
      !!ozonFbsScanComState.preferredCom &&
      !ozonFbsScanComState.closing &&
      _ozonFbsScanComModalOpen()
    );
  }

  async function _ozonFbsScanComReadLoop() {
    if (ozonFbsScanComState.reading) return;
    ozonFbsScanComState.reading = true;
    const decoder = new TextDecoder("latin1");
    try {
      while (_ozonFbsScanComShouldStayConnected()) {
        let port = ozonFbsScanComState.port;
        if (!port || !port.readable) {
          if (!_ozonFbsScanComShouldStayConnected()) break;
          _ozonFbsScanComSetStatus("COM: переподключение…", "error");
          const ok = await _ozonFbsScanComConnect({
            interactive: false,
            quiet: true,
            fromReconnect: true,
          });
          if (!ok) {
            await _ozonFbsScanComSleep(OZON_FBS_COM_RECONNECT_MS);
            continue;
          }
          port = ozonFbsScanComState.port;
          if (!port || !port.readable) {
            await _ozonFbsScanComSleep(OZON_FBS_COM_RECONNECT_MS);
            continue;
          }
        }

        const reader = port.readable.getReader();
        ozonFbsScanComState.reader = reader;
        let streamEnded = false;
        try {
          while (true) {
            const { value, done } = await reader.read();
            if (done) {
              streamEnded = true;
              break;
            }
            if (value && value.length) {
              _ozonFbsScanComOnChunk(decoder.decode(value, { stream: true }));
            }
          }
        } catch (_e) {
          streamEnded = true;
        } finally {
          try { reader.releaseLock(); } catch (_e2) { /* ignore */ }
          if (ozonFbsScanComState.reader === reader) ozonFbsScanComState.reader = null;
        }

        if (!streamEnded || !_ozonFbsScanComShouldStayConnected()) {
          break;
        }
        // Drop was unexpected: release and retry while COM mode stays on.
        _ozonFbsScanComSetStatus("COM: связь потеряна — переподключение…", "error");
        await _ozonFbsScanComReleasePort();
        await _ozonFbsScanComSleep(OZON_FBS_COM_RECONNECT_MS);
      }
    } finally {
      ozonFbsScanComState.reading = false;
    }
  }

  async function _ozonFbsScanComDisconnect() {
    ozonFbsScanComState.closing = true;
    try {
      await _ozonFbsScanComReleasePort();
      // Let the read loop observe `closing` before we clear the flag.
      let spins = 0;
      while (ozonFbsScanComState.reading && spins < 40) {
        await _ozonFbsScanComSleep(25);
        spins += 1;
      }
    } finally {
      ozonFbsScanComState.closing = false;
    }
  }

  async function _ozonFbsScanComConnect(opts) {
    const interactive = !!(opts && opts.interactive);
    const quiet = !!(opts && opts.quiet);
    const fromReconnect = !!(opts && opts.fromReconnect);
    if (!_ozonFbsScanComSupported()) {
      if (!quiet) _ozonFbsScanComSetStatus("COM недоступен в этом браузере", "error");
      return false;
    }
    if (ozonFbsScanComState.connectInFlight) return false;
    // Do not clear/override an intentional close (modal close / toggle off).
    if (ozonFbsScanComState.closing) return false;
    ozonFbsScanComState.connectInFlight = true;
    try {
      let port = ozonFbsScanComState.port;
      if (!port) {
        const ports = await navigator.serial.getPorts();
        if (ports && ports.length) port = ports[0];
      }
      if (!port && interactive) {
        // Empty filters — otherwise Yandex/Chromium may hide USB-UART scanners.
        port = await navigator.serial.requestPort({ filters: [] });
      }
      if (!port) {
        if (!quiet && !fromReconnect) {
          _ozonFbsScanComSetStatus("COM: выберите порт", "error");
        }
        return false;
      }
      if (ozonFbsScanComState.port !== port) {
        try {
          await port.open({ baudRate: OZON_FBS_COM_BAUD });
        } catch (e) {
          const msg = String(e && (e.message || e) || "");
          if (!/already\s+open/i.test(msg)) {
            if (quiet || fromReconnect) return false;
            const busy =
              /Failed to open|NetworkError|InvalidStateError|Access denied|занят|in use/i.test(
                msg + " " + String((e && e.name) || "")
              );
            _ozonFbsScanComSetStatus(
              busy
                ? "COM: порт занят — закройте Chrome и другие программы с этим портом"
                : "COM: не удалось открыть порт",
              "error"
            );
            return false;
          }
        }
        ozonFbsScanComState.port = port;
        _ozonFbsScanComBindDisconnect(port);
      }
      _ozonFbsScanComSetStatus("COM подключён", "ok");
      if (!ozonFbsScanComState.reading) {
        void _ozonFbsScanComReadLoop();
      }
      return true;
    } catch (e) {
      if (quiet || fromReconnect) return false;
      if (e && e.name === "NotFoundError") {
        _ozonFbsScanComSetStatus(_ozonFbsScanComEmptyPortsHint(), "error");
      } else {
        _ozonFbsScanComSetStatus("COM: ошибка подключения", "error");
      }
      return false;
    } finally {
      ozonFbsScanComState.connectInFlight = false;
    }
  }

  async function onOzonFbsScanModeToggleClick(event) {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    const next = !ozonFbsScanComState.preferredCom;
    if (next && !_ozonFbsScanComSupported()) {
      _ozonFbsScanComSetStatus("COM недоступен в этом браузере", "error");
      _ozonFbsScanComSetPref(false);
      _ozonFbsScanComSyncToggleUi();
      return;
    }
    _ozonFbsScanComSetPref(next);
    _ozonFbsScanComSyncToggleUi();
    if (!next) {
      await _ozonFbsScanComDisconnect();
      _ozonFbsScanComSetStatus("");
      return;
    }
    const ok = await _ozonFbsScanComConnect({ interactive: true });
    if (!ok) {
      // Stay preferred ON so operator can retry; UI remains green.
      _ozonFbsScanComSyncToggleUi();
    }
  }

  async function _ozonFbsScanComOnModalOpened() {
    ozonFbsScanComState.preferredCom = _ozonFbsScanComPrefEnabled();
    _ozonFbsScanComSyncToggleUi();
    if (!ozonFbsScanComState.preferredCom) {
      _ozonFbsScanComSetStatus("");
      return;
    }
    if (!_ozonFbsScanComSupported()) {
      _ozonFbsScanComSetStatus("COM недоступен", "error");
      return;
    }
    const ok = await _ozonFbsScanComConnect({ interactive: false });
    if (!ok) {
      _ozonFbsScanComSetStatus("COM: нажмите переключатель для порта", "error");
    }
  }

  async function _ozonFbsScanComOnModalClosed() {
    // Release port when leaving Ozon scan modals; preference remembered for next open.
    if (!_ozonFbsScanComModalOpen()) {
      await _ozonFbsScanComDisconnect();
    }
  }

  function _ozonFbsScanComInitFromStorage() {
    ozonFbsScanComState.preferredCom = _ozonFbsScanComPrefEnabled();
    _ozonFbsScanComSyncToggleUi();
  }
  if (typeof document !== "undefined") {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", _ozonFbsScanComInitFromStorage);
    } else {
      _ozonFbsScanComInitFromStorage();
    }
  }


  window.ozonFbsKizState = ozonFbsKizState;
  window.ozonFbsPickState = ozonFbsPickState;
  window.supplyDetailState = supplyDetailState;
  window._ozonFbsRowIsCancelled = _ozonFbsRowIsCancelled;
  window._ozonFbsKizSetInfo = _ozonFbsKizSetInfo;
  window._ozonFbsPickSetInfo = _ozonFbsPickSetInfo;
  window.openOzonFbsKizModal = openOzonFbsKizModal;
  window.closeOzonFbsKizModal = closeOzonFbsKizModal;
  window.saveOzonFbsKizModal = saveOzonFbsKizModal;
  window.renderOzonFbsKizTable = renderOzonFbsKizTable;
  window.onOzonFbsKizCodeInput = onOzonFbsKizCodeInput;
  window.onOzonFbsKizCodeBlur = onOzonFbsKizCodeBlur;
  window.onOzonFbsKizCodeKey = onOzonFbsKizCodeKey;
  window.onOzonFbsKizGtdInput = onOzonFbsKizGtdInput;
  window.addOzonFbsKizCode = addOzonFbsKizCode;
  window.removeOzonFbsKizCode = removeOzonFbsKizCode;
  window.onOzonFbsKizFilterFilledChange = onOzonFbsKizFilterFilledChange;
  window.onOzonFbsKizFilterEmptyChange = onOzonFbsKizFilterEmptyChange;
  window._ozonFbsKizUpdateFilterCounts = _ozonFbsKizUpdateFilterCounts;
  window.processOzonFbsKizStickerScan = processOzonFbsKizStickerScan;
  window.processOzonFbsKizMarkScan = processOzonFbsKizMarkScan;
  window.onOzonFbsKizStickerScanKey = onOzonFbsKizStickerScanKey;
  window.onOzonFbsKizMarkScanKey = onOzonFbsKizMarkScanKey;
  window.onOzonFbsScanModeToggleClick = onOzonFbsScanModeToggleClick;
  window.deliverOzonFbsComScan = deliverOzonFbsComScan;
  window.cancelOzonFbsKizMarkScan = cancelOzonFbsKizMarkScan;
  window.clearOzonFbsKizRow = clearOzonFbsKizRow;
  window.openOzonFbsKizImportModal = openOzonFbsKizImportModal;
  window.closeOzonFbsKizImportModal = closeOzonFbsKizImportModal;
  window.toggleOzonFbsKizImportPanel = toggleOzonFbsKizImportPanel;
  window.onOzonFbsKizImportTextInput = onOzonFbsKizImportTextInput;
  window.onOzonFbsKizImportTextBeforeInput = onOzonFbsKizImportTextBeforeInput;
  window.onOzonFbsKizImportTextPaste = onOzonFbsKizImportTextPaste;
  window.onOzonFbsKizImportTextKey = onOzonFbsKizImportTextKey;
  window.runOzonFbsKizImport = runOzonFbsKizImport;
  window.applyOzonFbsKizImportConflicts = applyOzonFbsKizImportConflicts;
  window.dismissOzonFbsKizImportConflicts = dismissOzonFbsKizImportConflicts;
  window.selectAllOzonFbsKizImportConflicts = selectAllOzonFbsKizImportConflicts;
  window.refreshOzonFbsMarkingStatus = refreshOzonFbsMarkingStatus;
  window.refreshOzonFbsPickVerifyStatus = refreshOzonFbsPickVerifyStatus;
  window.openOzonFbsPickVerifyModal = openOzonFbsPickVerifyModal;
  window.closeOzonFbsPickVerifyModal = closeOzonFbsPickVerifyModal;
  window.saveOzonFbsPickVerifyModal = saveOzonFbsPickVerifyModal;
  window.renderOzonFbsPickVerifyTable = renderOzonFbsPickVerifyTable;
  window.onOzonFbsPickFilterFilledChange = onOzonFbsPickFilterFilledChange;
  window.onOzonFbsPickFilterEmptyChange = onOzonFbsPickFilterEmptyChange;
  window._ozonFbsPickUpdateFilterCounts = _ozonFbsPickUpdateFilterCounts;
  window.processOzonFbsPickStickerScan = processOzonFbsPickStickerScan;
  window.processOzonFbsPickSkuScan = processOzonFbsPickSkuScan;
  window.onOzonFbsPickStickerScanKey = onOzonFbsPickStickerScanKey;
  window.onOzonFbsPickSkuScanKey = onOzonFbsPickSkuScanKey;
  window.onOzonFbsPickBarcodeInput = onOzonFbsPickBarcodeInput;
  window.onOzonFbsPickBarcodeBlur = onOzonFbsPickBarcodeBlur;
  window.onOzonFbsPickBarcodeKey = onOzonFbsPickBarcodeKey;
  window.cancelOzonFbsPickSkuScan = cancelOzonFbsPickSkuScan;
  window.clearOzonFbsPickVerify = clearOzonFbsPickVerify;
})();
