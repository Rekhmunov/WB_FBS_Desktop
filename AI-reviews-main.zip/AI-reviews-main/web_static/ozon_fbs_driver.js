/* Ozon FBS standalone driver page */
(function () {
  "use strict";

  const boot = window.OFD_BOOT || {};
  const main = document.getElementById("ofdMain");
  const toastEl = document.getElementById("ofdToast");
  let toastTimer = 0;

  const pageMode = String(boot.page_mode || "owner");
  const pageToken = String(boot.page_token || "").trim();
  const isPinMode = pageMode === "pin";

  const state = {
    plates: [],
    vehicleNumber: "",
    items: [],
    supplies: [],
    errors: [],
    loadingPlates: false,
    loadingItems: false,
    softRefresh: false,
    accessToken: "",
    driverName: "",
    unlocking: false,
    pinError: "",
    /** @type {Record<string, boolean>} */
    expandedSupplies: {},
    /** @type {Record<string, boolean>} */
    expandedStatusHistory: {},
    /** Extra days beyond sync lookback (load-more steps of 10). */
    extraDays: 0,
    hasMore: false,
    loadMoreDays: 10,
    loadingMore: false,
  };

  function esc(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function toast(message) {
    if (!toastEl) return;
    toastEl.textContent = String(message || "");
    toastEl.hidden = !message;
    if (toastTimer) window.clearTimeout(toastTimer);
    if (message) {
      toastTimer = window.setTimeout(function () {
        toastEl.hidden = true;
      }, 3200);
    }
  }

  async function api(path, options) {
    const opts = options || {};
    const headers = Object.assign(
      { Accept: "application/json" },
      opts.headers || {}
    );
    if (state.accessToken) {
      headers["X-Driver-Access-Token"] = state.accessToken;
    }
    // Public PIN page must not send the cabinet session cookie: CSRF would
    // block unlock for a logged-in owner testing the public link, and the
    // page is intentionally account-free.
    const res = await fetch(path, {
      credentials: isPinMode ? "omit" : "same-origin",
      method: opts.method || "GET",
      headers: headers,
      body: opts.body || undefined,
    });
    if (res.status === 401) {
      if (isPinMode) {
        state.accessToken = "";
        state.plates = [];
        state.vehicleNumber = "";
        state.items = [];
        renderPinForm("Сессия истекла. Введите ПИН снова.");
        throw new Error("Введите ПИН заново");
      }
      window.location.href = "/login";
      throw new Error("Требуется вход");
    }
    const data = await res.json().catch(function () {
      return {};
    });
    if (!res.ok) {
      const detail = data && (data.detail || data.message || data.error);
      throw new Error(String(detail || "Ошибка " + res.status));
    }
    return data;
  }

  function badgeClass(status) {
    const st = String(status || "").toLowerCase();
    if (st === "acceptance_in_progress" || st === "finished") return "is-sc";
    if (st === "formed") return "is-formed";
    return "";
  }

  /** Ozon GMs only — WB TRBX use a placeholder status and must not drive the banner. */
  function ozonPalletItems(items) {
    return (items || []).filter(function (item) {
      const mp = String(item.marketplace || "").toLowerCase();
      const kind = String(item.item_kind || "").toLowerCase();
      if (mp === "wb" || kind === "trbx") return false;
      return true;
    });
  }

  /** ``warn`` = any «Сформировано»; ``ok`` = none / all at SC / finished. */
  function palletBannerKind(items) {
    const list = items || [];
    // No cargo places at all → same green as fully accepted at SC.
    if (!list.length) return "ok";
    const ozon = ozonPalletItems(list);
    if (!ozon.length) return null;
    let hasFormed = false;
    let allAccepted = true;
    for (let i = 0; i < ozon.length; i++) {
      const st = String(ozon[i].status || "").toLowerCase();
      if (st === "formed") hasFormed = true;
      if (st !== "acceptance_in_progress" && st !== "finished") {
        allAccepted = false;
      }
    }
    if (hasFormed) return "warn";
    if (allAccepted) return "ok";
    return null;
  }

  const STATUS_SORT_ORDER = {
    formed: 0,
    acceptance_in_progress: 1,
    finished: 2,
  };

  function statusSortKey(status) {
    const st = String(status || "").toLowerCase();
    return Object.prototype.hasOwnProperty.call(STATUS_SORT_ORDER, st)
      ? STATUS_SORT_ORDER[st]
      : 99;
  }

  function sortCargoItems(items) {
    return (items || []).slice().sort(function (a, b) {
      const sa = statusSortKey(a && a.status);
      const sb = statusSortKey(b && b.status);
      if (sa !== sb) return sa - sb;
      const numA = Number((a && a.container_number) || 0);
      const numB = Number((b && b.container_number) || 0);
      if (numA !== numB) return numA - numB;
      return String((a && a.container_id) || "").localeCompare(
        String((b && b.container_id) || "")
      );
    });
  }

  function isWbItem(item) {
    const mp = String((item && item.marketplace) || "").toLowerCase();
    const kind = String((item && item.item_kind) || "").toLowerCase();
    return mp === "wb" || kind === "trbx" || mp.indexOf("wb") >= 0;
  }

  function supplyGroupKey(item) {
    const mp = isWbItem(item) ? "wb" : "ozon";
    const sid = String((item && item.source_id) || "");
    const supply = String((item && item.supply_id) || "");
    return mp + "|" + sid + "|" + supply;
  }

  /**
   * Per-supply tone from Ozon GMs only (WB TRBX have no SC statuses).
   * ``ok`` = all accepted/finished; ``warn`` = any not yet at SC.
   */
  function supplyTone(items) {
    const ozon = ozonPalletItems(items);
    if (!ozon.length) return "ok";
    for (let i = 0; i < ozon.length; i++) {
      const st = String(ozon[i].status || "").toLowerCase();
      if (st !== "acceptance_in_progress" && st !== "finished") {
        return "warn";
      }
    }
    return "ok";
  }

  function supplyDateMs(value) {
    const raw = String(value || "").trim();
    if (!raw) return 0;
    const t = Date.parse(raw);
    return Number.isFinite(t) ? t : 0;
  }

  function groupItemsBySupply(items) {
    const order = [];
    const map = {};
    (items || []).forEach(function (item) {
      const key = supplyGroupKey(item);
      if (!map[key]) {
        map[key] = {
          key: key,
          supply_id: String(item.supply_id || ""),
          supply_name: String(item.supply_name || item.supply_id || "Поставка"),
          supply_created_at: String(item.supply_created_at || "").trim(),
          warehouse_name: String(item.warehouse_name || "").trim(),
          marketplace: isWbItem(item) ? "wb" : "ozon",
          items: [],
        };
        order.push(key);
      }
      const g = map[key];
      if (!g.warehouse_name && item.warehouse_name) {
        g.warehouse_name = String(item.warehouse_name || "").trim();
      }
      if (!g.supply_name && item.supply_name) {
        g.supply_name = String(item.supply_name);
      }
      if (!g.supply_created_at && item.supply_created_at) {
        g.supply_created_at = String(item.supply_created_at || "").trim();
      }
      g.items.push(item);
    });
    const groups = order.map(function (key) {
      const g = map[key];
      // Inside supply: сформировано → принято на СЦ → завершено.
      g.items = sortCargoItems(g.items);
      g.tone = supplyTone(g.items);
      return g;
    });
    // Nearest supply dates first (missing dates last).
    groups.sort(function (a, b) {
      const da = supplyDateMs(a.supply_created_at);
      const db = supplyDateMs(b.supply_created_at);
      if (da !== db) return db - da;
      const nameA = String(a.supply_name || "");
      const nameB = String(b.supply_name || "");
      if (nameA < nameB) return -1;
      if (nameA > nameB) return 1;
      return String(a.supply_id || "").localeCompare(String(b.supply_id || ""));
    });
    return groups;
  }

  function renderCargoItem(item) {
    const isWb = isWbItem(item);
    const num = Number(item.container_number || 0);
    const metaParts = [];
    metaParts.push(
      "<div><span>Маркетплейс:</span> " +
        esc(isWb ? "Wildberries" : "Ozon") +
        "</div>"
    );
    if (item.warehouse_name) {
      metaParts.push(
        "<div><span>Склад:</span> " + esc(item.warehouse_name) + "</div>"
      );
    }
    const typeBits = [item.cargo_type_label, item.sort_type_label]
      .filter(Boolean)
      .join(" · ");
    if (typeBits) {
      metaParts.push("<div><span>Тип:</span> " + esc(typeBits) + "</div>");
    }
    metaParts.push(
      "<div><span>Заказов:</span> " +
        esc(String(item.order_count ?? 0)) +
        "</div>"
    );
    if (!isWb) {
      const hist = Array.isArray(item.status_history) ? item.status_history : [];
      if (hist.length) {
        const histKey =
          String(item.source_id || "") + "|" + String(item.container_id || "");
        const histOpen = !!state.expandedStatusHistory[histKey];
        const histRows = hist
          .map(function (h) {
            return (
              "<li>" +
              '<span class="ofd-status-hist-label">' +
              esc((h && (h.status_label || h.status)) || "—") +
              "</span>" +
              '<span class="ofd-status-hist-time">' +
              esc((h && h.observed_at_display) || "") +
              "</span>" +
              "</li>"
            );
          })
          .join("");
        metaParts.push(
          '<div class="ofd-status-hist">' +
            '<button type="button" class="ofd-status-hist-toggle" data-hist-key="' +
            esc(histKey) +
            '" aria-expanded="' +
            (histOpen ? "true" : "false") +
            '">История статусов</button>' +
            (histOpen
              ? '<ul class="ofd-status-hist-list">' + histRows + "</ul>"
              : "") +
            "</div>"
        );
      }
    }
    const title = isWb
      ? "Грузоместо " + esc(String(num || "—"))
      : "ГМ № " + esc(String(num || "—"));
    const idLabel = isWb ? "TRBX " : "ID ";
    return (
      '<li class="ofd-item">' +
      '<div class="ofd-item-top">' +
      "<div>" +
      '<div class="ofd-item-num">' +
      title +
      "</div>" +
      '<div class="ofd-item-id">' +
      idLabel +
      esc(String(item.container_id || "")) +
      "</div>" +
      "</div>" +
      '<span class="ofd-badge ' +
      badgeClass(item.status) +
      '">' +
      esc(item.status_label || item.status || "—") +
      "</span>" +
      "</div>" +
      '<div class="ofd-item-meta">' +
      metaParts.join("") +
      "</div>" +
      "</li>"
    );
  }

  function renderSupplyGroup(group) {
    const expanded = !!state.expandedSupplies[group.key];
    const toneClass =
      group.tone === "ok"
        ? " is-ok"
        : group.tone === "warn"
          ? " is-warn"
          : "";
    const count = group.items.length;
    const toneLabel =
      group.tone === "ok"
        ? "Все на СЦ / завершены"
        : group.tone === "warn"
          ? "Есть непринятые на СЦ"
          : "";
    const mpLabel = group.marketplace === "wb" ? "Wildberries" : "Ozon";
    const subBits = [mpLabel];
    if (group.warehouse_name) subBits.push(group.warehouse_name);
    subBits.push(count + " ГМ");
    return (
      '<li class="ofd-supply' +
      toneClass +
      (expanded ? " is-open" : "") +
      '" data-supply-key="' +
      esc(group.key) +
      '">' +
      '<button type="button" class="ofd-supply-head" aria-expanded="' +
      (expanded ? "true" : "false") +
      '">' +
      '<div class="ofd-supply-head-text">' +
      '<div class="ofd-supply-name">' +
      esc(group.supply_name || "Поставка") +
      "</div>" +
      '<div class="ofd-supply-sub">' +
      esc(subBits.join(" · ")) +
      (toneLabel ? " · " + esc(toneLabel) : "") +
      "</div>" +
      "</div>" +
      '<span class="ofd-supply-chevron" aria-hidden="true"></span>' +
      "</button>" +
      (expanded
        ? '<ul class="ofd-items ofd-supply-items">' +
          group.items.map(renderCargoItem).join("") +
          "</ul>"
        : "") +
      "</li>"
    );
  }

  function renderStatusBanner() {
    const host = document.getElementById("ofdStatusBanner");
    if (!host) return;
    if (!state.vehicleNumber) {
      host.innerHTML = "";
      host.hidden = true;
      return;
    }
    // First load: hide banner until data arrives. Soft refresh keeps it.
    if (state.loadingItems && !state.softRefresh) {
      host.innerHTML = "";
      host.hidden = true;
      return;
    }
    const kind = palletBannerKind(state.items);
    if (!kind) {
      host.innerHTML = "";
      host.hidden = true;
      return;
    }
    host.hidden = false;
    if (kind === "ok") {
      host.innerHTML =
        '<div class="ofd-banner ofd-banner-ok" role="status">' +
        "Ваши паллеты приняты на СЦ, все хорошо" +
        "</div>";
      return;
    }
    const refreshing = state.loadingItems && state.softRefresh;
    host.innerHTML =
      '<div class="ofd-banner ofd-banner-warn" role="status">' +
      "<p class=\"ofd-banner-text\">" +
      "Часть ваших паллет в статусе «Сформировано» — нужно дождаться, " +
      "пока статусы станут «Принято на СЦ» или «Завершено». " +
      "Нажмите «Обновить», чтобы проверить ещё раз. " +
      "Если не помогает в течение нескольких минут, то обратитесь на склад " +
      "для повторного сканирования." +
      "</p>" +
      '<button type="button" id="ofdRefreshBtn" class="ofd-btn ofd-btn-refresh' +
      (refreshing ? " is-loading" : "") +
      '"' +
      (refreshing ? " disabled" : "") +
      ">" +
      (refreshing
        ? '<span class="ofd-spinner" aria-hidden="true"></span><span>Обновление…</span>'
        : "Обновить") +
      "</button>" +
      "</div>";
    const btn = document.getElementById("ofdRefreshBtn");
    if (btn && !refreshing) {
      btn.addEventListener("click", function () {
        if (state.loadingItems) return;
        loadCargo(state.vehicleNumber, { soft: true });
      });
    }
  }

  function renderDenied() {
    main.innerHTML =
      '<div class="ofd-denied">Нет доступа к странице водителя Ozon FBS.</div>';
  }

  function renderPinForm(errorMessage) {
    const err = String(errorMessage || state.pinError || "");
    main.innerHTML =
      '<section class="ofd-panel ofd-pin-panel">' +
      '<h2 class="ofd-pin-title">Вход по ПИН</h2>' +
      '<p class="ofd-hint">Введите ПИН из настроек «Водители». После закрытия страницы потребуется ввести его снова.</p>' +
      '<label class="ofd-label" for="ofdPinInput">ПИН</label>' +
      '<input id="ofdPinInput" class="ofd-input" type="password" inputmode="numeric" ' +
      'autocomplete="one-time-code" maxlength="8" placeholder="••••" />' +
      (err ? '<p class="ofd-pin-error" role="alert">' + esc(err) + "</p>" : "") +
      '<button type="button" id="ofdPinSubmit" class="ofd-btn"' +
      (state.unlocking ? " disabled" : "") +
      ">" +
      (state.unlocking ? "Проверка…" : "Открыть") +
      "</button>" +
      "</section>";

    const input = document.getElementById("ofdPinInput");
    const btn = document.getElementById("ofdPinSubmit");
    if (input) {
      input.focus();
      input.addEventListener("keydown", function (ev) {
        if (ev.key === "Enter") {
          ev.preventDefault();
          submitPin();
        }
      });
    }
    if (btn) btn.addEventListener("click", submitPin);
  }

  async function submitPin() {
    if (state.unlocking) return;
    const input = document.getElementById("ofdPinInput");
    const pin = String((input && input.value) || "").trim();
    state.pinError = "";
    if (!pin) {
      renderPinForm("Введите ПИН");
      return;
    }
    state.unlocking = true;
    renderPinForm("");
    try {
      const data = await api(
        "/api/ozon-fbs/driver/p/" + encodeURIComponent(pageToken) + "/unlock",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ pin: pin }),
        }
      );
      state.accessToken = String(data.access_token || "");
      state.driverName = String(data.driver_name || "").trim();
      state.plates = Array.isArray(data.items) ? data.items : [];
      state.vehicleNumber = "";
      state.items = [];
      state.errors = [];
      state.loadingPlates = false;
      renderShell();
      renderResults();
      maybeAutoloadSinglePlate();
    } catch (err) {
      state.accessToken = "";
      state.pinError = String(err.message || err);
      state.unlocking = false;
      renderPinForm(state.pinError);
      return;
    }
    state.unlocking = false;
  }

  function renderShell() {
    const multi = state.plates.length > 1;
    const single = state.plates.length === 1;
    const disabled = state.loadingPlates ? "disabled" : "";
    const placeholder = state.loadingPlates
      ? "Загрузка…"
      : multi
        ? "Выберите гос. номер"
        : "Нет машин";

    const driverLine =
      isPinMode && state.driverName
        ? '<p class="ofd-driver-name">' + esc(state.driverName) + "</p>"
        : "";

    let vehicleBlock;
    if (!state.loadingPlates && !multi) {
      const number = single
        ? String(state.plates[0].number || "").trim()
        : "";
      const line = single
        ? String(state.plates[0].line || number).trim() || number
        : "Нет машин в карточке водителя";
      vehicleBlock =
        '<div class="ofd-label">Номер машины</div>' +
        '<div class="ofd-plate-value">' +
        esc(line || "—") +
        "</div>" +
        (single
          ? ""
          : '<p class="ofd-hint">Добавьте автомобиль в настройках «Водители».</p>');
      if (single && number) state.vehicleNumber = number;
    } else {
      vehicleBlock =
        '<label class="ofd-label" for="ofdVehicleSelect">Номер машины</label>' +
        '<select id="ofdVehicleSelect" class="ofd-select" ' +
        disabled +
        ">" +
        '<option value="">' +
        placeholder +
        "</option>" +
        "</select>";
    }

    main.innerHTML =
      '<section class="ofd-panel">' +
      driverLine +
      vehicleBlock +
      '<div id="ofdStatusBanner" class="ofd-status-banner" hidden></div>' +
      "</section>" +
      '<section class="ofd-panel" id="ofdResults">' +
      '<div class="ofd-empty">Выберите номер машины</div>' +
      "</section>";
    renderStatusBanner();

    const select = document.getElementById("ofdVehicleSelect");
    if (select) {
      state.plates.forEach(function (plate) {
        const number = String(plate.number || "").trim();
        if (!number) return;
        const opt = document.createElement("option");
        opt.value = number;
        opt.textContent = String(plate.line || number).trim() || number;
        if (number === state.vehicleNumber) opt.selected = true;
        select.appendChild(opt);
      });
      select.addEventListener("change", onVehicleChange);
    }
  }

  function renderResults() {
    const box = document.getElementById("ofdResults");
    if (!box) return;

    if (!state.vehicleNumber) {
      box.hidden = false;
      box.innerHTML = '<div class="ofd-empty">Выберите номер машины</div>';
      renderStatusBanner();
      return;
    }
    if (state.loadingItems && !state.softRefresh) {
      box.hidden = false;
      box.innerHTML = '<div class="ofd-loading">Загрузка грузомест…</div>';
      renderStatusBanner();
      return;
    }

    const errorsHtml = state.errors.length
      ? '<div class="ofd-errors">' +
        state.errors.map(esc).join("<br>") +
        "</div>"
      : "";

    const moreDays = Math.max(1, Number(state.loadMoreDays) || 10);
    const moreBtn = state.hasMore
      ? '<div class="ofd-load-more">' +
        '<button type="button" id="ofdLoadMoreBtn" class="ofd-btn ofd-btn-load-more"' +
        (state.loadingMore || state.loadingItems ? " disabled" : "") +
        ">" +
        (state.loadingMore
          ? "Загрузка…"
          : "Подгрузить ещё за " + moreDays + " дней") +
        "</button>" +
        "</div>"
      : "";

    // No cargo in the tracked statuses → green banner; keep load-more if older exist.
    if (!state.items.length) {
      if (errorsHtml || moreBtn) {
        box.hidden = false;
        box.innerHTML = errorsHtml + moreBtn;
        const moreEl = document.getElementById("ofdLoadMoreBtn");
        if (moreEl) moreEl.addEventListener("click", onLoadMore);
      } else {
        box.innerHTML = "";
        box.hidden = true;
      }
      renderStatusBanner();
      return;
    }

    box.hidden = false;

    const listClass =
      state.loadingItems && state.softRefresh
        ? "ofd-supplies is-refreshing"
        : "ofd-supplies";

    const groups = groupItemsBySupply(state.items);
    const rows = groups.map(renderSupplyGroup).join("");

    box.innerHTML =
      '<div class="ofd-list-head">' +
      '<h2 class="ofd-list-title">Поставки</h2>' +
      '<div class="ofd-list-count">' +
      groups.length +
      "</div>" +
      "</div>" +
      errorsHtml +
      '<ul class="' +
      listClass +
      '">' +
      rows +
      "</ul>" +
      moreBtn;

    Array.prototype.forEach.call(
      box.querySelectorAll(".ofd-supply-head"),
      function (btn) {
        btn.addEventListener("click", function () {
          const li = btn.closest(".ofd-supply");
          if (!li) return;
          const key = String(li.getAttribute("data-supply-key") || "");
          if (!key) return;
          state.expandedSupplies[key] = !state.expandedSupplies[key];
          renderResults();
        });
      }
    );
    Array.prototype.forEach.call(
      box.querySelectorAll(".ofd-status-hist-toggle"),
      function (btn) {
        btn.addEventListener("click", function (event) {
          event.preventDefault();
          event.stopPropagation();
          const key = String(btn.getAttribute("data-hist-key") || "");
          if (!key) return;
          state.expandedStatusHistory[key] = !state.expandedStatusHistory[key];
          renderResults();
        });
      }
    );
    const moreEl = document.getElementById("ofdLoadMoreBtn");
    if (moreEl) moreEl.addEventListener("click", onLoadMore);
    renderStatusBanner();
  }

  async function onLoadMore() {
    if (state.loadingMore || state.loadingItems || !state.hasMore) return;
    const step = Math.max(1, Number(state.loadMoreDays) || 10);
    state.extraDays = Math.max(0, Number(state.extraDays) || 0) + step;
    state.loadingMore = true;
    renderResults();
    try {
      await loadCargo(state.vehicleNumber, { soft: true, keepExtra: true });
    } finally {
      state.loadingMore = false;
      renderResults();
    }
  }

  async function loadCargo(value, opts) {
    const soft = !!(opts && opts.soft);
    const keepExtra = !!(opts && opts.keepExtra);
    const plate = String(value || "").trim();
    state.vehicleNumber = plate;
    state.softRefresh = soft;
    if (!soft) {
      state.items = [];
      state.errors = [];
      state.expandedSupplies = {};
      state.expandedStatusHistory = {};
      if (!keepExtra) {
        state.extraDays = 0;
        state.hasMore = false;
      }
    }
    renderResults();
    if (!plate) {
      state.softRefresh = false;
      return;
    }
    state.loadingItems = true;
    renderResults();
    try {
      const params = new URLSearchParams({ vehicle_number: plate });
      const extra = Math.max(0, Number(state.extraDays) || 0);
      if (extra > 0) params.set("extra_days", String(extra));
      let path;
      if (isPinMode) {
        path =
          "/api/ozon-fbs/driver/p/" +
          encodeURIComponent(pageToken) +
          "/cargo-places?" +
          params.toString();
      } else {
        path = "/api/ozon-fbs/driver/cargo-places?" + params.toString();
      }
      const data = await api(path);
      state.items = Array.isArray(data.items) ? data.items : [];
      state.supplies = Array.isArray(data.supplies) ? data.supplies : [];
      state.errors = Array.isArray(data.errors) ? data.errors : [];
      state.hasMore = data.has_more === true;
      if (data.load_more_days != null) {
        const n = Number(data.load_more_days);
        if (Number.isFinite(n) && n > 0) state.loadMoreDays = n;
      }
      if (data.extra_days != null) {
        const n = Number(data.extra_days);
        if (Number.isFinite(n) && n >= 0) state.extraDays = n;
      }
    } catch (err) {
      if (!soft) state.items = [];
      state.errors = [String(err.message || err)];
      toast(err.message || "Не удалось загрузить грузоместа");
    } finally {
      state.loadingItems = false;
      state.softRefresh = false;
      renderResults();
    }
  }

  async function onVehicleChange(event) {
    await loadCargo(event.target.value);
  }

  function maybeAutoloadSinglePlate() {
    if (state.plates.length === 1) {
      const number = String(state.plates[0].number || "").trim();
      if (number) loadCargo(number);
    }
  }

  async function loadPlates() {
    state.loadingPlates = true;
    renderShell();
    try {
      const data = await api("/api/ozon-fbs/driver/vehicles");
      state.plates = Array.isArray(data.items) ? data.items : [];
    } catch (err) {
      state.plates = [];
      toast(err.message || "Не удалось загрузить номера");
    } finally {
      state.loadingPlates = false;
      renderShell();
      renderResults();
      maybeAutoloadSinglePlate();
    }
  }

  function init() {
    if (!main) return;
    if (isPinMode) {
      if (!pageToken) {
        renderDenied();
        return;
      }
      renderPinForm("");
      return;
    }
    if (!boot.can_view) {
      renderDenied();
      return;
    }
    loadPlates();
  }

  init();
})();
